#!/usr/bin/env python3
"""ClaudeNewtra -- giris noktasi.

Kullanim:
    python3 main.py                    # varsayilan port 7801
    PORT=7801 NEWTRADE_DATA_DIR=/yol python3 main.py

GUVENLIK: acilista bot KAPALI baslar (eski sistemdeki dogru davranis
korundu). Kullanici Stratejiler sayfasindan bilerek acmali.
"""
from __future__ import annotations

import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.bot import trade_loop, watcher
from app.bot.scheduler import register_job, start_all_jobs
from app.config import paths
from app.config.settings import (load_settings, save_settings,
    list_orphan_settings, check_scalp_target_order, DEAD_SETTINGS)
from app.core.applog import get_logger, setup_logging
from app.market.rank_repository import verify_schema_contract
from app.notify.telegram_client import send_message
from app.notify.telegram_commands import start_command_poller
from app.web.routes import register_all_routes
from app.web.server import create_http_server, run_http_server

VARSAYILAN_PORT = 7801
_log = get_logger("main")


# Acilis denetimleri: sema uyumu, olu ayarlar, tutarsizliklar.
def run_startup_checks() -> dict:
    a = load_settings()
    sonuc = {"olu_ayar": list_orphan_settings(a), "sema": None, "uyari": []}
    try:
        sonuc["sema"] = verify_schema_contract()
        if not sonuc["sema"]["uyumlu"]:
            _log.error("SEMA AYRISMASI -- eksik sutun: %s", sonuc["sema"]["eksik"])
    except Exception as e:
        _log.error("rank.sqlite okunamadi: %s  (hermes-rank calisiyor mu?)", e)
    if sonuc["olu_ayar"]:
        # YAPAY ZEKA MIMO (24.09.2026): oluleri acilista dosyadan da temizle --
        # save_settings tarafinda da var, ama dosya hic kaydedilmezse uyari
        # her acilista tekrar ediyordu (derin inceleme orta).
        _log.warning("hicbir modulun okumadigi ayar(lar): %s",
                     ", ".join(sonuc["olu_ayar"]))
        try:
            ham = read_json_file(get_settings_path(), {}) if False else None
            # settings modulu zaten load/save yonetiyor; dogrudan dosyayi temizle
            import json as _json
            from pathlib import Path as _Path
            ayar_yol = _Path(os.environ.get("NEWTRADE_DATA_DIR") or "") / "ayar.json"
            if not ayar_yol.exists():
                # get_settings_path fallback
                from app.config.settings import get_settings_path as _gsp
                ayar_yol = _Path(_gsp())
            if ayar_yol.exists():
                ham = _json.loads(ayar_yol.read_text(encoding="utf-8"))
                for k in list(ham):
                    if k in DEAD_SETTINGS:
                        ham.pop(k, None)
                ayar_yol.write_text(_json.dumps(ham, ensure_ascii=False, indent=2),
                                    encoding="utf-8")
                _log.info("olu ayarlar otomatik temizlendi (YAPAY ZEKA MIMO)")
        except Exception as e:
            _log.warning("olu ayar temizligi atlandi: %s", e)
    u = check_scalp_target_order(a)
    if u:
        sonuc["uyari"].append(u)
        _log.warning(u)
    return sonuc


# Arka plan islerini kaydeder -- HEPSI TEK LISTEDE.
# Eski sistemde `takipci` tanimliydi ama baslatilmayi unutulmustu; burada
# kayit listesi disinda bir is BASLATILAMAZ, kayitlilar da acilista loglanir.
def register_all_jobs() -> None:
    register_job("bot_turu", 5.0,
                 lambda: trade_loop.run_bot_cycle(load_settings,
                     on_closed=pozisyon_kapandi_bildir),
                 description="giris dener + acik pozisyonlari yonetir")
    register_job("fiyat_takip", 2.0, watcher.run_price_watch_loop,
                 description="acik pozisyonlarin sembollerine abone olur (BESLER, karar vermez)")
    register_job("borsa_senkron", 60.0, _borsa_senkron,
                 description="emir durumlari + elle satilmislari uzlastir")


# Borsa senkronu HER IKI DEFTER icin calisir.
#
# 23.09.2026 HATA (Ismail: "al dedim, aldi gozukuyor; aldi madem takibe
# almasi lazim, takibe almiyor"):
# burada `live = bool(a.get("bot_canli"))` yaziyordu -- yani senkron
# YALNIZCA botun o anki moduna ait defteri tariyordu. Bot kagit modda
# oldugu icin kullanicinin ELLE actigi CANLI emir hicbir zaman kontrol
# edilmiyor, borsada DOLMUS olmasina ragmen defterde `durum: ACIK`
# kaliyor ve "takip" listesine hic gecmiyordu.
#
# Olculdu: Binance'de acik emir 0, hesapta 536.7 SAGA duruyordu; defter
# ise hala `dolan_miktar: 0, borsa_durum: NEW` diyordu.
#
# `run_bot_cycle` ayni hatayi tasiyordu ve duzeltilmisti (bkz. 7.11);
# bu is atlanmis. Emir durumu takibi BOTUN MODUNDAN BAGIMSIZDIR:
# hangi defterde acik emir varsa o kontrol edilmeli.
# YAPAY ZEKA MIMO (24.09.2026): pozisyon kapaninca Telegram'a bildir.
# Derin inceleme yuksek oncelik #1: close_position(on_closed=...) sarmalayacisi
# VARDI ama hicbir cagri yeri baglanmamisti -- stop/hedef/elle kapatmada
# Telegram'a mesaj hic gitmiyordu.
def pozisyon_kapandi_bildir(kapanan: dict) -> None:
    from app.config.settings import load_settings as _ls
    from app.notify.telegram_client import is_telegram_configured, send_message
    a = _ls()
    if not is_telegram_configured(a):
        return
    kar = kapanan.get("kar_p")
    sebep = (kapanan.get("kapanis") or {}).get("sebep") or "?"
    try:
        kar_s = f"{kar:+.2f}%" if kar is not None else "?"
        send_message(a, f"KAPANDI {kapanan.get('sembol')}: {kar_s} ({sebep})")
    except Exception:
        pass  # bildirim hatasi emir yolunu bozmamali


def _borsa_senkron() -> None:
    from app.market.price_source import get_prices
    from app.trading.ledger import list_open_orders
    from app.trading.reconcile import sync_with_exchange
    a = load_settings()
    for live in (True, False):
        acik = list_open_orders(live)
        # KAGIT: acik emir yoksa yapilacak is yok.
        # CANLI: acik emir olsa da OLMASA da senkron + takibe alma
        # (adopt_untracked_holdings) calismali -- borsadaki varliklar
        # defterde hic yer almamis olabilir.
        if not acik and not live:
            continue
        fiyatlar = get_prices([p["sembol"] for p in acik]) if acik else {}
        sync_with_exchange(live, prices=fiyatlar,
                           commission_pct=float(a.get("komisyon_toplam", 0)),
                           timeout_minutes=float(a.get("emir_asim_dk", 6)))


# Katmanlari kurar ve birbirine baglar.
def build_application(port: int) -> object:
    setup_logging(logging.INFO)
    _log.info("ClaudeNewtra basliyor -- veri koku: %s", paths.get_app_root())

    # GUVENLIK: her acilista bot KAPALI baslar.
    a = load_settings()
    if a.get("bot_acik"):
        save_settings({"bot_acik": False})
        _log.info("guvenlik: bot KAPALI baslatildi (panelden acilmali)")

    run_startup_checks()
    try:
        from app.exchange.binance_rest import sync_exchange_clock, sync_rate_limits
        sync_rate_limits()
        sync_exchange_clock()
    except Exception as e:
        _log.warning("borsa acilis senkronu yapilamadi: %s", e)
    n = register_all_routes()
    _log.info("%d uc kaydedildi", n)
    register_all_jobs()
    start_all_jobs()

    if a.get("telegram_token") and a.get("telegram_chat"):
        start_command_poller(load_settings,
                             live_getter=lambda: bool(load_settings().get("bot_canli")),
                             on_settings_change=lambda d: save_settings(d))
        _log.info("telegram dinleyicisi basladi (yalniz kayitli chat yetkili)")

    return create_http_server(port, paths.get_static_dir())


def main() -> int:
    port = int(os.environ.get("PORT") or VARSAYILAN_PORT)
    try:
        sunucu = build_application(port)
    except OSError as e:
        _log.error("baslatilamadi: %s", e)
        return 1
    run_http_server(sunucu)
    return 0


if __name__ == "__main__":
    sys.exit(main())
