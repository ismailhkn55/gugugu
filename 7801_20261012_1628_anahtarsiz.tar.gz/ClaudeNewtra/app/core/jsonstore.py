"""JSON ve JSONL dosyalarina TEK okuma/yazma noktasi.

Eski sistemde `_oku` UC modulde (`sunucu.py`, `strateji.py`, `wsizle.py`),
`_yaz` IKI modulde ayri ayri yaziliydi ve davranislari birbirinden farkliydi
(biri hatayi yutuyor, biri logluyordu). Burada tek tanim var.
"""
import json
import os
import tempfile
from typing import Any, Iterator

from app.core.applog import get_logger

_log = get_logger(__name__)


# JSON dosyasini guvenle okur; yoksa ya da bozuksa varsayilani doner.
def read_json_file(path: str, default: Any) -> Any:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as e:
        _log.warning("bozuk/okunamayan JSON, varsayilan kullaniliyor: %s (%s)", path, e)
        return default


# JSON'u ATOMIK yazar: gecici dosyaya yaz, fsync, sonra yerine tasi.
# Boylece yazma yarida kesilse bile dosya hicbir zaman yarim kalmaz.
def write_json_file(path: str, data: Any, *, mode: int = 0o644, indent: int = 2) -> None:
    dizin = os.path.dirname(path) or "."
    os.makedirs(dizin, exist_ok=True)
    fd, gecici = tempfile.mkstemp(dir=dizin, prefix=".tmp-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=indent)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(gecici, mode)
        os.replace(gecici, path)
    except BaseException:
        try:
            os.unlink(gecici)
        except OSError:
            pass
        raise


# JSONL dosyasina tek satir ekler (sembol basina gunluk/tick arsivleri).
def append_jsonl_record(path: str, record: Any) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


# JSONL dosyasini satir satir okur; bozuk satiri atlar, dosyayi cokertmez.
def read_jsonl_records(path: str, *, limit: int | None = None) -> Iterator[Any]:
    try:
        with open(path, encoding="utf-8") as f:
            for i, satir in enumerate(f):
                if limit is not None and i >= limit:
                    return
                satir = satir.strip()
                if not satir:
                    continue
                try:
                    yield json.loads(satir)
                except ValueError:
                    continue
    except FileNotFoundError:
        return
