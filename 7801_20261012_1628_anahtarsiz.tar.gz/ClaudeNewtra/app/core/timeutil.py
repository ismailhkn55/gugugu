"""Zaman yardimcilari. Tum zaman damgalari epoch MILISANIYE."""
import time

MS = 1000
DAKIKA_MS = 60 * MS
SAAT_MS = 60 * DAKIKA_MS
GUN_MS = 24 * SAAT_MS


# Simdiki zaman, epoch milisaniye.
def now_ms() -> int:
    return int(time.time() * MS)


