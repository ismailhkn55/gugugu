"""Defter kilidi ve kilit icinde ag cagrisi yasagi.

ESKI SISTEMDEKI IKI KUSUR:

1. Kilit YANLIS KAPSAMDA idi: okuma kilidin DISINDA, yazma ICINDE yapiliyordu.
   `takipci` defteri okuyor, `bot_turu` `stop_guncel`'i (kilitlenmis kari)
   yaziyor, sonra `takipci` elindeki ESKI kopyayi geri yazip o kilidi
   SILIYORDU. Ayni desen `_emir_kontrol_defter`, `borsa_senkron` ve iki POST
   ucunda da vardi.

2. Kilit tutulurken AG CAGRISI yapiliyordu: `emir_iptal` `with KILIT:` icinde
   15 saniye zaman asimli bir Binance DELETE cagrisi yapiyor, o sure boyunca
   tum defter yazimi bloke oluyordu.

Burada `ledger_lock()` oku-degistir-yaz'in TAMAMINI sarar ve kilit icindeyken
ag cagrisi denenirse hata firlatir.
"""
import threading
from contextlib import contextmanager

from app.core.errors import AppError

_KILIT = threading.RLock()
_yerel = threading.local()


# Defter kilidi: oku-degistir-yaz blogunun TAMAMINI sarmak icin kullanilir.
@contextmanager
def ledger_lock():
    with _KILIT:
        onceki = getattr(_yerel, "in_lock", False)
        _yerel.in_lock = True
        try:
            yield
        finally:
            _yerel.in_lock = onceki


# Su an kilit tutuluyor mu (ag katmani bunu sorar).
def is_holding_lock() -> bool:
    return getattr(_yerel, "in_lock", False)


# Kilit icinde ag cagrisi yapilmaya calisilirsa hata firlatir.
# `binance_rest` her istekten once bunu cagirir.
def assert_no_network_in_lock(what: str = "ag cagrisi") -> None:
    if is_holding_lock():
        raise AppError(
            f"kilit tutulurken {what} yapilamaz -- defter yazimini bloke eder "
            "(eski sistemde emir_iptal tam olarak bunu yapiyordu)")
