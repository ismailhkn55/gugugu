"""Uygulamanin kendi hata turleri.

Neden ayri bir dosya: eski sistemde neredeyse her cagri `except Exception: pass`
ile sarilmisti. Binance coktugunde, saat kaydiginda ya da bir strateji alani
bulunamadiginda sistem sessizce yanlis veriyle calismaya devam ediyordu.
Burada her hata sinifinin AYRI bir anlami var, boylece cagiran taraf
"yutulabilir" ile "yutulamaz"i ayirt edebiliyor.
"""


class AppError(Exception):
    """Tum uygulama hatalarinin atasi."""


class UnknownFieldError(AppError):
    """Strateji kurali var olmayan bir alani istedi.

    ESKI DAVRANIS (22.09.2026 `ema7`, hala acik olan `ema4`): `_alan_oku`
    alani bulamayinca `None` donuyor, `_kural_gecti` bunu sessizce `False`'a
    ceviriyordu. Kural HIC atesmiyor, hata da vermiyordu -- `rsi`, `ema4` ve
    `iz_yon` aylarca boyle kayboldu. Artik gurultu cikariyor.
    """

    def __init__(self, field: str, known: tuple[str, ...] = ()):
        self.field = field
        self.known = known
        super().__init__(f"bilinmeyen alan: {field!r}")


class ExchangeError(AppError):
    """Binance bir hata dondurdu; kodu ve govdesi tasinir.

    Eski `bcek` HTTPError'i hic yakalamiyordu, bu yuzden Binance'in kendi
    kodu (-2010 yetersiz bakiye, -1013 filtre hatasi, -1021 zaman damgasi)
    hicbir zaman gorulmuyor, log'a yalnizca "HTTP Error 400" dusuyordu.
    """

    def __init__(self, message: str, *, code: int | None = None,
                 http_status: int | None = None, payload: str = ""):
        self.code = code
        self.http_status = http_status
        self.payload = payload
        super().__init__(message)


class RateLimitError(ExchangeError):
    """429/418 -- kac saniye beklenmesi gerektigi `retry_after` ile gelir."""

    def __init__(self, message: str, *, retry_after: float = 1.0, **kw):
        self.retry_after = retry_after
        super().__init__(message, **kw)


class OrderRejectedError(ExchangeError):
    """Emir borsa tarafindan reddedildi -- yeniden denenmemeli."""


class LedgerConflictError(AppError):
    """Defter beklenmedik sekilde degismis.

    Ornegin kapatilmak uzere olan pozisyon, kilit alinana kadar baska bir
    is parcacigi tarafindan kapatilmis olabilir. Eski sistemde bu kontrol
    hic yoktu ve ayni pozisyon icin IKI MARKET SELL gonderilebiliyordu.
    """
