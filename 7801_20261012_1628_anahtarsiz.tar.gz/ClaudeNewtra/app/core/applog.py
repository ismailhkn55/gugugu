"""Log kurulumu.

Eski `sunucu.log` icinde 750 traceback vardi ve HICBIRI uygulama mantigi
degildi: 348 x "Address already in use", 172 x ConnectionResetError,
47 x BrokenPipeError -- istemci baglantiyi kapatinca cevap yazimi patliyordu.
Bu gurultu gercek hatalari gorunmez kiliyordu. Burada tekrarlayan ayni hata
sayilir, bir kez basilir.
"""
import collections
import logging
import sys

_SAYAC: collections.Counter = collections.Counter()
_KURULDU = False


# Log bicimini ve hedefini kurar; birden fazla cagrilsa da bir kez calisir.
def setup_logging(level: int = logging.INFO, stream=None) -> None:
    global _KURULDU
    if _KURULDU:
        return
    h = logging.StreamHandler(stream or sys.stdout)
    h.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)-24s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"))
    kok = logging.getLogger()
    kok.handlers[:] = [h]
    kok.setLevel(level)
    _KURULDU = True


# Modul adina bagli logger doner.
def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


# Ayni mesaji tekrar tekrar basmaz; N'inci tekrarda toplam sayiyi bildirir.
def log_once(logger: logging.Logger, key: str, message: str,
             *, level: int = logging.WARNING, every: int = 100) -> None:
    _SAYAC[key] += 1
    n = _SAYAC[key]
    if n == 1:
        logger.log(level, message)
    elif n % every == 0:
        logger.log(level, "%s  (bu hata %d kez tekrarlandi)", message, n)


