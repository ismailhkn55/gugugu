"""Tum dosya yollari TEK yerden turer.

Veri koku `NEWTRADE_DATA_DIR` ortam degiskeninden okunur. Boylece ayni kod
hem gercek dizinde hem de fark testi icin acilan KOPYA dizinde calisabilir --
eski sistemde yol `sunucu.py` icinde sabit yaziliydi ve test icin dosyayi
`sed` ile degistirmek gerekiyordu.
"""
import os

VARSAYILAN_VERI_KOKU = "/DATA/AppData/Newtrade"
VARSAYILAN_RANK_KOKU = "/DATA/AppData/rank"


# Veri koku: defterler, ayarlar, gunluk ve tick arsivleri burada.
def get_app_root() -> str:
    return os.environ.get("NEWTRADE_DATA_DIR", VARSAYILAN_VERI_KOKU)


# rank.sqlite ve panel_ayar.json'un bulundugu dizin (ayri servis yazar).
def get_rank_root() -> str:
    return os.environ.get("NEWTRADE_RANK_DIR", VARSAYILAN_RANK_KOKU)


# Defter yolu. `live` ZORUNLU -- varsayilandan ASLA turetilmez.
# Eski `defter_yolu(canli=None)` ayar["canli"]'ya dusuyordu ve SIFIRLA
# butonu bu yuzden gercek para defterini siliyordu (174 kayit).
def get_ledger_path(live: bool) -> str:
    if not isinstance(live, bool):
        raise TypeError("get_ledger_path: `live` acikca True/False verilmeli")
    ad = "defter_canli.json" if live else "defter_dry.json"
    return os.path.join(get_app_root(), ad)


# Binance API anahtarinin dosyasi (izin 0600, klasor 0700).
def get_secrets_path() -> str:
    return os.path.join(get_app_root(), "gizli", "binance.json")


# Panel ayarlari.
def get_settings_path() -> str:
    return os.path.join(get_app_root(), "ayar.json")


# Kayitli stratejiler.
def get_strategies_path() -> str:
    return os.path.join(get_app_root(), "stratejiler.json")


# Kullanici notlari.
def get_notes_path() -> str:
    return os.path.join(get_app_root(), "notlar.json")


# Borsa-defter uzlastirma gunlugu.
def get_reconcile_log_path() -> str:
    return os.path.join(get_app_root(), "uzlastirma_gunlugu.json")


# Sembol basina gunluk tur arsivi (gunluk/<SEMBOL>.jsonl).
def get_journal_dir() -> str:
    return os.path.join(get_app_root(), "gunluk")


# Heatmap endeks/akis snapshot durumu (YAPAY ZEKA MIMO).
def get_heatmap_state_path() -> str:
    return os.path.join(get_app_root(), "heatmap_durum.json")


# Sembol basina ham tick arsivi (tickler/<SEMBOL>.jsonl).
def get_tick_dir() -> str:
    return os.path.join(get_app_root(), "tickler")


# rank.sqlite -- SALT OKUNUR acilir, bu uygulama asla yazmaz.
def get_rank_db_path() -> str:
    return os.path.join(get_rank_root(), "rank.sqlite")


# Haric tutulan coinlerin listesi (rank servisiyle paylasilir).
def get_panel_config_path() -> str:
    return os.path.join(get_rank_root(), "panel_ayar.json")


# Tarayiciya servis edilen TEK dizin. Disinda hicbir sey verilmez --
# eski sistem veri kokunu oldugu gibi servis ettigi icin
# /gizli/binance.json tarayicidan HTTP 200 donuyordu.
def get_static_dir() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "web", "static")
