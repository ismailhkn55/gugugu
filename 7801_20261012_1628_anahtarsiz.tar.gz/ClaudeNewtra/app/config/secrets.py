"""Binance API anahtari.

ESKI DAVRANIS: `anahtar_al()` HER imzali istekte dosyayi diskten okuyup JSON
parse ediyordu. Bot 5 saniyede bir onlarca imzali cagri yaptigi icin bu,
saniyede birkac gereksiz disk okumasi demekti. Burada bellekte onbelleklenir
ve dosyanin degisme zamani izlenir.

GUVENLIK: dosya 0600, klasor 0700. Anahtar HICBIR ZAMAN HTTP cevabina
konmaz -- disariya yalnizca "bagli mi" bilgisi verilir.
"""
import os

from app.config.paths import get_secrets_path
from app.core.applog import get_logger
from app.core.jsonstore import read_json_file, write_json_file

_log = get_logger(__name__)
_onbellek: dict = {"mtime": None, "veri": None}


# Anahtari okur; dosya degismediyse bellekten verir.
def load_api_credentials() -> dict | None:
    yol = get_secrets_path()
    try:
        mtime = os.path.getmtime(yol)
    except OSError:
        _onbellek.update(mtime=None, veri=None)
        return None
    if _onbellek["mtime"] == mtime and _onbellek["veri"]:
        return _onbellek["veri"]
    d = read_json_file(yol, None)
    if not isinstance(d, dict) or not d.get("key") or not d.get("secret"):
        _onbellek.update(mtime=None, veri=None)
        return None
    _onbellek.update(mtime=mtime, veri=d)
    return d


# Anahtari 0600 izniyle yazar ve onbellegi bosaltir.
def save_api_credentials(key: str, secret: str) -> None:
    key, secret = (key or "").strip(), (secret or "").strip()
    if not key or not secret:
        raise ValueError("key ve secret bos olamaz")
    yol = get_secrets_path()
    os.makedirs(os.path.dirname(yol), exist_ok=True)
    os.chmod(os.path.dirname(yol), 0o700)
    write_json_file(yol, {"key": key, "secret": secret}, mode=0o600, indent=0)
    _onbellek.update(mtime=None, veri=None)
    _log.info("API anahtari kaydedildi (izin 0600)")


# Anahtari siler. Cagiran taraf ayrica canli modu kapatmalidir.
def delete_api_credentials() -> bool:
    _onbellek.update(mtime=None, veri=None)
    try:
        os.remove(get_secrets_path())
        _log.info("API anahtari silindi")
        return True
    except FileNotFoundError:
        return False


# Anahtar var mi -- emir uclarinin on kosulu (yoksa 409 donulur).
def has_api_credentials() -> bool:
    return load_api_credentials() is not None
