"""Not uclari."""
from __future__ import annotations

from app.config.paths import get_notes_path
from app.core.jsonstore import read_json_file, write_json_file
from app.core.timeutil import now_ms


def _oku() -> dict:
    d = read_json_file(get_notes_path(), {"notlar": []}) or {}
    d.setdefault("notlar", [])
    return d


# GET /yerel/notlar
def handle_notes_read(req):
    return 200, _oku()


# POST /yerel/notlar -- ekle / duzenle / sil.
def handle_notes_write(req):
    g = req["body"] or {}
    d = _oku()
    if g.get("sil") is not None:
        d["notlar"] = [n for n in d["notlar"] if n.get("id") != g["sil"]]
    elif g.get("id"):
        for n in d["notlar"]:
            if n.get("id") == g["id"]:
                n.update(baslik=g.get("baslik", n.get("baslik")),
                         icerik=g.get("icerik", n.get("icerik")), guncelleme=now_ms())
                break
    else:
        d["notlar"].insert(0, {"id": now_ms(), "baslik": g.get("baslik") or "",
                               "icerik": g.get("icerik") or "", "guncelleme": now_ms()})
    write_json_file(get_notes_path(), d)
    return 200, {"ok": True, **d}
