"""Rapor uclari: pnl, cuzdan, gecmis, isabet."""
from __future__ import annotations

from app.config.settings import load_settings
from app.reporting import accuracy as AC, pnl as PNL
from app.trading import ledger as LD, wallet as WL
from app.web.router import query_int, query_live


# GET /yerel/pnl
def handle_pnl(req):
    a = load_settings()
    p = req["params"]
    live = query_live(p, bool(a.get("canli")))
    # `sadece=el|bot`: cuzdan yalnizca ELLE acilanlari, bot sayfasi yalnizca
    # botunkileri sayar -- iki dunya ayri (bkz. 7.16).
    sadece = (p.get("sadece") or [None])[0] if isinstance(p.get("sadece"), list) else p.get("sadece")
    if sadece not in ("el", "bot"):
        sadece = None
    d = PNL.build_daily_pnl(live, query_int(p, "gun", 14), sadece=sadece)
    d["istatistik"] = WL.compute_ledger_stats(live, sadece=sadece)
    d["sadece"] = sadece
    return 200, d


# GET /yerel/bakiye -- GERCEK ve KAGIT cuzdan BIRLIKTE doner.
#
# Eskiden yalnizca aktif modun cuzdanini donuyordu; kagit modda gercek
# bakiye ve elde tutulan coinler hic gorunmuyordu (bkz. get_wallet_overview).
def handle_balance(req):
    return 200, WL.get_wallet_overview(load_settings())


# GET /yerel/bot-cuzdan
def handle_paper_wallet(req):
    return 200, WL.get_paper_wallet(load_settings())


# GET /yerel/gercek-cuzdan
def handle_live_wallet(req):
    c = WL.get_live_wallet()
    return (200, c) if c is not None else (502, {"hata": "Binance'e ulasilamadi"})


# GET /yerel/gecmis -- kapanmis emirler. `kaynak` HANGI DEFTER oldugunu belirler;
# istatistik de AYNI defterden gelir (eski sistem burada aktif modun
# defterini okuyup `kaynak=dry` istense bile CANLI istatistik donuyordu).
def handle_trade_history(req):
    a = load_settings()
    live = query_live(req["params"], bool(a.get("canli")))
    n = query_int(req["params"], "n", 100)
    gecmis = LD.list_closed_orders(live, limit=n)
    return 200, {"gecmis": gecmis, "sayi": len(gecmis),
                 "kaynak": "canli" if live else "dry",
                 "istatistik": WL.compute_ledger_stats(live)}


# GET /yerel/isabet
def handle_accuracy(req):
    return 200, AC.measure_signal_accuracy(
        lookahead_rows=query_int(req["params"], "ileri", 12),
        target_pct=float(req["params"].get("hedef") or 2.0))


