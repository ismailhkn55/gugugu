"""Strateji uclari."""
from __future__ import annotations

from app.config.settings import load_settings
from app.core.errors import UnknownFieldError
from app.market.indicators import field_meanings, list_available_fields
from app.strategy import registry as REG
from app.strategy.backtest import summarize_backtest_gaps
from app.strategy.rule_engine import OPERATORS
from app.web.router import query_live


# GET /yerel/strateji
def handle_strategy_list(req):
    d = REG.list_strategies()
    for s in d["stratejiler"]:
        s["_dogrulama"] = REG.validate_strategy(s)
        s["_calisan_kurallar"] = REG.stamp_measurement_context(s)
        s["_geriye_test"] = summarize_backtest_gaps(s)
    return 200, {**d, "alanlar": list(list_available_fields()),
                 "operatorler": list(OPERATORS), "aciklamalar": field_meanings()}


# POST /yerel/strateji -- kaydet / sil / aktif yap.
def handle_strategy_command(req):
    g = req["body"] or {}
    a = load_settings()
    if g.get("sil"):
        return 200, {"ok": REG.delete_strategy(g["sil"])}
    # Satir switch'i: {anahtar: {"ad": "...", "acik": true/false}}
    anahtar = g.get("anahtar")
    if isinstance(anahtar, dict):
        ad = anahtar.get("ad")
        if not ad:
            return 400, {"hata": "anahtar.ad gerekli"}
        ok, mesaj = REG.toggle_strategy(ad, bool(anahtar.get("acik")))
        if not ok:
            return 409, {"ok": False, "hata": mesaj, "mesaj": mesaj, "ad": ad}
        return 200, {"ok": True, "mesaj": mesaj, "ad": ad}
    if g.get("aktif_yap"):
        live = bool(g["canli"]) if "canli" in g else bool(a.get("bot_canli"))
        ok = REG.set_active_strategy(g["aktif_yap"], live=live)
        hata = None if ok else (f"'{g['aktif_yap']}' kapali -- once AC"
                                if not ok else None)
        return (200 if ok else 404), {"ok": ok, "canli": live, "hata": hata}
    st = g.get("strateji")
    if not st:
        return 400, {"hata": "strateji gerekli"}
    try:
        return 200, {"ok": True, **REG.save_strategy(st)}
    except UnknownFieldError as e:
        return 400, {"hata": str(e), "sorunlar": REG.validate_strategy(st)}


