"""Bot, durum, telegram ve uzlastirma uclari."""
from __future__ import annotations

from app.config.paths import get_reconcile_log_path
from app.config.secrets import has_api_credentials
from app.config.settings import load_settings, save_settings
from app.core.jsonstore import read_json_file
from app.exchange.binance_ws import STREAM
from app.market.price_source import get_prices
from app.notify.telegram_client import is_telegram_configured, send_message
from app.reporting.stats import compute_today_profit
from app.strategy.registry import get_active_strategy
from app.trading import ledger as LD, reconcile as RC
from app.bot.scheduler import list_running_jobs
from app.bot.trade_loop import get_bot_state
from app.web.router import list_routes, query_live


# GET /yerel/bot -- bot ozeti + CALISAN ISLER (eski sistemde bu gorunmuyordu,
# bu yuzden `takipci`'nin hic baslatilmadigi aylarca fark edilmedi).
def handle_bot_status(req):
    a = load_settings()
    live = bool(a.get("bot_canli"))
    st = get_active_strategy(live=live)
    return 200, {
        "bot_acik": bool(a.get("bot_acik")), "bot_canli": live,
        "canli": bool(a.get("canli")), "anahtar_var": has_api_credentials(),
        "strateji": st.get("ad"),
        "acik_pozisyon": len(LD.list_open_orders(live)),
        "bugun_kar_p": compute_today_profit(live),
        "durum": get_bot_state(),
        "isler": list_running_jobs(),
        "websocket": STREAM.get_stream_status(),
        "telegram": {"tanimli": is_telegram_configured(a)},
    }


# POST /yerel/bot -- eski sistemde TEK ucta BES farkli is yapiliyordu;
# burada islerin hepsi ayri ayri adlandirildi ve dogrulaniyor.
def handle_bot_command(req):
    g = req["body"] or {}
    a = load_settings()
    if "acik" in g:
        yeni, _r = save_settings({"bot_acik": bool(g["acik"])})
        return 200, {"ok": True, "bot_acik": yeni["bot_acik"]}
    if "bot_canli" in g:
        if g["bot_canli"] and not has_api_credentials():
            return 409, {"hata": "API anahtari yok -- bot canli moda alinamaz"}
        yeni, _r = save_settings({"bot_canli": bool(g["bot_canli"])})
        return 200, {"ok": True, "bot_canli": yeni["bot_canli"]}
    if g.get("sifirla"):
        # HER ZAMAN kagit defter. Eski sistemde `canli` argumani verilmedigi
        # icin bu dal GERCEK defteri siliyordu.
        return 200, {"ok": True, **LD.reset_ledger(False)}
    if g.get("cuzdan_sifirla"):
        r = LD.reset_ledger(False)
        yeni, _x = save_settings({"kagit_bakiye": float(
            g.get("bakiye") or a.get("kagit_bakiye", 30.0))})
        return 200, {"ok": True, "bakiye": yeni["kagit_bakiye"], **r}
    return 400, {"hata": "bilinmeyen bot komutu"}


# GET /yerel/durum -- eski panelin sade durum ucu.
def handle_legacy_status(req):
    a = load_settings()
    live = query_live(req["params"], bool(a.get("canli")))
    acik = LD.list_open_orders(live)
    return 200, {"canli": bool(a.get("canli")), "anahtar_var": has_api_credentials(),
                 "tutar": a.get("tutar"), "kar_al": a.get("kar_al"), "stop": a.get("stop"),
                 "acik_emir": sum(1 for p in acik if p.get("durum") == "ACIK"),
                 "takip": sum(1 for p in acik if p.get("durum") in ("DOLDU", "KISMI")),
                 "kaynak": "canli" if live else "dry"}


# GET /yerel/surum -- statik dosyanin surum damgasi.
def handle_app_version(req):
    import os
    from app.config.paths import get_static_dir
    yol = os.path.join(get_static_dir(), "index.html")
    try:
        return 200, {"surum": int(os.path.getmtime(yol))}
    except OSError:
        return 200, {"surum": 0}


# GET /yerel/saglik -- YENI: neyin calistigi tek bakista.
def handle_health(req):
    from app.exchange.binance_rest import (get_clock_skew_ms, get_request_counts,
                                           get_used_weight)
    from app.market.rank_repository import verify_schema_contract
    return 200, {
        "isler": list_running_jobs(),
        "websocket": STREAM.get_stream_status(),
        "binance": {"agirlik_1dk": get_used_weight(), "saat_farki_ms": get_clock_skew_ms(),
                    "cagrilar": get_request_counts()},
        "sema": verify_schema_contract(),
        "uclar": len(list_routes()),
    }


# GET /yerel/uclar -- kayitli tum uclar (dokumantasyon).
def handle_route_list(req):
    return 200, {"uclar": list_routes()}


# POST /yerel/telegram
def handle_telegram_config(req):
    g = req["body"] or {}
    if g.get("sil"):
        yeni, _r = save_settings({"telegram_token": "", "telegram_chat": ""})
        return 200, {"ok": True, "tanimli": False}
    yeni, _r = save_settings({k: v for k, v in
                              (("telegram_token", g.get("token")),
                               ("telegram_chat", g.get("chat"))) if v})
    return 200, {"ok": True, "tanimli": is_telegram_configured(yeni)}


# POST /yerel/telegram-mesaj
def handle_telegram_send(req):
    mesaj = (req["body"] or {}).get("mesaj")
    if not mesaj:
        return 400, {"hata": "mesaj gerekli"}
    return 200, {"ok": send_message(load_settings(), str(mesaj))}


# POST /yerel/uzlastir-simdi
def handle_reconcile_now(req):
    # YAPAY ZEKA MIMO (24.09.2026): holdings cift cekimi kaldirildi.
    # Derin inceleme: burada + reconcile_positions icinde iki kez
    # fetch_exchange_holdings() cagriliyordu; simdi bir kez alinir.
    a = load_settings()
    acik = LD.list_open_orders(True)
    semboller = {p["sembol"] for p in acik}
    holdings = {}
    try:
        holdings = RC.fetch_exchange_holdings()
        semboller |= set(holdings)
    except Exception:
        pass
    fiyatlar = get_prices(list(semboller)) if semboller else {}
    sonuc = RC.reconcile_positions(True, prices=fiyatlar,
                                   commission_pct=float(a.get("komisyon_toplam", 0)),
                                   holdings=holdings or None)
    return 200, sonuc


# GET /yerel/uzlastirma-gunlugu
def handle_reconcile_log(req):
    return 200, read_json_file(get_reconcile_log_path(), {"kayitlar": []})
