"""Ayar ve anahtar uclari."""
from __future__ import annotations

from app.config import secrets as SEC, settings as CFG
from app.core.errors import ExchangeError


def _maskele(a: dict) -> dict:
    """Token'i disariya HIC vermeyiz; yalnizca 'tanimli mi' bilgisi gider."""
    d = dict(a)
    if d.get("telegram_token"):
        d["telegram_token"] = "***"
    return d


# GET /yerel/ayar -- sema ile birlikte (arayuz etiketleri buradan uretilir).
def handle_settings_read(req):
    a = CFG.load_settings()
    sema = [{"anahtar": s.key, "etiket": s.label, "tip": s.kind.__name__,
             "varsayilan": s.default, "okuyan": s.reader,
             "degistirilebilir": s.editable}
            for s in CFG.SETTING_SCHEMA]
    return 200, {"ayar": _maskele(a), "sema": sema,
                 "olu_ayarlar": CFG.list_orphan_settings(a),
                 "uyari": CFG.check_scalp_target_order(a),
                 "anahtar_var": SEC.has_api_credentials()}


# POST /yerel/ayar -- sema disi anahtar REDDEDILIR.
#
# BOT MODU ILE PANEL MODU AYRIDIR (Ismail, 23.09.2026: "bottaki canli ve
# dry run ile ayarlardaki canli ve dryrun ayri islemler"). Olculdu: panel
# canliya alininca `bot_canli` degismiyor -- DOGRU davranis, cunku
# "ben acar isem bot canliya gecmeli", kendiliginden degil.
#
# TEK BAGLANTI su yonde: panel DRY RUN'a donerse bot da kagida cekilir --
# panel kagit derken botun gercek para harcamasi kabul edilemez. Acik
# pozisyonlar bundan ETKILENMEZ; `run_bot_cycle` her iki defteri de
# yonetmeye devam eder ve her pozisyon KENDI defterinin kurallariyla
# kapanir.
def handle_settings_write(req):
    g = dict(req["body"] or {})
    if g.get("canli") and not SEC.has_api_credentials():
        return 409, {"hata": "API anahtari yok -- canli mod acilamaz"}
    bot_kagida_alindi = False
    if "canli" in g and not g["canli"]:
        if bool(CFG.load_settings().get("bot_canli")):
            g["bot_canli"] = False
            bot_kagida_alindi = True
    yeni, reddedilen = CFG.save_settings(g)
    return 200, {"ok": True, "ayar": _maskele(yeni), "reddedilen": reddedilen,
                 "bot_kagida_alindi": bot_kagida_alindi}


# POST /yerel/anahtar -- kaydet veya sil. Anahtar ASLA geri donmez.
def handle_credentials_write(req):
    g = req["body"] or {}
    if g.get("sil"):
        silindi = SEC.delete_api_credentials()
        CFG.save_settings({"canli": False})      # anahtar yoksa canli mod kapanir
        return 200, {"ok": True, "silindi": silindi, "anahtar_var": False}
    key, secret = (g.get("key") or "").strip(), (g.get("secret") or "").strip()
    if not key or not secret:
        return 400, {"hata": "key ve secret gerekli"}
    SEC.save_api_credentials(key, secret)
    try:
        from app.exchange.binance_rest import fetch_account_balances
        fetch_account_balances()
    except ExchangeError as e:
        SEC.delete_api_credentials()
        return 400, {"hata": f"anahtar dogrulanamadi: {e}"}
    return 200, {"ok": True, "anahtar_var": True}
