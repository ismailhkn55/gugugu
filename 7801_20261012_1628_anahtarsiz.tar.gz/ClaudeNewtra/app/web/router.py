"""Yol -> isleyici TABLOSU.

Eski sistemde 39 uc, iki dev `if/elif` zincirindeydi: `do_GET` 615 satir,
`do_POST` 330 satir -- toplam 945 satir. `do_GET`'in %60'i tek bir ucun
(`/yerel/gecmis-sinyal`) icine gomulu 365 satirlik geriye-test motoruydu.
Sorgu ayristirma idiom'u ALTI kez kopyalanmisti.

Burada uclar bir tabloda; isleyiciler ayri dosyalarda; ayristirma tek yerde.
"""
from __future__ import annotations

import json
import urllib.parse
from dataclasses import dataclass
from typing import Any, Callable

from app.core.applog import get_logger

_log = get_logger(__name__)


@dataclass(frozen=True)
class Route:
    """Tek bir uc: yontem + yol + isleyici + aciklama."""
    method: str
    path: str
    handler: Callable
    description: str = ""


ROUTE_TABLE: dict[tuple[str, str], Route] = {}


# Uc kaydi. Ayni (yontem, yol) iki kez kaydedilemez.
def register_route(method: str, path: str, handler: Callable,
                   description: str = "") -> Route:
    anahtar = (method.upper(), path)
    if anahtar in ROUTE_TABLE:
        raise ValueError(f"uc zaten kayitli: {method} {path}")
    ROUTE_TABLE[anahtar] = Route(method.upper(), path, handler, description)
    return ROUTE_TABLE[anahtar]


# Gelen istegi isleyiciye esler.
def resolve_route(method: str, path: str) -> Route | None:
    return ROUTE_TABLE.get((method.upper(), path.split("?")[0]))


# Kayitli tum uclar (dokumantasyon ve saglik ucu icin).
def list_routes() -> list[dict]:
    return sorted(({"yontem": r.method, "yol": r.path, "aciklama": r.description}
                   for r in ROUTE_TABLE.values()),
                  key=lambda x: (x["yol"], x["yontem"]))


# Sorgu dizesini cozer -- eski sistemde ALTI yere kopyalanmis idiom.
def parse_query_params(path: str) -> dict[str, str]:
    if "?" not in path:
        return {}
    return {k: v[0] for k, v in urllib.parse.parse_qs(path.split("?", 1)[1]).items()}


# Sorgu parametresini tipli okur.
def query_int(params: dict, key: str, default: int) -> int:
    try:
        return int(params.get(key, default))
    except (TypeError, ValueError):
        return default


# "canli"/"dry" parametresini bool'a cevirir. Verilmemisse `default` doner.
# ASLA ayar["canli"]'ya dusmez -- B1'in kokü o desendi.
def query_live(params: dict, default: bool) -> bool:
    k = (params.get("kaynak") or "").strip().lower()
    if k == "canli":
        return True
    if k in ("dry", "kagit"):
        return False
    return default


# POST govdesini JSON olarak okur.
def read_json_body(raw: bytes) -> dict:
    if not raw:
        return {}
    try:
        d = json.loads(raw.decode("utf-8"))
        return d if isinstance(d, dict) else {}
    except (ValueError, UnicodeDecodeError):
        return {}
