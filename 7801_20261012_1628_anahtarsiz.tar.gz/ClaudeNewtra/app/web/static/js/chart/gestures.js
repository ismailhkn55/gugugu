// chart/gestures.js -- grafik uzerinde dokunma ve fare hareketleri.
//
// ESKI SISTEMDEKI KIRILGANLIK (F13): `#grafCanli{touch-action:none}` native
// kaydirmayi TAMAMEN kapatiyordu; dikey modda sayfa TEK SATIRLIK bir JS ile
// kaydiriliyordu (`scrollTop -=`). Momentum yoktu, `closest(".sayfa")` null
// donerse kaydirma SESSIZCE hic calismiyordu ve 4 mini grafik bu kodu
// paylasmadigi icin davranislari farkliydi.
//
// Yeni: dikey modda CSS `touch-action: pan-y` (bkz. 99-duzeltme.css) --
// DIKEY kaydirma tarayiciya birakilir. JS yalnizca YATAY suruklemeyi ve
// IKI PARMAK yakinlastirmayi isler.
import { applyZoom, clampCandleWidth, getCandleWidth, getScrollX, maxScrollX,
         setCandleWidth, setScrollX, setPriceLock, getPriceLock } from "./zoom.js";
import { getChartScale } from "./renderer.js";

const YON_ESIK = 5;     // yon kilidi icin gereken piksel

// Grafik kutusuna hareketleri baglar. `yenidenCiz` her degisimde cagrilir.
export function attachChartGestures(kutuId, yenidenCiz) {
  const kap = document.getElementById(kutuId);
  if (!kap || kap.dataset.hareketBagli === "1") return () => {};
  kap.dataset.hareketBagli = "1";
  const kontrol = new AbortController();
  const s = { signal: kontrol.signal, passive: false };

  let surukle = null;     // {x, kaydir}
  let pinch = null;       // {mesafe, genislik, dikey}
  let yonKilit = null;    // "x" | "y" | null

  const mesafe = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  const dikeyMesafe = (t) => Math.abs(t[0].clientY - t[1].clientY);
  const yatayMesafe = (t) => Math.abs(t[0].clientX - t[1].clientX);

  // Kaydirma tavani `zoom.maxScrollX` ile AYNI olmali; eskiden burada
  // ayri bir formul vardi ve sag bosluk hesaba katilmiyordu.
  const maksKaydir = () => {
    const o = getChartScale(kutuId);
    return o ? maxScrollX(o.toplam, kap.clientWidth) : 0;
  };

  // --- fare ---
  kap.addEventListener("wheel", (e) => {
    if (!e.ctrlKey && Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
      e.preventDefault();
      setScrollX(getScrollX() + e.deltaX, maksKaydir());
      yenidenCiz();
      return;
    }
    e.preventDefault();
    applyZoom(e.deltaY < 0 ? 1.12 : 1 / 1.12);
    setScrollX(getScrollX(), maksKaydir());
    yenidenCiz();
  }, s);

  kap.addEventListener("mousedown", (e) => {
    surukle = { x: e.clientX, kaydir: getScrollX() };
    kap.classList.add("suruklu");
  }, s);
  window.addEventListener("mousemove", (e) => {
    if (!surukle) return;
    setScrollX(surukle.kaydir - (e.clientX - surukle.x), maksKaydir());
    yenidenCiz();
  }, s);
  window.addEventListener("mouseup", () => {
    surukle = null;
    kap.classList.remove("suruklu");
  }, s);

  // --- dokunma ---
  kap.addEventListener("touchstart", (e) => {
    if (e.touches.length === 2) {
      pinch = { yatay: yatayMesafe(e.touches), dikey: dikeyMesafe(e.touches),
                genislik: getCandleWidth(), kilit: getPriceLock(),
                olcek: getChartScale(kutuId) };
      surukle = null;
      e.preventDefault();
    } else if (e.touches.length === 1) {
      surukle = { x: e.touches[0].clientX, y: e.touches[0].clientY, kaydir: getScrollX() };
      yonKilit = null;
    }
  }, s);

  kap.addEventListener("touchmove", (e) => {
    if (pinch && e.touches.length === 2) {
      e.preventDefault();
      // Yatay pinch -> mum genisligi. `hypot` DEGIL sadece |dx|:
      // saf dikey pinch yatayi da yakinlastirmasin (eski kodun dogru karari).
      const yeniYatay = yatayMesafe(e.touches);
      if (pinch.yatay > 12) {
        setCandleWidth(clampCandleWidth(pinch.genislik * (yeniYatay / pinch.yatay)));
      }
      // Dikey pinch -> fiyat ekseni kilidi.
      const yeniDikey = dikeyMesafe(e.touches);
      const o = pinch.olcek;
      if (o && pinch.dikey > 12) {
        const oran = yeniDikey / pinch.dikey;
        const orta = (o.en + o.az) / 2;
        const yariAra = (o.ara / 2) / Math.max(0.2, oran);
        setPriceLock({ en: orta + yariAra, az: orta - yariAra });
      }
      setScrollX(getScrollX(), maksKaydir());
      yenidenCiz();
      return;
    }
    if (!surukle || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - surukle.x;
    const dy = e.touches[0].clientY - surukle.y;
    if (!yonKilit) {
      if (Math.abs(dx) < YON_ESIK && Math.abs(dy) < YON_ESIK) return;
      yonKilit = Math.abs(dx) > Math.abs(dy) ? "x" : "y";
    }
    if (yonKilit === "y") return;        // DIKEY: tarayiciya birak (pan-y)
    e.preventDefault();
    setScrollX(surukle.kaydir - dx, maksKaydir());
    yenidenCiz();
  }, s);

  const bitir = () => { pinch = null; surukle = null; yonKilit = null; };
  kap.addEventListener("touchend", bitir, s);
  kap.addEventListener("touchcancel", bitir, s);

  // Tarayici jestlerini (iOS) engelle.
  for (const olay of ["gesturestart", "gesturechange", "gestureend"]) {
    kap.addEventListener(olay, (e) => e.preventDefault(), s);
  }

  // Dinleyiciler TOPLU iptal edilebilir -- eski `limitTutamacBagla`
  // her cagrida window'a dinleyici ekliyor ve HIC kaldirmiyordu (F7).
  return () => { kontrol.abort(); delete kap.dataset.hareketBagli; };
}
