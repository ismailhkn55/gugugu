// chart/zoom.js -- yakinlastirma durumu ve SINIRLAR.
//
// ESKI SISTEMDEKI CELISKI (F3): `MUM_GENISLIK_MIN=2, MAX=22` diye sinirlar
// tanimliydi ama `btnSon25` `MAX*4` (=88) kullaniyor, `btnTumu` 0.02'ye
// kadar iniyordu; `zoomUygula` ve pinch ise 22/2'ye klempliyordu. Sonuc:
// "50M" ya da "TUMU"ya bastiktan sonra ILK pinch/+/- hareketinde grafik
// aniden 22'ye (ya da 2'ye) SICRIYORDU.
//
// Burada TEK sinir kumesi var ve TUM yazicilar `clampCandleWidth`'ten gecer.
export const ZOOM_LIMITS = { min: 0.5, max: 88, varsayilan: 8 };

// Fiyat ekseni icin sagda AYRILAN genislik (piksel).
//
// 23.09.2026, Ismail: "trade'de 5m'de sagda fiyatlar var ya, yukari dogru
// kaldir, orasi ekrani kucultuyor."
// Eskiden 52 piksellik bir SUTUN ayriliyordu ve mumlar oraya hic
// girmiyordu; telefon yatayda orta sutun zaten dar oldugu icin bu
// ciddi kayipti. Artik etiketler grafigin sag kenarina BINDIRILIYOR
// (gercek borsa grafiklerindeki gibi), ayrilan sutun yok.
// Son mumun etiketlerin altinda kalmamasi `BOSLUK_MUM` ile saglanir.
export const SAG_EKSEN_PX = 0;

// Son mumdan SONRA birakilan bos mum yeri.
//
// 23.09.2026, Ismail: "trade ekraninda son mumu gostermesi lazim ayrica
// son mumdan sonra 3 4 mum kadar bos alan koy".
// OLCULDU: `scrollToEnd` kaydirma tavanini `toplam*gen - kapGenislik`
// olarak hesapliyordu, yani fiyat ekseninin kapladigi 52 pikseli HESABA
// KATMIYORDU. Sona kaydirildiginda son mumun merkezi `W - gen/2`'ye
// dusuyor ve eksenin ALTINDA kaliyordu -- son mum hic gorunmuyordu.
// Artik tavan kullanilabilir genislige gore hesaplanir ve uzerine
// BOSLUK_MUM kadar nefes payi eklenir.
export const BOSLUK_MUM = 3;

// Mumlarin cizilebildigi gercek genislik (fiyat ekseni haric).
const kullanilabilir = (kapGenislik) => Math.max(10, (kapGenislik || 0) - SAG_EKSEN_PX);

let _genislik = ZOOM_LIMITS.varsayilan;
let _kaydir = 0;              // yatay kaydirma (piksel)
let _fiyatKilit = null;       // {en, az} -- dikey pinch ile kilitlenmisse

// Mum genisligini tek ve ortak sinir kumesine oturtur.
export function clampCandleWidth(v) {
  const f = Number(v);
  if (!Number.isFinite(f)) return _genislik;
  return Math.min(ZOOM_LIMITS.max, Math.max(ZOOM_LIMITS.min, f));
}

// Gecerli mum genisligi (piksel).
export const getCandleWidth = () => _genislik;

// Mum genisligini sinirlar icinde yazar.
export function setCandleWidth(v) {
  _genislik = clampCandleWidth(v);
  return _genislik;
}

// Mum genisligini carpanla olceklendirir.  (eski: zoomUygula)
export function applyZoom(carpan) {
  return setCandleWidth(_genislik * carpan);
}

// Son N mumu ekrana sigdirir ve SONA kaydirir.
//
// HATA (23.09.2026, ilk cizimde yakalandi): burada `setScrollX(Infinity)`
// cagiriyordum; ust sinir verilmedigi icin kaydirma 1e9'a gidiyor ve TUM
// mumlar ekranin disinda kaliyordu -- grafik bos gorunuyordu. Sona
// kaydirmak icin toplam mum sayisi GEREKLI.  (eski: btnSon25)
// Son N mumu ekrana sigdirip en sona kaydirir.
//
// HATA (28.09.2026, Ismail: "128m mumu 128 mum mu gosteriyor"): genislik
// SADECE `n`e gore ayarlaniyordu (`kullanilabilir/n`), ama `scrollToEnd`
// en sona kaydirirken sag tarafa `BOSLUK_MUM` (3 mum) kadar nefes payi
// da ekliyordu -- bu pay AYNI n-mumluk genislik butcesinden CALINIYORDU.
// Olcum: "128M" tiklaninca ekranda GERCEKTE 125 mum vardi (128 degil),
// "50M" 47 gosteriyordu. Duzeltme: `fitAllCandles` ile AYNI desen --
// genislik `n + BOSLUK_MUM`e gore ayarlanir, boylece nefes payi n'in
// USTUNE eklenir, n'in İÇİNDEN cikmaz. Playwright ile dogrulandi: 128M
// sonrasi tam gorunen govde sayisi 128.
export function fitRecentCandles(n, kapGenislik, toplam) {
  if (!n || !kapGenislik) return _genislik;
  setCandleWidth(kullanilabilir(kapGenislik) / (n + BOSLUK_MUM));
  scrollToEnd(toplam ?? n, kapGenislik);
  return _genislik;
}

// Tum mumlari ekrana sigdirir.  (eski: btnTumu)
export function fitAllCandles(toplam, kapGenislik) {
  if (!toplam || !kapGenislik) return _genislik;
  setCandleWidth(kullanilabilir(kapGenislik) / (toplam + BOSLUK_MUM));
  setScrollX(0);
  return _genislik;
}

// En sagda (en yeni mumda) durur.
export function scrollToEnd(toplam, kapGenislik) {
  const maks = maxScrollX(toplam, kapGenislik);
  return setScrollX(maks, maks);
}

// Verilen toplam mum ve kap genisligine gore azami kaydirma.
export function maxScrollX(toplam, kapGenislik) {
  return Math.max(0, (toplam + BOSLUK_MUM) * _genislik - kullanilabilir(kapGenislik));
}

// Zoom, kaydirma ve fiyat kilidini varsayilana dondurur.  (eski: mumGenislikSifirla)
export function resetCandleWidth() {
  _genislik = ZOOM_LIMITS.varsayilan;
  _kaydir = 0;
  _fiyatKilit = null;
  return _genislik;
}

// Yatay kaydirma konumu (piksel).  (eski: anaXAl)
export const getScrollX = () => _kaydir;

// Yatay kaydirmayi ust sinira kadar yazar.  (eski: anaXAyarla)
export function setScrollX(v, maks = Infinity) {
  _kaydir = Math.max(0, Math.min(Number.isFinite(maks) ? maks : 1e9, v));
  return _kaydir;
}

// Dikey pinch ile kilitlenmis fiyat araligi (yoksa null).
export const getPriceLock = () => _fiyatKilit;
// Fiyat eksenini verilen araliga kilitler.
export const setPriceLock = (v) => { _fiyatKilit = v; };
// Fiyat ekseni kilidini kaldirir, otomatik sigdirmaya doner.
export const clearPriceLock = () => { _fiyatKilit = null; };
