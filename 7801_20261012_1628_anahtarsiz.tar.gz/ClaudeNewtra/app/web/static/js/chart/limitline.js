// chart/limitline.js -- suruklenebilir limit fiyat cizgisi.
//
// ESKI SISTEM (F7): `limitTutamacBagla` her cagrida `window`'a `mousemove`
// ve `mouseup` dinleyicisi ekliyor, HICBIRINI kaldirmiyordu -- her tutamac
// baglanmasinda yeni bir global dinleyici birikiyordu.
// Burada tum dinleyiciler tek `AbortController`'a bagli.
import { formatPrice } from "../format.js";
import { getChartScale, renderPriceLine } from "./renderer.js";

let _acik = false;
let _fiyat = null;
let _elle = false;       // kullanici surukledi mi
// 26.09.2026: cizginin TAVANI. Anlik fiyatin en fazla `_ustYuzde` % ustu.
// Ismail: "mumun ucu sariya degmiyordu -- switch acikken cizgi mumun
// %0.4'ten fazla ustune cikmasin" (ayar: limit_ust_yuzde).
let _anlik = null;
let _ustYuzde = 0.4;
let _kontrol = null;

// LIMIT anahtari acik mi.
export const isLimitOpen = () => _acik;
// Secili limit fiyati.
export const getLimitPrice = () => _fiyat;

// Limit fiyatini yazar.
export function setLimitPrice(v, { elle = false } = {}) {
  _fiyat = v == null ? null : +v;
  const tavan = getLimitCeiling();
  if (_fiyat != null && tavan != null && _fiyat > tavan) _fiyat = tavan;
  if (elle) _elle = true;
  return _fiyat;
}

// Tavan yuzdesini ayardan alir (limit_ust_yuzde).
export function setLimitCapPercent(p) {
  const v = +p;
  if (Number.isFinite(v) && v >= 0) _ustYuzde = v;
}

// Cizginin cikabilecegi en yuksek fiyat; anlik fiyat bilinmiyorsa null.
export function getLimitCeiling() {
  return _anlik > 0 ? _anlik * (1 + _ustYuzde / 100) : null;
}

// Limit cizgisini kapatir ve fiyati sifirlar.
export function resetLimit() { _fiyat = null; _elle = false; }

// Kullanici cizgiye DOKUNMADIYSA limit fiyatini anlik fiyata tasir.
//
// 23.09.2026, Ismail: "ben ekrana dokunmadigim surece fiyat cizgisi son
// mumun hareketini takip edecekti".
// `_elle` bayragi ilk yazimdan beri VARDI ama HICBIR YERDE OKUNMUYORDU:
// cizgi ilk kuruldugu fiyatta cakili kaliyordu. Olculdu: fiyat
// 0.05107 -> 0.0509 giderken limit 0.05108'de sabit kaldi.
// Kullanici cizgiyi surukler ya da kaydiriciyi oynatirsa `_elle` true
// olur ve takip DURUR -- elle konan fiyat websocket'le ezilmemeli.
export function followPrice(fiyat, kaydiriciId) {
  if (fiyat > 0) _anlik = +fiyat;
  // Elle konan cizgi, fiyat dusunce tavanin USTUNDE kalmasin.
  if (_acik && _elle && _fiyat != null) {
    const tavan = getLimitCeiling();
    if (tavan != null && _fiyat > tavan) {
      _fiyat = tavan;
      const k = kaydiriciId && document.getElementById(kaydiriciId);
      if (k) k.value = _fiyat;
      return true;
    }
  }
  if (!_acik || _elle || fiyat == null || !(fiyat > 0)) return false;
  _fiyat = +fiyat;
  const k = kaydiriciId && document.getElementById(kaydiriciId);
  if (k) {
    // Aralik disina tasarsa aralik da kaydirilir.
    if (_fiyat < +k.min || _fiyat > +k.max) {
      const [az, en] = getLimitRange(_fiyat);
      k.min = az; k.max = en; k.step = (en - az) / 1000;
    }
    k.value = _fiyat;
  }
  return true;
}

// Piksel <-> fiyat donusumu (son cizim olceginden).  (eski: limitPikselFiyat)
export function limitPixelToPrice(kutuId, clientY) {
  const o = getChartScale(kutuId);
  const kap = document.getElementById(kutuId);
  if (!o || !kap) return null;
  const r = kap.getBoundingClientRect();
  const yy = clientY - r.top;
  return o.en - ((yy - o.ustKenar) / o.anaYuk) * o.ara;
}

// Limit fiyatini grafikteki piksel yuksekligine cevirir.  (eski: limitFiyatPiksel)
export function limitPriceToPixel(kutuId, fiyat) {
  const o = getChartScale(kutuId);
  return o ? o.yOf(fiyat) : null;
}

// Cizgiyi cizer (ust katman -- mum katmani guncellenince silinmez).  (eski: limitCizgiCiz)
export function renderLimitLine(kutuId) {
  // Ham sayi yazilirsa kaydiricidan gelen deger tum ondaliklariyla
  // gorunuyordu (Ismail: "fiyatta ki kusurat cok fazla").
  renderPriceLine(kutuId, _acik ? _fiyat : null, "limitCizgi",
                  _acik && _fiyat != null ? `LIMIT ${formatPrice(_fiyat)}` : null);
}

// Kaydiriciyi mevcut fiyat araligina gore tazeler.  (eski: limitKaydiriciTazele)
//
// 23.09.2026 HATA: burada `getChartScale(kutuId)` okunup "olcek yoksa
// don" diye erken cikiliyordu -- ama olcek govdede HIC KULLANILMIYORDU.
// Mum verisi yuklendiginde grafik henuz cizilmemis oluyor, olcek null
// donuyor ve fonksiyon hicbir sey yapmadan cikiyordu; dolayisiyla
// `_fiyat` ilk 30 saniye boyunca null kaliyor, kullanici LIMIT anahtarini
// acsa bile yatay cizgi CIZILMIYORDU. Olculdu: anahtar acik, kaydirici
// gorunur, ust katman BOS (0 oge). Gereksiz bagimlilik kaldirildi.
export function refreshLimitSlider(kutuId, kaydiriciId, anlikFiyat) {
  if (anlikFiyat > 0) _anlik = +anlikFiyat;   // tavan hesabi icin
  const k = document.getElementById(kaydiriciId);
  if (!k) return;
  const [az, en] = getLimitRange(anlikFiyat);
  k.min = az; k.max = en;
  k.step = (en - az) / 1000;
  if (_fiyat == null) _fiyat = anlikFiyat ?? (az + en) / 2;
  if (_fiyat > en) _fiyat = en;                 // tavanin ustunde kalmasin
  k.value = _fiyat;
}

// Kaydirici araligi: anlik fiyatin +/- %8'i.  (eski: limitKaydiriciAralik)
export function getLimitRange(anlikFiyat) {
  const f = anlikFiyat || 1;
  // ust sinir: tavan (anlik + limit_ust_yuzde), alt: %8 asagi
  return [f * 0.92, f * (1 + _ustYuzde / 100)];
}

// Tutamaci ve kaydiriciyi baglar. Iptal fonksiyonu doner.  (eski: limitTutamacBagla)
export function attachLimitHandle(kutuId, { switchId, kaydiriciId, onChange }) {
  _kontrol?.abort();
  _kontrol = new AbortController();
  const s = { signal: _kontrol.signal };
  const kap = document.getElementById(kutuId);
  const anahtar = document.getElementById(switchId);
  const kaydirici = document.getElementById(kaydiriciId);

  anahtar?.addEventListener("change", () => {
    _acik = !!anahtar.checked;
    // Emniyet: fiyat hic kurulmadiysa kaydiricinin degerinden baslat,
    // boylece anahtar acilir acilmaz cizgi GORUNUR.
    if (_acik && _fiyat == null && kaydirici) _fiyat = +kaydirici.value || null;
    // Anahtar her acilista TAKIP moduna doner: kullanici surukleyene
    // kadar cizgi son mumu izler.
    if (_acik) _elle = false;
    document.getElementById("limitSwitchKutu")?.classList.toggle("acik", _acik);
    // KAYDIRICI GORUNURLUGU: CSS `.limitKaydirici.acik` kuralini bekliyor
    // (`display:none` varsayilan). Eskiden burada yalnizca `hidden`
    // niteligi degistiriliyordu -- CSS onu hic dinlemedigi icin cubuk
    // HICBIR ZAMAN gorunmuyordu (Ismail: "sagindaki yukari asagi kaydirma
    // cubugu vardi, o da yok"). Olculdu: display=none, genislik 0.
    // Bot modu dugmelerindeki `aktif`/`se` karisikligiyla ayni sinif.
    if (kaydirici) {
      kaydirici.classList.toggle("acik", _acik);
      kaydirici.hidden = !_acik;
    }
    onChange?.(_acik ? _fiyat : null);
  }, s);

  kaydirici?.addEventListener("input", () => {
    setLimitPrice(+kaydirici.value, { elle: true });
    onChange?.(_fiyat);
  }, s);

  // Cizgiyi grafik uzerinde surukle.
  let suruklu = false;
  kap?.addEventListener("pointerdown", (e) => {
    if (!_acik) return;
    const y = limitPriceToPixel(kutuId, _fiyat);
    const r = kap.getBoundingClientRect();
    if (y == null || Math.abs(e.clientY - r.top - y) > 10) return;
    suruklu = true;
    kap.setPointerCapture?.(e.pointerId);
    e.preventDefault();
  }, s);
  kap?.addEventListener("pointermove", (e) => {
    if (!suruklu) return;
    const f = limitPixelToPrice(kutuId, e.clientY);
    if (f != null) {
      const v = setLimitPrice(f, { elle: true });   // tavana kirpilmis deger
      if (kaydirici) kaydirici.value = v;
      onChange?.(v);
    }
  }, s);
  kap?.addEventListener("pointerup", () => { suruklu = false; }, s);

  return () => _kontrol?.abort();
}
