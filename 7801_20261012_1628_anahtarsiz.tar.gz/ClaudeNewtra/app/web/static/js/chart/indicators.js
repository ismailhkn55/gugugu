// chart/indicators.js -- EKRAN icin gosterge hesaplari (saf fonksiyonlar).
//
// NOT: bunlar YALNIZCA cizim icindir. KARAR veren gostergeler sunucuda
// (`app/market/indicators.py`) ve onlarin toplayiciyla birebir esitligi
// olculmustur (15/15). Burada tekrar yazilmis olmalari bir ayrisma degil:
// tarayici, sunucuya her mum icin sormadan cizgi cizebilmek zorunda.

// Ustel hareketli ortalama (EMA) serisi.
export function ema(v, n) {
  if (!v?.length || n <= 0) return [];
  const k = 2 / (n + 1);
  const o = [v[0]];
  for (let i = 1; i < v.length; i++) o.push(v[i] * k + o[i - 1] * (1 - k));
  return o;
}

// Basit hareketli ortalama (SMA) serisi.
export function sma(v, n) {
  const o = [];
  let t = 0;
  for (let i = 0; i < v.length; i++) {
    t += v[i];
    if (i >= n) t -= v[i - n];
    o.push(i >= n - 1 ? t / n : null);
  }
  return o;
}

// Goreli guc endeksi (RSI) serisi.
export function rsi(v, n = 14) {
  const o = new Array(v.length).fill(null);
  if (v.length < n + 1) return o;
  let k = 0, z = 0;
  for (let i = 1; i <= n; i++) {
    const d = v[i] - v[i - 1];
    if (d > 0) k += d; else z -= d;
  }
  k /= n; z /= n;
  o[n] = z < 1e-12 ? 100 : 100 - 100 / (1 + k / z);
  for (let i = n + 1; i < v.length; i++) {
    const d = v[i] - v[i - 1];
    k = (k * (n - 1) + Math.max(d, 0)) / n;
    z = (z * (n - 1) + Math.max(-d, 0)) / n;
    o[i] = z < 1e-12 ? 100 : 100 - 100 / (1 + k / z);
  }
  return o;
}

// Bollinger bantlari: ust, orta ve alt seri.
export function bollinger(v, n = 20, carpan = 2) {
  const orta = sma(v, n);
  const ust = [], alt = [];
  for (let i = 0; i < v.length; i++) {
    if (orta[i] == null) { ust.push(null); alt.push(null); continue; }
    let s = 0;
    for (let j = i - n + 1; j <= i; j++) s += (v[j] - orta[i]) ** 2;
    const sd = Math.sqrt(s / n);
    ust.push(orta[i] + carpan * sd);
    alt.push(orta[i] - carpan * sd);
  }
  return { orta, ust, alt };
}

// Hacim agirlikli ortalama fiyat (VWAP) serisi.
export function vwap(mumlar) {
  let pv = 0, hv = 0;
  return mumlar.map((m) => {
    const tp = (m.y + m.d + m.k) / 3;
    pv += tp * m.h; hv += m.h;
    return hv > 0 ? pv / hv : null;
  });
}

// Denge hacmi (OBV) serisi.
export function obv(mumlar) {
  const o = [0];
  for (let i = 1; i < mumlar.length; i++) {
    const d = mumlar[i].k - mumlar[i - 1].k;
    o.push(o[i - 1] + (d > 0 ? mumlar[i].h : d < 0 ? -mumlar[i].h : 0));
  }
  return o;
}

// Ortalama gercek aralik (ATR) serisi.
export function atr(mumlar, n = 14) {
  const o = new Array(mumlar.length).fill(null);
  if (mumlar.length < n + 1) return o;
  const tr = [];
  for (let i = 1; i < mumlar.length; i++) {
    const m = mumlar[i], p = mumlar[i - 1].k;
    tr.push(Math.max(m.y - m.d, Math.abs(m.y - p), Math.abs(m.d - p)));
  }
  let a = tr.slice(0, n).reduce((x, y) => x + y, 0) / n;
  o[n] = a;
  for (let i = n; i < tr.length; i++) { a = (a * (n - 1) + tr[i]) / n; o[i + 1] = a; }
  return o;
}

// Heikin Ashi -- yol bagimlidir, verilen diliminin TAMAMINDAN kurulur.
export function heikinAshi(mumlar) {
  const o = [];
  for (let i = 0; i < mumlar.length; i++) {
    const m = mumlar[i];
    const kp = (m.a + m.y + m.d + m.k) / 4;
    const ac = i === 0 ? (m.a + m.k) / 2 : (o[i - 1].a + o[i - 1].k) / 2;
    o.push({ t: m.t, a: ac, y: Math.max(m.y, ac, kp), d: Math.min(m.d, ac, kp), k: kp, h: m.h });
  }
  return o;
}

// CCI(n) -- YALNIZ SON deger (tam seri gerekmiyor, mini-gosterge seridi
// icin). `market/indicators.py`'nin `compute_cci`'siyle AYNI formul:
// TP=(H+L+C)/3, son n TP'nin ortalamasi + ortalama mutlak sapmasi.
export function cciSon(mumlar, n = 20) {
  if (mumlar.length < n) return null;
  const tp = mumlar.slice(-n).map((m) => (m.y + m.d + m.k) / 3);
  const ort = tp.reduce((a, b) => a + b, 0) / n;
  const sapma = tp.reduce((a, b) => a + Math.abs(b - ort), 0) / n;
  return sapma > 1e-12 ? (tp[n - 1] - ort) / (0.015 * sapma) : 0;
}

// Binance kline dizisini {t,a,y,d,k,h} nesnelerine cevirir.
export function klineCevir(ham) {
  return (ham || []).map((m) => ({
    t: +m[0], a: +m[1], y: +m[2], d: +m[3], k: +m[4], h: +m[5],
  }));
}
