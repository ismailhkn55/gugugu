// wallet.js -- CUZDAN: GERCEK Binance bakiyesi, pozisyonlar, kapanmis islemler.
//
// 23.09.2026, Ismail: "cuzdan canli modda da olsa dry run da da olsa
// gercek degeri ve mevcut coinlerimizi gosterecek ... dry run da bile
// olsak ben binanceden coin alir isem cuzdanda onu takip edecek".
//
// Onceki davranis: sayfa aktif moda bakip `kaynak=dry` ya da `kaynak=canli`
// istiyordu; kagit modda GERCEK bakiye ve elde tutulan coinler hic
// gorunmuyordu. Artik bu sayfa HER ZAMAN gercek parayi gosterir; kagit
// (bot) tarafi BOT sayfasinda durur.
import { apiGet, apiPost } from "../api.js";
import { askConfirm } from "../ui/confirm.js";
import { showToast } from "../ui/toast.js";
import { formatPrice, formatSigned, formatUsdt } from "../format.js";
import { registerPoll, refreshNow, sharePollResult } from "../poll.js";
import { getState, setState } from "../store.js";
import { renderClosedTrades, renderPositionTable,
         updatePositionPrices } from "../ui/positionTable.js";
import { createSocketManager } from "../live/socketManager.js";
import { navigateToPage } from "../ui/shell.js";
import { openMethodPicker, baglaYontemKapat } from "../ui/methodPicker.js";
import { openSymbol } from "./trade.js";

let _kuruldu = false;
let _soket = null;
const _fiyatlar = {};   // sembol -> son websocket fiyati

// Kar/zarar egrisi (SVG).  (eski: egriCiz)
export function renderPnlCurve(seri) {
  const e = document.getElementById("pnlEgri");
  if (!e) return;
  if (!seri?.length) { e.innerHTML = ""; return; }
  const v = seri.map((x) => x.birikim);
  const en = Math.max(...v, 0), az = Math.min(...v, 0), a = Math.max(1e-9, en - az);
  const n = v.length;
  const nokta = v.map((x, i) =>
    `${(i / Math.max(1, n - 1) * 300).toFixed(1)},${(52 - (x - az) / a * 44).toFixed(1)}`).join(" ");
  const sifir = (52 - (0 - az) / a * 44).toFixed(1);
  e.innerHTML = `<svg viewBox="0 0 300 58" preserveAspectRatio="none">
    <line x1="0" y1="${sifir}" x2="300" y2="${sifir}" stroke="currentColor" opacity=".25"/>
    <polyline points="${nokta}" fill="none" stroke="currentColor" stroke-width="1.6"
      class="${v.at(-1) >= 0 ? "arti" : "eksi"}"/></svg>`;
}

// Borsadaki varliklari (coin listesi) cizer.
function varliklariCiz(gercek, hata) {
  const p = document.getElementById("bakParalar");
  if (!p) return;
  if (!gercek) {
    p.innerHTML = `<div class="kucuk eksi">${hata || "gercek cuzdan okunamadi"}</div>`;
    return;
  }
  // YAPAY ZEKA MIMO (24.09.2026): gosterim esigi 1.0 USDT (adopt TOZ_ESIGI ile hizali).
  // Once 0.01 idi; 0.01-1.0 arasi varliklar listelenip asla takibe alinmiyordu.
  const para = (gercek.para || []).filter((x) => (x.usdt ?? 0) >= 1.0 || x.para === "USDT");
  // 26.09.2026, Ismail: "hizali olsun, tablo gibi". Sabit sutunlar (CSS grid,
  // .paraSatir) + baslik satiri. BUGUN % = COININ bugunku degisimi (senin
  // kar/zararin DEGIL).
  const baslik = `<div class="paraSatir paraBaslik"><span>COIN</span><span>MIKTAR</span>`
    + `<span title="coinin bugunku degisimi (UTC gun acilisina gore) -- senin kar/zararin degil">BUGUN %</span>`
    + `<span>USDT</span></div>`;
  p.innerHTML = para.length
    ? baslik + // YAPAY ZEKA MIMO (24.09.2026): 14 varlik siniri kaldirildi
        // (derin inceleme: 15+ varlikta satirlar sessizce kirpiyordu).
        // Coin adina tiklanir -> trade ekraninda o sembol acilir.
        para.map((x) => {
          const ham = String(x.para || "").toUpperCase();
          const sembol = ham === "USDT" || ham === "USDC" || !ham
            ? null
            : (ham.endsWith("USDT") ? ham : ham + "USDT");
          const ad = sembol
            ? `<span class="pozSembol" data-sembol="${sembol}" role="button" tabindex="0" title="${sembol} ac">${x.para}</span>`
            : `<span>${x.para}</span>`;
          return `<div class="paraSatir">
        ${ad}
        <span>${x.serbest + x.kilitli}</span>
        <span class="paraGun" ${sembol ? `data-gun="${sembol}"` : ""}>${sembol ? "·" : "—"}</span>
        <span>${x.usdt == null ? "·" : formatUsdt(x.usdt)}</span></div>`;
        }).join("")
    : `<div class="kucuk">borsada varlik yok</div>`;
  gunlukYuzdeleriYaz(p);
}

// Her varligin GUNLUK degisimi (UTC gun acilisina gore, Binance'teki gibi).
// 26.09.2026, Ismail: "cuzdanda BNB var ya, onun gunluk dusus yukselis
// yuzdesi de yazsin". Gun mumu /yerel/mum'dan; 30 sn onbellek.
const _gunOnbellek = new Map();
async function gunlukYuzdeleriYaz(kok) {
  for (const e of kok.querySelectorAll("[data-gun]")) {
    const s = e.dataset.gun;
    let k = _gunOnbellek.get(s);
    if (!k || Date.now() - k.t > 30000) {
      const ham = await apiGet(`/yerel/mum?symbol=${s}&interval=1d&limit=1`, { sessiz: true });
      const m = Array.isArray(ham) ? ham.at(-1) : null;
      const d = m && +m[1] ? (+m[4] / +m[1] - 1) * 100 : null;
      k = { t: Date.now(), d };
      _gunOnbellek.set(s, k);
    }
    if (!e.isConnected) continue;
    e.textContent = k.d == null ? "·" : formatSigned(k.d, 2);
    e.className = "paraGun " + (k.d == null ? "" : k.d >= 0 ? "arti" : "eksi");
    e.title = "bugunku degisim (UTC gun acilisina gore)";
  }
}

// Cuzdan ozetini, pozisyonlari ve gecmisi cizer.
export function renderWallet({ bakiye, pnl, gecmis }) {
  const yaz = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  if (bakiye) {
    const g = bakiye.gercek;
    yaz("bakToplam", g?.toplam == null ? "—" : formatUsdt(g.toplam));
    yaz("bakBot", g?.serbest == null ? "—" : formatUsdt(g.serbest));
    // 26.09.2026, Ismail: "cuzdanda serbest diye bi sey var ne alaka".
    // "serbest" etiketiyle KAGIT cuzdanin toplami gosteriliyordu (eski
    // 7777 index.html'inden tasinmisti). Kaldirildi; kagit cuzdan BOT
    // sayfasinda. Geri EKLEME.
    varliklariCiz(g, bakiye.gercek_hata);
  }
  if (pnl) {
    yaz("pnlToplam", formatUsdt(pnl.toplam, 4));
    yaz("pnlBugun", formatSigned(pnl.seri?.at(-1)?.gunluk_p));
    yaz("pnlGun", String(pnl.seri?.length || 0));
    const i = pnl.istatistik || {};
    // YAPAY ZEKA MIMO (24.09.2026): ust rakam 14 gunluk USDT, satir tum
    // zamanlarin % toplami -- ikisi de "toplam" idi, netlestirildi.
    yaz("pnlSatir", `${i.islem || 0} islem · isabet ${i.isabet ?? "—"}% · ort ${
      i.ortalama ?? "—"}% · tum zamanlar ${i.toplam ?? "—"}%`);
    renderPnlCurve(pnl.seri);
  }
  if (gecmis) {
    // CUZDAN = SENIN ELLE yaptigin gercek para islemleri.
    //
    // 23.09.2026, Ismail: "strategy/bot - cuzdan/canli bunlar farkli
    // seyler". Botun actigi pozisyonlar BOT sayfasinda; burada yalnizca
    // dugmelerle (AL / AL TAKIP / ALSAT) acilanlar gorunur.
    const elle = (gecmis.gecmis || []).filter((e) => !!e.el_kaynak);
    yaz("gecSayi", String(elle.length));
    renderClosedTrades("gecmisTablo", elle);
  }
}

// Bakiye, kar/zarar ve gecmisi sunucudan ceker.  (eski: bakiyeYenile)
//
// `kaynak` artik MODA BAGLI DEGIL: cuzdan sayfasi gercek parayi gosterdigi
// icin kar/zarar ve gecmis de HER ZAMAN canli defterden okunur.
export async function refreshWallet() {
  const [bakiye, pnl, gecmis, emirler] = await Promise.all([
    apiGet("/yerel/bakiye", { sessiz: true }),
    apiGet("/yerel/pnl?kaynak=canli&sadece=el", { sessiz: true }),
    apiGet("/yerel/gecmis?kaynak=canli&n=60", { sessiz: true }),
    apiGet("/yerel/emirler", { sessiz: true }),
  ]);
  return { bakiye, pnl, gecmis, emirler };
}

// Takipteki pozisyonu piyasadan kapatir.
async function pozisyonuKapat(emir) {
  if (!await askConfirm("POZISYONU KAPAT",
    `${emir.sembol} piyasadan kapatilacak.`, { onayMetni: "KAPAT" })) return;
  const c = await apiPost("/yerel/emir/kapat",
    { id: emir.id, canli: emir._live ?? emir.canli });
  if (c?.ok) {
    const toz = c.emir?.kapanis?.toz;
    const kar = c.emir?.kar_p ?? 0;
    if (toz) {
      showToast(`${emir.sembol} KAPANDI (toz) ${formatSigned(kar)}`, "uyari", 7000,
                "asgari tutar altinda -- coin borsada kaldi, pozisyon defterde kapandi");
    } else {
      showToast(`${emir.sembol} KAPANDI ${formatSigned(kar)}`,
                kar > 0 ? "kar" : "zarar");
    }
    refreshNow("cuzdan");
  }
}

// Henuz dolmamis emri borsadan IPTAL eder.
//
// 23.09.2026, Ismail: "acik emri iptal edebilmem lazim ... vazgectim
// diyelim nasil kapatacagim". Uc zaten vardi (`/yerel/emir/iptal`) ama
// arayuzde hicbir yerden cagrilmiyordu.
async function emriIptalEt(emir) {
  if (!await askConfirm("EMRI IPTAL ET",
    `${emir.sembol} icin bekleyen emir borsadan iptal edilecek. `
    + `Bagli duran tutar serbest kalir.`, { onayMetni: "IPTAL ET" })) return;
  const c = await apiPost("/yerel/emir/iptal",
    { id: emir.id, canli: emir._live ?? emir.canli });
  if (c?.ok) { showToast(`${emir.sembol} EMRI IPTAL EDILDI`, "iptal"); refreshNow("cuzdan"); }
}

// Acik emir ve pozisyonlarin sembollerine CANLI akisla abone olur.
function akisaAbone(emirler) {
  const el = (x) => !!x.el_kaynak && (x._live ?? x.canli);
  const s = [...(emirler.takip || []), ...(emirler.acik || [])]
    .filter(el).map((x) => x.sembol);
  _soket?.subscribeSymbols([...new Set(s)]);
}

// CUZDAN sayfasini kurar ve zamanlayicisini kaydeder.
export function mountWalletPage() {
  if (_kuruldu) return;
  _kuruldu = true;

  document.getElementById("btnUzlastirSimdi")?.addEventListener("click", async () => {
    const c = await apiPost("/yerel/uzlastir-simdi", {});
    if (c) {
      const kapat = c.kapatilan || 0;
      const takip = c.takip_eklenen || 0;
      const parca = [];
      if (kapat) parca.push(`${kapat} pozisyon kapatildi`);
      if (takip) parca.push(`${takip} takibe alindi`);
      showToast(`uzlastirma: ${parca.join(", ") || "degisiklik yok"}`, "ok");
      refreshNow("cuzdan");
    }
  });
  document.getElementById("btnHepsiniKapat")?.addEventListener("click", async () => {
    if (!await askConfirm("HEPSINI KAPAT",
      "Tum acik GERCEK PARA pozisyonlari piyasadan kapatilacak.")) return;
    const c = await apiPost("/yerel/emir/hepsini-kapat", { canli: true });
    if (c) { showToast(`${c.kapanan} pozisyon kapatildi`, "ok"); refreshNow(); }
  });
  document.getElementById("btnCanliTemizle")?.addEventListener("click", async () => {
    if (!await askConfirm("GECMISI TEMIZLE",
      "Kapanmis GERCEK PARA islem kayitlari silinecek; ACIK pozisyonlar korunur.")) return;
    const c = await apiPost("/yerel/defter-temizle", { canli: true });
    if (c) { showToast(`${c.silinen} kayit silindi (yedek alindi)`, "ok"); refreshNow("cuzdan"); }
  });

  baglaYontemKapat();

  // YAPAY ZEKA MIMO (24.09.2026): coin adina tika -> trade ekraninda ac.
  // Bakiye varliklari (bakParalar) ve kapanmis islemler (gecmisTablo).
  const sembolTikla = (e) => {
    const s = e.target.closest("[data-sembol]")?.dataset.sembol;
    if (s) openSymbol(s);
  };
  document.getElementById("bakParalar")?.addEventListener("click", sembolTikla);
  document.getElementById("gecmisTablo")?.addEventListener("click", sembolTikla);
  document.getElementById("bakParalar")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      sembolTikla(e);
    }
  });

  // SATIR EYLEMLERI: sembol -> islem ekrani, YONTEM, KAPAT / IPTAL.
  for (const id of ["cuzTakip", "cuzAcik"]) {
    document.getElementById(id)?.addEventListener("click", (e) => {
      // Once COIN ADINA bak (pozSembol): dogrudan trade'e git,
      // satir bulmaya gerek yok (eski kod data-id zorunlu kiliyordu).
      if (e.target.closest(".pozSembol")) {
        const kart = e.target.closest("[data-sembol]");
        const tr = e.target.closest("[data-id]");
        const liste = getState("emirler") || {};
        const hepsi = [...(liste.takip || []), ...(liste.acik || [])];
        let sembol = kart?.dataset.sembol;
        if (!sembol && tr) {
          const emir = hepsi.find((x) => String(x.id) === tr.dataset.id
            && String(x._live ?? x.canli) === tr.dataset.live);
          sembol = emir?.sembol;
        }
        if (sembol) openSymbol(sembol);
        return;
      }
      const tr = e.target.closest("[data-id]");
      if (!tr) return;
      const liste = getState("emirler") || {};
      const hepsi = [...(liste.takip || []), ...(liste.acik || [])];
      const emir = hepsi.find((x) => String(x.id) === tr.dataset.id
        && String(x._live ?? x.canli) === tr.dataset.live);
      if (!emir) return;
      const eylem = e.target.closest("[data-eylem]")?.dataset.eylem;
      if (eylem === "yontem") return openMethodPicker(emir, () => refreshNow("cuzdan"));
      if (eylem === "kapat") return pozisyonuKapat(emir);
      if (eylem === "iptal") return emriIptalEt(emir);
    });
  }

  // Acik emirler ve pozisyonlar websocket ile ANLIK izlenir
  // (Ismail: "cuzdanda acik emirleri websocket ile takip edecektik").
  _soket = createSocketManager({
    onFiyat: (sembol, fiyat) => {
      _fiyatlar[sembol] = fiyat;
      updatePositionPrices("cuzTakip", sembol, fiyat);
      updatePositionPrices("cuzAcik", sembol, fiyat);
    },
  });

  registerPoll("cuzdan", 20, refreshWallet, { sayfa: "cuzdan" });
  sharePollResult("cuzdan", (d) => {
    setState({ cuzdan: d.bakiye || {}, emirler: d.emirler || getState("emirler") });
    renderWallet(d);
    if (d.emirler) {
      const piyasa = d.emirler.piyasa || {};
      // Cuzdan = GERCEK PARA + ELLE acilanlar (bot sayfasindan ayri).
      const se = { live: true, sadece: "el", piyasa, fiyatlar: _fiyatlar };
      renderPositionTable("cuzTakip", d.emirler, { ...se, tur: "takip" });
      renderPositionTable("cuzAcik", d.emirler, { ...se, tur: "acik" });
      akisaAbone(d.emirler);
    }
  });
}

// Sayfadan cikilinca canli akis aboneligi birakilir.
export function unmountWalletPage() {
  _soket?.subscribeSymbols([]);
}
