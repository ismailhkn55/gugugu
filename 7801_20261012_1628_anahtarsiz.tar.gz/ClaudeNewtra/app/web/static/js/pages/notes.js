// notes.js -- NOTLAR.
//
// DUZELTME (23.09.2026): ilk yazimda kendi pencere isaretlememi
// olusturuyordum; iskelette ZATEN `#notPerde` (form) ve `#notGorPerde`
// (okuma) var, CSS'leri 96-notlar.css ve 97-kalan.css'te. Not kartlari da
// `.not / .not-ust / .not-baslik / .not-metin / .not-alt` sinifini kullanir.
import { apiGet, apiPost } from "../api.js";
import { askConfirm } from "../ui/confirm.js";
import { closePerde, openPerde } from "../ui/perde.js";
import { showToast } from "../ui/toast.js";
import { registerPoll, refreshNow, sharePollResult } from "../poll.js";
import { setState } from "../store.js";
import { formatClock } from "../format.js";

let _kuruldu = false;
let _liste = [];
let _duzenlenen = null;

const kacis = (s) => String(s ?? "").replace(/[<>&]/g, (c) =>
  ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" })[c]);

// Notlari kart listesi olarak cizer.  (eski: notCiz)
export function renderNotes(d) {
  const kap = document.getElementById("notlar");
  if (!kap) return;
  _liste = d?.notlar || [];
  kap.innerHTML = _liste.length
    ? _liste.map((n) => `
      <div class="not" data-id="${n.id}">
        <div class="not-ust">
          <div class="not-baslik">${kacis(n.baslik) || "(basliksiz)"}</div>
          <div>
            <button class="not-duzenle" data-ac="duzenle" title="duzenle">✎</button>
            <button class="not-sil" data-ac="sil" title="sil">✕</button>
          </div>
        </div>
        <div class="not-metin">${kacis(n.icerik).slice(0, 260)}</div>
        <div class="not-alt"><span class="not-tarih">${
          formatClock(n.guncelleme || n.id)}</span></div>
      </div>`).join("")
    : `<div class="bos">not yok</div>`;
}

// Not formunu acar (iskeletteki #notPerde).  (eski: notFormAc)
export function openNoteEditor(mevcut) {
  _duzenlenen = mevcut || null;
  const bas = document.getElementById("notFormBaslik");
  const bIn = document.getElementById("notBaslik");
  const mIn = document.getElementById("notMetin");
  if (bas) bas.textContent = mevcut ? "NOTU DUZENLE" : "YENI NOT";
  if (bIn) bIn.value = mevcut?.baslik || "";
  if (mIn) mIn.value = mevcut?.icerik || "";
  kalanYaz();
  openPerde("notPerde", { onClose: () => { _duzenlenen = null; } });
  bIn?.focus();
}

// Notu okuma penceresinde gosterir (iskeletteki #notGorPerde).  (eski: notGoruntule)
export function openNoteViewer(not) {
  const b = document.getElementById("notGorBaslik");
  const m = document.getElementById("notGorMetin");
  if (b) b.textContent = not?.baslik || "";
  if (m) m.textContent = not?.icerik || "";
  openPerde("notGorPerde");
}

function kalanYaz() {
  const m = document.getElementById("notMetin");
  const k = document.getElementById("notKalan");
  if (m && k) k.textContent = String(Math.max(0, (m.maxLength || 400) - m.value.length));
}

async function kaydet() {
  const govde = {
    baslik: document.getElementById("notBaslik")?.value || "",
    icerik: document.getElementById("notMetin")?.value || "",
  };
  if (_duzenlenen) govde.id = _duzenlenen.id;
  const c = await apiPost("/yerel/notlar", govde);
  if (!c) return;
  showToast("NOT KAYDEDILDI", "kar");
  closePerde("notPerde");
  refreshNow("notlar");
}

// Notlari sunucudan ceker.  (eski: notlariAl)
export async function refreshNotes() {
  return apiGet("/yerel/notlar", { sessiz: true });
}

// NOTLAR sayfasini kurar ve olaylarini baglar.
export function mountNotesPage() {
  if (_kuruldu) return;
  _kuruldu = true;

  document.getElementById("btnNotEkle")?.addEventListener("click", () => openNoteEditor(null));
  document.getElementById("notKaydet")?.addEventListener("click", kaydet);
  document.getElementById("notIptal")?.addEventListener("click", () => closePerde("notPerde"));
  document.getElementById("notMetin")?.addEventListener("input", kalanYaz);
  document.getElementById("notGorKapat")?.addEventListener("click", () => closePerde("notGorPerde"));

  document.getElementById("notlar")?.addEventListener("click", async (e) => {
    const kart = e.target.closest(".not");
    if (!kart) return;
    const id = +kart.dataset.id;
    const not = _liste.find((n) => n.id === id);
    const ac = e.target.closest("[data-ac]")?.dataset.ac;
    if (ac === "duzenle") return openNoteEditor(not);
    if (ac === "sil") {
      if (!await askConfirm("NOTU SIL", not?.baslik || "", { onayMetni: "SIL" })) return;
      await apiPost("/yerel/notlar", { sil: id });
      refreshNow("notlar");
      return;
    }
    openNoteViewer(not);          // karta tiklayinca oku
  });

  registerPoll("notlar", 120, refreshNotes, { sayfa: "notlar" });
  sharePollResult("notlar", (d) => { setState({ notlar: d.notlar || [] }); renderNotes(d); });
}
