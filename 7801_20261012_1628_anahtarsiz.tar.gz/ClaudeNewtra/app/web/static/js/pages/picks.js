// picks.js -- SECILENLER: aktif stratejinin adaylari.
import { apiGet } from "../api.js";
import { registerPoll, sharePollResult } from "../poll.js";
import { setState } from "../store.js";
import { alignStickyHeader, buildTableHead, buildTableRows, openSymbol,
         recordLivePrice, sortRows } from "./trade.js";
import { createSocketManager } from "../live/socketManager.js";

let _kuruldu = false;
// CANLI% ve FIYAT websocket'ten gelir; anasayfanin soketi bu sayfada kapali
// oldugu icin SECILENLER kendi adaylarina abone olur.
let _soket = null;
let _semboller = [];
// Baslik tiklamasiyla siralama (anasayfayla AYNI kural: ilk tik buyukten
// kucuge, # ve SEMBOL kucukten buyuge; ayni basliga tekrar tik ters cevirir).
// null = stratejinin aday sirasi.
let _siralama = null;
let _artan = true;
let _sonVeri = null;

// Aktif stratejinin sectigi coinleri cizer.  (eski: secCiz)
export function renderPicks(d) {
  const bilgi = document.getElementById("secBilgi");
  const tablo = document.getElementById("secTablo");
  if (!tablo) return;
  _sonVeri = d;
  const aday = (d?.aday || []).slice();
  if (_siralama) sortRows(aday, _siralama, _artan);
  if (bilgi) {
    bilgi.textContent = d
      ? `${d.strateji || "-"} · ${d.tarandi} coin tarandi · ${d.elenen ?? "?"} elendi · ${aday.length} SECILDI`
      : "yukleniyor...";
    // Yapilandirma hatasi varsa SESSIZ KALMA (eski sistemde sessizce eleniyordu).
    if (d?.yapilandirma_hatasi?.length) {
      bilgi.textContent += ` · HATA: ${d.yapilandirma_hatasi[0]}`;
      bilgi.classList.add("eksi");
    } else bilgi.classList.remove("eksi");
  }
  // 26.09.2026: ANASAYFA TABLOSUNUN AYNISI -- ayni kolonlar, ayni hucreler,
  // ayni CSS (trade.js buildTableHead/buildTableRows). Sira: stratejinin
  // aday sirasi; "#" kolonu anasayfadaki rank'i gosterir.
  // 9 kolonluk ayri kopya YAZMA -- bu sayfa bu yuzden "bozulup duruyordu".
  tablo.innerHTML = aday.length
    ? `<table><thead><tr id="secBasliklar">${buildTableHead({ siraNo: true })}</tr></thead>`
      + `<tbody id="secGovde">${buildTableRows(aday, { siraNo: true })}</tbody></table>`
    : `<div class="bos">aday yok</div>`;
  if (aday.length) alignStickyHeader("secGovde", "secBasliklar", 6);
  for (const th of document.getElementById("secBasliklar")?.children || []) {
    th.classList.toggle("aktif", th.dataset.a === _siralama);
    th.classList.toggle("artan", _artan);
  }
  _semboller = aday.map((x) => x.sembol);
  _soket?.subscribeSymbols(_semboller);
}

// Aday listesini sunucudan ceker.  (eski: secilenlerYukle)
export async function refreshPicks() {
  // 26.09.2026: n=30 idi -> 46 secilen varken yalniz 30'u gosterip "30 aday"
  // diyordu (secilen sayisi YANLIS gorunuyordu). Hepsi alinir.
  return apiGet("/yerel/aday?n=400");
}

// SECILENLER sayfasini kurar ve zamanlayicisini kaydeder.
export function mountPicksPage() {
  if (_kuruldu) { _soket?.subscribeSymbols(_semboller); return; }
  _kuruldu = true;
  _soket = createSocketManager({ onFiyat: recordLivePrice });
  document.getElementById("secTablo")?.addEventListener("click", (e) => {
    const th = e.target.closest("th");
    if (th) {
      const a = th.dataset.a;
      // NO basligi: stratejinin kendi aday sirasina don.
      if (!a) { _siralama = null; _artan = true; }
      else if (a === _siralama) _artan = !_artan;
      else { _siralama = a; _artan = a === "rank" || a === "sembol"; }
      renderPicks(_sonVeri);
      return;
    }
    const s = e.target.closest("tr")?.dataset.sembol;
    if (s) openSymbol(s);
  });
  registerPoll("aday", 20, refreshPicks, { sayfa: "secilenler" });
  sharePollResult("aday", (d) => { setState({ adaylar: d.aday || [] }); renderPicks(d); });
}

// Sayfadan cikinca canli aboneligi birakir.
export function unmountPicksPage() {
  _soket?.subscribeSymbols([]);
}
