// winners.js -- KAZANANLAR: siralamada tirmananlar.
//
// DUZELTME (23.09.2026): ilk yazimda `.kazKart/.kazBas/.kazSira/...` diye
// SINIF ADLARI UYDURMUSTUM; 95-kazananlar.css `.kaz / .kaz-ust / .kaz-ad /
// .kaz-deg / .kaz-alt / .kaz-mum / .kaz-etiket` bekliyor. Sonuc: kartlar
// bicimsiz, "sadece yazilar" gorunuyordu (kullanici bildirdi).
// Artik `tools/css_denetim.py` bu hatayi yakaliyor.
import { apiGet } from "../api.js";
import { formatPrice, formatSigned } from "../format.js";
import { registerPoll, sharePollResult } from "../poll.js";
import { setState } from "../store.js";
import { openSymbol } from "./trade.js";
import { klineCevir } from "../chart/indicators.js";
import { renderMiniChart } from "../chart/renderer.js";

let _kuruldu = false;
const MUM_KART = 12;        // kac karta mini mum cizilecek (istek maliyeti)
const KART_MUM = 20;        // her kartta kac mum gosterilecek

// Siralamada tirmanan coinleri kart olarak cizer.  (eski: kazananlariYenile)
export function renderWinners(d) {
  const kap = document.getElementById("kazKartlar");
  if (!kap) return;
  const satir = d?.satir || [];
  if (!satir.length) {
    kap.innerHTML = `<div class="yok">son ${d?.dakika ?? 15} dakikada ${
      d?.basamak ?? 20} basamak tirmanan yok</div>`;
    return;
  }
  kap.innerHTML = satir.map((x, i) => `
    <div class="kaz" data-sembol="${x.sembol}">
      <div class="kaz-ust">
        <span class="kaz-ad">${x.sembol.replace("USDT", "")}</span>
        <span class="kaz-deg ${x.deg24 > 0 ? "arti" : "eksi"}">${formatSigned(x.deg24, 1)}</span>
      </div>
      <div class="kaz-mum" id="kazMum${i}"><div class="yok">MUM YOK</div></div>
      <div class="kaz-alt">
        <span>sira <b>${x.eski_rank} → ${x.rank}</b></span>
        <span>tirmanis <b>+${x.tirmanis}</b></span>
        <span>fiyat <b>${formatPrice(x.fiyat)}</b></span>
        <span>gun <b class="${x.gun_pct > 0 ? "arti" : "eksi"}">${
          formatSigned(x.gun_pct, 1)}</b></span>
        <span>hiz <b>${x.hiz?.toFixed(1) ?? "·"}</b></span>
        <span>hacim <b>${x.hacim_x?.toFixed(1) ?? "·"}x</b></span>
      </div>
      <div class="kaz-etiket">${d.dakika} DK ICINDE</div>
    </div>`).join("");
  mumlariCiz(satir.slice(0, MUM_KART));
}

// Kart basina kisa mum serisi cizer (ilk MUM_KART kart icin).
async function mumlariCiz(liste) {
  for (const [i, x] of liste.entries()) {
    // 23.09.2026, Ismail: "kazananlarda 20 mum gozukecekti".
    const ham = await apiGet(
      `/yerel/mum?symbol=${x.sembol}&interval=5m&limit=${KART_MUM}`, { sessiz: true });
    if (!ham?.length) continue;
    renderMiniChart(`kazMum${i}`, klineCevir(ham), { bosMetin: "MUM YOK" });
  }
}

// Kazananlar listesini sunucudan ceker.
export async function refreshWinners() {
  return apiGet("/yerel/kazananlar?n=24");
}

// KAZANANLAR sayfasini kurar ve zamanlayicisini kaydeder.
export function mountWinnersPage() {
  if (_kuruldu) return;
  _kuruldu = true;
  document.getElementById("kazKartlar")?.addEventListener("click", (e) => {
    const s = e.target.closest("[data-sembol]")?.dataset.sembol;
    if (s) openSymbol(s);
  });
  registerPoll("kazananlar", 60, refreshWinners, { sayfa: "kazananlar" });
  sharePollResult("kazananlar", (d) => { setState({ kazananlar: d.satir || [] }); renderWinners(d); });
}
