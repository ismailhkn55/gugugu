// settingsPage.js -- AYARLAR.
//
// ESKI SISTEM: `ayar.json`'da ALTI anahtar hicbir kod tarafindan
// okunmuyordu (`altakip_esik/mesafe/stop`, `altakip_ema_periyot`,
// `al_trailing_baslangic`, `bot_tutar`). Kullanici bunlari degistiriyor,
// hicbir sey olmuyordu -- ustelik ucu POST beyaz listesindeydi, yani
// kaydediliyor ama kullanilmiyordu. Ayrica UC SAYI koda gomuluydu ve
// ekrandan gorulemiyordu.
//
// Burada sunucu AYAR SEMASINI da gonderiyor: her alanin etiketi ve ONU
// OKUYAN MODUL biliniyor, kullanilmayan anahtarlar isaretleniyor.
import { apiGet, apiPost } from "../api.js";
import { askConfirm } from "../ui/confirm.js";
import { showToast } from "../ui/toast.js";
import { registerPoll, refreshNow, sharePollResult } from "../poll.js";
import { getState, getTercih, setState, setTercih } from "../store.js";

let _kuruldu = false;

// Form alani -> ayar anahtari eslemesi.
const ALAN = {
  ayTutar: "tutar", ayKar: "kar_al", ayStop: "stop",
  ayAlSira: "al_sira", aySatSira: "sat_sira", ayAlSatSira: "alsat_sira",
  ayKagit: "kagit_bakiye", ayKomisyon: "komisyon_toplam",
  ayLimitUst: "limit_ust_yuzde",
  ayAlKilit2Esik: "al_kilit2_esik", ayAlKilit2Yuzde: "al_kilit2_yuzde",
  ayAlKilit3Esik: "al_kilit3_esik", ayAlKilit3Yuzde: "al_kilit3_yuzde",
  ayAlDinamikEsik: "al_dinamik_esik", ayAlTrMesafe: "al_trailing_mesafe",
  ayAlStop: "al_stop",
  // 06.10.2026: ATR IZI cikis yontemi (DOKUMANTASYON 7.52).
  ayAlCikisModu: "al_cikis_modu", ayAtrIzAktif: "atr_iz_aktif", ayAtrIzKilit: "atr_iz_kilit",
  ayAtrIzCarpan: "atr_iz_carpan", ayAtrIzMin: "atr_iz_min",
  ayBotCikisStop: "bot_cikis_stop",
  ayBotCikisMerdivenEsik: "bot_cikis_merdiven_esik",
  ayBotCikisMerdivenKilit: "bot_cikis_merdiven_kilit",
  ayBotCikisEsik: "bot_cikis_esik", ayBotCikisMesafe: "bot_cikis_mesafe",
  ayBotCikisIvmeAcik: "bot_cikis_ivme_acik",
  ayBotCikisIvmeCarpan: "bot_cikis_ivme_carpan",
  ayBotCikisIvmeEsik: "bot_cikis_ivme_esik",
  ayBotCikisIvmeHacim: "bot_cikis_ivme_hacim",
  ayAlsatHedef1: "alsat_hedef_1", ayAlsatHedef2: "alsat_hedef_2",
  ayAlsatHedef3: "alsat_hedef_3", ayAlsatStop: "alsat_stop",
  ayGunTf: "gun_tf", ayGunMum: "gun_mum", ayUstTf: "ust_tf", ayUstMum: "ust_mum",
  ayAltTf: "alt_tf", ayAltMum: "alt_mum", ayDortTf: "dort_tf", ayDortMum: "dort_mum",
  ayHmCci: "heatmap_cci_acik", ayHmSira: "heatmap_siralama",
  ayHmBtcEth: "heatmap_btc_eth",
  tgToken: "telegram_token", tgChat: "telegram_chat",
  // 27.09.2026: ISLEM grafiginde BOT/CUZDAN/STRATEJI isaret renkleri.
  ayRenkBot: "renk_bot_giris", ayRenkCuzdan: "renk_cuzdan_giris",
  ayRenkSinyal: "renk_strateji_sinyal",
  // 29.09.2026: CHCM (coklu borsa hacim) bar renkleri.
  ayRenkHacimBinance: "renk_hacim_binance", ayRenkHacimBybit: "renk_hacim_bybit",
  ayRenkHacimOkx: "renk_hacim_okx", ayRenkHacimMexc: "renk_hacim_mexc",
  ayRenkHacimGate: "renk_hacim_gate", ayRenkHacimUpbit: "renk_hacim_upbit",
};

// Hangi kaydet dugmesi hangi alanlari gonderir.
const GRUP = {
  btnAyarKaydet: ["ayTutar", "ayKar", "ayStop", "ayAlSira", "aySatSira",
                  "ayAlSatSira", "ayKagit", "ayKomisyon", "ayLimitUst"],
  btnAlAyarKaydet: ["ayAlKilit2Esik", "ayAlKilit2Yuzde", "ayAlKilit3Esik",
                    "ayAlKilit3Yuzde", "ayAlDinamikEsik", "ayAlTrMesafe", "ayAlStop",
                    "ayAlCikisModu", "ayAtrIzAktif", "ayAtrIzKilit", "ayAtrIzCarpan", "ayAtrIzMin"],
  btnBotCikisKaydet: ["ayBotCikisStop", "ayBotCikisMerdivenEsik",
                      "ayBotCikisMerdivenKilit", "ayBotCikisEsik", "ayBotCikisMesafe",
                      "ayBotCikisIvmeAcik", "ayBotCikisIvmeCarpan",
                      "ayBotCikisIvmeEsik", "ayBotCikisIvmeHacim"],
  btnAlsatAyarKaydet: ["ayAlsatHedef1", "ayAlsatHedef2", "ayAlsatHedef3", "ayAlsatStop"],
  btnGrafikKaydet: ["ayGunTf", "ayGunMum", "ayUstTf", "ayUstMum",
                    "ayAltTf", "ayAltMum", "ayDortTf", "ayDortMum",
                    "ayRenkBot", "ayRenkCuzdan", "ayRenkSinyal",
                    "ayRenkHacimBinance", "ayRenkHacimBybit", "ayRenkHacimOkx",
                    "ayRenkHacimMexc", "ayRenkHacimGate", "ayRenkHacimUpbit"],
  btnHmKaydet: ["ayHmCci", "ayHmSira", "ayHmBtcEth"],
};

// Gosterge ve EMA tercihleri -- bunlar SUNUCU ayari degil, KULLANICI
// tercihidir (tarayicida saklanir). Eski sistemde ikisi karisikti.
const GOSTERGELER = [
  ["ha", "Heikin Ashi"], ["ema", "EMA cizgileri"], ["bb", "Bollinger 20/2"],
  ["vwap", "VWAP"], ["hacim", "Hacim barlari"],
  ["hacimCokBorsa", "CHCM: coklu borsa hacim (HCM acik olmali)"], ["rsi", "RSI 14"],
  ["obv", "OBV"], ["atr", "ATR 14"],
];
const EMA_VARSAYILAN = [7, 20, 48, 99];

function gostergeListesiCiz() {
  const kap = document.getElementById("ayGostListe");
  if (!kap) return;
  const g = getTercih("gosterge") || {};
  kap.innerHTML = GOSTERGELER.map(([k, ad]) => `
    <label class="ayarSatir"><span>${ad}</span>
      <input type="checkbox" data-g="${k}" ${g[k] ? "checked" : ""}></label>`).join("");
}

function emaListesiCiz() {
  const kap = document.getElementById("ayEmaListe");
  if (!kap) return;
  const d = getTercih("emaDonem") || EMA_VARSAYILAN;
  kap.innerHTML = d.map((n, i) => `
    <label class="ayarSatir"><span>EMA ${i + 1}</span>
      <input type="number" min="2" max="400" data-ema="${i}" value="${n}"></label>`).join("");
}

function gostergeKaydet() {
  const g = {};
  for (const i of document.querySelectorAll("#ayGostListe [data-g]")) g[i.dataset.g] = i.checked;
  setTercih("gosterge", g);
  const d = [...document.querySelectorAll("#ayEmaListe [data-ema]")]
    .map((i) => parseInt(i.value, 10) || 0).filter((n) => n >= 2);
  setTercih("emaDonem", d.length ? d : EMA_VARSAYILAN);
  setTercih("gostergeGorunsun", !!document.getElementById("ayGostAcik")?.checked);
  setTercih("gostergeDugmeleri", !!document.getElementById("ayGostDugme")?.checked);
  gostergeGorunurluk();
  showToast("GOSTERGE AYARI KAYDEDILDI", "bilgi");
}

// Gosterge dugmeleri / cizgileri gorunur mu.
function gostergeGorunurluk() {
  const d = document.getElementById("gostergeDugmeler");
  if (d) d.hidden = getTercih("gostergeDugmeleri") === false;
}

// Ayar formunu semadan ve mevcut degerlerden doldurur.  (eski: ayarFormaBas)
export function fillSettingsForm(ayar) {
  for (const [id, anahtar] of Object.entries(ALAN)) {
    const e = document.getElementById(id);
    if (!e || document.activeElement === e) continue;
    const v = ayar[anahtar];
    if (e.type === "checkbox") e.checked = !!v;
    else if (v !== undefined && v !== null) e.value = v;
  }
  // ALSAT ornek butonlarindaki hedefler.
  for (const n of [1, 2, 3]) {
    const e = document.getElementById(`ornekAlsat${n}`);
    if (e) e.textContent = String(ayar[`alsat_hedef_${n}`] ?? "—");
  }
  // Telegram durumu.
  const tg = document.getElementById("tgDurum");
  if (tg) {
    const bagli = !!(ayar.telegram_token && ayar.telegram_chat);
    tg.textContent = bagli ? "BAGLI" : "BAGLI DEGIL";
    tg.className = "anahtarDurum " + (bagli ? "var" : "yok");
  }
  const ad = document.getElementById("ayAnahtarDurum");
  if (ad) {
    ad.textContent = ayar.anahtar_var ? "ANAHTAR VAR" : "ANAHTAR YOK";
    ad.className = "anahtarDurum " + (ayar.anahtar_var ? "var" : "yok");
  }
}

// Kullanilmayan ayarlari ekranda ISARETLE -- kullanici bosuna ugrasmasin.
function oluAyarlariIsaretle(olu) {
  if (!olu?.length) return;
  const ters = Object.fromEntries(Object.entries(ALAN).map(([k, v]) => [v, k]));
  for (const anahtar of olu) {
    const e = document.getElementById(ters[anahtar]);
    if (!e) continue;
    e.disabled = true;
    e.title = "Bu ayari hicbir modul okumuyor — etkisi yok";
    e.closest(".ayarSatir")?.classList.add("olu");
  }
}

async function grubuKaydet(dugmeId) {
  const govde = {};
  for (const id of GRUP[dugmeId] || []) {
    const e = document.getElementById(id);
    if (!e) continue;
    govde[ALAN[id]] = e.type === "checkbox" ? e.checked
                    : e.type === "number" ? parseFloat(e.value) : e.value;
  }
  const c = await apiPost("/yerel/ayar", govde);
  if (!c) return;
  if (c.reddedilen?.length) showToast("reddedilen: " + c.reddedilen.join(", "), "uyari");
  else showToast("ayarlar kaydedildi", "ok");
  setState({ ayar: { ...getState("ayar"), ...c.ayar } });
  refreshNow("ayar");
}

// Ayarlari sunucudan ceker.  (eski: ayarYukle)
export async function refreshSettings() {
  return apiGet("/yerel/ayar", { sessiz: true });
}

// AYARLAR sayfasini kurar ve form olaylarini baglar.
export function mountSettingsPage() {
  if (_kuruldu) return;
  _kuruldu = true;

  for (const id of Object.keys(GRUP)) {
    document.getElementById(id)?.addEventListener("click", () => grubuKaydet(id));
  }

  document.getElementById("btnAnahtarKaydet")?.addEventListener("click", async () => {
    const key = document.getElementById("ayKey")?.value.trim();
    const secret = document.getElementById("aySecret")?.value.trim();
    if (!key || !secret) return showToast("key ve secret gerekli", "hata");
    const c = await apiPost("/yerel/anahtar", { key, secret });
    if (c?.ok) {
      showToast("anahtar kaydedildi ve dogrulandi", "ok");
      document.getElementById("ayKey").value = "";
      document.getElementById("aySecret").value = "";
      refreshNow("ayar");
    }
  });
  document.getElementById("btnAnahtarSil")?.addEventListener("click", async () => {
    if (!await askConfirm("ANAHTARI SIL",
      "Binance API anahtari silinecek ve canli mod kapanacak.")) return;
    const c = await apiPost("/yerel/anahtar", { sil: 1 });
    if (c) { showToast("anahtar silindi, canli mod kapatildi", "ok"); refreshNow("ayar"); }
  });

  document.getElementById("btnTgKaydet")?.addEventListener("click", async () => {
    const c = await apiPost("/yerel/telegram", {
      token: document.getElementById("tgToken")?.value.trim(),
      chat: document.getElementById("tgChat")?.value.trim() });
    if (c) showToast(c.tanimli ? "telegram tanimlandi" : "telegram eksik", c.tanimli ? "ok" : "uyari");
  });
  document.getElementById("btnTgSil")?.addEventListener("click", async () => {
    const c = await apiPost("/yerel/telegram", { sil: 1 });
    if (c) showToast("telegram ayari silindi", "ok");
  });

  // gosterge tercihleri
  const ga = document.getElementById("ayGostAcik");
  const gd = document.getElementById("ayGostDugme");
  if (ga) ga.checked = getTercih("gostergeGorunsun") !== false;
  if (gd) gd.checked = getTercih("gostergeDugmeleri") !== false;
  gostergeListesiCiz();
  emaListesiCiz();
  gostergeGorunurluk();
  document.getElementById("btnGostergeKaydet")?.addEventListener("click", gostergeKaydet);

  baglaHaricPaneli("haric", "haricGiris", "btnHaricEkle", "haricListe", "/yerel/haric");
  baglaHaricPaneli("pozHaric", "pozHaricGiris", "btnPozHaricEkle", "pozHaricListe",
                   "/yerel/pozisyon-haric");

  registerPoll("ayarForm", 30, refreshSettings, { sayfa: "ayarlar" });
  sharePollResult("ayarForm", (d) => {
    if (!d?.ayar) return;
    fillSettingsForm({ ...d.ayar, anahtar_var: d.anahtar_var });
    oluAyarlariIsaretle(d.olu_ayarlar);
  });
}

// Haric listesi paneli -- TEK FABRIKA.
//
// Eski sistemde `haricCiz/haricYukle/haricKaydet/haricEkle` ve
// `pozHaricCiz/pozHaricYukle/pozHaricKaydet/pozHaricEkle` diye SEKIZ
// fonksiyon vardi; ~48 satiri birebir aynıydi, tek farklari degisken adi,
// uc ve element kimligiydi. Ustelik `haricCiz` ayni satirda
// `trHaricButonGuncelle()`yi IKI KEZ cagiriyordu (ikincisi erken `return`
// yuzunden ERISILEMEZ).  (eski: haricCiz + pozHaricCiz)
// Haric tutma panelini (coin ve pozisyon) kurar.
export function createExclusionPanel(ad, girisId, dugmeId, listeId, uc) {
  let liste = [];

  function ciz() {
    const e = document.getElementById(listeId);
    if (!e) return;
    e.innerHTML = liste.length
      ? liste.map((s) => `<span class="haricOge" data-s="${s}">${s}<button>×</button></span>`).join("")
      : `<span class="kucuk">liste bos</span>`;
  }
  async function yukle() {
    const d = await apiGet(uc, { sessiz: true });
    if (d) { liste = d.haric || []; ciz(); }
  }
  async function kaydet() {
    const c = await apiPost(uc, { haric: liste });
    if (c) { liste = c.haric || liste; ciz(); showToast(`${ad}: ${liste.length} kayit`, "ok"); }
  }
  function ekle(s) {
    const t = (s || "").trim().toUpperCase();
    if (!t || liste.includes(t)) return;
    liste.push(t);
    kaydet();
  }
  return { yukle, ekle, kaydet, ciz, liste: () => liste,
    bagla() {
      document.getElementById(dugmeId)?.addEventListener("click", () => {
        const g = document.getElementById(girisId);
        ekle(g?.value); if (g) g.value = "";
      });
      document.getElementById(girisId)?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") document.getElementById(dugmeId)?.click();
      });
      document.getElementById(listeId)?.addEventListener("click", (e) => {
        const s = e.target.closest("[data-s]")?.dataset.s;
        if (!s) return;
        liste = liste.filter((x) => x !== s);
        kaydet();
      });
      yukle();
    } };
}

function baglaHaricPaneli(ad, girisId, dugmeId, listeId, uc) {
  createExclusionPanel(ad, girisId, dugmeId, listeId, uc).bagla();
}
