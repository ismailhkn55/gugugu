// theme.js -- tema, yazi tipi, yogunluk ve dikey mod.
import { getTercih, setTercih } from "../store.js";

// Secilebilir tema adlari.
//
// 25.09.2026: ucuncu tema "hud" -- cyberpunk HUD (koyu lacivert zemin +
// camgobegi neon). CSS blogu `00-temel.css`'te vardi ama secilemiyordu.
// 26.09.2026: dorduncu tema "goz" -- GOZ DOSTU (koyu gri, amber, parlama yok).
// 03.10.2026: besinci tema "karbon" -- karbon siyah + metal + amber sci-fi cerceve
// (Ismail'in gonderdigi oyun arayuzu ornekleri); telefon/PC/TV'de NET (parlama yok).
export const TEMALAR = ["koyu", "acik", "hud", "goz", "karbon"];

// Tema dugmesinde gosterilecek kisa ad (kisa ad, buyuk harf).
export const TEMA_KISA = { koyu: "SIYAH", acik: "ACIK", hud: "HUD", goz: "GOZ DOSTU", karbon: "KARBON" };
// Secilebilir yazi tipi adlari.
//
// 23.09.2026, Ismail: "yazi tipi degistiriyoruz ya oraya dijital bi yazi
// tipi de ekle, android ve pc de calisan bi sey olsun". "Share Tech Mono"
// (SIL Open Font License) KENDI SUNUCUMUZDA barindirilir -- dis CDN yok,
// cevrimdisi da calisir, dolayisiyla Android ve masaustunde ayni gorunur.
// Sabit genislikli oldugu icin sayi sutunlari da hizali kalir.
export const YAZITIPLERI = ["Inter", "IBM Plex Sans", "Roboto",
                            "Liberation Sans", "Share Tech Mono"];

// Yazi tipi dugmesinde gosterilecek kisa ad.
export const YAZI_KISA = {
  "Inter": "INTER", "IBM Plex Sans": "PLEX", "Roboto": "ROBOTO",
  "Liberation Sans": "LIBER", "Share Tech Mono": "DIJITAL",
};

// Temayi uygular.  (eski: temaUygula)
export function applyTheme(ad) {
  const t = TEMALAR.includes(ad) ? ad : "koyu";
  document.documentElement.dataset.tema = t;
  setTercih("tema", t);
}

// Yazi tipini uygular.  (eski: yaziUygula)
export function applyFont(ad) {
  const y = YAZITIPLERI.includes(ad) ? ad : "Share Tech Mono";
  // Yedek zincir: woff2 yuklenemezse (eski Android, agirlikli onbellek
  // temizligi) arayuz bicimsiz kalmasin. Dijital secimde sistemin kendi
  // sabit genislikli yazi tipine dusulur.
  // "CN Sembol"/"CN Emoji": dugmelerdeki isaret ve emojiler (▲ ⚙ 🔒 🎯 ...)
  // KENDI sunucumuzdan -- sistemde emoji fontu olmasa da kutu (▯) cikmaz.
  const ortak = '"CN Sembol", "CN Emoji"';
  const yedek = y === "Share Tech Mono"
    ? `${ortak}, ui-monospace, "Roboto Mono", "DejaVu Sans Mono", monospace`
    : `${ortak}, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`;
  document.documentElement.style.setProperty("--yazi", `"${y}", ${yedek}`);
  setTercih("yazitipi", y);
}

// Yogunluk (sik/genis) modu.  (eski: modUygula)
export function applyDensityMode(mod) {
  document.documentElement.dataset.yogunluk = mod === "sik" ? "sik" : "genis";
  setTercih("yogunluk", mod);
}

// Dikey/telefon modu.
//
// ESKI SISTEM: `#grafCanli{touch-action:none}` native kaydirmayi TAMAMEN
// kapatiyor, dikey modda sayfa TEK SATIRLIK bir JS ile kaydiriliyordu
// (`kaydir.sayfa.scrollTop -= ...`). Momentum yoktu; `closest(".sayfa")`
// null donerse kaydirma SESSIZCE hic calismiyordu; 4 mini grafik bu kodu
// paylasmadigi icin davranislari farkliydi.
//
// Burada dikey modda grafik `touch-action: pan-y` alir -- dikey kaydirma
// TARAYICIYA birakilir (momentum, bounce, kaydirma cubugu hepsi dogal),
// yalniz yatay hareket JS'e kalir.  (eski: dikeyUygula)
// Dikey/yatay gorunum modunu uygular.
export function applyPortraitMode(acik) {
  document.documentElement.dataset.gorunum = acik ? "dikey" : "yatay";
  setTercih("gorunum", acik ? "dikey" : "yatay");
}

// TV MODU: data-cihaz="tv" -> 14px'ten kucuk TUM yazilar 14px (css/99-tv-mod.css),
// cizgiler 2px. 03.10.2026, Ismail: "temaya TV modu ekle, YALNIZCA TV modunda
// yazilar buyusun". Tercih (`tvMod`) verilmemisse TV tarayicisi (UA) otomatik acar.
export function applyDeviceClass() {
  const t = getTercih("tvMod");
  const ua = navigator.userAgent || "";
  const tv = t === true || (t == null && /SMART-TV|Tizen|Web0S|webOS|SmartTV/i.test(ua));
  document.documentElement.dataset.cihaz = tv ? "tv" : "";
  return tv;
}

// TV modunu elle ac/kapat (ust bardaki TV dugmesi).
export function setTvMode(acik) {
  setTercih("tvMod", !!acik);
  return applyDeviceClass();
}

// Kayitli tercihleri uygular (acilista bir kez).
export function temalariUygula() {
  applyDeviceClass();
  const t = getTercih();
  applyTheme(t.tema || "koyu");
  // 26.09.2026, Ismail: "share tech mono kullanalim". Eski tarayici
  // tercihi (Inter vb.) bir kereye mahsus Share Tech Mono'ya cekilir;
  // sonrasinda yazi tipi dugmesiyle yine degistirilebilir.
  if (!t.yazi_stm_2609) {
    setTercih("yazitipi", "Share Tech Mono");
    setTercih("yazi_stm_2609", 1);
  }
  applyFont(getTercih("yazitipi") || "Share Tech Mono");
  applyDensityMode(t.yogunluk || "genis");
  applyPortraitMode((t.gorunum || "yatay") === "dikey");
}
