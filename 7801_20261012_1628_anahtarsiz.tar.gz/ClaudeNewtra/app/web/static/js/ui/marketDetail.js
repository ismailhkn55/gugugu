// marketDetail.js -- anasayfadaki gosterge hucrelerinin TEK kaynagi.
//
// 23.09.2026, Ismail: "bot da da cuzdan da detaylari gorunmeli yani iz
// nerde atr nerde ayni ana sayfadaki gibi". Bu satirlar daha once yalnizca
// `trade.js` icinde uretiliyordu; cuzdan ve bot tablolari sembolden baska
// bir sey gostermiyordu. Ikinci bir kopya yazmak yerine cizim buraya
// alindi -- `trade.js` de iz grafigini BURADAN kullanir (tek uygulama).
import { formatPrice, formatSigned } from "../format.js";

// Sira izi sparkline'i (SVG).
//
// 23.09.2026, Ismail: "anasayfada iz yesil yada kirmizi olmali".
// Onceden cizgi `currentColor` ile ciziliyor, yon yalnizca OPAKLIKLA
// belirtiliyordu (yukselen 1.0, dusen 0.55) -- pratikte ikisi de ayni
// renkti ve yon okunmuyordu. Artik renk acik: siralamada TIRMANAN yesil,
// GERILEYEN kirmizi.
//
// `sira_izi` RANK dizisidir; rank KUCULURSE coin yukseliyor demektir,
// bu yuzden yon = ilk - son.
export function renderTrailSparkline(dizi) {
  if (!dizi || dizi.length < 2) return "";
  const en = Math.max(...dizi), az = Math.min(...dizi), a = Math.max(1, en - az);
  const n = dizi.length;
  const nokta = dizi.map((v, i) =>
    `${(i / (n - 1) * 100).toFixed(1)},${(((v - az) / a) * 12 + 1).toFixed(1)}`).join(" ");
  const yon = dizi[0] - dizi[n - 1];
  const sinif = yon > 0 ? "izArti" : yon < 0 ? "izEksi" : "izNotr";
  return `<svg class="iz ${sinif}" viewBox="0 0 100 14" preserveAspectRatio="none">
    <polyline points="${nokta}" fill="none" stroke="currentColor"
      stroke-width="1.4"/></svg>`;
}

// Iz grafigi + "ilk>son" sayilari (tablo hucresinin ici).
export function renderTrailCell(dizi) {
  const sayilar = dizi && dizi.length >= 2 ? `${dizi[0]}>${dizi[dizi.length - 1]}`
                : dizi && dizi.length ? String(dizi[0]) : "";
  return `<div class="izKutu">${renderTrailSparkline(dizi)}<small class="izSayi">${sayilar}</small></div>`;
}

// IZAS hucresi: buyuk = KENDI payi, kucuk = BASKALARININ payi (ikisi + = tirmanis).
// 05.10.2026, Ismail: "ben 5. idim ama deger kaybettim ve 6. oldum ama 5.
// hic kimildamadi" -> kendi -1, baskalari 0. "Biri beni gecti" -> kendi 0, baskalari -1.
export function renderOwnShareCell(kendi, diger) {
  if (kendi == null) return "·";
  const isaret = (v) => (v > 0 ? "+" : "") + v;
  return `<span class="izasKutu" title="kendi degerinden ${isaret(kendi)} sira, baskalarindan ${isaret(diger)} sira">` +
    `${isaret(kendi)}<small class="izasDiger">${isaret(diger)}</small></span>`;
}

// Bir gostergeyi "ad deger" rozetine cevirir; deger yoksa rozet uretilmez.
function rozet(ad, deger, sinif = "") {
  if (deger === null || deger === undefined || deger === "") return "";
  return `<span class="pd-oge ${sinif}"><i>${ad}</i><b>${deger}</b></span>`;
}

const sayi1 = (v) => (v == null ? null : (+v).toFixed(1));
const sayi2 = (v) => (v == null ? null : (+v).toFixed(2));
const tam = (v) => (v == null ? null : String(Math.round(v)));

// Bir sembolun piyasa satirindan anasayfadakiyle AYNI gostergeleri cizer.
//
// `satir`: /yerel/emirler yanitindaki `piyasa[SEMBOL]` kaydi (52 alan).
// Satir yoksa (coin rank veritabaninda degil) bos dizge doner -- uydurma
// deger URETILMEZ.
export function renderMarketDetail(satir) {
  if (!satir) return `<div class="piyasaDetay bos">piyasa verisi yok</div>`;
  const y = (v) => (v == null ? null : formatSigned(v, 1));
  const yonSinif = (v) => (v > 0 ? "arti" : v < 0 ? "eksi" : "");
  const obv = satir.obv_kesim;
  return `<div class="piyasaDetay">
    ${rozet("sira", satir.rank == null ? null : "#" + satir.rank)}
    <span class="pd-oge pd-iz"><i>iz</i>${renderTrailCell(satir.sira_izi)}</span>
    <span class="pd-oge ${satir.izas > 0 ? "arti" : satir.izas < 0 ? "eksi" : ""}"><i>izas</i><b>${renderOwnShareCell(satir.izas, satir.izas_diger)}</b></span>
    ${rozet("fiyat", satir.fiyat == null ? null : formatPrice(satir.fiyat))}
    ${rozet("24s", y(satir.deg24), yonSinif(satir.deg24))}
    ${rozet("gun", y(satir.gun_pct), yonSinif(satir.gun_pct))}
    ${rozet("hiz", sayi1(satir.hiz), yonSinif(satir.hiz))}
    ${rozet("ATR%", sayi2(satir.atr_pct))}
    ${rozet("RSI", tam(satir.rsi))}
    ${rozet("CCI", tam(satir.cci))}
    ${rozet("KDJ-J", tam(satir.kdj_j))}
    ${rozet("xH", sayi2(satir.hacim_x))}
    ${rozet("OBV", obv == null ? null
        : `${obv > 0 ? "▲" : "▼"}${Math.abs(obv) - 1}b`, yonSinif(obv))}
    ${rozet("HA", tam(satir.ha_ardisik_yesil))}
    ${rozet("sHIZ", tam(satir.rank_hiz))}
    ${rozet("sATR", tam(satir.rank_atr))}
  </div>`;
}
