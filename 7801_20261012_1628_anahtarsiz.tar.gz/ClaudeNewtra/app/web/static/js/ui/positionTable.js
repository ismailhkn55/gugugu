// positionTable.js -- acik emir / takipteki pozisyon / kapanmis islem
// kartlari. Ucu de AYNI duzeni kullanir (eski sistemde her biri ayri
// tabloydu ve hicbiri hizali degildi).
//
// DUZEN (23.09.2026, Ismail: "en solda sadece coin adi, sonrasinda 3
// satir alt alta koy ve degerleri yaz, kayma olmasin, duzenli
// gozuksun"):
//
//   +--------+-----------------------------------------------+
//   |        | 1. satir: etiketler ... ozet% sure [dugmeler] |
//   | COIN   | 2. satir: GIRIS  fiyat  saat  tutar  adet     |
//   |        | 3. satir: SIMDI  fiyat  yuzde stop   hedef    |
//   +--------+-----------------------------------------------+
//
// 2. ve 3. satir AYNI sabit sutun izgarasini kullanir; bu yuzden
// degerler hem kart icinde hem KARTLAR ARASINDA alt alta gelir.
// Coin adi kendi sutununda, 3 satiri da kaplar.
import { formatPrice, formatSigned, formatUsdt, buttonLabel, formatClock,
         formatDuration, coinName } from "../format.js";
import { renderMarketDetail } from "./marketDetail.js";

// Tutulma suresi -- `format.formatDuration` ZATEN bu isi yapiyor; ikinci
// bir kopya yazmak yerine sadece iki zaman damgasinin farki veriliyor.
const tutus = (bas, son) => (bas ? formatDuration((son || Date.now()) - bas) : "·");

const h = (v) => (v == null || v === "" ? "—" : v);

// Kartin govdesini kurar: sol sutun coin adi, sag sutun 3 satir.
function kartGovde({ sembol, canli, ustOgeler, satir2, satir3, piyasaSatiri }) {
  return `
    <div class="ik-sol">
      <span class="ik-ad pozSembol" title="${sembol}">${coinName(sembol)}</span>
      <span class="modEt ${canli ? "canli" : "kagit"}">${canli ? "CANLI" : "KAGIT"}</span>
    </div>
    <div class="ik-sag">
      <div class="ik-s1">${ustOgeler}</div>
      ${satir2}
      ${satir3}
    </div>
    ${piyasaSatiri || ""}`;
}

// Bir deger satiri: etiket + 4 hucre (sabit sutunlar).
function degerSatiri(etiket, hucreler) {
  return `<span class="ik-et">${etiket}</span>`
       + hucreler.map((x) => `<span class="ik-d">${x}</span>`).join("");
}

// `emirler`: /yerel/emirler yaniti. `live`: hangi defter (null = hepsi).
// `piyasa`: sembol -> anlik gosterge satiri. `fiyatlar`: sembol -> anlik fiyat.
//
// ACIK emirlerde "K/Z" gosterilmez: emir dolmadigi icin kar/zarar diye bir
// sey yoktur; onun yerine piyasanin limite gore nerede oldugu yazilir.
export function renderPositionTable(kapId, emirler, { live = null, tur = "takip",
                                                      fiyatlar = {},
                                                      piyasa = {},
                                                      sadece = null,
                                                      detay = true } = {}) {
  const kap = document.getElementById(kapId);
  if (!kap) return;
  let liste = (emirler?.[tur] || []);
  if (live !== null) liste = liste.filter((e) => (e._live ?? e.canli) === live);
  if (sadece === "bot") liste = liste.filter((e) => !e.el_kaynak);
  if (sadece === "el") liste = liste.filter((e) => !!e.el_kaynak);
  // "botVeKagit": botun actiklari (her modda) + KAGIT'ta elle acilanlar
  // (DRYRUN GIRIS). 26.09.2026: kagit elle girisler hicbir sayfada gorunmuyordu.
  if (sadece === "botVeKagit")
    liste = liste.filter((e) => !e.el_kaynak || !(e._live ?? e.canli));
  if (!liste.length) {
    kap.innerHTML = `<div class="bos">${tur === "acik" ? "acik emir yok" : "acik pozisyon yok"}</div>`;
    return;
  }
  const bekleyen = tur === "acik";

  kap.innerHTML = liste.map((e) => {
    const canli = e._live ?? e.canli;
    const giris = +(e.dolan_fiyat || e.fiyat);
    const f = fiyatlar[e.sembol] ?? piyasa[e.sembol]?.fiyat;
    const oran = f ? (f / giris - 1) * 100 : null;
    // Bekleyende piyasanin limitin USTUNDE olmasi kotudur (dolmaz);
    // dolmus pozisyonda fiyatin yukarida olmasi iyidir.
    const iyi = bekleyen ? oran < 0 : oran > 0;
    const durumSinif = oran == null ? "" : iyi ? "kazanc" : "kayip";
    const isaretSinif = oran == null ? "" : iyi ? "arti" : "eksi";
    const zaman = e.dolum_ts || e.ts;

    // YAPAY ZEKA MIMO (24.09.2026): yontem_label (uzlastirma) once okunur.
    const ust = `
      <span class="ik-etiket">${buttonLabel(e.yontem_label || e.el_kaynak || e.kaynak)}</span>
      ${bekleyen ? `<span class="ik-etiket">BEKLIYOR</span>` : ""}
      <span class="ik-net pozKzUst ${isaretSinif}"
            title="${bekleyen ? "piyasanin limite gore konumu" : "acik kar/zarar"}">${
        oran == null ? "—" : formatSigned(oran)}</span>
      <span class="ik-sure">${tutus(zaman)}</span>
      <span class="pozEylem">
        <button class="minik" data-eylem="yontem">YONTEM</button>
        <button class="minik ${bekleyen ? "iptalBtn" : "kapatBtn"}"
                data-eylem="${bekleyen ? "iptal" : "kapat"}">${bekleyen ? "IPTAL" : "KAPAT"}</button>
      </span>`;

    const s2 = degerSatiri(bekleyen ? "LIMIT" : "GIRIS", [
      formatPrice(giris), formatClock(zaman),
      `${formatUsdt(e.tutar)} USDT`, `${h(e.dolan_miktar ?? e.miktar)} adet`]);

    const s3 = `<span class="ik-et">${bekleyen ? "PIYASA" : "SIMDI"}</span>`
      + `<span class="ik-d pozSimdi">${f ? formatPrice(f) : "·"}</span>`
      + `<span class="ik-d pozKz ${isaretSinif}">${oran == null ? "—" : formatSigned(oran)}</span>`
      + `<span class="ik-d">stop ${h(e.stop_guncel ?? e.stop ? formatPrice(e.stop_guncel ?? e.stop) : null)}</span>`
      + `<span class="ik-d">hedef ${e.kar_al ? formatPrice(e.kar_al) : "trailing"}</span>`;

    const piyasaSatiri = detay
      ? `<div class="ik-piyasa">${renderMarketDetail(piyasa[e.sembol])}</div>` : "";

    return `<div class="islemKart pozKart ${durumSinif}"
                 data-id="${e.id}" data-live="${canli}" data-sembol="${e.sembol}"
                 data-giris="${giris}" data-bekleyen="${bekleyen ? 1 : 0}">${
      kartGovde({ sembol: e.sembol, canli, ustOgeler: ust,
                  satir2: s2, satir3: s3, piyasaSatiri })}</div>`;
  }).join("");
}

// Websocket fiyatiyla SIMDI ve yuzde hucrelerini tazeler -- kart yeniden
// cizilmeden. Tum karti her tikte yeniden yazmak hem pahali hem de
// tiklamayi bozuyor; yalnizca ilgili hucreler guncellenir.
export function updatePositionPrices(kapId, sembol, fiyat) {
  const kap = document.getElementById(kapId);
  if (!kap || fiyat == null) return;
  for (const kart of kap.querySelectorAll(`[data-sembol="${sembol}"]`)) {
    const simdi = kart.querySelector(".pozSimdi");
    if (simdi) simdi.textContent = formatPrice(fiyat);
    const hucreler = [...kart.querySelectorAll(".pozKz, .pozKzUst")];
    const giris = +(kart.dataset.giris || 0);
    if (!hucreler.length || !giris) continue;
    const oran = (fiyat / giris - 1) * 100;
    const bekleyen = kart.dataset.bekleyen === "1";
    const iyi = bekleyen ? oran < 0 : oran > 0;
    for (const x of hucreler) {
      x.textContent = formatSigned(oran);
      x.classList.toggle("arti", iyi);
      x.classList.toggle("eksi", !iyi && oran !== 0);
    }
    kart.classList.toggle("kazanc", iyi);
    kart.classList.toggle("kayip", !iyi && oran !== 0);
  }
}

// KAPANMIS ISLEMLER -- acik pozisyonlarla AYNI duzen.
//
// `giris_piyasa` / `cikis_piyasa` varsa (23.09.2026 sonrasi islemler) o
// anin gosterge degerleri de cizilir. Daha ESKI kayitlarda bu alanlar
// yoktur -- uydurulmaz, sadece gosterilmez.
export function renderClosedTrades(kapId, gecmis) {
  const kap = document.getElementById(kapId);
  if (!kap) return;
  const liste = gecmis || [];
  if (!liste.length) {
    kap.innerHTML = `<div class="bos">kapanmis islem yok</div>`;
    return;
  }
  kap.innerHTML = liste.map((e) => {
    const canli = e._live ?? e.canli;
    const giris = +(e.dolan_fiyat || e.fiyat);
    const cikis = e.kapanis?.fiyat;
    const net = e.kar_p;
    const gt = e.dolum_ts || e.ts;
    const ct = e.kapanis?.ts;
    // YAPAY ZEKA MIMO (24.09.2026): komisyon dahil NET kar'a gore renk.
    // > 0 yesil · < 0 kirmizi (komisyon kurtarmadi) · == 0 BEYAZ (sıfır).
    const netVar = net !== null && net !== undefined && !Number.isNaN(+net);
    const durumSinif = !netVar ? "" : +net > 0 ? "kazanc" : +net < 0 ? "kayip" : "sifir";
    const isaretSinif = !netVar ? "" : +net > 0 ? "arti" : +net < 0 ? "eksi" : "sifir";

    const ust = `
      <span class="ik-etiket">${buttonLabel(e.yontem_label || e.el_kaynak || e.kaynak)}</span>
      ${e.strateji ? `<span class="ik-etiket">${e.strateji}</span>` : ""}
      <span class="ik-net ${isaretSinif}">${net == null ? "—" : formatSigned(net)}</span>
      <span class="ik-sure">${tutus(gt, ct)}</span>`;

    const s2 = degerSatiri("GIRIS", [
      formatPrice(giris), formatClock(gt),
      `${formatUsdt(e.tutar)} USDT`, `${h(e.dolan_miktar ?? e.miktar)} adet`]);

    const s3 = degerSatiri("CIKIS", [
      cikis == null ? "—" : formatPrice(cikis),
      h(ct ? formatClock(ct) : null),
      h(e.kapanis?.sebep),
      h(e.kar == null ? null : `${formatUsdt(e.kar, 4)} USDT`),
      h(e.komisyon_usdt == null ? null : `kom ${formatUsdt(e.komisyon_usdt, 4)}`)]);

    const piyasaSatiri = (e.giris_piyasa || e.cikis_piyasa) ? `
      ${e.giris_piyasa ? `<div class="ik-piyasa"><span class="ik-pbas">giriste</span>
        ${renderMarketDetail(e.giris_piyasa)}</div>` : ""}
      ${e.cikis_piyasa ? `<div class="ik-piyasa"><span class="ik-pbas">cikista</span>
        ${renderMarketDetail(e.cikis_piyasa)}</div>` : ""}` : "";

    return `<div class="islemKart ${durumSinif}" data-sembol="${e.sembol}">${
      kartGovde({ sembol: e.sembol, canli, ustOgeler: ust,
                  satir2: s2, satir3: s3, piyasaSatiri })}</div>`;
  }).join("");
}
