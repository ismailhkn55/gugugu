// fullscreen.js -- tam ekran ve ekran yonu.
//
// HTTP sayfalarda bazi tarayicilar fullscreen'i reddeder; sessizce
// basarisiz olmak yerine kullaniciya NE YAPACAGI soylenir.
import { showToast } from "./toast.js";

// Tarayici tam ekran modunda mi.
export function isFullscreen() {
  return !!(document.fullscreenElement || document.webkitFullscreenElement);
}

// Tam ekrana gecer; istege bagli olarak ekran yonunu kilitler.
export async function enterFullscreen(yon) {
  const e = document.documentElement;
  const istek = e.requestFullscreen || e.webkitRequestFullscreen;
  if (!istek) {
    showToast("Bu tarayici tam ekrani desteklemiyor — F11 tusunu kullan", "uyari", 6000);
    return false;
  }
  try {
    await istek.call(e);
  } catch (_) {
    showToast("Tam ekran engellendi. HTTP sayfalarda tarayici izin vermeyebilir — "
              + "F11 tusuna bas ya da HTTPS kullan.", "uyari", 7000);
    return false;
  }
  if (yon && screen.orientation?.lock) {
    screen.orientation.lock(yon).catch(() => {});
  }
  return true;
}

// Tam ekran modundan cikar.
export async function exitFullscreen() {
  if (!isFullscreen()) return;
  try { await (document.exitFullscreen || document.webkitExitFullscreen).call(document); }
  catch (_) {}
}

// Tam ekrani acar/kapatir.
export async function toggleFullscreen(yon) {
  return isFullscreen() ? (await exitFullscreen(), false) : enterFullscreen(yon);
}

