// methodPicker.js -- acik pozisyonun CIKIS YONTEMINI degistirme penceresi.
// Iskeletteki `#yontemPerde` / `#yontemListe` / `#yontemKapat` kullanilir.
import { apiPost } from "../api.js";
import { closePerde, openPerde } from "./perde.js";
import { showToast } from "./toast.js";

// Secenekler: her biri farkli bir CIKIS PLANI uretir (trading/exit_rules).
export const YONTEMLER = [
  { k: "al", ad: "AL", not: "kademeli stop merdiveni — trailing yok" },
  { k: "altakip", ad: "AL TAKIP", not: "botla AYNI: esikten sonra ATR olcekli iz surme" },
  { k: "alsat1", ad: "ALSAT 1", not: "sabit hedef (alsat_hedef_1)" },
  { k: "alsat2", ad: "ALSAT 2", not: "sabit hedef (alsat_hedef_2)" },
  { k: "alsat3", ad: "ALSAT 3", not: "sabit hedef (alsat_hedef_3)" },
];

// Pencereyi acar. `onDegisti` basarili degisimden sonra cagrilir.  (eski: yontemAc)
export function openMethodPicker(emir, onDegisti) {
  const liste = document.getElementById("yontemListe");
  if (!liste) return;
  const suan = emir.el_kaynak || null;
  liste.innerHTML = YONTEMLER.map((y) => `
    <button class="yontemSecenek ${y.k === suan ? "aktif" : ""}" data-y="${y.k}">
      <b>${y.ad}</b><small>${y.not}</small>
    </button>`).join("");

  const tik = async (e) => {
    const y = e.target.closest("[data-y]")?.dataset.y;
    if (!y) return;
    const c = await apiPost("/yerel/yontem-degistir",
      { id: emir.id, canli: emir._live ?? emir.canli, yontem: y });
    if (c?.ok) {
      showToast("YONTEM DEGISTI", "bilgi", 3000);
      closePerde("yontemPerde");
      onDegisti?.(c.emir);
    }
  };
  liste.addEventListener("click", tik);
  openPerde("yontemPerde", { onClose: () => liste.removeEventListener("click", tik) });
}

// Yontem secici penceresinin kapatma olaylarini baglar.
export function baglaYontemKapat() {
  document.getElementById("yontemKapat")
    ?.addEventListener("click", () => closePerde("yontemPerde"));
}
