// toast.js -- kisa bildirim.
//
// DUZELTME (23.09.2026): ilk yazimda kendi `#toastKap` / `.toast-hata`
// isaretlememi uydurmustum -- o siniflarin CSS'i YOK, bildirimler
// BICIMSIZ cikiyordu. Iskelette zaten `#toastlar` kabi ve `.toast`
// (.tb baslik / .tm metin) yapisi var; stil dosyasi 80-bildirim.css.
// Ders: yeni isaretleme uydurmadan once var olani ARA.

// CSS'te tanimli tur siniflari (80-bildirim.css).
const TURLER = new Set(["kar", "zarar", "hata", "bilgi", "alis", "satis", "iptal"]);
const ESLEME = { ok: "kar", uyari: "iptal", basari: "kar" };

function kap() {
  return document.getElementById("toastlar");
}

// Bildirim gosterir. `tur`: kar | zarar | hata | bilgi | alis | satis | iptal
// (ok/uyari/basari da kabul edilir, CSS karsiligina eslenir).  (eski: toast)
// Kisa bildirim baloncugu gosterir.
export function showToast(baslik, tur = "bilgi", msSure, mesaj) {
  const k = kap();
  if (!k) { console.log("[toast]", baslik, mesaj || ""); return null; }
  const sinif = TURLER.has(tur) ? tur : (ESLEME[tur] || "bilgi");
  const e = document.createElement("div");
  e.className = `toast ${sinif}`;
  const bas = document.createElement("div");
  bas.className = "tb";
  bas.textContent = String(baslik);
  e.appendChild(bas);
  if (mesaj) {
    const m = document.createElement("div");
    m.className = "tm";
    m.textContent = String(mesaj);
    e.appendChild(m);
  }
  k.appendChild(e);
  const sure = msSure ?? (sinif === "hata" ? 7000 : 3200);
  const z = setTimeout(() => dismissToast(e), sure);
  e.addEventListener("click", () => { clearTimeout(z); dismissToast(e); });
  return e;
}

// Baslik + aciklama ile bildirim (eski `toast(baslik, mesaj, tur, sure)` karsiligi).
export function showToastDetail(baslik, mesaj, tur = "bilgi", msSure) {
  return showToast(baslik, tur, msSure, mesaj);
}

// Acik bildirimi kapatir.
export function dismissToast(e) {
  if (!e || !e.parentNode) return;
  e.classList.add("gider");
  setTimeout(() => e.remove(), 260);
}
