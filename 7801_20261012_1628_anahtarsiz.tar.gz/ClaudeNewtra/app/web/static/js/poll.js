// poll.js -- TEK zamanlayici kayit defteri.
//
// ESKI SISTEM:
//   * `/yerel/emirler` IKI BAGIMSIZ kanaldan, ikisi de 10 saniyede bir
//     cekiliyordu (`izIslemleriYukle` + `emirleriYenile`).
//   * `sayfaGit` zaten interval'de olan yenileyicileri TEKRAR cagiriyordu.
//   * Toplam 6 setInterval, hicbiri merkezden gorunmuyordu.
//
// 23.09.2026 -- KILITLENME DUZELTMESI: ilk yazimimda kayitli her is
// SONSUZA KADAR calisiyordu; sayfadan cikinca durmuyordu. Kullanici tum
// sayfalari gezdikten sonra AYNI ANDA 12 dongu doniyordu: ana tablo 10
// sn'de bir 213x28 hucre yeniden ciziyor, islem sayfasi 2016 mumu yeniden
// ciziyor, kazananlar 12 ayri mum istegi atiyordu. Tarayici kitleniyordu.
//
// Artik her is bir SAYFAYA bagli: yalnizca o sayfa acikken doner.
// `sayfa` verilmeyen isler (ayar gibi) her zaman doner.
// Sekme arka plana alininca (document.hidden) HEPSI durur.

const _isler = new Map();
let _aktifSayfa = null;
let _calisiyor = false;

// Bir yenileme isi kaydeder. `sayfa` verilirse YALNIZCA o sayfa acikken doner.
export function registerPoll(ad, saniye, cagri, { hemen = true, sayfa = null } = {}) {
  if (_isler.has(ad)) return ad;        // ayni ad iki kez kaydedilemez
  _isler.set(ad, {
    ad, sn: saniye, cagri, sayfa, dinleyiciler: new Set(),
    zaman: null, calisiyor: false, sonVeri: null, sonTur: 0,
  });
  if (hemen && _uygun(_isler.get(ad))) _turAt(_isler.get(ad));
  if (_calisiyor) _zamanlayiciyiAyarla(_isler.get(ad));
  return ad;
}

// Isin sonucuna abone olur; aboneligi iptal eden fonksiyon doner.
export function sharePollResult(ad, dinleyici) {
  const is = _isler.get(ad);
  if (!is) throw new Error(`bilinmeyen zamanlayici: ${ad}`);
  is.dinleyiciler.add(dinleyici);
  if (is.sonVeri !== null) dinleyici(is.sonVeri);
  return () => is.dinleyiciler.delete(dinleyici);
}

function _uygun(is) {
  if (document.hidden) return false;              // sekme arka planda
  return !is.sayfa || is.sayfa === _aktifSayfa;   // sayfaya bagli mi
}

async function _turAt(is) {
  if (is.calisiyor || !_uygun(is)) return;
  is.calisiyor = true;
  try {
    const veri = await is.cagri();
    if (veri !== null && veri !== undefined) {
      is.sonVeri = veri;
      is.sonTur = Date.now();
      for (const d of is.dinleyiciler) {
        try { d(veri); } catch (e) { console.error("[poll]", is.ad, e); }
      }
    }
  } finally {
    is.calisiyor = false;
  }
}

function _zamanlayiciyiAyarla(is) {
  if (is.zaman) { clearInterval(is.zaman); is.zaman = null; }
  if (!_calisiyor || !_uygun(is)) return;
  is.zaman = setInterval(() => _turAt(is), is.sn * 1000);
}

// Aktif sayfayi bildirir: baska sayfalarin isleri DURUR, bu sayfanınkiler
// baslar ve hemen bir tur atar.
// Aktif sayfayi bildirir; sayfaya bagli isler buna gore doner.
export function setActivePage(sayfa) {
  if (_aktifSayfa === sayfa) return;
  _aktifSayfa = sayfa;
  for (const is of _isler.values()) {
    const oncekiVardi = !!is.zaman;
    _zamanlayiciyiAyarla(is);
    if (!oncekiVardi && is.zaman) _turAt(is);     // sayfaya girince taze veri
  }
}

// O an aktif olan sayfanin adi.
export const getActivePage = () => _aktifSayfa;

// Kayitli tum zamanlayicilari baslatir.
export function startPolling() {
  _calisiyor = true;
  for (const is of _isler.values()) _zamanlayiciyiAyarla(is);
}


// Elle yenileme: interval'i SIFIRLAR, boylece hemen sonra bir tur daha atmaz.
export function refreshNow(ad) {
  const hedefler = ad ? [_isler.get(ad)].filter(Boolean)
                      : [..._isler.values()].filter(_uygun);
  // SOZ dondurur: arayuz "yukleniyor" gostergesini gercek bitise
  // baglayabilsin diye (bkz. shell.js/manualRefresh).
  return Promise.all(hedefler.map((is) => {
    _zamanlayiciyiAyarla(is);
    return _turAt(is);
  }));
}

// Kayitli isler ve son tur bilgileri (hata ayiklama / saglik).
export function listPolls() {
  return [..._isler.values()].map((i) => ({
    ad: i.ad, sn: i.sn, sayfa: i.sayfa, aktif: !!i.zaman,
    dinleyici: i.dinleyiciler.size,
    sonTurSnOnce: i.sonTur ? Math.round((Date.now() - i.sonTur) / 1000) : null,
  }));
}

// Sekme arka plana alininca TUM isler durur, one gelince devam eder.
document.addEventListener("visibilitychange", () => {
  for (const is of _isler.values()) _zamanlayiciyiAyarla(is);
  if (!document.hidden) refreshNow();
});
