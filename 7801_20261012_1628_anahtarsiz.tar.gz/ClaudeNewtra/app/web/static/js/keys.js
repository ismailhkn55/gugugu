// keys.js -- TEK klavye yonlendiricisi + modal yigini.
//
// ESKI SISTEM: `document` uzerinde DORT ayri `keydown` dinleyicisi vardi
// (2811 menu, 2928 not, 2962 yontem, 6634 "r"). Ucunde de Escape
// yakalaniyordu, yani TEK Escape basisi UC katmani birden kapatiyordu --
// not okurken Escape hem notu hem menuyu kapatiyordu. Onay penceresinin
// ise Escape isleyicisi HIC YOKTU (tutarsizlik).
//
// Burada Escape YALNIZCA yigindaki EN USTTEKI katmani kapatir.

const _kisayollar = new Map();   // "escape" -> [fn]
const _yigin = [];               // acik modal katmanlari

// Kisayol kaydi. Iptal eden fonksiyon doner.
export function registerShortcut(tus, geri, { ctrl = false } = {}) {
  const k = (ctrl ? "ctrl+" : "") + tus.toLowerCase();
  if (!_kisayollar.has(k)) _kisayollar.set(k, []);
  _kisayollar.get(k).push(geri);
  return () => {
    const liste = _kisayollar.get(k) || [];
    const i = liste.indexOf(geri);
    if (i >= 0) liste.splice(i, 1);
  };
}

// Modal katmanini yigina ekler.
export function pushModalLayer(ad, kapat) {
  _yigin.push({ ad, kapat });
  return () => {
    const i = _yigin.findIndex((x) => x.kapat === kapat);
    if (i >= 0) _yigin.splice(i, 1);
  };
}

// En ustteki katmani kapatir; katman yoksa false doner.
export function popModalLayer() {
  const ust = _yigin.pop();
  if (!ust) return false;
  try { ust.kapat(); } catch (e) { console.error("[keys]", e); }
  return true;
}


// Merkezi klavye yonlendiricisi.
export function handleKeyDown(olay) {
  if (["INPUT", "TEXTAREA", "SELECT"].includes(olay.target?.tagName)) {
    if (olay.key !== "Escape") return;
  }
  if (olay.key === "Escape") {
    if (popModalLayer()) { olay.preventDefault(); return; }
  }
  const k = (olay.ctrlKey ? "ctrl+" : "") + olay.key.toLowerCase();
  const liste = _kisayollar.get(k);
  if (liste && liste.length) {
    olay.preventDefault();
    liste[liste.length - 1](olay);
  }
}

// Merkezi klavye yonlendiricisini belgeye baglar.
export function baglaKlavye() {
  document.addEventListener("keydown", handleKeyDown);
}
