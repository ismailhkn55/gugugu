// store.js -- uygulama durumu.
//
// ESKI SISTEM: ~95 ust seviye global degisken vardi. `MUM_GENISLIK`'in BES,
// `LIMIT_*`'in DORT ayri yazicisi vardi; kimin ne zaman degistirdigi
// izlenemiyordu. `gecmisSinyalYukle` her 60 saniyede `IZ_STRATEJI_ACIK`i
// zorla `true` yapip kullanicinin dugme tercihini EZIYORDU.
//
// Burada durum tek yerde, degisiklikler abonelere duyuruluyor ve
// KULLANICI TERCIHLERI ayri tutuluyor -- yenileme donguleri onlara dokunamaz.

const _durum = {
  // --- sunucudan gelen ---
  satirlar: [],          // /yerel/ozet
  emirler: { acik: [], takip: [], kapali: [] },
  ayar: {},
  sema: [],
  stratejiler: [],
  adaylar: [],
  kazananlar: [],
  bot: {},
  cuzdan: {},
  notlar: [],
  haric: [],
  // --- arayuz durumu ---
  sayfa: "trade",
  seciliSembol: null,
  baglanti: "kapali",
};

// KULLANICI TERCIHLERI. Yalnizca kullanici eylemiyle degisir; yenileme
// donguleri buraya ASLA yazmaz (F1'in cozumu).
const _tercih = {
  izCuzdan: false,
  izStrateji: false,
  tema: "koyu",
  gorunum: "yatay",
  gosterge: {},
};

const _aboneler = new Map();
let _sonrakiId = 1;

// Durumu okur (kopya degil, salt okunur kullanin).
export function getState(anahtar) {
  return anahtar ? _durum[anahtar] : _durum;
}

// Durumu gunceller ve ilgili aboneleri uyarir.
export function setState(yamalar) {
  const degisen = [];
  for (const [k, v] of Object.entries(yamalar || {})) {
    if (_durum[k] !== v) { _durum[k] = v; degisen.push(k); }
  }
  if (degisen.length) _duyur(degisen);
  return degisen;
}

// Durum degisimine abone olur; aboneligi iptal eden fonksiyon doner.
export function subscribeState(anahtarlar, geri) {
  const id = _sonrakiId++;
  _aboneler.set(id, { anahtarlar: new Set([].concat(anahtarlar)), geri });
  return () => _aboneler.delete(id);
}

function _duyur(degisen) {
  for (const { anahtarlar, geri } of _aboneler.values()) {
    if (degisen.some((k) => anahtarlar.has(k))) {
      try { geri(_durum, degisen); } catch (e) { console.error("[store]", e); }
    }
  }
}

// --- kullanici tercihleri ---

// Kullanici tercihini okur (anahtarsiz cagrilirsa tumunu).
export function getTercih(anahtar) {
  return anahtar ? _tercih[anahtar] : _tercih;
}

// Tercihi YALNIZCA kullanici eylemiyle degistirin.
export function setTercih(anahtar, deger) {
  _tercih[anahtar] = deger;
  try { localStorage.setItem("cn-tercih", JSON.stringify(_tercih)); } catch (_) {}
  _duyur(["tercih:" + anahtar]);
}

// Tercihleri `localStorage`'dan okuyup bellege alir.
export function tercihleriYukle() {
  try {
    Object.assign(_tercih, JSON.parse(localStorage.getItem("cn-tercih") || "{}"));
  } catch (_) {}
  return _tercih;
}

// --- secilenler ---
// Anasayfa coin tablosunun satirlari.
export const selectRows = () => _durum.satirlar;
