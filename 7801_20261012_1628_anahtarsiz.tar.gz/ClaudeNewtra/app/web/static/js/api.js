// api.js -- sunucuyla konusmanin TEK noktasi.
//
// ESKI SISTEM: 27 `fetch` cagrisindan yalnizca ~8'i sarmalayiciyi (`jget`)
// kullaniyordu. Kalan 19'unda `r.ok` KONTROLU YOKTU ve hata `catch(_){}`
// ile SESSIZCE yutuluyordu -- sunucu 500 donse bile arayuz eski veriyi
// gosterip hic uyarmiyordu. "Calismiyor ama hata da yok" sikayetinin ana
// kaynagi buydu.
//
// Burada her istek `r.ok` kontrollu, her hata gorunur.

import { showToast } from "./ui/toast.js";

// Sunucu koku. Uygulama hem kendi portundan (7801) hem de panel4'un
// nginx'i altindaki /cn/ alt yolundan servis ediliyor; TABAN sayfanin
// kendi yolundan turetilir ki iki durumda da ayni kod calissin.
// (Varliklar zaten goreli; mutlak olan yalniz /yerel/... API yollariydi.)
const TABAN = location.pathname.replace(/\/[^/]*$/, "").replace(/\/+$/, "");
let _hataSayaci = 0;

// Istek zaman asimi ve iptal denetleyicisi uretir.
function iptalDenetleyici(msSure = 20000) {
  const c = new AbortController();
  const z = setTimeout(() => c.abort(), msSure);
  return { signal: c.signal, bitir: () => clearTimeout(z) };
}

// Sunucu hatasini kullaniciya GORUNUR kilar.
export function apiError(yol, hata, { sessiz = false } = {}) {
  _hataSayaci++;
  const mesaj = `${yol}: ${hata?.message || hata}`;
  console.error("[api]", mesaj);
  if (!sessiz) showToast(mesaj, "hata");
  return null;
}


// TEK GET noktasi. `r.ok` ZORUNLU.  (eski: jget)
export async function apiGet(yol, { sessiz = false, msSure } = {}) {
  const { signal, bitir } = iptalDenetleyici(msSure);
  try {
    const r = await fetch(TABAN + yol, { cache: "no-store", signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } catch (e) {
    if (e.name === "AbortError") return apiError(yol, "zaman asimi", { sessiz });
    return apiError(yol, e, { sessiz });
  } finally {
    bitir();
  }
}

// TEK POST noktasi.  (eski: gonder)
export async function apiPost(yol, govde, { sessiz = false, msSure } = {}) {
  const { signal, bitir } = iptalDenetleyici(msSure);
  try {
    const r = await fetch(TABAN + yol, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(govde || {}),
      cache: "no-store",
      signal,
    });
    const veri = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(veri.hata || `HTTP ${r.status}`);
    return veri;
  } catch (e) {
    if (e.name === "AbortError") return apiError(yol, "zaman asimi", { sessiz });
    return apiError(yol, e, { sessiz });
  } finally {
    bitir();
  }
}

// Sayfa degisiminde tum acik istekleri iptal etmek icin ortak denetleyici.
let _sayfaDenetleyici = new AbortController();


// Acik tum istekleri iptal eder ve yeni denetleyici kurar.
export function iptalEtHepsini() {
  _sayfaDenetleyici.abort();
  _sayfaDenetleyici = new AbortController();
}
