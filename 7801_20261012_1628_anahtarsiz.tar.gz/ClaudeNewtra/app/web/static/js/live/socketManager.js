// socketManager.js -- TEK abone-ol/cik yoneticisi.
//
// ESKI SISTEM: IKI ayri websocket yoneticisi vardi (`POZ_WS` 5631 ve
// `ANA_WS` 5703) ve kodun kendi yorumu bunu itiraf ediyordu:
// "anasayfa ilk-30 icin canli fiyat (WS) -- POZ_WS ile AYNI desen".
// Ayni abone-ol/abonelikten-cik mantigi iki kere yaziliydi.

// Binance birlesik akis ucu. Akis listesi ADRESTE TASINMAZ; baglanti
// kurulduktan sonra SUBSCRIBE/UNSUBSCRIBE mesajlariyla yonetilir.
//
// 23.09.2026, Ismail: "websocketi kapatmadan ekle websocket'e".
// Onceki surumde abonelik kumesi her degistiginde soket KAPATILIP yeni
// adresle yeniden aciliyordu: el sikisma (~300-800 ms) boyunca fiyat
// akmiyor, Binance'e gereksiz baglanti gidiyordu. Binance birlesik akis
// zaten canli baglanti uzerinde abonelik degisikligini destekliyor.
const WS_URL = "wss://stream.binance.com:9443/stream";

// Abonelik bosaldiktan sonra soketi kapatmadan once beklenen sure.
//
// 23.09.2026 OLCUM: sayfa gezinti testinde 6 tur boyunca 6 soket
// KURULDU ve HICBIRI ACILAMADI (ws 0/6). Sebep: sayfadan cikarken
// abonelik HEMEN birakiliyor, soket daha el sikismayi bitirmeden
// kapaniyordu. Bu sure icinde sayfaya donulurse soket YERINDE kalir.
const BOSALTMA_GECIKME_MS = 20000;

// 03.10.2026, Ismail: "websocket trade ekraninda surekli kesiliyor".
// NABIZ: illikit coinde dakikalarca islem olmayabilir; olu baglanti ile sessiz
// coin ayirt edilemiyordu. Her baglantiya ~2 sn'de bir veri gonderen BTC 1dk mum
// akisi eklenir (fiyat olarak KULLANILMAZ). BEKCI_MS boyunca HICBIR mesaj gelmezse
// baglanti olu sayilir ve yeniden kurulur. Sekme/telefon uykudan donunce ya da
// internet geri gelince de hemen yeniden baglanilir.
const NABIZ_AKISI = "btcusdt@kline_1m";
const BEKCI_MS = 45000;
const BEKLE_TAVAN_MS = 8000;      // eskiden 30 sn'ye kadar uzayabiliyordu
const FARK_BEKLE_MS = 600;        // abonelik farki toplanip gonderilir (Binance 5 mesaj/sn siniri)

// (eski: POZ_WS + ANA_WS)
// `onGecikme(ms)`: saniyede en fazla bir kez, son mesajlarin ortalama
// gecikmesi (tarayici saati - Binance olay zamani `E`). Oyunlardaki ms gibi.
export function createSocketManager({ onFiyat, onDurum, onGecikme } = {}) {
  let gecikmeOrt = null, gecikmeSon = 0;
  let soket = null;
  let semboller = new Set();      // ISTENEN kume
  let abone = new Set();          // TELDE gecerli olan kume
  let surum = 0;
  let bekle = 1000;
  let mesajNo = 1;
  let bosaltmaZamani = null;
  let sonMesaj = 0;
  let farkZamani = null;
  const fiyatlar = new Map();

  const akisAdi = (s) => `${s.toLowerCase()}@aggTrade`;

  function bosaltmayiIptalEt() {
    if (bosaltmaZamani) { clearTimeout(bosaltmaZamani); bosaltmaZamani = null; }
  }

  function durumBildir(d, ek) {
    onDurum?.(d, ek);
  }

  function kapat() {
    bosaltmayiIptalEt();
    surum++;
    abone = new Set();
    if (soket) { try { soket.close(); } catch (_) {} soket = null; }
  }

  // Acik baglanti uzerinden abonelik FARKINI uygular.
  function farkiUygula() {
    if (!soket || soket.readyState !== WebSocket.OPEN) return false;
    const eklenecek = [...semboller].filter((s) => !abone.has(s));
    const cikarilacak = [...abone].filter((s) => !semboller.has(s));
    if (!eklenecek.length && !cikarilacak.length) return true;
    try {
      if (cikarilacak.length) {
        soket.send(JSON.stringify({ method: "UNSUBSCRIBE",
                                    params: cikarilacak.map(akisAdi), id: mesajNo++ }));
      }
      if (eklenecek.length) {
        soket.send(JSON.stringify({ method: "SUBSCRIBE",
                                    params: eklenecek.map(akisAdi), id: mesajNo++ }));
      }
    } catch (_) {
      return false;                 // gonderilemedi -> cagiran yeniden baglar
    }
    abone = new Set(semboller);
    durumBildir("canli", abone.size);
    return true;
  }

  function bagla() {
    if (!semboller.size) { kapat(); durumBildir("kapali"); return; }
    kapat();
    bosaltmayiIptalEt();
    const benimSurum = surum;
    const s = new WebSocket(WS_URL);
    soket = s;
    durumBildir("baglaniyor", semboller.size);

    s.onopen = () => {
      if (benimSurum !== surum) return;
      bekle = 1000;
      sonMesaj = Date.now();
      abone = new Set();
      try { s.send(JSON.stringify({ method: "SUBSCRIBE", params: [NABIZ_AKISI], id: mesajNo++ })); } catch (_) {}
      farkiUygula();                // acilista TUM kumeye abone ol
      durumBildir("canli", semboller.size);
    };
    s.onmessage = (olay) => {
      if (benimSurum !== surum) return;
      sonMesaj = Date.now();
      let m;
      try { m = JSON.parse(olay.data); } catch (_) { return; }
      // SUBSCRIBE/UNSUBSCRIBE yanitlari: {"result":null,"id":N} -- veri degil.
      if (m && m.result !== undefined && m.id !== undefined) return;
      const d = m.data || m;
      if (!d?.s || d?.p === undefined) return;
      const f = +d.p;
      if (!Number.isFinite(f)) return;
      if (d.E && onGecikme) {
        // Telefon saati Binance'ten biraz ileri/geri olabilir; eksiye dusmesin.
        const g = Math.max(0, Date.now() - d.E);
        gecikmeOrt = gecikmeOrt == null ? g : gecikmeOrt * 0.8 + g * 0.2;
        const simdi = Date.now();
        if (simdi - gecikmeSon >= 1000) { gecikmeSon = simdi; onGecikme(Math.round(gecikmeOrt)); }
      }
      const onceki = fiyatlar.get(d.s);
      fiyatlar.set(d.s, f);
      // 4. arguman: Binance islem zamani (T) -- canli mumun hangi 5 dk donemine
      // ait oldugunu cizici bilsin (yoksa yeni donemde ESKI mum uzatiliyordu).
      onFiyat?.(d.s, f, onceki, +d.T || +d.E || Date.now());
    };
    s.onclose = () => {
      if (benimSurum !== surum) return;
      abone = new Set();
      durumBildir("koptu");
      setTimeout(() => { if (benimSurum === surum) bagla(); }, bekle);
      bekle = Math.min(BEKLE_TAVAN_MS, bekle * 2);
    };
    s.onerror = () => { durumBildir("hata"); };
  }

  // BEKCI: acik gorunen ama veri gelmeyen (olu) baglantiyi yeniden kurar.
  setInterval(() => {
    if (!semboller.size || !soket || soket.readyState !== WebSocket.OPEN) return;
    if (Date.now() - sonMesaj > BEKCI_MS) { durumBildir("koptu"); bagla(); }
  }, 5000);
  // Sekme gorunur olunca / internet gelince: bagli degilse HEMEN yeniden baglan.
  const uyan = () => {
    if (document.visibilityState === "hidden" || !semboller.size) return;
    if (!soket || soket.readyState === WebSocket.CLOSED || soket.readyState === WebSocket.CLOSING
        || Date.now() - sonMesaj > BEKCI_MS) { bekle = 1000; bagla(); }
  };
  document.addEventListener("visibilitychange", uyan);
  window.addEventListener("online", uyan);

  return {
    // Abonelik kumesini gunceller.
    //
    // Soket ACIKSA kapatilmaz: yalnizca FARK kadar SUBSCRIBE/UNSUBSCRIBE
    // gonderilir. Kume BOSALIRSA soket hemen kapatilmaz;
    // `BOSALTMA_GECIKME_MS` kadar beklenir (bkz. yukaridaki olcum).
    subscribeSymbols(yeni) {
      const k = new Set([...yeni].filter(Boolean).map((x) => x.toUpperCase()));
      if (!k.size) {
        if (!semboller.size || bosaltmaZamani) return;
        bosaltmaZamani = setTimeout(() => {
          bosaltmaZamani = null;
          semboller = new Set();
          kapat();
          durumBildir("kapali");
        }, BOSALTMA_GECIKME_MS);
        return;
      }
      bosaltmayiIptalEt();
      const ayni = k.size === semboller.size && [...k].every((x) => semboller.has(x));
      semboller = k;
      if (ayni && soket) return;
      // 03.10.2026: soket HENUZ KURULUYORSA kapatip yeniden acma -- onopen TUM
      // kumeye abone olur. Eskiden kurulum sirasinda coin degisince soket
      // kapatilip bastan aciliyordu; sik degisimde baglanti hic acilamiyordu.
      if (soket && soket.readyState === WebSocket.CONNECTING) return;
      // Soket acikken YENIDEN BAGLANMA: farki tel uzerinden gonder.
      // 03.10.2026: Binance tek baglantida SANIYEDE EN FAZLA 5 kontrol mesajina izin
      // verir, asilirsa baglantiyi KESER. Her coin degisimi 2 mesaj (UNSUB+SUB);
      // hizli gezinmede sinir asilip baglanti kopuyordu. Fark FARK_BEKLE_MS
      // bekletilip TEK SEFERDE gonderilir.
      if (soket && soket.readyState === WebSocket.OPEN) {
        clearTimeout(farkZamani);
        farkZamani = setTimeout(() => { farkZamani = null; if (!farkiUygula()) bagla(); }, FARK_BEKLE_MS);
        return;
      }
      bagla();
    },
    getPrice: (s) => fiyatlar.get((s || "").toUpperCase()),
    getConnectionState: () => (soket ? ["baglaniyor", "canli", "kapaniyor", "kapali"][soket.readyState] : "kapali"),
    // Telde gecerli abonelik sayisi (tanilama).
    getSubscriptionCount: () => abone.size,
    close: kapat,
  };
}
