"""Statik dosya BEYAZ LISTESI.

Eski sunucu veri kokunu (`/DATA/AppData/Newtrade`) oldugu gibi statik
servis ediyordu. Sonuc olculdu:

    http://<makine>:7777/gizli/binance.json   -> HTTP 200

Yani Binance API anahtari ve secret, panele erisebilen HERKES tarafindan
tarayicidan okunabiliyordu. Panel `0.0.0.0`'da dinliyor ve Tailscale
uzerinden de erisilebilir durumda (log'da 100.101.80.77'den 175 istek),
yani anahtar tum tailnet'e acikti. `ayar.json` (Telegram token),
`defter_*.json`, `*.py` ve `.oncesi_*` yedekleri de ayni sekilde aciktı.

Kara liste yerine BEYAZ LISTE: arayuzun gercekten istedigi dosyalar
disinda hicbir sey servis edilmez. Olculdu -- index.html yalnizca kendisini,
telefon_onizleme.html'i ve fonts/*.woff2 istiyor.
"""
from __future__ import annotations

import os
import posixpath

# Tam ad eslesmesi gereken dosyalar.
PUBLIC_FILES: frozenset[str] = frozenset({
    "/index.html", "/telefon_onizleme.html", "/favicon.ico",
})
# (on ek, uzanti) ciftleri.
PUBLIC_PREFIXES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("/fonts/", (".woff2", ".woff")),
    ("/css/", (".css",)),
    ("/js/", (".js", ".mjs")),
)


# Bu yol tarayiciya statik dosya olarak verilebilir mi?
def is_public_asset(path: str) -> bool:
    yol = posixpath.normpath(path.split("?")[0])
    if not yol.startswith("/") or ".." in yol:
        return False
    if yol in PUBLIC_FILES:
        return True
    for onek, uzantilar in PUBLIC_PREFIXES:
        if yol.startswith(onek) and yol.endswith(uzantilar):
            # alt dizin derinligi sinirli: /js/pages/trade.js gecerli,
            # ama ".." ile disari cikilamaz (yukarida elendi)
            return True
    return False


# Istenen yolu statik dizindeki gercek dosyaya cevirir; disariya cikamaz.
def resolve_static_path(path: str, static_root: str) -> str | None:
    if not is_public_asset(path):
        return None
    yol = posixpath.normpath(path.split("?")[0]).lstrip("/")
    tam = os.path.normpath(os.path.join(static_root, yol))
    kok = os.path.normpath(static_root)
    if not tam.startswith(kok + os.sep) and tam != kok:
        return None
    return tam if os.path.isfile(tam) else None


# Uzantiya gore icerik tipi.
def guess_content_type(path: str) -> str:
    return {
        ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".mjs": "application/javascript; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".woff2": "font/woff2", ".woff": "font/woff",
        ".ico": "image/x-icon", ".svg": "image/svg+xml",
    }.get(os.path.splitext(path)[1].lower(), "application/octet-stream")
