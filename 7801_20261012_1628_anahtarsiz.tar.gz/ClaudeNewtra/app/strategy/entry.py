"""Giris karari -- SAF.

Eski `giris_uygun` iki yolluydu: `kurallar` listesi varsa onu kullaniyor,
yoksa 55 satirlik ESKI `giris` sozlugu dalina dusuyordu. Kayitli tek
strateji `kurallar` tasidigi icin o 55 satir ULASILAMAZDI. Burada yalnizca
kural listesi var; eski sozluk bicimi `registry` tarafindan goce birakilir.
"""
from __future__ import annotations

from typing import Any, Mapping

from app.strategy.rule_engine import RuleOutcome, evaluate_rule_set


# Bu satir stratejinin giris kurallarini geciyor mu?  (eski: giris_uygun)
def is_entry_allowed(row: Mapping[str, Any], strategy: Mapping[str, Any],
                     *, strict_fields: bool = True) -> dict:
    kurallar = strategy.get("kurallar") or []
    if not kurallar:
        return {"gecti": False, "red_gerekce": ["stratejide kural yok"],
                "hata_gerekce": [], "olculmedi_gerekce": [], "sonuclar": []}
    return evaluate_rule_set(row, kurallar, strict_fields=strict_fields)


# Kurallari gecen satirlari hiza gore siralayip aday listesi uretir.
# (eski: adaylar)
def select_candidates(rows, strategy: Mapping[str, Any], *, limit: int = 20,
                      strict_fields: bool = True) -> dict:
    adaylar, elenen, hatali = [], 0, []
    for r in rows or []:
        sonuc = is_entry_allowed(r, strategy, strict_fields=strict_fields)
        if sonuc["gecti"]:
            adaylar.append(r)
        else:
            elenen += 1
            if sonuc.get("hata_gerekce") and len(hatali) < 3:
                hatali.append(f"{r.get('sembol')}: {sonuc['hata_gerekce'][0]}")
    adaylar.sort(key=lambda x: -(x.get("hiz") or 0))
    return {"aday": adaylar[:limit], "tarandi": len(rows or []),
            "elenen": elenen, "yapilandirma_hatasi": hatali}
