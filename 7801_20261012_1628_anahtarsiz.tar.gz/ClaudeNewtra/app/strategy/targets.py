"""Hedef ve stop geometrisi -- SAF.

Ismail'in olcum birikimi buradaki yorumlarda; tarih ve sayilarla birlikte
KORUNDU. Bunlar suslemede degil, neden o esigin secildiginin kaydi.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

EPS = 1e-9


@dataclass(frozen=True)
class StopPlan:
    """Stop fiyati + yuzdesi + neden o degerde oldugu."""
    price: float
    percent: float
    reason: str


@dataclass(frozen=True)
class TargetPlan:
    """Kar hedefi: sabit yuzde mi, iz surme mi."""
    kind: str                  # "sabit" | "trailing" | "kar_trailing"
    target: float | None
    trailing: float | None


# Hiza gore kar hedefi. Yuksek hizda iz surme devreye girer. (eski: hedef_belirle)
def resolve_profit_target(speed: float | None, exit_cfg: Mapping[str, Any]) -> TargetPlan:
    h = 0.0 if speed is None else float(speed)
    if h >= float(exit_cfg["hizli_esik"]):
        return TargetPlan("trailing", None, exit_cfg.get("trailing"))
    if h < float(exit_cfg["hiz_yavas"]):
        return TargetPlan("sabit", exit_cfg["hedef_yavas"], None)
    return TargetPlan("sabit", exit_cfg["hedef_normal"], None)


# Kar hangi merdiven esiklerini gectiyse en yuksegini uygular.
# Esikler artan sirada varsayilir; `en_yuksek` hic azalmadigi icin sonuc
# dogal olarak monoton -- stop ASLA geriye gitmez.
def apply_stop_ladder(profit_pct: float, ladder, start_stop: float) -> tuple[float, str]:
    yuzde, sebep = -float(start_stop), "baslangic"
    for esik, kilit in ladder:
        if profit_pct >= float(esik) - EPS:   # kayan nokta payi: sinirda kilit atlanmasin
            yuzde = float(kilit)
            sebep = "basabas" if kilit == 0 else f"kilit_%{float(kilit):g}"
    return yuzde, sebep


# Klasik sabit kilit modu (basabas_esik / kilit_esik / kilit_deger).
def apply_fixed_lock(profit_pct: float, stop_cfg: Mapping[str, Any]) -> tuple[float, str]:
    if profit_pct >= float(stop_cfg["kilit_esik"]):
        # kar kilidi: stop girisin USTUNE cikar -> pozisyon artik kesin karda
        return float(stop_cfg["kilit_deger"]), "kar_kilidi"
    if profit_pct >= float(stop_cfg["basabas_esik"]):
        # 17.09.2026, Ismail: "1.2'yi gecti ise 1.2'den satis koy, neden
        # zararina satiyoruz" -- eskiden burada TAM sifira kilitleniyordu;
        # kar esigi bir kez gordukten sonra stop O ESIGIN KENDISINE kilitlenir.
        return float(stop_cfg["basabas_esik"]), "basabas"
    return -float(stop_cfg["baslangic"]), "baslangic"


# ATR olcekli dinamik takip mesafesi (yuzde).
def apply_dynamic_trail(atr_pct: float | None, stop_cfg: Mapping[str, Any],
                        *, accelerating: bool = False) -> float:
    taban = float(stop_cfg.get("dinamik_mesafe_taban", 1.0))
    tavan = float(stop_cfg.get("dinamik_mesafe_tavan", 4.0))
    carpan = float(stop_cfg.get("dinamik_atr_carpan", 1.2))
    mesafe = taban
    if atr_pct:
        mesafe = min(max(float(atr_pct) * carpan, taban), tavan)
    # 21.09.2026, Ismail: "obv'yi stratejiden kaldirmistik, neden hala
    # gozukuyor" -- burada OBV'ye gore mesafeyi degistiren, hicbir ayar
    # karsiligi olmayan GIZLI bir dal vardi. Kaldirildi; mesafe artik
    # SADECE ATR'ye gore olceklenir.
    ivme_c = stop_cfg.get("ivme_carpan")
    if ivme_c and accelerating:
        # 22.09.2026, Ismail (CHR: +%1.2'de kilit_%0.7 ile kesildi, 27 dk
        # sonra +%22.9 gordu): hareket HIZLANIYORSA takip mesafesini genislet
        # ki tepe takibi kuyrugu birakmasin. Olculen (gunluk 5m, 1h ve 4h
        # mum, uc kaynak ayni yon): 4h 174 gun ivme x3 esik%1 -> bekl
        # -0.174 => +0.003; 1h 49 gun -0.053 => +0.000.
        mesafe = min(tavan * float(ivme_c), mesafe * float(ivme_c))
    return mesafe


# Dip donusu fitili: fitil derinse stop'u fitilin biraz altina koyar.
def apply_wick_tolerance(price: float, entry: float, low_wick: float | None,
                         stop_cfg: Mapping[str, Any]) -> tuple[float, str | None]:
    if not stop_cfg.get("fitil_kullan") or not low_wick or low_wick >= entry:
        return price, None
    derinlik = (1 - low_wick / entry) * 100
    if derinlik <= float(stop_cfg.get("fitil_maks", 10.0)) and low_wick < price:
        return low_wick * 0.999, f"fitil_%{derinlik:.1f}"
    return price, None


# Kar kilitli stop. (eski: stop_belirle)
#
# 13.09.2026, Ismail: "hep sifir oluyor" -- esikleri komisyon payi kadar
# kaydirmak ile kapanista NET kar hesaplamak AYNI komisyonu IKI KEZ
# dusuyordu, sonuc hep ~0'a cekiliyordu. Stop artik STRATEJIDE YAZAN HAM
# esikleri kullanir; komisyon SADECE kapanista bir defa dusulur.
def resolve_stop_price(entry: float, highest: float, stop_cfg: Mapping[str, Any],
                       *, low_wick: float | None = None,
                       atr_pct: float | None = None,
                       accelerating: bool = False) -> StopPlan:
    kar = ((highest / entry - 1) * 100) if entry else 0.0
    merdiven = stop_cfg.get("merdiven")
    dinamik_esik = stop_cfg.get("dinamik_esik")

    if merdiven:
        yuzde, sebep = apply_stop_ladder(kar, merdiven, stop_cfg["baslangic"])
    elif dinamik_esik is not None:
        # 11.09.2026: "cikis modu: dinamik takip" -- merdiven hilesine gerek yok.
        # Esige kadar duz baslangic stop'ta kal, sonrasi asagidaki ortak hesap.
        yuzde, sebep = -float(stop_cfg["baslangic"]), "baslangic"
    else:
        yuzde, sebep = apply_fixed_lock(kar, stop_cfg)

    # ATR IZI (`atr_zorunlu`): ATR olculmemisse iz hesaplanmaz -- mesafe tabana
    # dusup stopu bir anda tepeye yapistirmasin; kilit/cark yine gecerli.
    atr_yok = bool(stop_cfg.get("atr_zorunlu")) and not atr_pct
    if dinamik_esik is not None and kar >= float(dinamik_esik) and not atr_yok:
        mesafe = apply_dynamic_trail(atr_pct, stop_cfg, accelerating=accelerating)
        fiyat_dinamik = highest * (1 - mesafe / 100)
        fiyat_kilit = entry * (1 + yuzde / 100)
        if fiyat_dinamik > fiyat_kilit:
            return StopPlan(fiyat_dinamik,
                            round((fiyat_dinamik / entry - 1) * 100, 3),
                            f"DINAMIK:atr%{(atr_pct or 0):.2f}/-%{mesafe:.2f}")

    fiyat = entry * (1 + yuzde / 100)
    fiyat, fitil_sebep = apply_wick_tolerance(fiyat, entry, low_wick, stop_cfg)
    return StopPlan(fiyat, yuzde, fitil_sebep or sebep)


# Hedefe ulasildi ama momentum guclu -> satma, bekle. (eski: beklet_mi)
#
# DURUM: bugun HICBIR yapilandirmada calismiyor -- bot yolunda hedef 999'a
# cekildigi icin bu dala hic girilmiyor, el yolunda `beklet.aktif` False
# sabitleniyor. Yine de esdegerlik testi anlamli olsun diye BIREBIR
# tasindi; test "hicbir zaman tetiklenmiyor" dedigi anda silinebilir.
def should_hold_on_momentum(candle, wait_cfg: Mapping[str, Any] | None,
                            *, obv_angle: float | None = None,
                            atr_rising: bool | None = None) -> tuple[bool, str]:
    b = wait_cfg or {"aktif": False}
    if not b.get("aktif"):
        return False, "beklet kapali"
    try:
        ac, yk, _ds, kp = (float(candle[1]), float(candle[2]),
                           float(candle[3]), float(candle[4]))
    except (TypeError, ValueError, IndexError):
        return False, "mum yok"
    if kp <= ac:
        return False, "mum kirmizi"
    govde = yk - ac
    if govde <= 0:
        return False, "govde yok"
    kayip = (yk - kp) / govde * 100
    if kayip > float(b["govde_kaybi_maks"]):
        return False, f"govde %{kayip:.0f} kaybetti"
    if obv_angle is None or obv_angle < float(b["obv_aci_min"]):
        return False, f"obv acisi zayif ({obv_angle})"
    if b.get("atr_artiyor") and not atr_rising:
        return False, "atr artmiyor"
    return True, f"momentum guclu (obv {obv_angle:.0f}°, govde -%{kayip:.0f})"


