"""Kural motoru -- SAF. Dosya okumaz, aga cikmaz, yalnizca veri alir karar doner.

ESKI MOTORUN TEMEL KUSURU: `_kural_gecti` ALTI farkli sebebi tek `False`'a
indiriyordu (strateji.py:237, 239, 242, 248, 253, 261):
    * alan yok / NULL
    * deger_alan yok / NULL
    * sayiya cevrilemeyen deger
    * taninmayan operator
    * kosul gercekten saglanmadi
Panelde yalnizca "cci >= 68" yaziyordu; sebebin "cci 40 idi" mi yoksa
"cci diye bir alan yok" mu oldugu ANLASILAMIYORDU. En az uc uretim hatasi
bu yuzden aylarca gorunmez kaldi:
    * `rsi`  -- hic hesaplanmiyordu (sunucu.py:2258 yorumunda itiraf ediliyor)
    * `ema4` -- toplayici hesapliyor ama veritabanina YAZMIYOR; arayuzde hala
      secilebiliyor, bu kurali kullanan strateji sonsuza kadar sifir aday veriyor
    * `iz_yon` -- geriye-testte hic uretilmiyordu

Burada sonuc UC DURUMLU. `ALAN_YOK` bir HATADIR: loglanir, panelde gerekce
olarak gorunur ve strateji KAYDEDILIRKEN reddedilir.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Any, Mapping

from app.core.applog import get_logger
from app.market.indicators import COLOR_SOURCE, is_known_field, list_available_fields

_log = get_logger(__name__)

# Desteklenen operatorler (strateji.py:255-261 ile ayni kume).
OPERATORS: tuple[str, ...] = (">=", "<=", ">", "<", "==", "!=", "yukari", "asagi")
DIRECTION_OPS: tuple[str, ...] = ("yukari", "asagi")
EPSILON = 1e-9


class RuleOutcome(enum.Enum):
    """Bir kuralin dort olasi sonucu.

    OLCULMEDI ile ALAN_YOK'u AYIRMAK sart. Ikisi de eski motorda ayni sessiz
    `False`'a iniyordu, ama anlamlari taban tabana zit:
      * OLCULMEDI = deger mesru sekilde NULL. Ornegin `ha_yesil_yukselis`
        son mum yesil degilken NULL'dur ("UYDURMA VERI YOK" ilkesi). Bu bir
        HATA DEGIL, normal bir elemedir -- sembol elenir, strateji calisir.
      * ALAN_YOK = boyle bir alan hic yok (`ema4`), operator taninmiyor ya da
        kural bozuk. Bu bir YAPILANDIRMA HATASIDIR -- strateji kaydedilirken
        reddedilmeli, calisma aninda gurultu cikarmali.
    Ilk yazimimda NULL'u da ALAN_YOK sayiyordum; kati kipte `ha_yesil_yukselis`
    kullanan strateji her sembolde patlardi.
    """
    GECTI = "GECTI"            # kosul saglandi
    KALDI = "KALDI"            # kosul saglanmadi -- normal eleme
    OLCULMEDI = "OLCULMEDI"    # deger NULL -- mesru, sembol elenir
    ALAN_YOK = "ALAN_YOK"      # alan/operator/kural bozuk -- YAPILANDIRMA HATASI


@dataclass(frozen=True)
class RuleResult:
    """Kural sonucu + nedeni. Panelde gerekce olarak gosterilir."""
    outcome: RuleOutcome
    text: str                 # "cci >= 68"
    reason: str               # "cci 40.2 idi" / "alan olculmemis (NULL)"
    field: str = ""
    value: Any = None

    @property
    def passed(self) -> bool:
        return self.outcome is RuleOutcome.GECTI


# Yuzde degerini mum rengine cevirir: 1 yesil, -1 kirmizi, 0 yatay, None olculmemis.
# Gizli esik YOK (16.09.2026, Ismail: "arka planda gizli gorunmeyen bi sey olmasin").
def derive_color_field(value: Any) -> int | None:
    if value is None:
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return 1 if f > 0 else (-1 if f < 0 else 0)


# Kural yazarken secilebilecek TUM alanlar.
def list_known_fields() -> tuple[str, ...]:
    return list_available_fields()


# Satirdan alan okur. (deger, bilinen_alan_mi) doner.
# Eski `_alan_oku` bilinmeyen alan ile NULL degeri AYIRT ETMIYORDU.
def read_rule_field(row: Mapping[str, Any], name: str) -> tuple[Any, bool]:
    if name in COLOR_SOURCE:
        return derive_color_field(row.get(COLOR_SOURCE[name])), True
    if not is_known_field(name):
        return None, False
    return row.get(name), True


# Kurali okunur metne cevirir.   (eski: _kural_metni)
def describe_rule(rule: Mapping[str, Any]) -> str:
    alan, op = rule.get("alan", "?"), rule.get("op", "?")
    if op in DIRECTION_OPS:
        return f"{alan} {op}"
    if rule.get("deger_alan"):
        return f"{alan} {op} {rule['deger_alan']}"
    deger = rule.get("deger")
    # 26.09.2026, Ismail: bu alanlar ekranda 1 ondalikla gosterilir.
    if alan in ("coinsay", "coingreen", "yesildeg", "kirmizideg", "fark128",
                "kare128", "yukselis128"):
        try:
            return f"{alan} {op} {float(deger):.1f}"
        except (TypeError, ValueError):
            pass
    return f"{alan} {op} {deger}"


def _sayi(v: Any) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# Tek kurali degerlendirir.   (eski: _kural_gecti)
def evaluate_rule(row: Mapping[str, Any], rule: Mapping[str, Any]) -> RuleResult:
    metin = describe_rule(rule)
    alan = rule.get("alan")
    op = rule.get("op")

    if not alan:
        return RuleResult(RuleOutcome.ALAN_YOK, metin, "kuralda alan adi yok")
    if op not in OPERATORS:
        return RuleResult(RuleOutcome.ALAN_YOK, metin,
                          f"taninmayan operator: {op!r}", field=alan)

    v, bilinen = read_rule_field(row, alan)
    if not bilinen:
        return RuleResult(RuleOutcome.ALAN_YOK, metin,
                          f"boyle bir alan yok: {alan!r}", field=alan)
    if v is None:
        return RuleResult(RuleOutcome.OLCULMEDI, metin,
                          f"{alan} olculmemis (NULL)", field=alan)

    sv = _sayi(v)
    if sv is None:
        return RuleResult(RuleOutcome.ALAN_YOK, metin,
                          f"{alan} sayiya cevrilemedi: {v!r}", field=alan, value=v)


    # --- yon kurallari ---
    if op == "yukari":
        ok = sv > 0
        return RuleResult(RuleOutcome.GECTI if ok else RuleOutcome.KALDI, metin,
                          f"{alan}={sv:g} ({'pozitif' if ok else 'pozitif degil'})",
                          field=alan, value=sv)
    if op == "asagi":
        ok = sv < 0
        return RuleResult(RuleOutcome.GECTI if ok else RuleOutcome.KALDI, metin,
                          f"{alan}={sv:g} ({'negatif' if ok else 'negatif degil'})",
                          field=alan, value=sv)

    # --- kiyaslama: sabit sayi VEYA baska bir alan ---
    if rule.get("deger_alan"):
        hedef_ad = rule["deger_alan"]
        d, bilinen2 = read_rule_field(row, hedef_ad)
        if not bilinen2:
            return RuleResult(RuleOutcome.ALAN_YOK, metin,
                              f"boyle bir alan yok: {hedef_ad!r}", field=hedef_ad)
        if d is None:
            return RuleResult(RuleOutcome.OLCULMEDI, metin,
                              f"{hedef_ad} olculmemis (NULL)", field=hedef_ad)
        sd = _sayi(d)
    else:
        if "deger" not in rule:
            return RuleResult(RuleOutcome.ALAN_YOK, metin,
                              "kuralda ne deger ne deger_alan var", field=alan)
        sd = _sayi(rule["deger"])
    if sd is None:
        return RuleResult(RuleOutcome.ALAN_YOK, metin,
                          "kiyas degeri sayiya cevrilemedi", field=alan, value=v)

    ok = {">=": sv >= sd, "<=": sv <= sd, ">": sv > sd, "<": sv < sd,
          "==": abs(sv - sd) < EPSILON, "!=": abs(sv - sd) >= EPSILON}[op]
    return RuleResult(RuleOutcome.GECTI if ok else RuleOutcome.KALDI, metin,
                      f"{alan}={sv:g} (kiyas {sd:g})", field=alan, value=sv)


# Kural listesinin tamamini degerlendirir (hepsi VE'lenir).
# `strict_fields=True` iken ALAN_YOK cikan kural HATA sayilir ve
# butun kume basarisiz olur -- sessizce "elendi" gorunmez.
def evaluate_rule_set(row: Mapping[str, Any], rules,
                      *, strict_fields: bool = True) -> dict:
    # 27.09.2026, Ismail: "her seferinde silmek istemiyorum, switch koy" --
    # kural silinmeden `aktif: false` ile devre disi birakilabilir.
    # Belirtilmemisse (eski kayitlar) varsayilan AKTIF -- geriye donuk uyum.
    aktif_kurallar = [k for k in (rules or []) if k.get("aktif", True)]
    sonuclar = [evaluate_rule(row, k) for k in aktif_kurallar]
    alan_yok = [r for r in sonuclar if r.outcome is RuleOutcome.ALAN_YOK]
    olculmedi = [r for r in sonuclar if r.outcome is RuleOutcome.OLCULMEDI]
    kaldi = [r for r in sonuclar if r.outcome is RuleOutcome.KALDI]
    # OLCULMEDI sembolu ELER ama hata degildir; ALAN_YOK yapilandirma hatasidir.
    gecti = not kaldi and not olculmedi and (not alan_yok if strict_fields else True)
    return {
        "gecti": gecti,
        "sonuclar": sonuclar,
        "alan_yok": alan_yok,
        "olculmedi": olculmedi,
        "red_gerekce": [r.text for r in kaldi],
        "olculmedi_gerekce": [r.reason for r in olculmedi],
        "hata_gerekce": [f"{r.text} -> {r.reason}" for r in alan_yok],
    }


