"""Sembol basina gunluk tur arsivi (gunluk/*.jsonl).

DIKKAT: eski sistemde bu arsiv 5 dakikada bir 400 dosyaya yaziliyordu ve
klasor 1.1 GB'a ulasmisti -- ama onu okuyan TEK ozellik (`/yerel/isabet`)
arayuzde HIC cagrilmiyordu. Yani hicbir sey okumadan surekli buyuyordu.
Burada yazim, okuyan ozellikle birlikte ACILIP KAPANIR.
"""
from __future__ import annotations

import os

from app.config.paths import get_journal_dir
from app.core.applog import get_logger
from app.core.jsonstore import append_jsonl_record

_log = get_logger(__name__)


# Arsiv acik mi? Kapaliysa yazim da yapilmaz.
def is_archive_enabled(settings) -> bool:
    return bool((settings or {}).get("gunluk_arsiv_acik", False))


# Bir turun satirlarini sembol basina dosyalara ekler.  (eski: _gunluk_kaydet)
def append_daily_snapshot(rows, settings) -> int:
    if not is_archive_enabled(settings):
        return 0
    dizin = get_journal_dir()
    os.makedirs(dizin, exist_ok=True)
    n = 0
    for r in rows or []:
        sembol = r.get("sembol")
        if not sembol:
            continue
        append_jsonl_record(os.path.join(dizin, f"{sembol}.jsonl"), r)
        n += 1
    return n
