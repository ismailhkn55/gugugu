"""Sinyal isabet olcumu (gunluk/*.jsonl arsivinden)."""
from __future__ import annotations

import os

from app.config.paths import get_journal_dir
from app.core.jsonstore import read_jsonl_records


# Arsivden sinyal isabetini olcer. Arsiv yoksa None doner --
# uydurma sayi uretmez.                                  (eski: isabet_olc)
def measure_signal_accuracy(*, lookahead_rows: int = 12,
                            target_pct: float = 2.0,
                            max_symbols: int = 60) -> dict:
    dizin = get_journal_dir()
    if not os.path.isdir(dizin):
        return {"durum": "arsiv yok", "olcum": None}
    dosyalar = sorted(f for f in os.listdir(dizin) if f.endswith(".jsonl"))[:max_symbols]
    if not dosyalar:
        return {"durum": "arsiv bos", "olcum": None}

    dilim: dict[str, dict] = {}
    for ad in dosyalar:
        satirlar = list(read_jsonl_records(os.path.join(dizin, ad)))
        for i, s in enumerate(satirlar):
            ileri = satirlar[i + 1:i + 1 + lookahead_rows]
            if not ileri:
                break
            baz = s.get("fiyat")
            if not baz:
                continue
            en_yuksek = max((float(x.get("fiyat") or 0) for x in ileri), default=0)
            basardi = ((en_yuksek / float(baz) - 1) * 100) >= target_pct
            for alan in ("obv_kesim", "hacim_x", "rsi"):
                v = s.get(alan)
                if v is None:
                    continue
                kova = f"{alan}:{_kova(alan, float(v))}"
                d = dilim.setdefault(kova, {"n": 0, "basari": 0})
                d["n"] += 1
                d["basari"] += int(basardi)
    for d in dilim.values():
        d["isabet_yuzde"] = round(d["basari"] / d["n"] * 100, 2) if d["n"] else None
    return {"durum": "ok", "hedef_pct": target_pct, "ileri_satir": lookahead_rows,
            "olcum": dict(sorted(dilim.items()))}


def _kova(alan: str, v: float) -> str:
    if alan == "rsi":
        return f"{int(v // 10) * 10}-{int(v // 10) * 10 + 10}"
    if alan == "hacim_x":
        return ">=3" if v >= 3 else (">=2" if v >= 2 else "<2")
    return "taze_yukari" if v == 1 else ("taze_asagi" if v == -1 else "diger")
