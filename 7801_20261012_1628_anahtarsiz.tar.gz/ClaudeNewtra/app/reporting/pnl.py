"""Gunluk kar/zarar egrisi."""
from __future__ import annotations

import datetime
from collections import OrderedDict

from app.trading.ledger import list_closed_orders


def _gun(ts_ms: int) -> str:
    return datetime.datetime.fromtimestamp(ts_ms / 1000, datetime.UTC).strftime("%Y-%m-%d")


# Son `days` gunun kar/zarar serisi. `live` ZORUNLU.
#
# `sadece`: "el" -> yalnizca dugmelerle acilanlar, "bot" -> yalnizca botun
# actiklari, None -> hepsi. Cuzdan sayfasi "el" kullanir (bkz. 7.16).
#
# GUNLUK YUZDE NASIL HESAPLANIR:
# 23.09.2026, Ismail: "cuzdanda -57 zarar yaziyor, bu ne demek ya".
# Eski kod gunun islemlerinin `kar_p` degerlerini TOPLUYORDU. Farkli
# buyuklukteki islemlerin yuzdelerini toplamak matematiksel olarak
# anlamsizdir: 5 islemin (-0.62, -30.28, -38.69, -4.19, +16.08) toplami
# -57.7 cikiyor ve "bugun %57 zarar" gibi gorunuyordu -- oysa ayni gun
# USDT kari 0.0 yaziyordu. Iki rakam birbirini tutmuyordu.
#
# Dogrusu SERMAYE AGIRLIKLI getiri:
#     gunluk_p = (gunun toplam kari USDT / gunun baglanan toplam USDT) * 100
# Boylece buyuk pozisyonun sonucu kucuk pozisyonunkinden daha agir basar
# ve sonuc gercekten "o gun paranin yuzde kaci kazanildi" olur.
#
# Bazi eski kayitlarda `kar` (USDT) bos, yalnizca `kar_p` var; o durumda
# USDT karsiligi `tutar * kar_p / 100` ile TURETILIR -- aksi halde gunun
# USDT toplami 0 gorunuyordu.
def build_daily_pnl(live: bool, days: int = 14, *, sadece: str | None = None) -> dict:
    kapali = list_closed_orders(live)
    if sadece == "el":
        kapali = [e for e in kapali if e.get("el_kaynak")]
    elif sadece == "bot":
        kapali = [e for e in kapali if not e.get("el_kaynak")]
    gunler: OrderedDict[str, dict] = OrderedDict()
    bugun = datetime.datetime.now(datetime.UTC).date()
    for i in range(days - 1, -1, -1):
        g = (bugun - datetime.timedelta(days=i)).strftime("%Y-%m-%d")
        gunler[g] = {"tarih": g, "gunluk": 0.0, "gunluk_p": 0.0,
                     "baglanan": 0.0, "islem": 0}
    for e in kapali:
        ts = (e.get("kapanis") or {}).get("ts")
        if not ts:
            continue
        g = _gun(ts)
        if g not in gunler:
            continue
        tutar = float(e.get("tutar") or 0)
        kar = e.get("kar")
        karp = e.get("kar_p")
        if kar is None and karp is not None and tutar:
            kar = tutar * float(karp) / 100.0      # eksik USDT karsiligini turet
        gunler[g]["gunluk"] += float(kar or 0)
        gunler[g]["baglanan"] += tutar
        gunler[g]["islem"] += 1
    for g in gunler.values():
        g["gunluk_p"] = (g["gunluk"] / g["baglanan"] * 100.0) if g["baglanan"] else 0.0
    return {"seri": compute_cumulative_curve(list(gunler.values())),
            "toplam": round(sum(g["gunluk"] for g in gunler.values()), 4),
            "kaynak": "canli" if live else "dry"}


# Gunluk degerlerden birikimli egri uretir.
def compute_cumulative_curve(daily: list[dict]) -> list[dict]:
    birikim = 0.0
    for g in daily:
        birikim += g["gunluk"]
        g["gunluk"] = round(g["gunluk"], 4)
        g["gunluk_p"] = round(g["gunluk_p"], 3)
        g["baglanan"] = round(g.get("baglanan", 0.0), 4)
        g["birikim"] = round(birikim, 4)
    return daily
