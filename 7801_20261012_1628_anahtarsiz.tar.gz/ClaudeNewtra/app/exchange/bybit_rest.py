"""Bybit spot REST -- SADECE coklu borsa hacim (CHCM) ozelligi icin, imzasiz/
public mum verisi. `binance_rest.fetch_klines`'in DONUS SEKLIYLE AYNI:
[ts_ms, open, high, low, close, volume] listesi, ESKIDEN YENIYE sirali.

Bybit ham yaniti YENIDEN ESKIYE doner (`list` alani ters) -- burada
ESKIDEN YENIYE cevrilir ki candles.py'deki birlestirme TUM borsalarda
AYNI yonde calissin.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request

BASE_URL = "https://api.bybit.com"
DEFAULT_TIMEOUT = 15

# Binance-tarzi interval -> Bybit'in dakika sayisi/"D"/"W"/"M" bicimi.
_INTERVAL_MAP = {
    "1m": "1", "3m": "3", "5m": "5", "15m": "15", "30m": "30",
    "1h": "60", "2h": "120", "4h": "240", "6h": "360", "12h": "720",
    "1d": "D", "1w": "W", "1M": "M",
}


def fetch_klines(symbol: str, interval: str, *, limit: int = 200) -> list:
    bybit_aralik = _INTERVAL_MAP.get(interval)
    if bybit_aralik is None:
        raise ValueError(f"bybit_rest: desteklenmeyen interval: {interval!r}")

    p = {"category": "spot", "symbol": symbol, "interval": bybit_aralik, "limit": limit}
    url = BASE_URL + "/v5/market/kline?" + urllib.parse.urlencode(p)
    try:
        with urllib.request.urlopen(urllib.request.Request(url), timeout=DEFAULT_TIMEOUT) as c:
            d = json.load(c)
    except urllib.error.URLError as e:
        raise RuntimeError(f"bybit_rest: baglanti hatasi: {e}") from e

    if d.get("retCode") != 0:
        raise RuntimeError(f"bybit_rest: {d.get('retCode')} {d.get('retMsg')}")

    ham = d.get("result", {}).get("list") or []
    # Bybit: [start_ms, open, high, low, close, volume(taban), turnover(karsit)]
    # -- YENIDEN ESKIYE gelir, burada ESKIDEN YENIYE cevrilir.
    sirali = [[int(m[0]), float(m[1]), float(m[2]), float(m[3]), float(m[4]), float(m[5])]
              for m in reversed(ham)]
    return sirali
