"""MEXC spot REST -- SADECE coklu borsa hacim (CHCM) ozelligi icin, imzasiz/
public mum verisi. Yanit formati Binance ile NEREDEYSE BIREBIR AYNI
(ESKIDEN YENIYE sirali) -- tek fark saat araliginin adi: MEXC "1h" DEGIL
"60m" bekler (29.09.2026 curl ile dogrulandi: interval=1h -> "Invalid
interval" hatasi).
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request

BASE_URL = "https://api.mexc.com"
DEFAULT_TIMEOUT = 15

_INTERVAL_MAP = {
    "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m",
    "1h": "60m", "4h": "4h", "8h": "8h",
    "1d": "1d", "1w": "1W", "1M": "1M",
}


def fetch_klines(symbol: str, interval: str, *, limit: int = 200) -> list:
    mexc_aralik = _INTERVAL_MAP.get(interval)
    if mexc_aralik is None:
        raise ValueError(f"mexc_rest: desteklenmeyen interval: {interval!r}")

    p = {"symbol": symbol, "interval": mexc_aralik, "limit": limit}
    url = BASE_URL + "/api/v3/klines?" + urllib.parse.urlencode(p)
    try:
        with urllib.request.urlopen(urllib.request.Request(url), timeout=DEFAULT_TIMEOUT) as c:
            ham = json.load(c)
    except urllib.error.URLError as e:
        raise RuntimeError(f"mexc_rest: baglanti hatasi: {e}") from e

    if isinstance(ham, dict) and ham.get("code"):
        raise RuntimeError(f"mexc_rest: {ham.get('code')} {ham.get('msg')}")

    # MEXC: [open_time_ms, open, high, low, close, volume(taban), close_time_ms,
    # quote_volume, ...] -- ESKIDEN YENIYE, Binance ile AYNI sira.
    return [[int(m[0]), float(m[1]), float(m[2]), float(m[3]), float(m[4]), float(m[5])]
            for m in ham]
