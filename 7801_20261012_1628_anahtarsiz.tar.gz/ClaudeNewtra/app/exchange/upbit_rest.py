"""Upbit (Kore) REST -- SADECE coklu borsa hacim (CHCM) ozelligi icin, imzasiz/
public mum verisi. `binance_rest.fetch_klines`'in DONUS SEKLIYLE AYNI:
[ts_ms, open, high, low, close, volume] listesi, ESKIDEN YENIYE sirali.

06.10.2026, Ismail: "upbit'i ekle, her borsa icin renk ayri olsun". Olculdu:
MIRA'nin 24s hacminin %42'si Upbit'te (CoinGecko tickers), Binance %34; CHCM'nin
eski 5 borsasi hacmin yalniz ~%36'sini goruyordu.

Upbit'te bir coin KRW-XXX ve/veya USDT-XXX pazarinda islem gorur. Hacim TABAN
(coin adedi) cinsinden oldugu icin iki pazar dogrudan TOPLANIR -- KRW kuru
gerekmez. Fiyat alanlari KRW pazarinda won cinsindendir; CHCM yalnizca
hacmi (m[5]) kullanir, o yuzden OHLC USDT pazari varsa ondan, yoksa KRW'den.

Upbit ham yaniti YENIDEN ESKIYE ve istek basina en fazla 200 mum doner; daha
uzun `limit` icin `to` ile geriye sayfalanir. Sinir: IP basina mumlarda
dakikada 600 / saniyede 10 istek (yanit basligi Remaining-Req).
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

BASE_URL = "https://api.upbit.com"
DEFAULT_TIMEOUT = 15
SAYFA = 200                     # Upbit'in tek istekte verdigi en fazla mum
PAZAR_ONBELLEK_SN = 3600        # pazar listesi saatte bir yenilenir

# Binance-tarzi interval -> Upbit uc yolu.
_INTERVAL_MAP = {
    "1m": "minutes/1", "3m": "minutes/3", "5m": "minutes/5", "15m": "minutes/15",
    "30m": "minutes/30", "1h": "minutes/60", "4h": "minutes/240",
    "1d": "days", "1w": "weeks", "1M": "months",
}

_pazar_kilit = threading.Lock()
_pazar: dict = {"ts": 0.0, "kume": frozenset()}


def _get_json(path: str, params: dict) -> list | dict:
    url = BASE_URL + path + "?" + urllib.parse.urlencode(params)
    istek = urllib.request.Request(url, headers={"accept": "application/json"})
    try:
        with urllib.request.urlopen(istek, timeout=DEFAULT_TIMEOUT) as c:
            return json.load(c)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"upbit_rest: HTTP {e.code}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"upbit_rest: baglanti hatasi: {e}") from e


# Upbit'teki pazar adlari (KRW-BTC, USDT-BTC ...) -- saatte bir yenilenen onbellek.
def list_upbit_markets() -> frozenset:
    with _pazar_kilit:
        if _pazar["kume"] and time.time() - _pazar["ts"] < PAZAR_ONBELLEK_SN:
            return _pazar["kume"]
    ham = _get_json("/v1/market/all", {})
    kume = frozenset(m["market"] for m in ham if isinstance(m, dict) and m.get("market"))
    with _pazar_kilit:
        _pazar.update(ts=time.time(), kume=kume)
    return kume


# Tek bir Upbit pazarinin mumlari, ESKIDEN YENIYE (gerekirse sayfalayarak).
def fetch_market_candles(market: str, interval: str, *, limit: int = 200) -> list:
    yol = _INTERVAL_MAP.get(interval)
    if yol is None:
        raise ValueError(f"upbit_rest: desteklenmeyen interval: {interval!r}")
    kalan, to, tum = int(limit), None, []
    while kalan > 0:
        p = {"market": market, "count": min(SAYFA, kalan)}
        if to:
            p["to"] = to
        ham = _get_json(f"/v1/candles/{yol}", p)
        if not ham:
            break
        tum.extend(ham)
        kalan -= len(ham)
        if len(ham) < p["count"]:
            break
        # bir sonraki sayfa: en eski mumun baslangicindan ONCEKILER
        to = ham[-1]["candle_date_time_utc"] + "Z"
    sirali = []
    for m in reversed(tum):
        ts = datetime.fromisoformat(m["candle_date_time_utc"]).replace(tzinfo=timezone.utc)
        sirali.append([int(ts.timestamp() * 1000), float(m["opening_price"]),
                       float(m["high_price"]), float(m["low_price"]),
                       float(m["trade_price"]), float(m["candle_acc_trade_volume"])])
    return sirali


def fetch_klines(symbol: str, interval: str, *, limit: int = 200) -> list:
    """BTCUSDT -> Upbit KRW-BTC + USDT-BTC hacimleri TOPLANIR. Coin Upbit'te
    yoksa bos liste (CHCM o borsayi sessizce atlar)."""
    taban = symbol[:-4] if symbol.endswith(("USDT", "USDC")) else symbol
    pazarlar = list_upbit_markets()
    adaylar = [p for p in (f"USDT-{taban}", f"KRW-{taban}") if p in pazarlar]
    if not adaylar:
        return []
    birlesik: dict[int, list] = {}
    for p in adaylar:
        for m in fetch_market_candles(p, interval, limit=limit):
            if m[0] in birlesik:
                birlesik[m[0]][5] += m[5]       # ayni mum: taban hacimler toplanir
            else:
                birlesik[m[0]] = list(m)        # OHLC ilk (USDT) pazardan
    return [birlesik[t] for t in sorted(birlesik)][-int(limit):]
