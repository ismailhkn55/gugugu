"""OKX spot REST -- SADECE coklu borsa hacim (CHCM) ozelligi icin, imzasiz/
public mum verisi. `binance_rest.fetch_klines`'in DONUS SEKLIYLE AYNI:
[ts_ms, open, high, low, close, volume] listesi, ESKIDEN YENIYE sirali.

OKX ham yaniti YENIDEN ESKIYE doner -- burada ESKIDEN YENIYE cevrilir.
Sembol bicimi tireli (BTC-USDT); cagiran taraf hep BTCUSDT verir, tire
BURADA eklenir.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request

BASE_URL = "https://www.okx.com"
DEFAULT_TIMEOUT = 15

# Binance-tarzi interval -> OKX'in "bar" bicimi (dakika kucuk harf, saat/gun/
# hafta/ay BUYUK harf -- 29.09.2026 curl ile dogrulandi: bar=1H/1D calisiyor,
# bar=1h/1d CALISMIYOR).
_INTERVAL_MAP = {
    "1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m",
    "1h": "1H", "2h": "2H", "4h": "4H", "6h": "6H", "12h": "12H",
    "1d": "1D", "1w": "1W", "1M": "1M",
}


def _instid(symbol: str) -> str:
    # BTCUSDT -> BTC-USDT / BTCUSDC -> BTC-USDC (kuyruk her zaman 4 karakter).
    return f"{symbol[:-4]}-{symbol[-4:]}"


def fetch_klines(symbol: str, interval: str, *, limit: int = 200) -> list:
    okx_bar = _INTERVAL_MAP.get(interval)
    if okx_bar is None:
        raise ValueError(f"okx_rest: desteklenmeyen interval: {interval!r}")

    p = {"instId": _instid(symbol), "bar": okx_bar, "limit": limit}
    url = BASE_URL + "/api/v5/market/candles?" + urllib.parse.urlencode(p)
    try:
        with urllib.request.urlopen(urllib.request.Request(url), timeout=DEFAULT_TIMEOUT) as c:
            d = json.load(c)
    except urllib.error.URLError as e:
        raise RuntimeError(f"okx_rest: baglanti hatasi: {e}") from e

    if d.get("code") != "0":
        raise RuntimeError(f"okx_rest: {d.get('code')} {d.get('msg')}")

    ham = d.get("data") or []
    # OKX: [ts_ms, open, high, low, close, vol(taban), volCcy, volCcyQuote, confirm]
    # -- YENIDEN ESKIYE gelir, burada ESKIDEN YENIYE cevrilir.
    sirali = [[int(m[0]), float(m[1]), float(m[2]), float(m[3]), float(m[4]), float(m[5])]
              for m in reversed(ham)]
    return sirali
