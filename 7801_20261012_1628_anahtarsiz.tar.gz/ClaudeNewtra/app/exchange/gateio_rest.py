"""Gate.io spot REST -- SADECE coklu borsa hacim (CHCM) ozelligi icin,
imzasiz/public mum verisi. `binance_rest.fetch_klines`'in DONUS SEKLIYLE
AYNI: [ts_ms, open, high, low, close, volume] listesi, ESKIDEN YENIYE
sirali (Gate.io zaten bu sirada doner, CEVIRME GEREKMEZ).

Gate.io ham alan sirasi Binance'ten FARKLI: [ts_sn, quote_hacim, kapanis,
yuksek, dusuk, acilis, taban_hacim, pencere_kapali_mi] -- ts SANIYE
cinsinden (Binance/Bybit/OKX/MEXC hepsi MS), burada *1000 ile cevrilir.
Sembol bicimi alt cizgili (BTC_USDT); cagiran taraf hep BTCUSDT verir,
alt cizgi BURADA eklenir.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request

BASE_URL = "https://api.gateio.ws"
DEFAULT_TIMEOUT = 15

_INTERVAL_MAP = {
    "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m",
    "1h": "1h", "4h": "4h", "8h": "8h", "1d": "1d", "1w": "7d",
}


def _currency_pair(symbol: str) -> str:
    # BTCUSDT -> BTC_USDT / BTCUSDC -> BTC_USDC (kuyruk her zaman 4 karakter).
    return f"{symbol[:-4]}_{symbol[-4:]}"


def fetch_klines(symbol: str, interval: str, *, limit: int = 200) -> list:
    gate_aralik = _INTERVAL_MAP.get(interval)
    if gate_aralik is None:
        raise ValueError(f"gateio_rest: desteklenmeyen interval: {interval!r}")

    p = {"currency_pair": _currency_pair(symbol), "interval": gate_aralik, "limit": limit}
    url = BASE_URL + "/api/v4/spot/candlesticks?" + urllib.parse.urlencode(p)
    try:
        with urllib.request.urlopen(urllib.request.Request(url), timeout=DEFAULT_TIMEOUT) as c:
            ham = json.load(c)
    except urllib.error.URLError as e:
        raise RuntimeError(f"gateio_rest: baglanti hatasi: {e}") from e

    if isinstance(ham, dict) and ham.get("label"):
        raise RuntimeError(f"gateio_rest: {ham.get('label')} {ham.get('message')}")

    # [ts_sn, quote_hacim, kapanis, yuksek, dusuk, acilis, taban_hacim, kapali_mi]
    return [[int(m[0]) * 1000, float(m[5]), float(m[3]), float(m[4]), float(m[2]), float(m[6])]
            for m in ham]
