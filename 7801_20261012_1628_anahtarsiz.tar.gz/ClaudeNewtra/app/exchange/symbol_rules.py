"""Sembol adi normalizasyonu ve borsa filtreleri (LOT_SIZE, MIN_NOTIONAL).

Filtreler 1 saat onbelleklenir. Eski `sembol_kural` onbellegi KILITSIZDI ve
iki is parcacigi ayni anda `exchangeInfo` cagirabiliyordu.
"""
from __future__ import annotations

import threading
import time

from app.core.applog import get_logger
from app.exchange.binance_rest import fetch_exchange_info

_log = get_logger(__name__)
_kilit = threading.Lock()
_onbellek: dict[str, tuple[float, dict]] = {}
ONBELLEK_SN = 3600
QUOTE = "USDT"


# "btc" -> "BTCUSDT".  Zaten USDT ile bitiyorsa dokunmaz.
def normalize_symbol(symbol: str) -> str:
    s = (symbol or "").strip().upper().replace("/", "").replace("-", "")
    if not s:
        raise ValueError("bos sembol")
    return s if s.endswith(QUOTE) else s + QUOTE


# Sembolun borsa filtreleri: adim, tick, asgari tutar. 1 saat onbellekli.
def get_symbol_filters(symbol: str) -> dict:
    s = normalize_symbol(symbol)
    simdi = time.time()
    with _kilit:
        kayit = _onbellek.get(s)
        if kayit and simdi - kayit[0] < ONBELLEK_SN:
            return kayit[1]

    bilgi = fetch_exchange_info(s)
    kurallar = {"symbol": s, "step": 0.0, "tick": 0.0, "min_notional": 0.0,
                "min_qty": 0.0, "status": "UNKNOWN"}
    for sem in bilgi.get("symbols", []):
        if sem.get("symbol") != s:
            continue
        kurallar["status"] = sem.get("status", "UNKNOWN")
        for f in sem.get("filters", []):
            t = f.get("filterType")
            if t == "LOT_SIZE":
                kurallar["step"] = float(f.get("stepSize") or 0)
                kurallar["min_qty"] = float(f.get("minQty") or 0)
            elif t == "PRICE_FILTER":
                kurallar["tick"] = float(f.get("tickSize") or 0)
            elif t in ("MIN_NOTIONAL", "NOTIONAL"):
                kurallar["min_notional"] = float(f.get("minNotional") or 0)
        break
    with _kilit:
        _onbellek[s] = (simdi, kurallar)
    return kurallar


def _floor_to(value: float, step: float) -> float:
    """Degeri adim buyuklugune ASAGI yuvarlar ve adimin basamagina kirpar."""
    if not step or step <= 0:
        return float(value)
    n = int(float(value) / step + 1e-9)
    basamak = max(0, len(f"{step:.10f}".rstrip("0").split(".")[-1]))
    return round(n * step, basamak)


# Miktari LOT_SIZE adimina yuvarlar.   (eski: basamakla)
def round_quantity_to_step(quantity: float, step: float) -> float:
    return _floor_to(quantity, step)


# Fiyati PRICE_FILTER tick'ine yuvarlar.
def round_price_to_tick(price: float, tick: float) -> float:
    return _floor_to(price, tick)


# Emir asgari tutari gecti mi (MIN_NOTIONAL).
def meets_min_notional(quantity: float, price: float, min_notional: float) -> bool:
    return (quantity * price) >= (min_notional or 0)


