"""Binance aggTrade akisi -- harici paket YOK, ham socket + ssl.

Eski `wsizle.py` calisiyordu ama alti kirilgan noktasi vardi; hepsi burada
kapatildi:
  1. FIN biti HIC okunmuyordu -- parcali (fragmented) mesaj gelirse JSON
     sessizce bozulurdu. Artik parcalar birlestiriliyor.
  2. Cerceve uzunluguna UST SINIR yoktu; bozuk bir cerceve dev bir `n`
     verirse okuma bellegi sisirebilirdi.
  3. SUBSCRIBE yaniti DOGRULANMIYORDU. Binance `{"error":...}` donse bile
     durum "canli" kaliyor, o sembolden veri hic gelmiyordu.
  4. Bayatlık kontrolu yoktu: ping gelmeye devam edip veri dursa fark
     edilmezdi.
  5. `_tick_arsiv` SINIRSIZ buyuyordu.
  6. Abonelikten cikan sembolun tepe/dip'i siliniyordu; ayni coin tekrar
     alinirsa en yuksek sifirlaniyordu.
"""
from __future__ import annotations

import collections
import json
import os
import secrets as _secrets
import socket
import ssl
import struct
import threading
import time

from app.core.applog import get_logger, log_once
from app.core.timeutil import now_ms

_log = get_logger(__name__)

WS_HOST = "stream.binance.com"
WS_PORT = 9443
MAX_FRAME_BYTES = 8 * 1024 * 1024        # 8 MB ustu cerceve reddedilir
TICK_BUFFER_PER_SYMBOL = 5000            # halka tampon -- sinirsiz buyume yok
STALE_AFTER_SN = 90                      # bu kadar veri gelmezse "bayat"
MAX_SYMBOLS_PER_SOCKET = 180             # URL uzunluk siniri icin

# 27.09.2026, Ismail: PYTHUSDT'de gercek parada olculdu -- AL'dan 1.5 saniye
# sonra "STOP:baslangic" ile satildi ama kapanis fiyati stopun COK ustundeydi
# (giris 0.084485, stop 0.081950, kapanis 0.084475). `is_stream_stale()`
# YALNIZCA soketin GENEL olarak mesaj alip almadigina bakiyordu; sembole ozel
# veri bayatligina degil. Bir sembol pozisyon kapaninca abonelikten cikip
# sonra YENIDEN acilinca, ilk taze tik gelene kadar `_veri[s]["f"]` eski
# degeri donduruyor ve get_price() bunu "akis, anlik" diye yutuyordu
# (GLMRUSDT'de 2 saat 9 dk once kapanan islemin fiyatiyla BIT-BIT ayni
# kapanis kanitladi). Duzeltme: her sembolun kendi son veri yasi da kontrol
# edilir; asilirsa None donup price_source REST/anlik-goruntu'ye duser.
STALE_SYMBOL_PRICE_SN = 20


# WebSocket istemci maskesi uygular (RFC 6455: istemci->sunucu zorunlu).
def mask_payload(data: bytes) -> bytes:
    m = _secrets.token_bytes(4)
    return m + bytes(b ^ m[i % 4] for i, b in enumerate(data))


# WebSocket cercevesi kurar (FIN + opkod + uzunluk + maske).
def encode_frame(data: bytes, opcode: int = 0x1) -> bytes:
    n = len(data)
    bas = bytes([0x80 | opcode])
    if n < 126:
        bas += bytes([0x80 | n])
    elif n < 65536:
        bas += bytes([0x80 | 126]) + struct.pack(">H", n)
    else:
        bas += bytes([0x80 | 127]) + struct.pack(">Q", n)
    return bas + mask_payload(data)


# Cerceve basligini cozer: (FIN, opkod, uzunluk). Uzunluk tavani uygulanir.
def decode_frame_header(first: int, second: int, read_exact) -> tuple[bool, int, int]:
    fin = bool(first & 0x80)
    opcode = first & 0x0F
    n = second & 0x7F
    if n == 126:
        n = struct.unpack(">H", read_exact(2))[0]
    elif n == 127:
        n = struct.unpack(">Q", read_exact(8))[0]
    if n > MAX_FRAME_BYTES:
        raise OSError(f"cerceve cok buyuk: {n} bayt (tavan {MAX_FRAME_BYTES})")
    return fin, opcode, n


class _Socket:
    """Tek bir TLS WebSocket baglantisi."""

    def __init__(self, path: str):
        self._tampon = b""
        self._yazma_kilit = threading.Lock()
        ham = socket.create_connection((WS_HOST, WS_PORT), timeout=20)
        ctx = ssl.create_default_context()
        self._s = ctx.wrap_socket(ham, server_hostname=WS_HOST)
        self._s.settimeout(35)
        anahtar = __import__("base64").b64encode(os.urandom(16)).decode()
        self._s.sendall((
            f"GET {path} HTTP/1.1\r\nHost: {WS_HOST}\r\n"
            f"Upgrade: websocket\r\nConnection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {anahtar}\r\nSec-WebSocket-Version: 13\r\n\r\n"
        ).encode())
        basliklar = b""
        while b"\r\n\r\n" not in basliklar:
            parca = self._s.recv(4096)
            if not parca:
                raise OSError("el sikismasi sirasinda baglanti kapandi")
            basliklar += parca
        if b"101" not in basliklar.split(b"\r\n")[0]:
            raise OSError(f"el sikismasi reddedildi: {basliklar.split(chr(13).encode())[0][:120]!r}")

    def _read_exact(self, n: int) -> bytes:
        while len(self._tampon) < n:
            parca = self._s.recv(65536)
            if not parca:
                raise OSError("baglanti kapandi")
            self._tampon += parca
        veri, self._tampon = self._tampon[:n], self._tampon[n:]
        return veri

    def read_message(self) -> str | None:
        """Tek TAM mesaj okur; parcalari birlestirir, ping'e pong doner."""
        parcalar: list[bytes] = []
        while True:
            bas = self._read_exact(2)
            fin, opcode, n = decode_frame_header(bas[0], bas[1], self._read_exact)
            govde = self._read_exact(n) if n else b""
            if opcode == 0x9:                       # ping -> pong
                self.send_raw(govde, 0xA)
                continue
            if opcode == 0x8:                       # close
                raise OSError("sunucu baglantiyi kapatti")
            if opcode == 0xA:                       # pong
                continue
            if opcode in (0x1, 0x2, 0x0):
                parcalar.append(govde)
                if fin:
                    return b"".join(parcalar).decode("utf-8", "replace")
                continue
            parcalar.clear()

    def send_raw(self, data: bytes, opcode: int = 0x1) -> None:
        with self._yazma_kilit:
            self._s.sendall(encode_frame(data, opcode))

    def send_json(self, obj: dict) -> None:
        self.send_raw(json.dumps(obj).encode())

    def close(self) -> None:
        try:
            self._s.close()
        except OSError:
            pass


class LiveTradeStream:
    """aggTrade akisindan fiyat / tepe / dip ve tick arsivi. (eski: Izleyici)"""

    def __init__(self) -> None:
        self._kilit = threading.Lock()
        self._semboller: set[str] = set()
        self._veri: dict[str, dict] = {}
        self._tickler: dict[str, collections.deque] = {}
        self._socket: _Socket | None = None
        self._surum = 0
        self._durum = "kapali"
        self._hata: str | None = None
        self._son_mesaj_ts = 0.0
        self._istek_id = 0

    # Abonelik kumesini gunceller; ortak sembolleri KESMEZ.
    def subscribe_symbols(self, symbols) -> None:
        yeni = {s.upper() for s in symbols if s}
        if len(yeni) > MAX_SYMBOLS_PER_SOCKET:
            log_once(_log, "ws-limit",
                     f"{len(yeni)} sembol istendi, {MAX_SYMBOLS_PER_SOCKET} ile sinirlandi")
            yeni = set(sorted(yeni)[:MAX_SYMBOLS_PER_SOCKET])
        with self._kilit:
            eski, self._semboller = self._semboller, yeni
            sock, canli = self._socket, self._durum == "canli"
        if yeni == eski:
            return
        eklenen, cikan = yeni - eski, eski - yeni
        if canli and sock and (eklenen or cikan):
            try:
                if cikan:
                    self._send_control(sock, "UNSUBSCRIBE", cikan)
                if eklenen:
                    self._send_control(sock, "SUBSCRIBE", eklenen)
                return
            except OSError as e:
                _log.warning("abonelik guncellenemedi, baglanti yenileniyor: %s", e)
        self._restart()

    def _send_control(self, sock: _Socket, method: str, symbols) -> None:
        """SUBSCRIBE/UNSUBSCRIBE gonderir. YANIT OKUNMAZ (okuma dongusu ayri is parcaciginda);
        reddedilen abonelikte o sembol icin STALE_SYMBOL_PRICE_SN sonra fiyat REST'e duser."""
        with self._kilit:
            self._istek_id += 1
            iid = self._istek_id
        sock.send_json({"method": method,
                        "params": [f"{s.lower()}@aggTrade" for s in symbols], "id": iid})

    def _restart(self) -> None:
        with self._kilit:
            self._surum += 1
            surum = self._surum
        threading.Thread(target=self.run_stream_loop, args=(surum,), daemon=True).start()

    # Sembolun son fiyati. Sembole ozel bayatsa None doner (eski: fiyat).
    def get_last_price(self, symbol: str) -> float | None:
        with self._kilit:
            d = self._veri.get(symbol.upper())
            if d is None:
                return None
            if time.time() - d.get("alindi", 0.0) > STALE_SYMBOL_PRICE_SN:
                return None
            return d["f"]

    # Izlemeye alindigindan beri en yuksek.                  (eski: tepe)
    def get_session_high(self, symbol: str) -> float | None:
        with self._kilit:
            d = self._veri.get(symbol.upper())
        return d["en"] if d else None

    # Izlemeye alindigindan beri en dusuk.                   (eski: dip)
    def get_session_low(self, symbol: str) -> float | None:
        with self._kilit:
            d = self._veri.get(symbol.upper())
        return d["az"] if d else None

    # Tepe/dip'i anlik fiyata sifirlar (pozisyon acildiginda).
    def reset_symbol_extremes(self, symbol: str) -> None:
        s = symbol.upper()
        with self._kilit:
            d = self._veri.get(s)
            if d:
                d["en"] = d["az"] = d["f"]

    # Biriken tick'leri alir ve tamponu bosaltir; cagiran diske yazar.
    def drain_tick_buffer(self) -> dict[str, list]:
        with self._kilit:
            cikti = {s: list(q) for s, q in self._tickler.items() if q}
            for q in self._tickler.values():
                q.clear()
        return cikti

    # Baglanti durumu, sembol sayisi ve son verinin yasi.
    def get_stream_status(self) -> dict:
        with self._kilit:
            yas = time.time() - self._son_mesaj_ts if self._son_mesaj_ts else None
            return {"durum": self._durum, "hata": self._hata,
                    "sembol": len(self._semboller),
                    "son_veri_sn": round(yas, 1) if yas is not None else None,
                    "bayat": self.is_stream_stale()}

    # Baglanti "canli" gorunuyor ama veri akmiyorsa True.
    def is_stream_stale(self) -> bool:
        if self._durum != "canli" or not self._son_mesaj_ts:
            return False
        return (time.time() - self._son_mesaj_ts) > STALE_AFTER_SN

    # ZOMBI BAGLANTI KORUMASI (01.10.2026, Ismail: "websocket'e care bul,
    # firsat kaciyor"). is_stream_stale() yalnizca RAPORLUYORDU, kendi
    # basina yeniden baglanmiyordu. run_stream_loop SADECE read_message()
    # bir OSError/timeout FIRLATIRSA yeniden baglaniyor -- ama soket TCP
    # katmaninda hala "acik" sayilabilir (ornegin sunucudan ping/kontrol
    # cercevesi gelmeye devam edip gercek aggTrade verisi hic gelmezse,
    # ya da ag/NAT sessizce paket dusururken soket hicbir hata vermeden
    # sonsuza dek recv()'te bekleyebilir). Canli logda GOZLENDI: durum
    # "canli" kalirken bayat sure 4525 sn'ye (75+ dakika) kadar
    # cikti, bu sure icinde tek bir "websocket acildi"/"koptu" logu
    # OLUSMADI -- yani hic reconnect denemesi tetiklenmedi. watcher
    # artik her turda bunu da kontrol eder; STALE_AFTER_SN asilirsa
    # -- read_message() hic hata vermese de -- baglanti ZORLA yenilenir.
    def recover_if_stale(self) -> bool:
        """Akis uzun suredir bayatsa baglantiyi zorla yeniler.

        Returns:
            True: yenileme baslatildi. False: zaten saglikli veya zaten
            yenileniyor (durum "canli" degil) -- tekrarli cagrilarda
            cakisan birden fazla soket acilmaz.
        """
        with self._kilit:
            if self._durum != "canli" or not self._son_mesaj_ts:
                return False
            yas = time.time() - self._son_mesaj_ts
            if yas <= STALE_AFTER_SN:
                return False
            # Durumu HEMEN degistir (kilit icinde) -- is_stream_stale() artik
            # "canli" gormeyecegi icin bu fonksiyon tekrar cagrilsa da
            # ikinci bir _restart() tetiklenmez (asagidaki run_stream_loop
            # yeni soket acip "canli"ya donene kadar).
            self._durum = "yeniden baglaniyor"
            self._hata = f"zombi baglanti: {yas:.1f} sn veri yok"
            eski_soket, self._socket = self._socket, None
        if eski_soket:
            eski_soket.close()
        _log.warning(
            "websocket zombi baglanti tespit edildi (%.1f sn veri yok), "
            "zorla yeniden baglaniliyor", yas)
        self._restart()
        return True

    # Okuma dongusu; koparsa ustel bekleyip yeniden baglanir.  (eski: _dongu)
    def run_stream_loop(self, version: int) -> None:
        bekle = 1
        while True:
            with self._kilit:
                if version != self._surum:
                    return
                semboller = sorted(self._semboller)
            if not semboller:
                with self._kilit:
                    self._durum, self._socket = "kapali", None
                return
            try:
                yol = "/stream?streams=" + "/".join(f"{s.lower()}@aggTrade" for s in semboller)
                sock = _Socket(yol)
                with self._kilit:
                    if version != self._surum:
                        sock.close(); return
                    self._socket, self._durum, self._hata = sock, "canli", None
                    self._son_mesaj_ts = time.time()
                bekle = 1
                _log.info("websocket acildi: %d sembol", len(semboller))
                while True:
                    ham = sock.read_message()
                    with self._kilit:
                        if version != self._surum:
                            sock.close(); return
                    if ham:
                        self._apply_message(ham)
            except Exception as e:
                with self._kilit:
                    if version != self._surum:
                        return
                    self._durum, self._hata = "yeniden baglaniyor", str(e)
                    if self._socket:
                        self._socket.close()
                    self._socket = None
                log_once(_log, "ws-kopus", f"websocket koptu: {e}")
                time.sleep(bekle)
                bekle = min(30, bekle * 2)

    def _apply_message(self, raw: str) -> None:
        try:
            m = json.loads(raw)
        except ValueError:
            return
        d = m.get("data") or m
        s, p = d.get("s"), d.get("p")
        if not s or p is None:
            return
        try:
            fiyat = float(p)
        except (TypeError, ValueError):
            return
        ts = int(d.get("T") or now_ms())
        with self._kilit:
            if s not in self._semboller:        # yoldaki eski UNSUBSCRIBE mesajlari
                return
            alindi = self._son_mesaj_ts = time.time()
            kayit = self._veri.get(s)
            if kayit is None:
                self._veri[s] = {"f": fiyat, "en": fiyat, "az": fiyat, "ts": ts, "alindi": alindi}
            else:
                kayit["f"], kayit["ts"], kayit["alindi"] = fiyat, ts, alindi
                if fiyat > kayit["en"]:
                    kayit["en"] = fiyat
                if fiyat < kayit["az"]:
                    kayit["az"] = fiyat
            q = self._tickler.get(s)
            if q is None:
                q = self._tickler[s] = collections.deque(maxlen=TICK_BUFFER_PER_SYMBOL)
            q.append({"ts": ts, "fiyat": fiyat})


# Uygulama genelinde tek akis nesnesi.
STREAM = LiveTradeStream()
