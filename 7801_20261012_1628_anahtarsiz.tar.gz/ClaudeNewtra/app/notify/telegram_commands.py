"""Telegram komutlari.

IKI DEGISIKLIK:

1. YETKILENDIRME. Eski `komut_isle(metin, chat)` gelen chat kimligini HIC
   dogrulamiyordu; `ayar["telegram_chat"]` yalnizca GIDEN mesajin varsayilan
   hedefiydi. Yani bota yazabilen HERKES `/bot_ac`, `/bot_kapat` ve
   `/sifirla` -> `/evet` calistirabiliyordu -- sonuncusu gercek para
   defterini siliyordu.

2. KANCA SOZLUGU YOK. Eski `telegram.py` `KANCA = {}` sozlugune sunucu.py
   tarafindan 14 fonksiyon enjekte ediliyordu (dairesel import'tan kacmak
   icin). Bir kanca baglanmayi unutulursa calisma aninda KeyError veriyordu.
   Burada katmanlama sayesinde gerek yok: `notify` servisleri DOGRUDAN
   cagirir, hicbir servis `notify`'i cagirmaz -- dongu olusmaz.

3. `/strateji` artik CALISAN kurallari yazar. Eskisi `giris`/`stop`
   bloklarindaki filtreleri gosteriyordu; aktif strateji `kurallar` tabanli
   oldugu icin onlarin HICBIRI uygulanmiyordu.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Mapping

from app.core.applog import get_logger
from app.notify.telegram_client import (build_panel_keyboard, call_telegram_api,
                                        is_telegram_configured, send_message)

_log = get_logger(__name__)
_bekleyen: dict[str, str] = {}


# Gelen chat yetkili mi? Kayitli chat yoksa kilitlemez (bot kullanilamaz hale gelmesin).
def is_authorized_chat(settings: Mapping[str, Any], chat: Any) -> bool:
    kayitli = str((settings or {}).get("telegram_chat") or "").strip()
    return (not kayitli) or str(chat).strip() == kayitli


def _yuzde(v) -> str:
    return "-" if v is None else f"{float(v):+.2f}%"


# /durum metni.
def render_status(settings, *, live: bool) -> str:
    from app.config.secrets import has_api_credentials
    from app.reporting.stats import compute_today_profit
    from app.strategy.registry import get_active_strategy
    from app.trading.ledger import list_open_orders
    st = get_active_strategy(live=live)
    acik = list_open_orders(live)
    return ("<b>DURUM</b>\n"
            f"mod: {'CANLI' if live else 'KAGIT'}\n"
            f"anahtar: {'var' if has_api_credentials() else 'YOK'}\n"
            f"bot: {'acik' if settings.get('bot_acik') else 'kapali'}\n"
            f"strateji: {st.get('ad')}\n"
            f"acik pozisyon: {len(acik)}\n"
            f"bugun: {_yuzde(compute_today_profit(live))}")


# /profit metni.
def render_profit(settings, *, live: bool) -> str:
    from app.reporting.pnl import build_daily_pnl
    from app.trading.wallet import compute_ledger_stats, get_wallet
    ist = compute_ledger_stats(live)
    p = build_daily_pnl(live, 7)
    c = get_wallet(live, settings)
    return ("<b>KAR/ZARAR</b>\n"
            f"islem: {ist['islem']}  isabet: {ist['isabet']}%\n"
            f"ortalama: {_yuzde(ist['ortalama'])}  toplam: {_yuzde(ist['toplam'])}\n"
            f"7 gun: {p['toplam']:+.4f} USDT\n"
            f"cuzdan: {c.get('toplam')}")


# /pozisyon metni.
def render_positions(settings, *, live: bool) -> str:
    from app.market.price_source import get_prices
    from app.trading.ledger import list_open_orders
    acik = list_open_orders(live)
    if not acik:
        return "<b>POZISYON</b>\nacik pozisyon yok"
    fiyatlar = get_prices([p["sembol"] for p in acik])
    satirlar = ["<b>POZISYON</b>"]
    for p in acik:
        f, _k = fiyatlar.get(p["sembol"], (None, "yok"))
        giris = float(p.get("dolan_fiyat") or p["fiyat"])
        kar = ((float(f) / giris - 1) * 100) if f else None
        satirlar.append(f"{p['sembol']} {_yuzde(kar)}  "
                        f"({p.get('el_kaynak') or p.get('kaynak') or '-'})")
    return "\n".join(satirlar)


# /aday metni.
def render_candidates(settings, *, live: bool, limit: int = 8) -> str:
    from app.market.rank_repository import fetch_latest_snapshot
    from app.strategy.entry import select_candidates
    from app.strategy.registry import get_active_strategy
    st = get_active_strategy(live=live)
    d = fetch_latest_snapshot(limit=400)
    sonuc = select_candidates(d["satir"], st, limit=limit)
    if not sonuc["aday"]:
        return f"<b>ADAY</b>\n{sonuc['tarandi']} coin tarandi, aday yok"
    satirlar = [f"<b>ADAY</b> ({sonuc['tarandi']} tarandi)"]
    for x in sonuc["aday"]:
        hiz = x.get("hiz")
        satirlar.append(f"{x['sembol']}  hiz {hiz:.2f}" if hiz is not None else x["sembol"])
    return "\n".join(satirlar)


# /emirler metni.
def render_orders(settings, *, live: bool, limit: int = 8) -> str:
    from app.trading.ledger import list_closed_orders, list_open_orders
    acik = list_open_orders(live)
    kapali = list_closed_orders(live, limit=limit)
    satirlar = [f"<b>EMIRLER</b>\nacik: {len(acik)}"]
    for e in kapali:
        satirlar.append(f"{e['sembol']} {_yuzde(e.get('kar_p'))} "
                        f"{(e.get('kapanis') or {}).get('sebep', '')}")
    return "\n".join(satirlar)


# /strateji metni -- CALISAN kurallari yazar.   (eski: strateji_metni)
def render_active_rules(settings, *, live: bool) -> str:
    from app.strategy.registry import get_active_strategy, stamp_measurement_context
    st = get_active_strategy(live=live)
    return (f"<b>STRATEJI</b>\n{st.get('ad')}\n\n"
            f"<b>Calisan kurallar:</b>\n{stamp_measurement_context(st)}\n\n"
            f"tutar: {st.get('tutar')}  maks pozisyon: {st.get('maks_pozisyon')}")


# Komutu isler. Yetkisiz chat SESSIZCE reddedilir.   (eski: komut_isle)
def handle_telegram_command(settings: Mapping[str, Any], text: str, chat: Any, *,
                            live: bool, on_settings_change=None) -> str | None:
    if not is_authorized_chat(settings, chat):
        _log.warning("yetkisiz Telegram chat komut denedi: %s", chat)
        return None
    k = (text or "").strip().lower().split("@")[0]

    if k in ("/start", "/yardim", "/help", "/panel"):
        cevap = ("<b>NEWTRADE PANEL</b>\n/durum /profit /pozisyon /aday\n"
                 "/emirler /strateji\n/bot_ac /bot_kapat /sifirla")
    elif k == "/durum":
        cevap = render_status(settings, live=live)
    elif k == "/profit":
        cevap = render_profit(settings, live=live)
    elif k == "/pozisyon":
        cevap = render_positions(settings, live=live)
    elif k == "/aday":
        cevap = render_candidates(settings, live=live)
    elif k == "/emirler":
        cevap = render_orders(settings, live=live)
    elif k == "/strateji":
        cevap = render_active_rules(settings, live=live)
    elif k in ("/bot_ac", "/bot_kapat"):
        ac = k == "/bot_ac"
        if on_settings_change:
            on_settings_change({"bot_acik": ac})
        cevap = f"bot {'ACILDI' if ac else 'KAPATILDI'}"
    elif k == "/sifirla":
        _bekleyen[str(chat)] = "sifirla"
        cevap = ("<b>ONAY</b>\nKAGIT defteri sifirlanacak "
                 "(gercek para defterine DOKUNULMAZ).\nOnaylamak icin /evet")
    elif k == "/evet" and _bekleyen.pop(str(chat), None) == "sifirla":
        from app.trading.ledger import reset_ledger
        r = reset_ledger(False)          # HER ZAMAN kagit defter
        cevap = f"kagit defter sifirlandi ({r['silinen']} kayit, yedek alindi)"
    else:
        cevap = "bilinmeyen komut -- /yardim"
    send_message(settings, cevap, keyboard=build_panel_keyboard(), chat=chat)
    return cevap


# getUpdates dongusu.                          (eski: _dongu)
def run_command_poller(get_settings, *, live_getter, on_settings_change=None) -> None:
    son = 0
    while True:
        ayar = get_settings()
        if not is_telegram_configured(ayar):
            time.sleep(15); continue
        cevap = call_telegram_api(ayar, "getUpdates", offset=son + 1, timeout=25)
        if not cevap or not cevap.get("ok"):
            time.sleep(5); continue
        for g in cevap.get("result", []):
            son = max(son, g.get("update_id", 0))
            msj = g.get("message") or {}
            cb = g.get("callback_query") or {}
            if msj.get("text"):
                handle_telegram_command(ayar, msj["text"], (msj.get("chat") or {}).get("id"),
                                        live=live_getter(),
                                        on_settings_change=on_settings_change)
            elif cb.get("data"):
                handle_telegram_command(ayar, "/" + cb["data"],
                                        ((cb.get("message") or {}).get("chat") or {}).get("id"),
                                        live=live_getter(),
                                        on_settings_change=on_settings_change)


# Dinleyiciyi arka planda baslatir.            (eski: basla)
def start_command_poller(get_settings, *, live_getter, on_settings_change=None) -> threading.Thread:
    t = threading.Thread(target=run_command_poller, args=(get_settings,),
                         kwargs={"live_getter": live_getter,
                                 "on_settings_change": on_settings_change},
                         daemon=True, name="telegram-poller")
    t.start()
    return t
