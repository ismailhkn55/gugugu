"""Telegram gonderimi."""
from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import Any, Mapping

from app.core.applog import get_logger, log_once

_log = get_logger(__name__)
API = "https://api.telegram.org"
TIMEOUT = 35


# Token ve chat tanimli mi.                    (eski: _acik)
def is_telegram_configured(settings: Mapping[str, Any]) -> bool:
    return bool((settings or {}).get("telegram_token") and (settings or {}).get("telegram_chat"))


# Telegram API cagrisi.                        (eski: _cagir)
def call_telegram_api(settings: Mapping[str, Any], method: str, **params) -> dict | None:
    token = (settings or {}).get("telegram_token")
    if not token:
        return None
    veri = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None}).encode()
    istek = urllib.request.Request(f"{API}/bot{token}/{method}", data=veri, method="POST")
    try:
        with urllib.request.urlopen(istek, timeout=TIMEOUT) as c:
            return json.load(c)
    except Exception as e:
        log_once(_log, "tg", f"Telegram cagrisi basarisiz ({method}): {e}")
        return None


# Panel inline tus takimi.                     (eski: _panel_tuslari)
def build_panel_keyboard() -> dict:
    satirlar = [["durum", "profit"], ["pozisyon", "aday"], ["emirler", "strateji"]]
    return {"inline_keyboard": [[{"text": t.upper(), "callback_data": t} for t in s]
                                for s in satirlar]}


# Mesaj gonderir.                              (eski: yaz / tg)
def send_message(settings: Mapping[str, Any], text: str, *,
                 keyboard: dict | None = None, chat: str | None = None) -> bool:
    hedef = chat or (settings or {}).get("telegram_chat")
    if not hedef or not (settings or {}).get("telegram_token"):
        return False
    cevap = call_telegram_api(settings, "sendMessage", chat_id=hedef, text=text,
                              parse_mode="HTML",
                              reply_markup=json.dumps(keyboard) if keyboard else None)
    return bool(cevap and cevap.get("ok"))
