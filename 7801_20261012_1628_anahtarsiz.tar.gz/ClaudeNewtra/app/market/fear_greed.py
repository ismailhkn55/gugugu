"""Kripto Korku & Acgozluluk endeksi (alternative.me) -- borsa API'si DEGIL.

BAN/YUK KORUMASI (01.10.2026, Ismail: "api ban yer, surekli sorgu atma"):
endeks GUNDE BIR guncellenir. Yanit, kaynagin bildirdigi
`time_until_update` suresi kadar onbellekte tutulur; disari gunde
yaklasik 1 istek cikar. Hata olursa HATA_BEKLEME_SN boyunca yeniden
denenmez. Tarayici bu modulu degil 7801'in kendi ucunu okur.

Uydurma deger YOK: hic veri alinamadiysa None doner. Daha once alinmis
GERCEK bir deger varsa kendi zaman damgasiyla dondurulur (arayuz tarihi
gosterir).
"""
from __future__ import annotations

import json
import threading
import time
import urllib.request

from app.core.applog import get_logger, log_once

_log = get_logger(__name__)

FNG_URL = "https://api.alternative.me/fng/?limit=1"
FNG_TIMEOUT_SN = 10
MIN_ONBELLEK_SN = 3600          # kaynak "2 dk sonra" dese bile saatte 1'den sik sorulmaz
MAX_ONBELLEK_SN = 86400
HATA_BEKLEME_SN = 600

_kilit = threading.Lock()
_onbellek: dict = {"veri": None, "gecerli_bitis": 0.0, "dis_istek": 0}


# Endeks degeri (0-100) + kaynagin kendi sinifi; onbellekli, hata olursa son gercek deger ya da None.
def fetch_fear_greed_index() -> dict | None:
    # Kilit ag cagrisini da kapsar: es zamanli iki istek dışarı IKI kez gitmesin.
    with _kilit:
        simdi = time.time()
        if simdi < _onbellek["gecerli_bitis"]:
            return _onbellek["veri"]
        _onbellek["dis_istek"] += 1
        try:
            istek = urllib.request.Request(FNG_URL, headers={"User-Agent": "ClaudeNewtra/7801"})
            with urllib.request.urlopen(istek, timeout=FNG_TIMEOUT_SN) as y:
                ham = json.loads(y.read().decode("utf-8"))
            kayit = ham["data"][0]
            deger = int(kayit["value"])
            if not 0 <= deger <= 100:
                raise ValueError(f"aralik disi deger: {deger}")
            kalan = int(kayit.get("time_until_update") or MIN_ONBELLEK_SN)
            _onbellek["veri"] = {
                "deger": deger,
                "sinif": str(kayit.get("value_classification") or ""),
                "ts": int(kayit["timestamp"]) * 1000,
                "alindi": int(simdi * 1000),
            }
            _onbellek["gecerli_bitis"] = simdi + min(MAX_ONBELLEK_SN, max(MIN_ONBELLEK_SN, kalan))
        except Exception as e:
            log_once(_log, "korku-acgozluluk", f"Korku & Acgozluluk alinamadi: {e}")
            _onbellek["gecerli_bitis"] = simdi + HATA_BEKLEME_SN
        return _onbellek["veri"]


# Kac kez gercekten disari istek atildi (saglik/tanilama -- ban korumasi olculebilsin).
def count_fear_greed_requests() -> int:
    with _kilit:
        return _onbellek["dis_istek"]
