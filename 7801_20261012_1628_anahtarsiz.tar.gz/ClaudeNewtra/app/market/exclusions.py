"""Haric tutulan coinler -- TEK kaynak.

Eski sistemde ayni mantik UC yerde yaziliydi: `veri.haric_kume()`,
`toplayici.haric_liste()` ve `sunucu.haric_yaz()`. Ucunde de ayni 60 saniyelik
onbellek ve ayni "hem BNB hem BNBUSDT bicimi" genislemesi vardi; biri hatayi
logluyor, biri sessizce yutuyordu.

NOT: `toplayici.py` ayri bir servis ve ona DOKUNULMUYOR, yani oradaki kopya
duruyor. Dokumantasyonda isaretli.
"""
from __future__ import annotations

import time

from app.config.paths import get_panel_config_path, get_settings_path
from app.core.applog import get_logger
from app.core.jsonstore import read_json_file, write_json_file

_log = get_logger(__name__)

ONBELLEK_SN = 60
_onbellek: dict = {"ts": 0.0, "kume": frozenset()}


# "BNB" -> {"BNB", "BNBUSDT"} ; "BNBUSDT" -> {"BNBUSDT", "BNB"}
def expand_symbol_forms(raw: str) -> set[str]:
    s = str(raw).strip().upper().replace("/", "")
    if not s:
        return set()
    return {s, s[:-4] if s.endswith("USDT") else s + "USDT"}


# Haric tutulan semboller (her iki bicimde). 60 saniye onbellekli.
def load_excluded_symbols(*, force: bool = False) -> frozenset[str]:
    if not force and time.time() - _onbellek["ts"] < ONBELLEK_SN:
        return _onbellek["kume"]
    ham = read_json_file(get_panel_config_path(), {}) or {}
    kume: set[str] = set()
    for x in (ham.get("haric") or []):
        kume |= expand_symbol_forms(x)
    sonuc = frozenset(kume)
    _onbellek.update(ts=time.time(), kume=sonuc)
    return sonuc


# Haric listesini yazar.
#
# DIKKAT: `panel_ayar.json` bu uygulamanin DISINDAKI `hermes-rank` servisiyle
# PAYLASILAN bir dosyadir -- `NEWTRADE_DATA_DIR` ile izole EDILMEZ, ayri
# `NEWTRADE_RANK_DIR` gerekir. Test ortamlarinda bu ayarlanmazsa gercek
# haric listesi bozulur (23.09.2026'da tam olarak bu oldu: 267 giris 2'ye
# dustu, yedekten geri yuklendi).
def save_excluded_symbols(symbols) -> list[str]:
    temiz, gorulen = [], set()
    for x in symbols or []:
        s = str(x).strip().upper().replace("/", "")
        if s and s not in gorulen:
            gorulen.add(s)
            temiz.append(s)
    yol = get_panel_config_path()
    d = read_json_file(yol, {}) or {}
    d["haric"] = temiz
    write_json_file(yol, d)
    _onbellek.update(ts=0.0)          # onbellegi hemen tazele
    return temiz


# Uzlastirmada pozisyon sayilmayacak varliklar (ornegin BNB komisyon bakiyesi).
def load_position_exclusions() -> list[str]:
    a = read_json_file(get_settings_path(), {}) or {}
    return [str(x).strip().upper() for x in (a.get("pozisyon_haric") or []) if str(x).strip()]


# Pozisyon haric listesini yazar.
def save_position_exclusions(symbols) -> list[str]:
    temiz, gorulen = [], set()
    for x in symbols or []:
        s = str(x).strip().upper().replace("/", "")
        if s and s not in gorulen:
            gorulen.add(s)
            temiz.append(s)
    yol = get_settings_path()
    a = read_json_file(yol, {}) or {}
    a["pozisyon_haric"] = temiz
    write_json_file(yol, a)
    return temiz


# --------------------------------------------------- coklu borsa temiz liste
# 29.09.2026, Ismail: "binancede ve diger borsalarda olan usdt ve usdc
# coinlerini bulmamiz lazim, delist olacaklari ayirt etmemiz lazim, binance
# de delist filter var zaten binancede calisacagimiz sekilde ayarla" --
# rank/toplayici.py'deki canli_semboller()/uygun() ile AYNI mantik (status==
# TRADING + kaldiracli token/stabil/statik-haric filtresi), SADECE:
#   (a) hem USDT hem USDC kuyruguna bakar (toplayici.py yalniz USDT),
#   (b) bu uygulamanin KENDI `binance_rest.fetch_exchange_info()`'sunu
#       kullanir (hiz siniri/yeniden deneme zaten var) -- toplayici.py'nin
#       canli rank dongusune (tur()/uygun()/canli_semboller()) DOKUNULMAZ,
#       o ayri servis kendi USDT-only islerine devam eder.
# Sadece COKLU BORSA HACIM (CHCM) ozelligi icin "bu taban coini diger
# borsalarda da sormaya deger mi" sorusunun TEK KAYNAGI -- rank/strateji
# secimini ETKILEMEZ.
KALDIRACLI_KUYRUK = ("UPUSDT", "DOWNUSDT", "BULLUSDT", "BEARUSDT",
                     "UPUSDC", "DOWNUSDC", "BULLUSDC", "BEARUSDC")
# toplayici.py'deki DURAGAN ile AYNI kume (elle senkron tutulur, orada da
# not edildi: PAXG bilerek YOK -- altin destekli, gercekten oynuyor).
DURAGAN_TABAN = {"USDC", "USDT", "FDUSD", "TUSD", "BUSD", "DAI", "USDP", "EUR",
                 "TRY", "BRL", "GBP", "AUD", "JPY", "ARS", "RUB", "ZAR", "PLN",
                 "RON", "MXN", "COP", "CZK", "UAH", "NGN", "IDRT", "VAI",
                 "BVND", "BIDR", "AEUR", "XUSD", "EURI", "PAX", "SUSD",
                 "USD1", "USDS", "USDSB", "PYUSD", "BFUSD", "BKRW", "USDD",
                 "FRAX", "LUSD", "GUSD", "USDE", "USDF"}

COKLU_ONBELLEK_SN = 3600
_coklu_onbellek: dict = {"ts": 0.0, "kume": frozenset()}


# Binance'te su an TRADING olan, kaldiracli/stabil/statik-haric OLMAYAN
# USDT+USDC ciftlerinin TABAN coin kumesi (orn. {"BTC","ETH","SOL",...}).
# Saatte bir yenilenir (toplayici.py'nin canli_semboller() ile ayni ritim).
def load_clean_base_coins(*, force: bool = False) -> frozenset[str]:
    if not force and _coklu_onbellek["kume"] and time.time() - _coklu_onbellek["ts"] < COKLU_ONBELLEK_SN:
        return _coklu_onbellek["kume"]
    from app.exchange import binance_rest   # dongusel import onlemek icin gecikmeli

    try:
        bilgi = binance_rest.fetch_exchange_info()
    except Exception as e:
        _log.warning("load_clean_base_coins: exchangeInfo alinamadi (%s), onceki liste kullaniliyor",
                     type(e).__name__)
        return _coklu_onbellek["kume"]

    haric = load_excluded_symbols()
    taban: set[str] = set()
    for s in bilgi.get("symbols", []):
        sym = s.get("symbol", "")
        if s.get("status") != "TRADING":
            continue
        if not sym.endswith(("USDT", "USDC")) or sym.endswith(KALDIRACLI_KUYRUK):
            continue
        kok = sym[:-4]
        if not kok or kok in DURAGAN_TABAN:
            continue
        if sym in haric or kok in haric:
            continue
        taban.add(kok)

    if taban:
        _coklu_onbellek.update(ts=time.time(), kume=frozenset(taban))
    return _coklu_onbellek["kume"]
