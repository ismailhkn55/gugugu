"""rank.sqlite okuyucusu -- SALT OKUNUR.

`hermes-rank` servisi (`toplayici.py`) yazar, bu uygulama yalnizca okur.
WAL kipinde `mode=ro` URI ile acilir, boylece yazici calisirken okuma bloke
olmaz.

Sutun listesi ELLE YAZILMAZ: `market.indicators.build_select_clause()`
uretir. Eski `veri.py` icindeki 50 sutunluk elle yazilmis `KOLON` dizesi ve
`toplayici.py`'deki elle sayilmis `"?"*51` bu yuzden vardi -- ikisi
ayrisabiliyordu ve `ema7` tam olarak boyle kayboldu.
"""
from __future__ import annotations

import bisect
import os
import sqlite3
import threading
import time

from app.config.paths import get_rank_db_path
from app.core.applog import get_logger
from app.market.indicators import build_select_clause
from app.market.exclusions import load_excluded_symbols

_log = get_logger(__name__)
_onbellek: dict = {"ts": 0.0, "imza": None, "veri": None}
_onbellek_kilit = threading.Lock()

SNAPSHOT_CACHE_SN = 20
TRAIL_ROUNDS = 20            # gosterimde 20 tur
TRAIL_DIRECTION_ROUNDS = 5   # yon hesabi bilerek son 5 turda kalir


# rank.sqlite'i SALT OKUNUR acar. (eski: _ac)
def open_rank_db_readonly(path: str | None = None) -> sqlite3.Connection:
    yol = path or get_rank_db_path()
    if not os.path.exists(yol):
        raise FileNotFoundError(f"rank veritabani yok: {yol} "
                                "(hermes-rank servisi calisiyor mu?)")
    c = sqlite3.connect(f"file:{yol}?mode=ro", uri=True, timeout=15)
    c.row_factory = sqlite3.Row
    return c


# Veritabanindaki gercek sutunlar -- kayit defteriyle karsilastirmak icin.
def list_db_columns(conn: sqlite3.Connection | None = None) -> set[str]:
    kapat = conn is None
    c = conn or open_rank_db_readonly()
    try:
        return {r[1] for r in c.execute("PRAGMA table_info(anlik)")}
    finally:
        if kapat:
            c.close()


# Kayit defteri ile veritabani semasini karsilastirir.
# Acilista cagrilir: ayrisma varsa SESSIZ KALMAZ.
def verify_schema_contract() -> dict:
    from app.market.indicators import COLUMN_REGISTRY
    dbde = list_db_columns()
    defterde = {c.name for c in COLUMN_REGISTRY if not c.derived}
    eksik = sorted(defterde - dbde)      # defterde var, DB'de yok -> sorgu coker
    fazla = sorted(dbde - defterde - {"ts"})   # DB'de var, defterde yok -> kullanilmiyor
    if eksik:
        _log.error("SEMA AYRISMASI: kayit defterinde olup veritabaninda OLMAYAN "
                   "sutunlar: %s", ", ".join(eksik))
    if fazla:
        _log.warning("veritabaninda olup kayit defterinde olmayan sutunlar: %s",
                     ", ".join(fazla))
    return {"eksik": eksik, "fazla": fazla, "db_sutun": len(dbde),
            "defter_sutun": len(defterde), "uyumlu": not eksik}


# Son turun satirlari + sira izi. Haric tutulanlar elenir. (eski: ozet)
def fetch_latest_snapshot(limit: int = 400, *, cache_sn: int = SNAPSHOT_CACHE_SN) -> dict:
    haric = load_excluded_symbols()
    imza = (limit, haric)
    with _onbellek_kilit:
        if (_onbellek["veri"] is not None and _onbellek["imza"] == imza
                and time.time() - _onbellek["ts"] < cache_sn):
            return _onbellek["veri"]

    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {"ts": None, "turlar": [], "satir": [], "rejim": None}

        turlar = [r[0] for r in c.execute(
            "SELECT DISTINCT ts FROM anlik WHERE ts<=? ORDER BY ts DESC LIMIT ?",
            (son, TRAIL_ROUNDS)).fetchall()][::-1]

        # Haric tutulanlari Python'da eliyoruz; LIMIT'i asmamak icin fazladan cekip kirpiyoruz.
        ham = [dict(r) for r in c.execute(
            f"SELECT {build_select_clause()} FROM anlik "
            f"WHERE ts=? AND rank IS NOT NULL ORDER BY rank LIMIT ?",
            (son, limit + len(haric) + 20)).fetchall()]
        satir = [s for s in ham if s["sembol"] not in haric][:limit]

        if turlar and satir:
            attach_rank_trail(c, satir, turlar)
        attach_market_fields(satir)
        attach_flow_fields(c, satir, turlar[-2] if len(turlar) > 1 else None, haric, limit)
        attach_prev_round_change(c, satir, turlar[-2] if len(turlar) > 1 else None)

        rejim = None
        try:
            r = c.execute("SELECT * FROM rejim WHERE ts=?", (son,)).fetchone()
            rejim = dict(r) if r else None
        except sqlite3.Error:
            pass

    d = {"ts": son, "turlar": turlar, "satir": satir, "rejim": rejim}
    with _onbellek_kilit:
        _onbellek.update(ts=time.time(), imza=imza, veri=d)
    return d


# Verilen sembollerin son tur satirlari -- HARIC LISTESI UYGULANMAZ.
#
# Elde tuttugumuz bir coin haric listesinde olabilir (ornegin sonradan
# elendi); cuzdan ve defter ekranlari onun gostergelerini yine de
# gostermeli. `fetch_latest_snapshot` haric tutulanlari eledigi icin ayri
# bir sorgu gerekiyor.
def fetch_rows_for_symbols(symbols) -> dict[str, dict]:
    istenen = sorted({str(x).strip().upper() for x in (symbols or []) if str(x).strip()})
    if not istenen:
        return {}
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        isaret = ",".join("?" * len(istenen))
        satir = [dict(r) for r in c.execute(
            f"SELECT {build_select_clause()} FROM anlik "
            f"WHERE ts=? AND sembol IN ({isaret})", (son, *istenen)).fetchall()]
        turlar = [r[0] for r in c.execute(
            "SELECT DISTINCT ts FROM anlik WHERE ts<=? ORDER BY ts DESC LIMIT ?",
            (son, TRAIL_ROUNDS)).fetchall()][::-1]
        if turlar and satir:
            attach_rank_trail(c, satir, turlar)
            attach_prev_round_change(c, satir, turlar[-2] if len(turlar) > 1 else None)
        # Piyasa kosullari tek sembolle KURULAMAZ; o anki tum evrenden
        # hesaplanip satira yazilir ki giris/cikis kaydi hangi piyasa
        # kosulunda acildigini da saklasin. (emir kaydindaki market snapshot)
        # 10.10.2026, Ismail: "botta acilis ve kapanista heatmap degeri, yuzde kac yesil
        # yuzde kac kirmizi... analiz yapabilecegimiz seyleri eklesin". Evren artik botun
        # gordugu evrenle AYNI (haric elenmis, `build_round_snapshot`); eskiden haric
        # coinler de genislige sayiliyordu.
        if satir:
            try:
                evren = build_round_snapshot(c, son, turlar, load_excluded_symbols())
                if evren:
                    for r in satir:
                        for alan in PIYASA_ALANLARI:
                            r[alan] = evren[0].get(alan)
            except sqlite3.Error:
                pass
    return {x["sembol"]: x for x in satir}


# Tek sembolun O ANKI piyasa goruntusu -- emir kaydina gomulur.
#
# 23.09.2026, Ismail: "giris detaylari cikis detaylari hepsi olmali ki
# ilerde bize strategy yazarken lazim olabilir". Defterde bugune kadar
# yalnizca fiyat/zaman vardi; hangi kosullarda girildigi KAYITLI DEGILDI,
# dolayisiyla gecmis islemlerden kural cikarmak imkansizdi. Bundan sonra
# her giriste ve cikista o anin tum gosterge degerleri saklanir.
# Rank veritabani okunamazsa emir yolu CALISMAYA DEVAM EDER (None doner).
def capture_market_snapshot(symbol: str) -> dict | None:
    try:
        return fetch_rows_for_symbols([symbol]).get(str(symbol).strip().upper())
    except Exception as e:                      # noqa: BLE001 - emir yolu bozulmamali
        _log.warning("piyasa goruntusu alinamadi (%s): %s", symbol, e)
        return None


# Satirlara son turlardaki rank izini ve yonunu ekler.
def attach_rank_trail(conn: sqlite3.Connection, rows: list[dict], rounds: list[int]) -> None:
    isaret = ",".join("?" * len(rounds))
    iz: dict[str, dict[int, int]] = {}
    deg24: dict[str, dict[int, float]] = {}
    son_evren: list[float] = []                 # son turdaki TUM coinlerin deg24'u
    for r in conn.execute(
            f"SELECT sembol, ts, rank, deg24 FROM anlik WHERE ts IN ({isaret}) "
            f"AND rank IS NOT NULL", rounds).fetchall():
        iz.setdefault(r["sembol"], {})[r["ts"]] = r["rank"]
        if r["deg24"] is not None:
            deg24.setdefault(r["sembol"], {})[r["ts"]] = float(r["deg24"])
            if r["ts"] == rounds[-1]:
                son_evren.append(float(r["deg24"]))
    son_evren.sort()
    for s in rows:
        d = iz.get(s["sembol"], {})
        dizi = [d[t] for t in rounds if t in d]
        s["sira_izi"] = dizi
        s["iz_yon"] = compute_trail_direction(dizi)
        g = deg24.get(s["sembol"], {})
        ilk_ts = next((t for t in rounds if t in d and t in g), None)
        if ilk_ts is None or rounds[-1] not in d or rounds[-1] not in g:
            s["izas"] = s["izas_diger"] = None
            continue
        s["izas"], s["izas_diger"] = compute_own_rank_share(
            d[ilk_ts], g[ilk_ts], d[rounds[-1]], g[rounds[-1]], son_evren)


# IZAS: iz degisimini (ilk - son rank) KENDI ve BASKALARININ payina ayirir.
#
# 05.10.2026, Ismail: "ben 5. idim ama deger kaybettim ve 6. oldum ama 5. hic
# kimildamadi ki". Rank = deg24'e gore sira (toplayici). Soru: benim deg24'um
# ilk turdaki gibi KALSAYDI, son turun evreninde kacinci olurdum (`cf`)?
#   izas       = cf - son_rank   -> KENDI degerimin etkisi (+ = kendim tirmandim)
#   izas_diger = ilk_rank - cf   -> BASKALARININ etkisi (- = biri beni gecti)
# Toplami her zaman ilk_rank - son_rank (iz'in gosterdigi degisim).
# `last_universe` son turdaki tum deg24'ler, SIRALI (benimki dahil).
def compute_own_rank_share(first_rank: int, first_deg: float, last_rank: int,
                           last_deg: float, last_universe: list[float]) -> tuple[int, int]:
    ustumde = len(last_universe) - bisect.bisect_right(last_universe, first_deg)
    if last_deg > first_deg:                    # kendi yeni degerim sayilmasin
        ustumde -= 1
    cf = 1 + ustumde
    return cf - last_rank, first_rank - cf


# Satirlara PIYASA KOSULU ekler: `genislik` ve `total3_5m`.
#
# 25.09.2026, Ismail (TP085 deneyi): "heatmap'in en az %25'i yesil olmali ve
# TOTAL3 bir onceki 5 dk'da yukseliyor olmali". Bu ikisi TEK SEMBOLLE
# kurulamaz -- tum evrenin snapshot'i gerekir, o yuzden `iz_yon` gibi
# "calisma aninda turetilmis" bir alan ve GERIYE-TESTTE SINANAMAZ
# (bkz. strategy/backtest.py UNTESTABLE_FIELDS).
#
# Tanimlar app/market/indicators.py'deki sutun kaydindaki ile BIREBIR:
#   genislik   = deg24>0 olan coinlerin payi (%)     (heatmap yesil %)
#   total3_5m  = hacim-agirlikli ort deg5m (%)       (TOTAL3 son 5m yonu)
#               (app/market/total3: deg24-agirlikli versiyonunun hizli kardesi;
#                "son 5 dakikada yukseliyor mu" sorusu icin deg5m gerekir)
#   kirmizi_pct = deg24<0 olan coinlerin payi (%)     (heatmap kirmizi %, 10.10.2026)
#   total3_24   = hacim-agirlikli ort deg24 (%)      (heatmap'teki TOTAL3, 10.10.2026)
def attach_market_fields(rows: list[dict]) -> None:
    if not rows:
        return
    olcu = [r for r in rows if r.get("deg24") is not None]
    genislik = (100.0 * sum(1 for r in olcu if (r.get("deg24") or 0) > 0) / len(olcu)
                if olcu else None)
    kirmizi = (100.0 * sum(1 for r in olcu if (r.get("deg24") or 0) < 0) / len(olcu)
               if olcu else None)
    hacimli24 = [r for r in olcu if (r.get("hacim") or 0) > 0]
    toplam24 = sum(float(r["hacim"]) for r in hacimli24)
    total3_24 = (sum(float(r["deg24"]) * float(r["hacim"]) for r in hacimli24) / toplam24
                 if toplam24 else None)
    hacimli = [r for r in rows
               if r.get("deg5m") is not None and (r.get("hacim") or 0) > 0]
    toplam_h = sum(float(r["hacim"]) for r in hacimli)
    total3_5m = (sum(float(r["deg5m"]) * float(r["hacim"]) for r in hacimli) / toplam_h
                 if toplam_h else None)
    # 10.10.2026, Ismail: "strategy'e ekleyelim: en az 10 tanesi artida olmali ve en az 4 tanesi
    # yuzde 2'yi gecmis olmali" -- UTC gun acilisina gore (gun_pct), evrendeki coin SAYISI.
    gunluk = [float(r["gun_pct"]) for r in rows if r.get("gun_pct") is not None]
    arti_say = sum(1 for g in gunluk if g > 0) if gunluk else None
    iki_say = sum(1 for g in gunluk if g > 2) if gunluk else None
    for r in rows:
        r["genislik"] = genislik
        r["total3_5m"] = total3_5m
        r["kirmizi_pct"] = kirmizi
        r["total3_24"] = total3_24
        r["gun_arti_sayi"] = arti_say
        r["gun_iki_ustu_sayi"] = iki_say


# Satirlara bir ONCEKI tura gore degisim ekler: `obv_aci_degisim`.
#
# 10.10.2026, Ismail: "anasayfada OBV'nin yaninda +78 yaziyor (obv_aci), onu strategy'e su sekilde
# ekleyebilir miyiz: 0'dan buyuk VE yukseliyor". Kural motorunda "onceki tura gore artti" operatoru
# yok ("yukari" = > 0); bu yuzden fark ALAN olarak: obv_aci (bu tur) - obv_aci (onceki tur, 5 dk).
# Kural: obv_aci > 0 VE obv_aci_degisim > 0. Onceki turda yoksa None (OLCULMEDI).
def attach_prev_round_change(conn: sqlite3.Connection, rows: list[dict], prev_round: int | None) -> None:
    for r in rows:
        r["obv_aci_degisim"] = None
    if not rows or prev_round is None:
        return
    try:
        onceki = {s: a for s, a in conn.execute(
            "SELECT sembol, obv_aci FROM anlik WHERE ts=?", (prev_round,)).fetchall()}
    except sqlite3.Error as e:
        _log.warning("onceki tur degisimi hesaplanamadi: %s", e)
        return
    for r in rows:
        a, b = r.get("obv_aci"), onceki.get(r["sembol"])
        if a is not None and b is not None:
            r["obv_aci_degisim"] = float(a) - float(b)


# Giris/cikis kaydina tum evrenden kopyalanan piyasa alanlari.
PIYASA_ALANLARI = ("genislik", "kirmizi_pct", "total3_5m", "total3_24",
                   "usdt_hacim_d", "akis_coin", "gun_arti_sayi", "gun_iki_ustu_sayi")


# Satirlara PARA AKISI ekler: `usdt_hacim_d` ve `akis_coin`.
#
# 10.10.2026, Ismail: "heatmapte USDT coinlere akiyor diyor ya, onu da ekleyelim,
# sonra ben onu strategy'e eklerim". Heatmap rozeti (`handle_heatmap`) Binance'in TUM
# USDT hacmini bir ONCEKI heatmap cagrisiyla karsilastiriyor: o cagri yalniz heatmap
# sayfasi acikken olur (aralik belirsiz, saatler olabilir), her seferinde dis istek
# atar ve gecmiste kurulamaz. Strateji alani olarak AYNI formul her turda, bir ONCEKI
# turla (5 dk) ve evrenin kendi 24s hacimlerinden (dis istek YOK):
#   usdt_hacim_d = iki turda da olan coinlerin toplam 24s hacmi, simdi / onceki - 1 (%)
#                  (listeye giren/cikan coin toplami ziplatmasin diye ortak coinler)
#   akis_coin    = 1  <=>  usdt_hacim_d < -1  VE  genislik >= 55   (rozetin esikleri)
# Hata olursa alanlar None kalir (OLCULMEDI) -- bot dongusu BOZULMAZ.
AKIS_USDT_ESIK = -1.0
AKIS_GENISLIK_ESIK = 55.0


def attach_flow_fields(conn: sqlite3.Connection, rows: list[dict], prev_round: int | None,
                       excluded, limit: int = 400) -> None:
    for r in rows:
        r["usdt_hacim_d"] = r["akis_coin"] = None
    if not rows or prev_round is None:
        return
    try:
        onceki = {s: h for s, h in [
            (x[0], x[1]) for x in conn.execute(
                "SELECT sembol, hacim FROM anlik WHERE ts=? AND rank IS NOT NULL "
                "ORDER BY rank LIMIT ?", (prev_round, limit + len(excluded) + 20)).fetchall()
            if x[0] not in excluded][:limit] if h}
        ortak = [r for r in rows if r.get("hacim") and r["sembol"] in onceki]
        simdi_t = sum(float(r["hacim"]) for r in ortak)
        onceki_t = sum(float(onceki[r["sembol"]]) for r in ortak)
        if not (simdi_t > 0 and onceki_t > 0):
            return
        d = (simdi_t / onceki_t - 1.0) * 100.0
        g = rows[0].get("genislik")
        ak = None if g is None else int(d < AKIS_USDT_ESIK and g >= AKIS_GENISLIK_ESIK)
    except (sqlite3.Error, TypeError, ValueError) as e:
        _log.warning("akis alanlari hesaplanamadi: %s", e)
        return
    for r in rows:
        r["usdt_hacim_d"], r["akis_coin"] = d, ak


# Iz yonu: POZITIF = siralamada tirmaniyor (rank kuculuyor).
# Yeterli tur yoksa None doner -- "olculmedi" ile "kipirdamadi" AYRIDIR.
# (Eski `veri.py` ikisine de 0 donuyordu; "UYDURMA VERI YOK" ilkesine aykiriydi.)
def compute_trail_direction(trail: list[int]) -> float | None:
    son = trail[-TRAIL_DIRECTION_ROUNDS:]
    if len(son) < 2:
        return None
    return float(son[0] - son[-1])


# N dakika onceki rank'lar: {sembol: eski_rank}.  (eski: rank_gecmisi)
def fetch_rank_history(minutes: int = 15) -> dict[str, int]:
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        hedef = son - minutes * 60_000
        eski = c.execute("SELECT max(ts) FROM anlik WHERE ts <= ?", (hedef,)).fetchone()[0]
        if not eski:
            return {}
        return {r["sembol"]: r["rank"] for r in c.execute(
            "SELECT sembol, rank FROM anlik WHERE ts=? AND rank IS NOT NULL",
            (eski,)).fetchall()}


# YAPAY ZEKA MIMO (24.09.2026): N dakika onceki CCI degerleri {sembol: cci} (heatmap filtresi).
def fetch_cci_history(minutes: int = 5) -> dict[str, float]:
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        hedef = son - minutes * 60_000
        eski = c.execute(
            "SELECT max(ts) FROM anlik WHERE ts <= ?", (hedef,)
        ).fetchone()[0]
        if not eski:
            return {}
        out: dict[str, float] = {}
        for r in c.execute(
            "SELECT sembol, cci FROM anlik WHERE ts=? AND cci IS NOT NULL",
            (eski,),
        ):
            try:
                out[r["sembol"]] = float(r["cci"])
            except (TypeError, ValueError):
                pass
        return out


# Son turdaki tum fiyatlar: {sembol: fiyat}.  (eski: son_fiyatlar -- hic cagrilmiyordu)
def fetch_snapshot_prices() -> dict[str, float]:
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        return {r[0]: r[1] for r in c.execute(
            "SELECT sembol, fiyat FROM anlik WHERE ts=?", (son,)).fetchall()}


# --- GECMIS TURLAR (10.10.2026) ---
# Ismail: "strategy ne diyorsa ona gore secmeli". Mumdan yeniden kurulan geriye-test
# (`/yerel/gecmis-sinyal`) genislik / rank_hacim / izas kurallarini SINAYAMIYOR; oysa
# canli botun okudugu satirlar her tur icin zaten `anlik`'ta. Gecmis bir turun goruntusu
# = fetch_latest_snapshot(limit=400)'un O TURDA calismis hali: ayni sorgu, ayni haric
# listesi, ayni 20 turluk iz (izas) ve ayni genislik (haric elendikten SONRAKI satirlar).
# Dogrulama (DOKUMANTASYON 7.59): bot girislerinin kayitli satirlariyla birebir.
def build_round_snapshot(conn: sqlite3.Connection, son: int, rounds: list[int],
                         excluded, limit: int = 400) -> list[dict]:
    ham = [dict(r) for r in conn.execute(
        f"SELECT {build_select_clause()} FROM anlik "
        f"WHERE ts=? AND rank IS NOT NULL ORDER BY rank LIMIT ?",
        (son, limit + len(excluded) + 20)).fetchall()]
    satir = [s for s in ham if s["sembol"] not in excluded][:limit]
    if rounds and satir:
        attach_rank_trail(conn, satir, rounds)
    attach_market_fields(satir)
    attach_flow_fields(conn, satir, rounds[-2] if len(rounds) > 1 else None, excluded, limit)
    attach_prev_round_change(conn, satir, rounds[-2] if len(rounds) > 1 else None)
    return satir


# [start_ms, end_ms] araligindaki turlar, her biri kendi iz penceresiyle:
# [(tur_ts, [o tura kadarki son TRAIL_ROUNDS tur])].
def list_rounds_with_trail(conn: sqlite3.Connection, start_ms: int,
                           end_ms: int) -> list[tuple[int, list[int]]]:
    once = [r[0] for r in conn.execute(
        "SELECT DISTINCT ts FROM anlik WHERE ts<? ORDER BY ts DESC LIMIT ?",
        (start_ms, TRAIL_ROUNDS - 1)).fetchall()][::-1]
    icinde = [r[0] for r in conn.execute(
        "SELECT DISTINCT ts FROM anlik WHERE ts>=? AND ts<=? ORDER BY ts",
        (start_ms, end_ms)).fetchall()]
    tum = once + icinde
    return [(ts, tum[max(0, i - TRAIL_ROUNDS + 1):i + 1])
            for i, ts in enumerate(tum) if ts >= start_ms]
