"""Tick arsivi.

Eski `tickler/*.jsonl` dosyalarinda ayni `(ts, fiyat)` cifti defalarca
yaziliydi -- orneklenen dosyada %35 tekrar, toplam 217 MB. Websocket ayni
fiyati arka arkaya gonderdiginde her biri ayri satir olarak diske
yaziliyordu. Burada son yazilan cift hatirlanir, aynisi tekrar yazilmaz.
"""
from __future__ import annotations

import os

from app.config.paths import get_tick_dir
from app.core.applog import get_logger
from app.core.jsonstore import read_jsonl_records

_log = get_logger(__name__)


def _yol(symbol: str) -> str:
    return os.path.join(get_tick_dir(), f"{symbol.upper()}.jsonl")


# Bir sembolun tick gecmisini okur.
def read_tick_archive(symbol: str, *, limit: int | None = None) -> list[dict]:
    return list(read_jsonl_records(_yol(symbol), limit=limit))
