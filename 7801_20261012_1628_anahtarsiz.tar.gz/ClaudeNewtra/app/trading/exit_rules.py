"""Cikis planlari -- `kar_al` ve `stop` alanlarinin TEK YAZICISI.

ESKI SISTEMDEKI CAKISMA (kullanicinin "birbiriyle cakisiyor" dedigi sey):
giriste `_bot_strateji_giris_dene` HAM stratejinin hedefini `kar_al`'a
yaziyordu (`ST.hedef_belirle(hiz, st_i)` -> hedef_normal = 1.8), cikista ise
`_bot_cikis_olustur` o stratejiyi 999'larla eziyordu. Ama 1 saniyelik
`takipci` yazilmis `kar_al`'i okuyup satiyordu.

Canli defterde olculdu (defter_dry.json id 307, SANTOSUSDT):
    giris 0.529   kar_al 0.539 (= +%1.8 = hedef_normal)
    stop 0.513 (= -%3.0 = ayar["stop"])   stop_guncel 0.49726 (= -%6.0 = bot_cikis_stop)
Yani `bot_cikis_esik: 5.0` ayari HIC CALISMIYOR; merdiven/dinamik takip
devreye girmeden once pozisyon +%1.8'de kesiliyordu.

BURADA: her emrin plani `plan_for_source()` ile TEK yerden uretilir ve
`apply_plan_to_order()` ile deftere yazilir. Baska hicbir kod `kar_al`
ya da `stop` alanina dokunmaz.
"""
from __future__ import annotations

from typing import Any, Mapping

from app.strategy.targets import resolve_profit_target, resolve_stop_price

# Cikis blogunu "kapali" hale getiren degerler: karar TAMAMEN stop
# merdiveninden/dinamik takipten gelir.
_KAPALI_CIKIS: dict[str, Any] = {
    "hedef_yavas": 999, "hedef_normal": 999,
    "kar_trailing_esik": None, "trailing": None,
    "hizli_esik": 999999, "hiz_yavas": -999999, "zaman_asimi_dk": 0,
}
# Eski `ortak_stop_ek`: merdiven varken kullanilmaz, geriye donuk uyum icin.
_ESKI_KILIT_ALANLARI: dict[str, Any] = {
    "basabas_esik": 0.8, "kilit_esik": 1.2, "kilit_deger": 1.2,
    "fitil_kullan": False, "fitil_maks": 10,
}
_BEKLET_KAPALI: dict[str, Any] = {"aktif": False}


def _dinamik_ortak(settings: Mapping[str, Any]) -> dict:
    """Eskiden KODA GOMULU olan uc sayi; artik ayar semasindan geliyor."""
    return {
        "dinamik_atr_carpan": float(settings.get("dinamik_atr_carpan", 1.2)),
        "dinamik_mesafe_tavan": float(settings.get("dinamik_mesafe_tavan", 4.0)),
        "dinamik_mesafe_min": float(settings.get("dinamik_mesafe_taban_min", 0.6)),
    }


# BOT ve AL TAKIP'in ORTAK plani.              (eski: _bot_cikis_olustur)
#
# Ismail: "stratejide sadece alis ayarlari olsun, cikis ayarlari cok karisik,
# surekli zararla kapatiyordu -- Ayarlar sekmesine tasi, AL TAKIP butonu gibi
# basit trailing kullansin". Botun actigi TUM pozisyonlar, hangi strateji
# actirmis olursa olsun, stratejinin kendi cikis/stop alanlarini DEGIL bu
# tek ortak global kurali kullanir.
def build_bot_plan(settings: Mapping[str, Any]) -> dict:
    baslangic = float(settings.get("bot_cikis_stop", 3.0))
    m_esik = settings.get("bot_cikis_merdiven_esik")
    m_kilit = settings.get("bot_cikis_merdiven_kilit")
    if m_esik is not None and m_kilit is not None:
        # 21.09.2026: gercek merdiven adimi -- esik dinamik_esik'ten DUSUK
        # olmali ki arada bir koruma penceresi olsun; ikisi ayni noktada
        # tetiklenirse dinamik merdiveni aninda ezer, hicbir katkisi olmaz.
        merdiven = [(float(m_esik), float(m_kilit))]
    else:
        merdiven = [(999999.0, -baslangic)]
    return {
        "cikis": dict(_KAPALI_CIKIS),
        "stop": {
            "baslangic": baslangic,
            "merdiven": merdiven,
            "dinamik_esik": float(settings.get("bot_cikis_esik", 2.0)),
            "dinamik_mesafe_taban": float(settings.get("bot_cikis_mesafe", 1.0)),
            **_dinamik_ortak(settings),
            # 22.09.2026 IVME GENISLETME (CHR ornegi: +%1.2'de kesildi,
            # 27 dk sonra +%22.9). Kapaliysa carpan None -> o dal HIC calismaz.
            "ivme_carpan": (float(settings.get("bot_cikis_ivme_carpan", 3.0))
                            if settings.get("bot_cikis_ivme_acik") else None),
            "ivme_esik": float(settings.get("bot_cikis_ivme_esik", 1.0)),
            "ivme_hacim": float(settings.get("bot_cikis_ivme_hacim", 3.0)),
        },
    }


# ATR IZI: kilit merdiveni YOK; +aktif%'e kadar yalniz baslangic stop, sonra
# kilit% ve tepe - carpan x ATR(5m)% izi.
#
# 06.10.2026, Ismail: "erken ciktik, hala yukseliyorlar ve %6 stopa da gelmediler".
# Olculdu (DOKUMANTASYON 7.52): gercek cuzdanin 308 islemi + botun 425 girisi,
# 1m mum, kotumser sira. Merdiven (+1.8 -> +0.7) en kotu yarida -%0.67; bu plan
# (+5 / kilit 2 / ATRx4) dort yarinin dordunde arti, en kotu +%0.30. Komsulari
# (+4/+6, kilit 2, x4) da arti -- tek sansli nokta degil.
# `cark`: stop asla geri cekilmez. `atr_zorunlu`: ATR yoksa iz HAREKET ETMEZ
# (yoksa mesafe tabana duser ve stop bir anda tepeye yapisir).
def build_atr_trail_plan(settings: Mapping[str, Any]) -> dict:
    aktif = float(settings.get("atr_iz_aktif", 5.0))
    return {
        "ad": "AL (ATR izi)",
        "cikis": dict(_KAPALI_CIKIS),
        "stop": {
            "baslangic": float(settings.get("al_stop", 3.0)),
            **_ESKI_KILIT_ALANLARI,
            "merdiven": [(aktif, float(settings.get("atr_iz_kilit", 2.0)))],
            "dinamik_esik": aktif,
            "dinamik_atr_carpan": float(settings.get("atr_iz_carpan", 4.0)),
            "dinamik_mesafe_taban": float(settings.get("atr_iz_min", 1.0)),
            "dinamik_mesafe_tavan": 100.0,      # tavan yok: mesafe yalniz ATR'den
            "dinamik_mesafe_min": float(settings.get("atr_iz_min", 1.0)),
            "atr_zorunlu": True,
            "cark": True,
        },
        "beklet": dict(_BEKLET_KAPALI),
    }


# AL butonu: kademeli stop merdiveni, trailing YOK.  (eski: el_strateji("al"))
# `al_cikis_modu == "atr_iz"` ise ATR IZI plani doner (bot `cikis_yontemi: al`
# pozisyonlari da bu yoldan gectigi icin onlar da ayni plani kullanir).
def build_manual_plan(settings: Mapping[str, Any]) -> dict:
    if str(settings.get("al_cikis_modu") or "merdiven").lower() == "atr_iz":
        return build_atr_trail_plan(settings)
    return {
        "ad": "AL (kademeli stop)",
        "cikis": dict(_KAPALI_CIKIS),
        "stop": {
            "baslangic": float(settings.get("al_stop", 3.0)),
            **_ESKI_KILIT_ALANLARI,
            # HATA DUZELTMESI (Ismail, gercek COTI kaybi ile yakaladi):
            # eskiden %0.6'da basabase kilitleyen bir basamak vardi -- istek
            # BU DEGILDI. "0.6'nin ALTINDA stop-loss'a kadar BEKLE": %3'e
            # kadar HICBIR kilitleme yok, stop baslangicta kalir. Coin
            # +%0.6-2.5 arasi gidip gelince erken kilitlenip kucuk bir
            # kayipla satilmasin diye o basamak KALDIRILDI.
            "merdiven": [
                (float(settings.get("al_kilit2_esik", 3.0)),
                 float(settings.get("al_kilit2_yuzde", 1.0))),
                (float(settings.get("al_kilit3_esik", 5.0)),
                 float(settings.get("al_kilit3_yuzde", 3.0))),
            ],
            "dinamik_esik": float(settings.get("al_dinamik_esik", 7.0)),
            "dinamik_mesafe_taban": float(settings.get("al_trailing_mesafe", 1.0)),
            **_dinamik_ortak(settings),
        },
        "beklet": dict(_BEKLET_KAPALI),
    }


# AL TAKIP butonu: botla BIREBIR AYNI mekanik.  (eski: el_strateji("altakip"))
#
# 21.09.2026, Ismail: "AL TAKIP butonu ile botun cikisi AYNI olsun, strateji
# sadece giris kurallarindan olussun". Eskiden bu buton ya aktif stratejinin
# cikisini ya kendi `altakip_*` ayarlarini kullaniyordu -- iki kaynak,
# tutarsizlik riski. (Not: `altakip_*` ayarlari bu yuzden artik OLU.)
def build_follow_plan(settings: Mapping[str, Any]) -> dict:
    p = build_bot_plan(settings)
    return {"ad": "AL TAKIP (trailing)", "cikis": p["cikis"], "stop": p["stop"],
            "beklet": dict(_BEKLET_KAPALI)}


# ALSAT 1/2/3: sabit hedef, hedefe ORANTILI kilit. (eski: el_strateji("alsatN"))
#
# HATA DUZELTMESI (Ismail: "1.8 yaziyor ama 0.8'de kapatiyor, 1.8 istedi isem
# minimum 1.4 alabilmeli"): eskiden SABIT 0.8/1.2 kilit esikleri kullanilirdi,
# hedef ne olursa olsun hep ayni yerde kilitleniyordu. Simdi kilit hedefin
# ~%78'i -- 1.8 hedefte ~1.4 eder, istenen tam buydu.
def build_scalp_plan(settings: Mapping[str, Any], slot: int = 1) -> dict:
    alan = {2: "alsat_hedef_2", 3: "alsat_hedef_3"}.get(int(slot), "alsat_hedef_1")
    hedef = float(settings.get(alan, 1.8))
    oran = float(settings.get("alsat_kilit_orani", 0.78))
    kilit = round(hedef * oran, 4)
    return {
        "ad": f"ALSAT {hedef}%",
        "cikis": {
            "hedef_yavas": hedef, "hedef_normal": hedef,
            "kar_trailing_esik": None, "trailing": None,
            "hizli_esik": 999999, "hiz_yavas": -999999, "zaman_asimi_dk": 0,
        },
        "stop": {
            # `merdiven` tanimli oldugu icin basabas_esik/kilit_esik/
            # kilit_deger alanlari HIC okunmaz (bkz. targets.resolve_stop_price
            # dal siralamasi). Ilk yazimimda "tamamlik olsun" diye eklemistim;
            # eski planda yoklar ve esdegerlik testi farki yakaladi. Var olmayan
            # alan eklemek de bir ayrisma bicimi -- cikarildi.
            "baslangic": float(settings.get("alsat_stop", 3.0)),
            "fitil_kullan": False, "fitil_maks": 10,
            "merdiven": [(kilit, kilit)],
        },
        "beklet": dict(_BEKLET_KAPALI),
    }


# Emrin kaynagina gore DOGRU plani secer -- tek giris noktasi.
def plan_for_source(source: str | None, settings: Mapping[str, Any],
                    *, strategy: Mapping[str, Any] | None = None) -> dict:
    k = (source or "").lower()
    if k == "al":
        return build_manual_plan(settings)
    if k == "altakip":
        return build_follow_plan(settings)
    if k.startswith("alsat"):
        return build_scalp_plan(settings, int(k[-1]) if k[-1].isdigit() else 1)
    # kaynak yok = BOT pozisyonu: stratejinin GIRIS kurallari kalir,
    # cikis/stop global ortak plandan gelir.
    #
    # 25.09.2026, Ismail (TP085): strateji KENDI hedefini tanimlayabilsin --
    # "tp 0,85 i begendim, bunu strategy olarak yap". Stratejide `cikis` /
    # `stop` ALANI YOKSA eski davranis AYNEN devam (global plan); varsa
    # ustune biner. Yani strateji seviyesinde TP deneyi opt-in'dir; mevcut
    # "HA Cok Zamanli N3" ve global ayarlar hic degismez.
    temel = dict(strategy or {})
    # 05.10.2026, Ismail: "bot AL BUTONU (kademeli stop) bu butonun ayari ile girsin".
    # Stratejide `cikis_yontemi: "al"` varsa bot pozisyonu AL dugmesinin planiyla
    # (al_stop + al_kilit* merdiveni + al_dinamik iz) yonetilir; stratejinin kendi
    # `stop`/`cikis` alanlari bu durumda KULLANILMAZ (buton ayari neyse o).
    if strategy and str(strategy.get("cikis_yontemi") or "").lower() == "al":
        temel.update(build_manual_plan(settings))
        return temel
    p = build_bot_plan(settings)
    cikis = dict(p["cikis"]); stop = dict(p["stop"])
    _sc = strategy.get("cikis") if strategy else None
    _ss = strategy.get("stop") if strategy else None
    if isinstance(_sc, Mapping):
        cikis.update({k: v for k, v in _sc.items() if v is not None})
    if isinstance(_ss, Mapping):
        stop.update({k: v for k, v in _ss.items() if v is not None})
    temel["cikis"], temel["stop"] = cikis, stop
    temel.setdefault("beklet", dict(_BEKLET_KAPALI))
    return temel


# Plani emrin `kar_al` / `stop` alanlarina yazar -- BU ALANLARIN TEK YAZICISI.
# Eski sistemde giris ve cikis bu alanlari ayri ayri, birbirinden habersiz
# yaziyordu; `bot_cikis_esik` ayarinin hic calismamasinin sebebi buydu.
def apply_plan_to_order(order: dict, plan: Mapping[str, Any], *,
                        entry_price: float, atr_pct: float | None = None,
                        round_price=None) -> dict:
    hedef = resolve_profit_target(order.get("hiz"), plan["cikis"])
    stop = resolve_stop_price(entry_price, entry_price, plan["stop"], atr_pct=atr_pct)

    kar_al = None
    if hedef.kind == "sabit" and hedef.target is not None and hedef.target < 900:
        kar_al = entry_price * (1 + float(hedef.target) / 100)
        if round_price:
            kar_al = round_price(kar_al)
    stop_fiyat = round_price(stop.price) if round_price else stop.price

    order["kar_al"] = kar_al
    order["stop"] = stop_fiyat
    order["stop_guncel"] = stop_fiyat      # giris ve yonetim AYNI kaynaktan
    order["stop_sebep"] = stop.reason
    order["hedef_tur"] = hedef.kind
    order["en_yuksek"] = entry_price
    return order
