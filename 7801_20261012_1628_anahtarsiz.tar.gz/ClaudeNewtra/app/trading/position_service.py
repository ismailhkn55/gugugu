"""Pozisyon kapatma -- gercek paranin en riskli noktasi.

ESKI SISTEMDEKI IKI KUSUR:

1. CIFTE MARKET SELL RISKI. `takipci` (1 sn) ve `_pozisyon_kapat` satis
   emrini gondermeden once defterdeki `durum`/`kapanis` alanini YENIDEN
   OKUMUYORDU. Senaryo: takipci stop gorup SELL gonderir; ayni saniye
   `bot_turu` elindeki 5 saniyelik eski anlik goruntuyle `ST.cikis_karari`
   SAT der ve IKINCI SELL gider. `/yerel/emir/hepsini-kapat` ayni anda
   basilirsa ucuncu. Elde coin kalmadigi icin ikincisi hata verir, ama
   yanlis miktarla dolarsa GERCEK ZARAR olur.

2. IKI AYRI KAPATMA UYGULAMASI. `takipci` (sunucu.py:1022-1057) ve
   `_pozisyon_kapat` (1906-1990) ayni isi iki farkli kodla yapiyordu:
   biri giris fiyatini NOMINAL `fiyat`tan, digeri GERCEK `dolan_fiyat`tan
   aliyordu; takipci ile kapanan pozisyonlar icin Telegram bildirimi HIC
   GITMIYORDU; BOT sayaclarini guncelleyen 5 satir iki yere kopyalanmisti.

BURADA: satis TEK fonksiyondan gecer, kilit satistan ONCE alinir ve defter
yeniden okunur.
"""
from __future__ import annotations

from typing import Any, Callable, Mapping

from app.core.applog import get_logger
from app.core.errors import LedgerConflictError
from app.core.locking import ledger_lock
from app.core.timeutil import now_ms
from app.market.rank_repository import capture_market_snapshot
from app.trading.ledger import list_open_orders, load_ledger, save_ledger

_log = get_logger(__name__)


# Kapanisi deftere ve sayaclara isler -- TEK kopya.
def record_position_close(live: bool, order_id: int, *, price: float, reason: str,
                          commission_pct: float = 0.0, toz: bool = False) -> dict:
    # Piyasa goruntusu KILIDIN DISINDA alinir: kilit icinde yalnizca
    # oku-degistir-yaz kalsin (bkz. core/locking.py kurali).
    cikis_piyasa = None
    with ledger_lock():
        d = load_ledger(live)
        for i, e in enumerate(d["emirler"]):
            if int(e.get("id", -1)) != int(order_id):
                continue
            if e.get("kapanis"):
                raise LedgerConflictError(
                    f"pozisyon zaten kapali (id={order_id}, live={live})")
            # Giris fiyati: GERCEK ortalama dolum (nominal degil).
            giris = float(e.get("dolan_fiyat") or e["fiyat"])
            miktar = float(e.get("dolan_miktar") or e.get("miktar") or 0)
            brut_p = (price / giris - 1) * 100 if giris else 0.0
            # Komisyon SADECE burada, BIR KEZ dusulur. 13.09.2026'da
            # esikleri de komisyon kadar kaydirmak ayni komisyonu IKI KEZ
            # dusuyordu ve kar hep ~0 cikiyordu.
            net_p = brut_p - float(commission_pct or 0)
            e["kapanis"] = {"fiyat": price, "sebep": reason, "ts": now_ms()}
            if toz:
                e["kapanis"]["toz"] = True
            # CIKIS ANININ PIYASA GORUNTUSU -- girisinkiyle birlikte
            # "hangi kosulda girdik, hangi kosulda ciktik" sorusunu
            # gecmis kayitlardan cevaplanabilir kilar.
            if cikis_piyasa is None:
                cikis_piyasa = capture_market_snapshot(e.get("sembol") or "")
            e["cikis_piyasa"] = cikis_piyasa
            e["durum"] = "KAPANDI"
            e["kar_brut_p"] = round(brut_p, 3)
            e["kar_p"] = round(net_p, 3)
            e["kar"] = round(giris * miktar * net_p / 100, 6)
            d["emirler"][i] = e
            save_ledger(d, live)
            return e
    raise LedgerConflictError(f"emir bulunamadi (id={order_id}, live={live})")


# Pozisyonu kapatir. Satis emri GONDERILMEDEN ONCE kilit alinir ve
# defter yeniden okunur -- cifte SELL yapisal olarak imkansiz.
#
# `sell` : gercek satisi yapan fonksiyon (kagit modda None gecilir).
#          Kilit ICINDE cagrilmaz -- ag cagrisi kilit disinda yapilir,
#          sonra kapanis kilit icinde yazilir.
def close_position(live: bool, order_id: int, *, price: float, reason: str,
                   sell: Callable[[dict], dict] | None = None,
                   commission_pct: float = 0.0,
                   on_closed: Callable[[dict], None] | None = None) -> dict:
    # 1) KILIT ICINDE: hala acik mi, ve "kapatiliyor" olarak isaretle.
    with ledger_lock():
        d = load_ledger(live)
        hedef = None
        for i, e in enumerate(d["emirler"]):
            if int(e.get("id", -1)) == int(order_id):
                hedef, sira = e, i
                break
        if hedef is None:
            raise LedgerConflictError(f"emir bulunamadi (id={order_id}, live={live})")
        if hedef.get("kapanis"):
            raise LedgerConflictError(
                f"pozisyon zaten kapali (id={order_id}, live={live}) -- "
                "cifte satis engellendi")
        if hedef.get("_kapatiliyor"):
            raise LedgerConflictError(
                f"pozisyon su an baska bir is parcacigi tarafindan kapatiliyor "
                f"(id={order_id}, live={live}) -- cifte satis engellendi")
        hedef["_kapatiliyor"] = now_ms()
        d["emirler"][sira] = hedef
        save_ledger(d, live)
        kopya = dict(hedef)

    # 2) KILIT DISINDA: gercek satis (ag cagrisi).
    #
    # YAPAY ZEKA MIMO (24.09.2026): `sell` toz donerse (NOTIONAL/LOT_SIZE
    # filtresi) SATISSIZ devam -- defter piyasa fiyatindan kapanir.
    dolum = None
    toz = False
    try:
        if sell is not None:
            dolum = sell(kopya)
            if dolum and dolum.get("fiyat"):
                price = float(dolum["fiyat"])
            if dolum and dolum.get("toz"):
                toz = True
                _log.warning("pozisyon toz kapatiliyor (satis yok): id=%s %s",
                             order_id, dolum.get("uyari") or "")
    except Exception:
        # Satis basarisizsa isareti geri al, pozisyon acik kalsin.
        with ledger_lock():
            d = load_ledger(live)
            for i, e in enumerate(d["emirler"]):
                if int(e.get("id", -1)) == int(order_id):
                    e.pop("_kapatiliyor", None)
                    d["emirler"][i] = e
                    save_ledger(d, live)
                    break
        raise

    # 3) KILIT ICINDE: kapanisi yaz.
    kapanan = record_position_close(live, order_id, price=price, reason=reason,
                                    commission_pct=commission_pct, toz=toz)
    with ledger_lock():
        d = load_ledger(live)
        for i, e in enumerate(d["emirler"]):
            if int(e.get("id", -1)) == int(order_id):
                e.pop("_kapatiliyor", None)
                d["emirler"][i] = e
                save_ledger(d, live)
                break
    _log.info("pozisyon kapandi: %s id=%s %s kar=%s%%",
              kapanan.get("sembol"), order_id, reason, kapanan.get("kar_p"))
    if on_closed:
        on_closed(kapanan)          # Telegram bildirimi TEK yerden
    return kapanan


# Tum acik pozisyonlari kapatir.
def close_all_positions(live: bool, prices: Mapping[str, Any], *, reason: str,
                        sell=None, commission_pct: float = 0.0,
                        on_closed=None) -> dict:
    kapanan, atlanan = [], []
    for poz in list_open_orders(live):
        f = prices.get(poz["sembol"])
        fiyat = f[0] if isinstance(f, tuple) else f
        if not fiyat:
            atlanan.append(poz["sembol"]); continue
        try:
            kapanan.append(close_position(live, poz["id"], price=float(fiyat),
                                          reason=reason, sell=sell,
                                          commission_pct=commission_pct,
                                          on_closed=on_closed))
        except LedgerConflictError as e:
            atlanan.append(f"{poz['sembol']}: {e}")
    return {"kapanan": len(kapanan), "atlanan": atlanan}


# Acik pozisyonun cikis yontemini degistirir.   (eski: _yontem_uygula)
def change_exit_method(live: bool, order_id: int, source: str,
                       settings: Mapping[str, Any], *, atr_pct: float | None = None,
                       round_price=None) -> dict:
    from app.trading.exit_rules import apply_plan_to_order, plan_for_source
    with ledger_lock():
        d = load_ledger(live)
        for i, e in enumerate(d["emirler"]):
            if int(e.get("id", -1)) != int(order_id):
                continue
            if e.get("kapanis"):
                raise LedgerConflictError("kapali pozisyonun yontemi degistirilemez")
            giris = float(e.get("dolan_fiyat") or e["fiyat"])
            plan = plan_for_source(source, settings)
            # Yontem degisiminde giris fiyati ve tepe SIFIRLANMAZ --
            # pozisyon devam ediyor. (Eski `_hedef_stop_kur` sifirliyordu,
            # `_yontem_uygula` sifirlamiyordu; %95 kopya iki fonksiyondu.)
            tepe = float(e.get("en_yuksek") or giris)
            apply_plan_to_order(e, plan, entry_price=giris, atr_pct=atr_pct,
                                round_price=round_price)
            e["en_yuksek"] = tepe
            e["el_kaynak"] = source
            d["emirler"][i] = e
            save_ledger(d, live)
            return e
    raise LedgerConflictError(f"emir bulunamadi (id={order_id}, live={live})")
