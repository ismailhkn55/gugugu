"""Emir gonderme ve durum takibi.

DEGISENLER:
  * Kagit modda ELLE alim SERBEST. Eski `emir_ver` `canli=False` iken
    manuel AL/ALSAT/ALTAKIP'i 409 ile reddediyordu -- oysa `defter_dry.json`
    ve `el_kaynak` altyapisi kagit icin hazirdi. "Kagit uzerinde deneme"
    kapisi bosuna kapaliydi.
  * `kar_al`/`stop` alanlarini BU MODUL YAZMAZ; `exit_rules.apply_plan_to_order`
    yazar. Eski sistemde giris ve cikis bu alanlari birbirinden habersiz
    yaziyordu.
  * Gercek emir yalnizca `live=True` VE anahtar varken gonderilir.
  * `newClientOrderId` ile idempotent -- ag zaman asiminda emir bulunabilir.
"""
from __future__ import annotations

from typing import Any, Mapping

from app.config.secrets import has_api_credentials
from app.core.applog import get_logger
from app.core.errors import ExchangeError, OrderRejectedError
from app.core.timeutil import now_ms
from app.exchange import binance_rest as REST
from app.exchange.symbol_rules import (get_symbol_filters, meets_min_notional,
                                       normalize_symbol, round_price_to_tick,
                                       round_quantity_to_step)
from app.trading.exit_rules import apply_plan_to_order, plan_for_source
from app.trading.ledger import append_order, load_ledger, update_order
from app.market.rank_repository import capture_market_snapshot
from app.trading.wallet import get_free_quote_balance

_log = get_logger(__name__)
LIMIT_SAPMA_MAKS = 20.0          # elle verilen limit fiyat piyasadan en fazla %20 sapabilir


# Emir defteri derinliginden limit fiyati secer.
def pick_limit_price(symbol: str, side: str, depth_rank: int) -> float:
    kitap = REST.fetch_order_book(symbol, limit=max(10, depth_rank))
    taraf = kitap["bids"] if side.upper() == "BUY" else kitap["asks"]
    if not taraf:
        raise ExchangeError(f"{symbol}: emir defteri bos")
    return float(taraf[min(depth_rank - 1, len(taraf) - 1)][0])


# Dolum fiyati ve miktarini okur.                (eski: _dolum_oku)
def read_fill_details(exchange_order: Mapping[str, Any]) -> dict:
    dolan = float(exchange_order.get("executedQty") or 0)
    tutar = float(exchange_order.get("cummulativeQuoteQty") or 0)
    fiyat = (tutar / dolan) if dolan else None
    return {"dolan_miktar": dolan, "dolan_fiyat": fiyat,
            "borsa_durum": exchange_order.get("status"),
            "borsa_id": exchange_order.get("orderId"),
            "dolum_ts": now_ms() if dolan else None}


# Alis emri gonderir. `live` ZORUNLU.            (eski: emir_ver alis yolu)
def place_entry_order(symbol: str, *, live: bool, settings: Mapping[str, Any],
                      source: str | None, quote_amount: float,
                      limit_price: float | None = None,
                      strategy: Mapping[str, Any] | None = None,
                      atr_pct: float | None = None,
                      speed: float | None = None,
                      reference_price: float | None = None,
                      check_balance: bool = True,
                      extra: Mapping[str, Any] | None = None) -> dict:
    if not isinstance(live, bool):
        raise TypeError("place_entry_order: `live` acikca True/False verilmeli")
    s = normalize_symbol(symbol)
    if live and not has_api_credentials():
        raise ExchangeError("API anahtari yok -- gercek emir gonderilemez")

    kurallar = get_symbol_filters(s)
    if kurallar.get("status") != "TRADING":
        raise OrderRejectedError(f"{s} islem gormuyor (durum: {kurallar.get('status')})")

    # BAKIYE KONTROLU. Bu kontrol eski sistemde YOKTU: sabit `tutar` ile arka
    # arkaya pozisyon acinca kagit cuzdanin "serbest" bakiyesi EKSIYE
    # dusebiliyordu (30 USDT ana para ile 4 x 30 USDT pozisyon). Faz 3
    # yasam dongusu testinde serbest=-86.7 cikmasiyla yakalandi.
    if check_balance:
        serbest = get_free_quote_balance(live, settings)
        if float(quote_amount) > serbest + 1e-9:
            raise OrderRejectedError(
                f"yetersiz bakiye: {quote_amount:.2f} USDT isteniyor, "
                f"{serbest:.2f} USDT serbest ({'canli' if live else 'kagit'})")

    # --- fiyat ---
    if limit_price is not None:
        piyasa = reference_price or pick_limit_price(s, "BUY", 1)
        sapma = abs(limit_price / piyasa - 1) * 100 if piyasa else 0
        if sapma > LIMIT_SAPMA_MAKS:
            raise OrderRejectedError(
                f"limit fiyat piyasadan %{sapma:.1f} sapiyor (tavan %{LIMIT_SAPMA_MAKS})")
        fiyat = limit_price
    else:
        fiyat = pick_limit_price(s, "BUY", int(settings.get("al_sira", 1)))
    fiyat = round_price_to_tick(fiyat, kurallar["tick"])
    if fiyat <= 0:
        raise OrderRejectedError(f"{s}: gecersiz fiyat")

    # --- miktar ---
    miktar = round_quantity_to_step(float(quote_amount) / fiyat, kurallar["step"])
    if miktar <= 0:
        raise OrderRejectedError(f"{s}: miktar adim buyuklugunun altinda")
    if not meets_min_notional(miktar, fiyat, kurallar["min_notional"]):
        raise OrderRejectedError(
            f"{s}: tutar asgari altinda ({miktar * fiyat:.2f} < {kurallar['min_notional']})")

    kayit: dict[str, Any] = {
        "sembol": s, "taraf": "BUY", "dugme": (source or "BOT").upper(),
        "fiyat": fiyat, "miktar": miktar, "tutar": round(miktar * fiyat, 6),
        "ts": now_ms(), "durum": "ACIK", "borsa_id": None, "borsa_durum": None,
        "dolan_miktar": 0.0, "dolan_fiyat": None, "dolum_ts": None,
        "kapanis": None, "kar": None, "takip": True, "hiz": speed,
        # GIRIS ANININ PIYASA GORUNTUSU -- sonradan strateji cikarabilmek
        # icin (bkz. rank_repository.capture_market_snapshot).
        "giris_piyasa": capture_market_snapshot(s),
    }
    if source:
        kayit["el_kaynak"] = source
    else:
        kayit["kaynak"] = "BOT"
        if strategy:
            kayit["strateji"] = strategy.get("ad")
    # 02.10.2026: deneme sinyali etiketleri (grup, HA sirasi, olcumler) ve
    # ATR stopu. Cekirdek alanlarin USTUNE YAZILMAZ.
    for _k, _v in (extra or {}).items():
        kayit.setdefault(_k, _v)

    # --- borsaya gonder (yalniz canli) ---
    # YAPAY ZEKA MIMO (24.09.2026): recover_after_send_failure ignelendi.
    # Derin inceleme yuksek oncelik #2: submit_order retry=False ile
    # gonderiliyor ama ag zaman asiminda emir borsada olabilir, defterde
    # olmayabilirdi; fonksiyon tanimli ama hic cagrilmıyordu.
    if live:
        coid = REST.make_client_order_id()
        try:
            cevap = REST.submit_order(s, "BUY", "LIMIT", quantity=miktar,
                                      price=fiyat, time_in_force="GTC",
                                      client_order_id=coid)
        except ExchangeError:
            bulunan = recover_after_send_failure(s, coid)
            if not bulunan:
                raise
            _log.warning("%s: gonderim hatasi sonrasi emir borsada bulundu "
                         "(id=%s) -- deftere yaziliyor", s,
                         bulunan.get("orderId"))
            cevap = bulunan
        kayit.update(read_fill_details(cevap))
        kayit["durum"] = {"FILLED": "DOLDU", "PARTIALLY_FILLED": "KISMI"}.get(
            cevap.get("status"), "ACIK")
    else:
        # Kagit: aninda dolmus say.
        kayit.update(durum="DOLDU", dolan_miktar=miktar, dolan_fiyat=fiyat,
                     dolum_ts=now_ms(), borsa_durum="PAPER")

    # --- cikis plani: kar_al/stop'un TEK yazicisi ---
    giris = float(kayit.get("dolan_fiyat") or kayit["fiyat"])
    plan = plan_for_source(source, settings, strategy=strategy)
    apply_plan_to_order(kayit, plan, entry_price=giris, atr_pct=atr_pct,
                        round_price=lambda p: round_price_to_tick(p, kurallar["tick"]))
    return append_order(kayit, live)


# Kagit giris -- canli mod kapaliyken de calisir. (eski: dryrun_giris_manuel)
def place_paper_entry(symbol: str, *, settings: Mapping[str, Any],
                      source: str | None = "al", quote_amount: float | None = None,
                      strategy: Mapping[str, Any] | None = None,
                      atr_pct: float | None = None, speed: float | None = None,
                      check_balance: bool = True) -> dict:
    tutar = float(quote_amount if quote_amount is not None else settings.get("tutar", 30.0))
    # check_balance=False: DRYRUN dugmesi (04.10.2026) -- sabit 30 USDT "varmis gibi".
    return place_entry_order(symbol, live=False, settings=settings, source=source,
                             quote_amount=tutar, strategy=strategy,
                             atr_pct=atr_pct, speed=speed, check_balance=check_balance)


# Filtre hatasi mi? (-1013 NOTIONAL / LOT_SIZE -- asgari tutar/miktar)
def is_filter_reject(ex: BaseException) -> bool:
    kod = getattr(ex, "code", None)
    if kod == -1013:
        return True
    msg = str(ex).upper()
    return "NOTIONAL" in msg or "LOT_SIZE" in msg


# Satis emri gonderir; `close_position` tarafindan KILIT DISINDA cagrilir.
#
# YAPAY ZEKA MIMO (24.09.2026): asgari tutar (NOTIONAL) / LOT_SIZE asagisinda
# borsa SELL'i reddediyordu; hatadan dolayi pozisyon hic kapanmiyordu
# (cuzdan KAPAT -> "Filter failure: NOTIONAL"). Boyle durumlarda SATISSIZ
# toz donulur; `close_position` piyasa fiyatindan defteri kapatir, coin
# borsada kalir (kullaniciya toast ile bildirilir).
def place_exit_order(order: Mapping[str, Any], *, live: bool) -> dict:
    s = normalize_symbol(order["sembol"])
    miktar = float(order.get("dolan_miktar") or order.get("miktar") or 0)
    if not live:
        return {"fiyat": None, "borsa_durum": "PAPER"}
    kurallar = get_symbol_filters(s)
    miktar = round_quantity_to_step(miktar, kurallar["step"])
    toz_mesaj = None
    if miktar <= 0:
        toz_mesaj = f"miktar yuvarlaninca sifir ({s})"
    elif kurallar.get("min_qty") and miktar < float(kurallar["min_qty"]):
        toz_mesaj = f"miktar asgari altinda ({miktar} < {kurallar['min_qty']} {s})"
    if toz_mesaj:
        _log.warning("satis atlandi (toz): %s -- %s", s, toz_mesaj)
        return {"fiyat": None, "borsa_durum": "TOZ", "toz": True,
                "toz_miktar": miktar, "uyari": toz_mesaj}
    try:
        cevap = REST.submit_order(s, "SELL", "MARKET", quantity=miktar,
                                  client_order_id=REST.make_client_order_id("cx"))
    except (OrderRejectedError, ExchangeError) as ex:
        if is_filter_reject(ex):
            _log.warning("satis filtre reddi (toz): %s x %s -- %s", s, miktar, ex)
            return {"fiyat": None, "borsa_durum": "TOZ", "toz": True,
                    "toz_miktar": miktar,
                    "uyari": f"asgari tutar nedeniyle satilamadi ({s} borsada kaldi)"}
        raise
    d = read_fill_details(cevap)
    return {"fiyat": d["dolan_fiyat"], **d}


# Acik limit emri iptal eder. Ag cagrisi KILIT DISINDA yapilir.
# (eski `emir_iptal` `with KILIT:` icinde 15 sn'lik DELETE cagiriyordu ve
#  o sure boyunca TUM defter yazimini bloke ediyordu.)
def cancel_open_order(live: bool, order_id: int) -> dict:
    from app.trading.ledger import find_order
    emir = find_order(live, order_id)
    if not emir:
        raise OrderRejectedError(f"emir bulunamadi: id={order_id}")
    if live and emir.get("borsa_id"):
        REST.cancel_order(normalize_symbol(emir["sembol"]), int(emir["borsa_id"]))
    return update_order(live, order_id,
                        lambda e: {**e, "durum": "IPTAL", "borsa_durum": "CANCELED"})


# Binance'in "emir bitti, artik bekleyen degil" durumlari.
BORSADA_KAPALI_DURUMLAR = ("CANCELED", "EXPIRED", "REJECTED", "EXPIRED_IN_MATCH")


# Borsada kapanmis, hic dolmamis emri defterde IPTAL yapar ve gunluge yazar.
def mark_closed_on_exchange(live: bool, order: Mapping[str, Any], exchange_status: str) -> None:
    from app.trading.reconcile import log_reconciliation
    update_order(live, order["id"], lambda o: None if o.get("durum") != "ACIK" else {
        **o, "durum": "IPTAL", "borsa_durum": exchange_status})
    log_reconciliation({"tur": "borsada_kapali_emir", "live": live, "id": order["id"],
                        "sembol": order.get("sembol"), "borsa_durum": exchange_status,
                        "aciklama": "Binance'te acik emir yok -- defterden IPTAL"})
    _log.info("emir borsada kapali (%s) -> IPTAL: %s id=%s",
              exchange_status, order.get("sembol"), order["id"])


# Acik emirlerin borsa durumunu tazeler.         (eski: emir_durum_kontrol)
def refresh_order_statuses(live: bool, *, timeout_minutes: float = 6.0) -> dict:
    from app.trading.ledger import list_open_orders
    guncellenen, iptal = 0, 0
    for e in list_open_orders(live):
        # 26.09.2026 HATA: yalniz "ACIK" yenileniyordu. Emir bir kez "KISMI"
        # olunca bir daha HIC sorulmuyordu -> RARE id=500: borsada 1192.5'in
        # TAMAMI dolmustu, defter 592 saniyordu; stop gelse yalniz 592 satilir,
        # 600.5 RARE korumasiz kalirdi. KISMI de yenilenir.
        durum = e.get("durum")
        if durum not in ("ACIK", "KISMI"):
            continue
        if live and e.get("borsa_id"):
            try:
                cevap = REST.fetch_order_status(normalize_symbol(e["sembol"]),
                                                int(e["borsa_id"]))
            except ExchangeError as ex:
                # -2013 "Order does not exist": Binance emri hic tanimiyor --
                # defterde ACIK tutmanin anlami yok (bkz. asagidaki 06.10 notu).
                if ex.code == -2013 and durum == "ACIK" \
                        and float(e.get("dolan_miktar") or 0) <= 0:
                    mark_closed_on_exchange(live, e, "BORSADA_YOK")
                    guncellenen += 1
                    continue
                _log.warning("emir durumu alinamadi (id=%s): %s", e["id"], ex)
                continue
            d = read_fill_details(cevap)
            if d["borsa_durum"] in ("FILLED", "PARTIALLY_FILLED"):
                update_order(live, e["id"], lambda o, d=d: {
                    **o, **d,
                    "durum": "DOLDU" if d["borsa_durum"] == "FILLED" else "KISMI"})
                guncellenen += 1
                continue
            # 06.10.2026 HATA (Ismail: "binance de acik emir yok ama acik emir
            # olarak kaldi, kendisi kaldirsin"): borsada KAPANMIS emir yalniz
            # KISMI icin isleniyordu. BAND id=571 Binance'te CANCELED (0/111.4)
            # iken defterde ACIK kaldi; zaman asimi iptali her dakika -2011
            # "Unknown order" aldi ve kayit hic kapanmadi.
            # Borsa kapali diyorsa: dolum varsa o miktarla DOLDU, yoksa IPTAL.
            if d["borsa_durum"] in BORSADA_KAPALI_DURUMLAR:
                if d["dolan_miktar"] > 0:
                    update_order(live, e["id"], lambda o, d=d: {**o, **d, "durum": "DOLDU"})
                else:
                    mark_closed_on_exchange(live, e, d["borsa_durum"])
                guncellenen += 1
                continue
        # KISMI emre zaman asimi iptali UYGULANMAZ: yarisi alinmis pozisyonun
        # kalanini kendiliginden iptal etmeyiz.
        if durum == "KISMI":
            continue
        # zaman asimi: bu surede dolmadiysa iptal
        gecen_dk = (now_ms() - int(e.get("ts") or 0)) / 60000
        if gecen_dk > timeout_minutes:
            try:
                cancel_open_order(live, e["id"])
                iptal += 1
            except Exception as ex:
                _log.warning("emir iptal edilemedi (id=%s): %s", e["id"], ex)
    return {"guncellenen": guncellenen, "iptal": iptal}


# Ag zaman asimindan sonra emrin gercekten gidip gitmedigini borsaya sorar.
def recover_after_send_failure(symbol: str, client_order_id: str) -> dict | None:
    try:
        return REST.signed_request("/api/v3/order", symbol=normalize_symbol(symbol),
                                   origClientOrderId=client_order_id)
    except ExchangeError:
        return None
