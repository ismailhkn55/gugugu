"""Emir defteri -- gercek para kayitlari burada.

UC YAPISAL DEGISIKLIK:

1. `live` ASLA varsayilandan turetilmez. Eski `defter_yolu(canli=None)`
   `ayar["canli"]`'ya dusuyordu; SIFIRLA butonu `defter_yaz({...})` derken
   argumani vermedigi icin ayar canli:true iken **defter_canli.json'daki
   174 gercek kaydi siliyordu**. Burada `live` her imzada ZORUNLU.

2. Yikici islem oncesi ZAMAN DAMGALI YEDEK alinir.

3. Emir kimligi `(kaynak, id)` ciftidir. Eski `id` defter-lokal bir sayacti
   ama `/yerel/emirler` iki defteri birlestiriyordu; `/yerel/emir/kapat`
   ilk eslesen id'yi alip YANLIS DEFTERDEKI pozisyonu kapatabiliyordu.

KILIT: oku-degistir-yaz'in TAMAMI `ledger_lock()` icinde. Eski sistemde
okuma kilidin DISINDA, yazma ICINDE yapiliyordu; `takipci` elindeki eski
kopyayi geri yazip `bot_turu`'nun az once kaydettigi kilitli stop'u
SILIYORDU.
"""
from __future__ import annotations

import os
import shutil
from typing import Any, Iterator, Mapping

from app.config.paths import get_ledger_path
from app.core.applog import get_logger
from app.core.errors import LedgerConflictError
from app.core.jsonstore import read_json_file, write_json_file
from app.core.locking import ledger_lock
from app.core.timeutil import now_ms

_log = get_logger(__name__)

ACIK_DURUMLAR = ("ACIK", "KISMI", "DOLDU")


# Defteri okur. `live` ZORUNLU.               (eski: defter_al)
def load_ledger(live: bool) -> dict:
    d = read_json_file(get_ledger_path(live), {"emirler": [], "sira": 1}) or {}
    d.setdefault("emirler", [])
    d.setdefault("sira", 1)
    return d


# Defteri atomik yazar. `live` ZORUNLU.       (eski: defter_yaz)
def save_ledger(data: Mapping[str, Any], live: bool) -> None:
    write_json_file(get_ledger_path(live), dict(data))


# Yikici islem oncesi zaman damgali yedek alir; yedek dosyanin yolunu doner.
YEDAK_TUTMAK = 10  # YAPAY ZEKA MIMO (24.09.2026): rotasyon -- son N yedek


def backup_ledger(live: bool) -> str | None:
    kaynak = get_ledger_path(live)
    if not os.path.exists(kaynak):
        return None
    hedef = f"{kaynak}.{now_ms()}.yedek"
    shutil.copy2(kaynak, hedef)
    _log.info("defter yedeklendi: %s", hedef)
    # YAPAY ZEKA MIMO: eski yedekleri temizle (derin inceleme: rotasyon yoktu).
    try:
        import glob as _glob
        yedekler = sorted(_glob.glob(f"{kaynak}.*.yedek"))
        for eski_y in yedekler[:-YEDAK_TUTMAK]:
            os.remove(eski_y)
            _log.info("eski yedek silindi: %s", eski_y)
    except Exception:
        pass
    return hedef


# Defteri sifirlar. Hedef defter ACIKCA verilir ve once YEDEK alinir.
# (eski: defter_sifirla -- `canli` argumani verilmedigi icin gercek defteri siliyordu)
def reset_ledger(live: bool) -> dict:
    with ledger_lock():
        yedek = backup_ledger(live)
        onceki = load_ledger(live)
        save_ledger({"emirler": [], "sira": 1}, live)
    _log.warning("defter SIFIRLANDI (live=%s, %d kayit silindi, yedek: %s)",
                 live, len(onceki["emirler"]), yedek)
    return {"silinen": len(onceki["emirler"]), "yedek": yedek, "live": live}


# Kapanmis emirleri siler, aciklari korur.
def purge_closed_orders(live: bool) -> dict:
    with ledger_lock():
        yedek = backup_ledger(live)
        d = load_ledger(live)
        once = len(d["emirler"])
        d["emirler"] = [e for e in d["emirler"] if not e.get("kapanis")]
        save_ledger(d, live)
    return {"silinen": once - len(d["emirler"]), "kalan": len(d["emirler"]),
            "yedek": yedek}


# Emir kimligi: hangi defterden geldigi DAIMA tasinir.
def make_order_key(live: bool, order_id: int) -> tuple[str, int]:
    return ("canli" if live else "dry", int(order_id))


# Siradaki emir kimligi (kilit ICINDE cagrilmali).
def next_order_id(ledger: dict) -> int:
    sira = int(ledger.get("sira") or 1)
    ledger["sira"] = sira + 1
    return sira


# Emri bulur. `live` ZORUNLU -- yanlis defterdeki pozisyonu bulma riski yok.
def find_order(live: bool, order_id: int) -> dict | None:
    for e in load_ledger(live)["emirler"]:
        if int(e.get("id", -1)) == int(order_id):
            return e
    return None


# Acik/takipteki emirler. `live=None` ise HER IKI defter, her kayit
# `_kaynak` alaniyla isaretlenerek doner.     (eski: _acik_pozisyonlar)
def list_open_orders(live: bool | None = None) -> list[dict]:
    kaynaklar = [live] if isinstance(live, bool) else [True, False]
    cikti = []
    for c in kaynaklar:
        for e in load_ledger(c)["emirler"]:
            if e.get("durum") in ACIK_DURUMLAR and not e.get("kapanis"):
                kayit = dict(e)
                kayit["_kaynak"] = "canli" if c else "dry"
                kayit["_live"] = c
                kayit["_anahtar"] = make_order_key(c, e.get("id", -1))
                cikti.append(kayit)
    return cikti


# Kapanmis emirler, en yeniden eskiye.
def list_closed_orders(live: bool, *, limit: int | None = None) -> list[dict]:
    kapali = [e for e in load_ledger(live)["emirler"] if e.get("kapanis")]
    kapali.sort(key=lambda e: (e.get("kapanis") or {}).get("ts") or 0, reverse=True)
    return kapali[:limit] if limit else kapali


# Deftere emir ekler (kilit ICINDE, kimlik atayarak). Eklenen kaydi doner.
def append_order(record: Mapping[str, Any], live: bool) -> dict:
    with ledger_lock():
        d = load_ledger(live)
        kayit = dict(record)
        kayit["id"] = next_order_id(d)
        kayit["canli"] = live
        d["emirler"].insert(0, kayit)
        save_ledger(d, live)
    return kayit


# Emri KILIT ICINDE okur, degistirir, yazar -- kayip guncelleme olmaz.
# `mutate(order) -> dict|None` : None donerse yazim yapilmaz.
def update_order(live: bool, order_id: int, mutate) -> dict | None:
    with ledger_lock():
        d = load_ledger(live)
        for i, e in enumerate(d["emirler"]):
            if int(e.get("id", -1)) != int(order_id):
                continue
            yeni = mutate(dict(e))
            if yeni is None:
                return None
            d["emirler"][i] = yeni
            save_ledger(d, live)
            return yeni
    raise LedgerConflictError(f"emir bulunamadi: {make_order_key(live, order_id)}")


# Birden cok emrin alanlarini TEK okuma/yazmada gunceller: {id: {alan: deger}}.
# Bulunmayan ya da kapanmis emir ATLANIR (arada kapatilmis olabilir). Yazilan sayiyi doner.
# 02.10.2026: yonetim dongusu her pozisyon icin tum defteri ayri ayri yaziyordu.
def update_orders_bulk(live: bool, fields_by_id: Mapping[int, Mapping[str, Any]]) -> int:
    if not fields_by_id:
        return 0
    n = 0
    with ledger_lock():
        d = load_ledger(live)
        for i, e in enumerate(d["emirler"]):
            alan = fields_by_id.get(int(e.get("id", -1)))
            if alan is None or e.get("kapanis") or e.get("durum") not in ACIK_DURUMLAR:
                continue
            d["emirler"][i] = {**e, **alan}
            n += 1
        if n:
            save_ledger(d, live)
    return n


