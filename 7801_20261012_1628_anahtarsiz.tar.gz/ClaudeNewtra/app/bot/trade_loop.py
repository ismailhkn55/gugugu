"""Bot turu: giris dener, acik pozisyonlari TEK cikis karariyla yonetir.

`BOT` sozlugu eski sistemde TAMAMEN KILITSIZDI ve uc ayri is parcacigindan
(`takipci`, `bot_turu`, HTTP) `setdefault`+yazma ile guncelleniyordu.
Burada durum kilit altinda.
"""
from __future__ import annotations

import threading
from typing import Any, Mapping

from app.core.applog import get_logger, log_once
from app.core.errors import LedgerConflictError, OrderRejectedError
from app.core.timeutil import now_ms
from app.config.paths import get_app_root
from app.market.price_source import get_prices
from app.market.rank_repository import fetch_latest_snapshot
from app.strategy.entry import select_candidates
from app.strategy.exit import decide_exit
from app.strategy.targets import StopPlan
from dataclasses import replace
from app.strategy.registry import get_active_strategy, get_strategy_by_name
from app.trading.exit_rules import plan_for_source
from app.trading.ledger import list_open_orders, update_order, update_orders_bulk
from app.trading.order_service import place_entry_order
from app.trading.position_service import close_position
import json as _json
import os as _os

_log = get_logger(__name__)


# Her basarili bot girisini JSONL olarak yazar (kazanan ozellik analizi icin).
def giris_kaydi_yaz(kayit: dict, aday: dict | None = None) -> None:
    try:
        yol = _os.path.join(get_app_root(), "giris_kaydi.jsonl")
        satir = {
            "ts": kayit.get("ts"),
            "sembol": kayit.get("sembol"),
            "fiyat": kayit.get("fiyat"),
            "tutar": kayit.get("tutar"),
            "strateji": kayit.get("strateji"),
            "hiz": kayit.get("hiz"),
            "id": kayit.get("id"),
            "giris_piyasa": kayit.get("giris_piyasa"),
        }
        if aday:
            satir["aday_ozellik"] = {k: aday.get(k) for k in (
                "hiz", "atr_pct", "deg5m", "deg1h", "deg4h", "rank", "iz_yon",
                "cci", "rsi", "kdj_j", "wma48", "hacim_x", "gun_pct",
                "ha_ardisik_yesil", "rank_atr")}
        with open(yol, "a", encoding="utf-8") as f:
            f.write(_json.dumps(satir, ensure_ascii=False, default=str) + "\n")
        # 05.10.2026, Ismail: "botun sectiklerini bir yere not et, su fiyatta secti, yarin sabah
        # test edecegiz, degerleri de yaz ATR'si CCI'si ne varsa". Okunur CSV: secim anindaki
        # TUM gosterge degerleri (sutun kayit defterinin tamami + izas/genislik gibi turetilenler).
        if aday:
            import csv as _csv
            from datetime import datetime, timedelta, timezone
            from app.market.indicators import COLUMN_REGISTRY
            alanlar = [c.name for c in COLUMN_REGISTRY if c.kind is not list and c.name not in ("ts", "sembol")]
            csv_yol = _os.path.join(get_app_root(), "bot_secimleri.csv")
            yeni = not _os.path.exists(csv_yol)
            tr = datetime.fromtimestamp((kayit.get("ts") or now_ms()) / 1000, timezone(timedelta(hours=3)))
            with open(csv_yol, "a", encoding="utf-8", newline="") as f:
                w = _csv.writer(f)
                if yeni:
                    w.writerow(["zaman_tr", "sembol", "secim_fiyat", "alis_fiyat", "tutar_usdt", "strateji", "emir_id"] + alanlar)
                w.writerow([tr.strftime("%Y-%m-%d %H:%M:%S"), kayit.get("sembol"), aday.get("fiyat"),
                            kayit.get("dolan_fiyat") or kayit.get("fiyat"), kayit.get("tutar"),
                            kayit.get("strateji"), kayit.get("id")] + [aday.get(a) for a in alanlar])
    except Exception as e:  # noqa: BLE001 - log yazimi girisi engellemez
        _log.warning("giris kaydi yazilamadi: %s", e)

_kilit = threading.Lock()
_DURUM: dict[str, Any] = {
    "son_tur": 0, "tur_sayisi": 0, "son_hata": None, "durdu": None,
    "son_aday": [], "son_sebep": None, "kapanan_coinler": {},
    "son_kapanis_ts_strateji": {},
}


# Bot durumunun kopyasi (kilit altinda okunur).
def get_bot_state() -> dict:
    with _kilit:
        return {k: (dict(v) if isinstance(v, dict) else
                    list(v) if isinstance(v, list) else v)
                for k, v in _DURUM.items()}


# Bot durumunu kilit altinda gunceller.
def update_bot_state(**alanlar) -> None:
    with _kilit:
        _DURUM.update(alanlar)


def _bekleme_gecti(sembol: str, settings: Mapping[str, Any]) -> bool:
    """Bu coin yakin zamanda kapandiysa nefes payi dolmus mu?"""
    dk = float(settings.get("coin_bekleme_dk", 0) or 0)
    if dk <= 0:
        return True
    with _kilit:
        ts = _DURUM["kapanan_coinler"].get(sembol)
    return not ts or (now_ms() - ts) / 60000 >= dk


# Botun giris tutarini (USDT) belirler; yuzde doluysa cuzdan toplamindan.
#
# 26.09.2026: stratejinin `tutar_yuzde` alani arayuzde gosteriliyor ama bot
# onu HIC okumuyordu -- ekranda "%5 = 500 USDT" yazarken bot sabit `tutar`
# (100) aciyordu. Artik arayuzle AYNI tanim (strategies.js
# renderStrategyWallet): botun KENDI modundaki cuzdanin `toplam`i x yuzde.
# Canli modda cuzdan okunamazsa None doner -> giris YAPILMAZ (tahminle
# gercek para harcanmaz).
def resolve_entry_amount(strategy: Mapping[str, Any], settings: Mapping[str, Any],
                         *, live: bool) -> float | None:
    # 05.10.2026, Ismail: "toplam bakiye -1 yapip kalani 2'ye bolerek calissin".
    # `tutar_bolen` verilmisse tutar = (cuzdan toplami - 1 USDT) / bolen
    # (kagit kipte kagit cuzdan, canlida gercek hesap toplami).
    bolen = strategy.get("tutar_bolen")
    if bolen not in (None, "", 0):
        from app.trading.wallet import get_wallet
        toplam = get_wallet(live, settings).get("toplam")
        if toplam is None:
            return None
        return round(max(0.0, float(toplam) - 1.0) / float(bolen), 2)
    yuzde = strategy.get("tutar_yuzde")
    if yuzde in (None, "", 0):
        return float(strategy.get("tutar") or settings.get("tutar", 30.0))
    from app.trading.wallet import get_wallet
    toplam = get_wallet(live, settings).get("toplam")
    if toplam is None:
        return None
    return round(float(toplam) * float(yuzde) / 100.0, 2)


# Strateji bu saatte giris yapmasin mi? `kapali_saatler`: [[bas, bit], ...] TR saati
# (UTC+3), bas dahil bit haric; gece yarisini asabilir ([19, 2] = 19:00-01:59).
# 03.10.2026, Ismail: "19-02 arasi kapali olsun, ben manuel yaparim o saatlerde"
# (6 aylik olcumde HA girisinin en kotu saatleri). Yalniz BOT girisi -- elle
# dugmeler ve acik pozisyon yonetimi ETKILENMEZ.
def is_entry_hour_closed(strategy: Mapping[str, Any], now: int | None = None) -> bool:
    saat = ((now if now is not None else now_ms()) // 3_600_000 + 3) % 24
    for ar in strategy.get("kapali_saatler") or []:
        try:
            bas, bit = int(ar[0]) % 24, int(ar[1]) % 24
        except (TypeError, ValueError, IndexError):
            continue
        if (bas <= saat < bit) if bas < bit else (saat >= bas or saat < bit):
            return True
    return False


# Stratejiye gore giris dener.                 (eski: _bot_strateji_giris_dene)
def try_strategy_entry(settings: Mapping[str, Any], *, live: bool) -> dict:
    st = get_active_strategy(live=live)
    if is_entry_hour_closed(st):
        return {"acilan": 0, "sebep": "strateji bu saatte kapali (kapali_saatler)"}
    d = fetch_latest_snapshot(limit=400)
    sonuc = select_candidates(d["satir"], st, limit=int(st.get("maks_pozisyon", 3) or 3) * 3)
    update_bot_state(son_aday=[x["sembol"] for x in sonuc["aday"]][:10])

    if sonuc["yapilandirma_hatasi"]:
        # Eski sistemde bu SESSIZCE eleniyordu; artik gorunur.
        log_once(_log, "giris-hata",
                 f"strateji yapilandirma hatasi: {sonuc['yapilandirma_hatasi'][0]}")

    acik = list_open_orders(live)
    maks = int(st.get("maks_pozisyon", 3) or 3)
    if len(acik) >= maks:
        return {"acilan": 0, "sebep": f"maks pozisyon ({maks}) dolu"}

    acik_semboller = {p["sembol"] for p in acik}
    tutar = resolve_entry_amount(st, settings, live=live)
    if tutar is None:
        log_once(_log, "giris-tutar", "cuzdan toplami okunamadi, tutar_yuzde hesaplanamadi -- giris yok")
        return {"acilan": 0, "sebep": "cuzdan okunamadi (tutar_yuzde)"}
    acilan = []
    son_red = None
    for aday in sonuc["aday"]:
        if len(acik) + len(acilan) >= maks:
            break
        s = aday["sembol"]
        if s in acik_semboller or not _bekleme_gecti(s, settings):
            continue
        try:
            emir = place_entry_order(s, live=live, settings=settings, source=None,
                                     quote_amount=tutar, strategy=st,
                                     atr_pct=aday.get("atr_pct"), speed=aday.get("hiz"),
                                     reference_price=aday.get("fiyat"))
            acilan.append(emir["sembol"])
            giris_kaydi_yaz(emir, aday)
        except OrderRejectedError as e:
            son_red = f"{s}: {e}"
            log_once(_log, f"giris-{s}", f"{s} girisi reddedildi: {e}")
        except Exception as e:
            update_bot_state(son_hata=f"{s}: {e}")
            _log.warning("%s girisi basarisiz: %s", s, e)
    # 05.10.2026: "bot calisiyor mu anlamiyorum" -- durum satiri bos kalmasin.
    sebep = f"{len(sonuc['aday'])} aday, {len(acilan)} acildi, tutar {tutar:.2f} USDT"
    if son_red and not acilan:
        sebep += f" -- son ret: {son_red}"
    return {"acilan": len(acilan), "semboller": acilan, "sebep": sebep,
            "aday": len(sonuc["aday"]), "tarandi": sonuc["tarandi"]}


# Acik pozisyonlari TEK cikis karariyla yonetir.
def manage_open_positions(settings: Mapping[str, Any], *, live: bool,
                          on_closed=None) -> dict:
    acik = list_open_orders(live)
    if not acik:
        return {"yonetilen": 0, "kapanan": 0}
    fiyatlar = get_prices([p["sembol"] for p in acik])
    anlik = fetch_latest_snapshot(limit=400)
    olcum = {r["sembol"]: r for r in anlik["satir"]}
    # YAPAY ZEKA MIMO (24.09.2026): gunluk arsiv writer baglandi.
    # Derin inceleme: append_daily_snapshot hic cagrilmıyordu; ayar kapaliyken
    # fonksiyon zaten 0 doner (is_archive_enabled).
    try:
        from app.reporting.daily_archive import append_daily_snapshot
        append_daily_snapshot(anlik["satir"], settings)
    except Exception:
        pass
    komisyon = float(settings.get("komisyon_toplam", 0) or 0)
    st = get_active_strategy(live=live)
    _st_bellek: dict = {}     # tur basina strateji okuma (dosya) onbellegi
    toplu: dict = {}          # satilmayan pozisyonlarin degisen alanlari -- turda TEK yazim

    kapanan = 0
    for poz in acik:
        f, _kaynak = fiyatlar.get(poz["sembol"], (None, "yok"))
        if not f:
            continue
        o = olcum.get(poz["sembol"], {})
        # 02.10.2026: BOT pozisyonu ACILDIGI stratejinin planiyla yonetilir
        # (strateji silinmis/yoksa eskisi gibi aktif strateji). Emre giriste
        # sabitlenmis `stop_baslangic` (ATR stopu) varsa o kullanilir.
        ad = None if poz.get("el_kaynak") else poz.get("strateji")
        if ad not in _st_bellek:
            _st_bellek[ad] = get_strategy_by_name(ad)
        poz_st = _st_bellek[ad] or st
        plan = plan_for_source(poz.get("el_kaynak"), settings, strategy=poz_st)
        if poz.get("stop_baslangic") is not None:
            plan = {**plan, "stop": {**plan["stop"], "baslangic": float(poz["stop_baslangic"])}}
        # 03.10.2026: ELLE STOP (STP). Baslangic stopu elle stopa esitlenir (gevsetme de
        # olur); karar sonrasi elle stop TABAN uygulanir -- merdiven/iz daha yukari
        # cekerse o gecerli, ama elle stopun ALTINA inmez. Dokunulmayan pozisyon: plan.
        elle = poz.get("stop_elle")
        if elle is not None:
            giris_f = float(poz.get("dolan_fiyat") or poz["fiyat"])
            plan = {**plan, "stop": {**plan["stop"], "baslangic": (1 - float(elle) / giris_f) * 100}}
        karar = decide_exit(poz, float(f), plan, atr_pct=o.get("atr_pct"),
                            change_pct=o.get("deg5m"), volume_ratio=o.get("hacim_x"))
        if elle is not None and karar.stop.reason == "baslangic":
            # baslangic stopu = elle stop -> sebep adi 'elle' olsun (gunluk/bildirim acik okunsun)
            karar = replace(karar, stop=replace(karar.stop, reason="elle"),
                            reason="STOP:elle" if karar.reason == "STOP:baslangic" else karar.reason)
        if elle is not None and karar.stop.price < float(elle):
            yeni_stop = StopPlan(float(elle), round((float(elle) / giris_f - 1) * 100, 3), "elle")
            vurdu = float(f) <= float(elle)
            karar = replace(karar, stop=yeni_stop,
                            action="SAT" if (vurdu or karar.should_sell) else karar.action,
                            reason=karar.reason if karar.should_sell else ("STOP:elle" if vurdu else karar.reason))
        # tepe ve stop bilgisini deftere yaz (tek kaynak: karar nesnesi).
        # 02.10.2026: degismediyse YAZMA -- her tur her pozisyon icin tum
        # defter dosyasi yeniden yaziliyordu.
        degisti = (poz.get("en_yuksek") != karar.highest or poz.get("stop_guncel") != karar.stop.price
                   or poz.get("stop_sebep") != karar.stop.reason or poz.get("hedef_tur") != karar.target.kind)
        if not karar.should_sell:
            if degisti:
                toplu[int(poz["id"])] = {"en_yuksek": karar.highest, "stop_guncel": karar.stop.price,
                                         "stop_sebep": karar.stop.reason, "hedef_tur": karar.target.kind}
            continue
        try:
            update_order(live, poz["id"], lambda e, k=karar: {
                **e, "en_yuksek": k.highest, "stop_guncel": k.stop.price,
                "stop_sebep": k.stop.reason, "hedef_tur": k.target.kind})
        except LedgerConflictError:
            continue
        if not karar.should_sell:
            continue
        try:
            from app.trading.order_service import place_exit_order
            close_position(live, poz["id"], price=float(f), reason=karar.reason,
                           sell=(lambda e: place_exit_order(e, live=live)) if live else None,
                           commission_pct=komisyon, on_closed=on_closed)
            kapanan += 1
            with _kilit:
                _DURUM["kapanan_coinler"][poz["sembol"]] = now_ms()
        except LedgerConflictError as e:
            _log.info("kapatma atlandi (%s): %s", poz["sembol"], e)
    update_orders_bulk(live, toplu)
    return {"yonetilen": len(acik), "kapanan": kapanan}


# Tek bot turu.                                (eski: bot_turu)
#
# GIRIS yalnizca botun O ANKI moduna acilir (`bot_canli`).
# YONETIM ise HER IKI DEFTERDE de calisir.
#
# 23.09.2026, Ismail: "olduki botu canliya aldim diyelim ve coin aldi
# takip ediyor, ben ayarlardan canlidan dry run a gecer isem o zaman botu
# dry run a cekecek ve acik islemleri her zamanki gibi takip edecek ...
# takip her durumda devam edecek, hangisi ile alindi ise onun ayarina
# gore satisini yapacak".
#
# ONCEKI DAVRANIS: yonetim de `live = bot_canli` ile tek deftere
# bakiyordu. Bot canliyken pozisyon acilip sonra kagida alininca, acik
# GERCEK pozisyon bot dongusunun disinda kaliyor; stop/hedef kararlari
# hic uygulanmiyordu. `watcher` zaten iki defteri de BESLIYOR ama karar
# vermiyor (bkz. B3 duzeltmesi), dolayisiyla pozisyon korumasiz kaliyordu.
def run_bot_cycle(get_settings, *, on_closed=None) -> dict:
    ayar = get_settings()
    live = bool(ayar.get("bot_canli"))
    # Yonetim, bot kapaliyken de ve HER IKI DEFTERDE de calisir:
    # acik pozisyon hicbir kosulda korumasiz kalmasin.
    yonetim = {"yonetilen": 0, "kapanan": 0, "defter": {}}
    for defter_canli in (True, False):
        y = manage_open_positions(ayar, live=defter_canli, on_closed=on_closed)
        yonetim["yonetilen"] += y["yonetilen"]
        yonetim["kapanan"] += y["kapanan"]
        yonetim["defter"]["canli" if defter_canli else "kagit"] = y
    giris = {"acilan": 0, "sebep": "bot kapali"}
    if ayar.get("bot_acik"):
        giris = try_strategy_entry(ayar, live=live)
    with _kilit:
        _DURUM["tur_sayisi"] += 1
        _DURUM["son_tur"] = now_ms()
        _DURUM["son_sebep"] = giris.get("sebep")
    return {"giris": giris, "yonetim": yonetim, "live": live}
