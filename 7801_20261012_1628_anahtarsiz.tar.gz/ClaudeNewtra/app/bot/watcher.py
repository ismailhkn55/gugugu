"""Websocket fiyat takibi -- YALNIZCA BESLER, KARAR VERMEZ.

ESKI `takipci()` KARAR VERIYORDU: kendi `if/elif`'i vardi, `e["kar_al"]`
alanini okuyup satiyordu. `bot_turu()` ise ayni anda `ST.cikis_karari()`
ile tam kural zincirini calistiriyordu. Iki motor ayni pozisyon uzerinde
calisinca `bot_cikis_esik` ayari hic devreye giremiyordu.

BURADA: bu modul yalnizca acik pozisyonlarin sembollerine abone olur ve
tepe/dip bilgisini besler. Satma karari SADECE
`strategy.exit.decide_exit` -> `bot.trade_loop` yolundan gecer.
"""
from __future__ import annotations

from app.core.applog import get_logger
from app.exchange.binance_ws import STREAM
from app.trading.ledger import list_open_orders

_log = get_logger(__name__)

# Bir onceki turda izlenen semboller. HATA DUZELTMESI (23.09.2026, Faz 4
# testinde yakalandi): bu kume `STREAM.get_stream_status()` icinden
# okunmaya calisiliyordu ama orada boyle bir alan YOK -- her turda bos
# donuyordu. Sonuc: `semboller - onceki` HER ZAMAN tum semboller oluyor ve
# tepe/dip HER 2 SANIYEDE BIR sifirlaniyordu. Boyle bir sistemde iz suren
# stop asla tetiklenemez: tepe surekli anlik fiyata cekilir, "tepeden geri
# cekilme" hicbir zaman olusmaz. Sessiz ve olumcul bir hata olurdu.
_izlenen: set[str] = set()


# Acik pozisyonlarin sembollerine abone olur; YALNIZCA YENI acilanlarin
# tepe/dipini sifirlar.
def feed_position_extremes() -> dict:
    global _izlenen
    acik = list_open_orders(None)          # her iki defter
    semboller = {p["sembol"] for p in acik}
    yeni = semboller - _izlenen
    STREAM.subscribe_symbols(semboller)
    for s in yeni:
        STREAM.reset_symbol_extremes(s)
    _izlenen = semboller
    return {"izlenen": len(semboller), "yeni": sorted(yeni),
            "durum": STREAM.get_stream_status()}


# Zamanlayiciya kaydedilen is: abonelikleri tazeler, bayatligi raporlar.
def run_price_watch_loop() -> None:
    sonuc = feed_position_extremes()
    if sonuc["durum"].get("bayat"):
        _log.warning("websocket bayat: %s sn'dir veri gelmiyor",
                     sonuc["durum"].get("son_veri_sn"))
        STREAM.recover_if_stale()
