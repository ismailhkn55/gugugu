# ClaudeNewtra

Binance spot trade paneli + botu — eski Newtrade'in (7777) sıfırdan yeniden yazımı.

**26.09.2026: ASIL SİSTEM BU.** Port **7801**, canlı mod, gerçek anahtar.
Açılışta `claudenewtra.service` (systemd kullanıcı servisi) başlatır;
eski `newtrade.service` (7777) kapalı ve disable. Ayrıntı ve açık maddeler:
`DOKUMANTASYON.md` başı ve §99. `sunucu_testi_kur.py`'yi ÇALIŞTIRMA
(gerçek veri klasörünü siler).

## Bu klasörde ne var

| Dosya | Ne |
|---|---|
| `DOKUMANTASYON.md` | Ana belge: katman diyagramı, veri sözleşmeleri, emir yaşam döngüsü |
| `FONKSIYONLAR.txt` | **521 fonksiyon adı**, her birinin tek cümlelik görevi — kod yazılmadan önce |
| `ESLESTIRME.md` | Eski ad → yeni ad haritası (140 eşleşme + 381 yeni ad) |
| `tools/check_unique_names.py` | Adların benzersizliğini **makineyle** doğrular |
| `tools/gen_eslestirme.py` | `ESLESTIRME.md`'yi listeden üretir |
| `app/` | Kod (10 katman, 81 modül) |
| `main.py` | Giriş noktası |

## Neden yeniden yazılıyor

Eski sistem 11.205 satır ve aylar içinde parça parça büyümüş. Ölçülen
sonuçlar (hepsi `DOKUMANTASYON.md` ve plan belgesinde ayrıntılı):

- `sunucu.py`'de `do_GET` **615 satır**, içinde 365 satırlık bir geriye-test motoru
- `index.html` **6.646 satır**, 130 fonksiyon + ~95 global değişken tek dosyada
- `_oku` üç modülde, `_yaz` iki, `_dongu` iki modülde — hepsi farklı iş yapıyor
- **İki ayrı çıkış motoru** aynı anda çalışıyor → `bot_cikis_esik` ayarı hiç işlemiyor
- Bir strateji alanı eksikse kural **sessizce hiç ateşlemiyor**, hata da vermiyor
- 6 ölü ayar: kullanıcı değiştiriyor, hiçbir şey olmuyor *(yeni sistemde de 5 etkisiz ayar var — DOKUMANTASYON §99)*

## Kurallar

1. Tanımlayıcılar İngilizce; **yorumlar, dokümantasyon ve arayüz metinleri Türkçe**.
2. Her fonksiyonun üstünde bir satırlık Türkçe yorum.
3. Aynı ad iki modülde geçmez.
4. Katman kuralı: oklar yalnız aşağı doğru.
5. `live` / `canli` parametresi **asla** varsayılandan türetilmez.
6. Kilit içinde ağ çağrısı yasak.

## Denetim

```bash
python3 tools/check_unique_names.py          # ad çakışması var mı
python3 tools/check_unique_names.py --kod    # liste ile gerçek kod örtüşüyor mu
python3 tools/gen_eslestirme.py              # eşleştirme tablosunu tazele
```
