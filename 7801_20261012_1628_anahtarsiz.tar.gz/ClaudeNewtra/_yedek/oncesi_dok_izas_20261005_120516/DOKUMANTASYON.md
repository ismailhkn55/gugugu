# ClaudeNewtra — Sistem Dokümantasyonu

> **Güncel (05.10.2026):** 538 fonksiyon adı / 83 modül (`--kod` 0/0), **46 uç** (27 GET + 19 POST).
> Bot **DRY** çalışır (kullanıcı kararı); AL/SAT düğmeleri panelin moduna göre. GERİYE TEST, GÜNLÜK
> ve ANINDA K/Z kaldırıldı (§7.43), ölü kod temizlendi (§7.44).
>
> **Durum (26.09.2026):** Faz 0–5 tamam. **ClaudeNewtra ASIL SİSTEM** —
> port 7801, **canlı mod, gerçek Binance anahtarı yüklü**. Eski 7777
> (`newtrade.service`) durduruldu ve açılıştan çıkarıldı.
> Bugünkü denetimin bulguları ve açık kalanlar: **§99**.

Bu, `/DATA/AppData/Newtrade/` altındaki port 7777 trade panelinin sıfırdan
yeniden yazımıdır; eski koddan dosya kopyalanmadı.

**Çalıştırma:** systemd kullanıcı servisi `~/.config/systemd/user/claudenewtra.service`
(enabled, linger açık, `Restart=always`). Ortam:
`PORT=7801`, `NEWTRADE_DATA_DIR=/DATA/AppData/_cn_sunucu_testi`,
`NEWTRADE_RANK_DIR=/DATA/AppData/_cn_sunucu_testi/rank`.
Veri klasörünün adında "test" geçse de **gerçek defter oradadır**.
`sunucu_testi_kur.py` o klasörü SİLİP yeniden kurar ve eski 7777
`index.html`'ini arayüzün üstüne kopyalar — **ÇALIŞTIRMA.**

---

## 1. Sistem haritası

```mermaid
flowchart TD
    TARAYICI["Tarayıcı<br/>static/js (ES modülleri)"]
    subgraph WEB["app/web"]
        SRV["server.py<br/>soket, thread, hata yutma"]
        RT["router.py<br/>(yöntem, yol) → işleyici TABLOSU"]
        HD["handlers/<br/>7 dosya, 46 uç"]
        SG["static_guard.py<br/>BEYAZ LİSTE"]
    end
    subgraph BOT["app/bot"]
        SCH["scheduler.py<br/>TEK iş kayıt defteri"]
        TL["trade_loop.py"]
        WT["watcher.py<br/>besler, KARAR VERMEZ"]
    end
    subgraph TRD["app/trading"]
        LD["ledger.py"]
        OS["order_service.py"]
        PS["position_service.py"]
        ER["exit_rules.py<br/>TEK plan üretici"]
        RC["reconcile.py"]
        WL["wallet.py"]
    end
    subgraph STR["app/strategy — SAF"]
        RE["rule_engine.py<br/>GECTI/KALDI/OLCULMEDI/ALAN_YOK"]
        EN["entry.py"]
        TG2["targets.py"]
        EX["exit.py<br/>TEK çıkış kararı"]
        BT["backtest.py"]
    end
    subgraph MKT["app/market"]
        IND["indicators.py<br/>SÜTUN KAYIT DEFTERİ"]
        RR["rank_repository.py"]
        PSRC["price_source.py"]
        CN["candles.py"]
        TK["ticks.py"]
    end
    subgraph EXC["app/exchange"]
        BR["binance_rest.py<br/>retry + hız sınırı + saat"]
        BW["binance_ws.py"]
        SR["symbol_rules.py"]
    end
    CORE["app/core<br/>jsonstore · locking · applog · errors · timeutil"]
    CFG["app/config<br/>settings · paths · secrets"]
    NTF["app/notify<br/>telegram"]

    TARAYICI -->|"/yerel/*"| RT
    SRV --> RT --> HD --> SG
    HD --> TRD
    HD --> STR
    HD --> MKT
    SCH --> TL --> TRD
    SCH --> WT -->|"tepe/dip besler"| TRD
    TRD --> STR
    TRD --> MKT
    TRD --> EXC
    STR --> MKT
    MKT --> EXC
    EXC --> CORE --> CFG
    TRD -.->|"olay"| NTF
    BOT -.->|"olay"| NTF

    DB[("rank.sqlite<br/>SALT OKUNUR")]
    BIN[["Binance<br/>REST + WebSocket"]]
    RR --> DB
    BR --> BIN
    BW --> BIN
```

**Kural (hedef):** oklar yalnız aşağı doğru.

> **Gerçek durum (26.09.2026 import denetimi) — kural 4 yerde ihlal:**
> - `config/settings.py`, `config/secrets.py` → `core` (applog, jsonstore) import ediyor;
>   yani yön **core → config değil, config → core**.
> - `strategy/registry.py` `stratejiler.json` okuyup yazıyor; `strategy/backtest.py`
>   `market.candles` (o da `binance_rest`) import ediyor — strategy tam SAF değil.
> - `notify/telegram_commands.py` ledger, wallet, registry, entry, rank_repository,
>   reporting'i **doğrudan çağırıyor**. notify'ı çağıranlar trading/bot değil,
>   `web/handlers/admin_api.py`, `orders_api.py` ve `main.py`; kapanış olayı
>   `on_closed` geri çağrısıyla enjekte ediliyor.
> - `bot/trade_loop.py` market + strategy'yi, `bot/watcher.py` exchange.binance_ws'yi,
>   `trade_loop.py` ayrıca reporting'i (8 > 7, YUKARI) import ediyor.

---

## 2. Katmanlar

| # | Paket | Sorumluluk | Bağımlı olduğu | **Bağımlı olamayacağı** |
|---|---|---|---|---|
| 1 | `config/` | Ayar, yol, gizli anahtar | — | her şey |
| 2 | `core/` | Dosya, kilit, log, hata, zaman | config | exchange ve üstü |
| 3 | `exchange/` | Binance REST + WebSocket | core, config | market ve üstü |
| 4 | `market/` | Gösterge sözleşmesi, rank, fiyat, mum, tick | exchange, core | strategy ve üstü |
| 5 | `strategy/` | **SAF** karar motoru | *(sadece veri alır)* | dosya, ağ, defter |
| 6 | `trading/` | Defter, emir, pozisyon, çıkış planı | strategy, market, exchange | bot, web |
| 7 | `bot/` | Zamanlanmış işler | trading | web |
| 8 | `reporting/` | PnL, istatistik, arşiv | trading, market | web |
| 9 | `notify/` | Telegram | trading, reporting | *(kimse onu çağırmaz)* |
| 10 | `web/` | HTTP sunucu, yönlendirme, işleyiciler | hepsi | — |

`strategy/` neden saf: bugün test edilemiyor çünkü dosya okuyor ve ağa
çıkıyor. Ayrıldığında eski motorla **213 sembol üzerinde bire bir**
karşılaştırma mümkün olur (bkz. §7).

---

## 3. Fonksiyon envanteri

Tüm adlar ve görevleri: **`FONKSIYONLAR.txt`** (**538 ad, 83 modül — 05.10.2026**; aşağıdaki tablo güncel).
> YAPAY ZEKA MIMO (24.09.2026): sayaç 438 → 506 guncellendi.
> 25.09.2026: 5 eksik ad + `TEMA_KISA` eklendi → **520**
> (`tools/check_unique_names.py`: 520 benzersiz, `--kod` **0/0**).
> 26.09.2026: 128 mum analizi — `formatRuleValue` eklendi → **521**
Benzersizlik `tools/check_unique_names.py` ile **makineyle** doğrulanır.

| Katman | Fonksiyon |
|---|---:|
| `static/js` | 206 |
| `app/web` | 63 |
| `app/market` | 57 |
| `app/strategy` | 46 |
| `app/trading` | 44 |
| `app/exchange` | 40 |
| `app/config` | 24 |
| `app/core` | 17 |
| `app/bot` | 16 |
| `app/notify` | 14 |
| `app/reporting` | 6 |
| `main.py` | 5 |
| **Toplam** | **538** |

Eski adların karşılıkları: **`ESLESTIRME.md`**.

> Her fazda modül başına ayrıntılı tablo buraya eklenecek:
> `ad | görev | çağıran | çağırdığı`.

---

## 4. Veri sözleşmeleri

### 4.1 `rank.sqlite` — `anlik` tablosu

Salt okunur. `toplayici.py` (ayrı servis, `hermes-rank`) yazar. **58 sütun**
seçilir; ayrıca `ts`, türetilmiş `sira_izi` / `iz_yon` ve 15 `renk_*` alanı
(DB'de toplam **59** sütun).

Tam sütun tablosu (ad, tip, anlam, üreten fonksiyon) Faz 1'de buraya
girecek; kaynağı `app/market/indicators.py` içindeki `COLUMN_REGISTRY`.
#### 128 mum analizi (26.09.2026)

Son **128 kapanmış 5m mum** (≈ 10 saat 40 dakika) sekiz alanda özetlenir.

| Alan | Anlam |
|---|---|
| `deg128m` | Pencerenin kapanış-kapanış **% değişimi** (kural alanı) |
| `coingreen` | Pencere içinde **yeşil** mum adedi (kapanış > açılış) |
| `coinsay` | **yeşil − kırmızı** fark; eşit (doji) mumlar sayılmaz |
| `yesildeg` | Yeşil mumların **değişim toplamı (%)** — gösterilmez, kurala yarar |
| `kirmizideg` | Kırmızı mumların **değişim toplamı (%)** — genellikle eksi, gösterilmez |
| `fark128` | `yesildeg − \|kirmizideg\|` — anasayfadaki **FARK** kolonu |
| `kare128` | Son 128 mumun **fiyat aralığı %** = `(enYüksek/enDüşük − 1)·100` — anasayfadaki **KARE** kolonu (1% = 1 izgara karesi) |
| `yukselis128` | **Son kapanan mumun en yükseği / pencere en düşüğü − 1** (`·100`) — anasayfadaki **YUKSELIS** kolonu: dibinden bu yana ne kadar yükseldi; `kare128`'yi **asmaz** |

Mum değişim'i ardışıktır: `değişimᵢ = kapanışᵢ / kapanışᵢ₋₁ − 1` (Binance
24s gibi). **128 değişim için 129 kapanmış mum** gerekir; pencere 129'dan
kısaysa **sekizi de NULL** — uydurma veri yok.

Hepsi `toplayici.ince_olc` üretir (`_kapanmis_mi` ile oluşan mum atlanır);
geriye-testte **aynı hesap** `candles.build_indicator_frame`'dedir, aksi halde
kural "geçmişte yeniden kurulamaz" olurdu.

**Gösterim (2. tur, 26.09.2026):**

- Anasayfa: `CHANGE` ve `YESIL` kolonları **kaldırıldı**; yerine **FARK**
  (değerin işaretiyle renklenen, bar'lı) ve **KARE** (nötr renk) kolonları
  geldi. KARE ekrandaki ızgara karelerinin **ham** sayısıdır: izgara yükseklik
  daraldıkça 2/5/10% adıma yuvarlanır, bu yuvarlama KARE'ye yansımaz.
  **YUKSELIS** (3. tur, 26.09.2026) son kapanan mumun en yükseğini pencere
  dibine böler: `fark128` gibi hep pozitif, bar'lı; son mum tepepedeyse
  KARE ile eşit, değilse ondan küçük çıkar.
- İşlem ekranı: `128m` kutusu artık **FARK** yazar (renk işarettinden gelir),
  `Y/K` kutusu yeşil/kırmızı adedini **olduğu gibi** sürdürür; **128M**
  düğmesi grafiği son 128 muma sığdırır (`50M` EKLENDİ, kaldırılmadı).
- `yesildeg` / `kirmizideg` **hiçbir yerde gösterilmez** — yalnız DB'de
  durur, strateji kuralında kullanılabilir.
- Strateji kurallarında `fark128` / `kare128` / `yukselis128` / `yesildeg` /
  `kirmizideg` / `coinsay` / `coingreen` **her zaman 1 ondalık** gösterilir
  (`format.js:formatRuleValue`).


> **Neden tek kayıt defteri:** eski sistemde bir sütun eklemek **dört** yere
> elle dokunmayı gerektiriyordu (`toplayici.py` INSERT, `db.py` göç listesi,
> `veri.py` `KOLON`, `sunucu.py` geriye-test). `ema7` bunlardan birinde
> unutulduğu için kural aylarca **sessizce hiç ateşlemedi**; `ema4` hâlâ
> arayüzde seçilebiliyor ama veritabanında yok. Kayıt defteri bu sınıfı
> yapısal olarak imkânsız kılar.

### 4.2 Emir kaydı (`defter_canli.json` / `defter_dry.json`)

Şema **değişmiyor** — eski defterler olduğu gibi okunur.

| Alan | Anlam |
|---|---|
| `id` | Defter-lokal sayaç. **Yeni:** dışarıya `(kaynak, id)` çifti olarak verilir |
| `sembol`, `taraf`, `dugme` | Sembol, BUY/SELL, hangi buton |
| `durum` | `ACIK` / `KISMI` / `DOLDU` / `KAPANDI` / `IPTAL` / `RED` |
| `fiyat`, `miktar`, `tutar` | Emir büyüklüğü |
| `kar_al`, `stop` | Hedef ve başlangıç stop. **Yeni:** yalnız `exit_rules` yazar |
| `stop_guncel`, `stop_sebep`, `en_yuksek`, `hedef_tur` | Çalışma anında güncellenen takip alanları |
| `borsa_id`, `borsa_durum`, `dolan_fiyat`, `dolan_miktar`, `dolum_ts` | Borsa tarafı |
| `kapanis`, `kar`, `kar_p`, `kar_brut_p` | Kapanış |
| `el_kaynak` / `kaynak` / `strateji` | Emri kim açtı |
| `canli`, `ts` | Gerçek para mı, ne zaman |

### 4.3 Strateji kuralı

```json
{"alan": "cci",   "op": ">",      "deger": 68}
{"alan": "ema20", "op": ">",      "deger_alan": "wma48"}
{"alan": "wma48", "op": "yukari"}
```

Operatörler: `>` `>=` `<` `<=` `==` `!=` `yukari` `asagi`. Kurallar düz
liste, hepsi **VE**'lenir.

> **Yeni:** `evaluate_rule` dört durum döner — `GECTI` / `KALDI` / `OLCULMEDI` / `ALAN_YOK`.
> (`OLCULMEDI`: alan meşru olarak boş, ör. son mum yeşil değilken `ha_yesil_yukselis`.)
> Eski sistemde altı farklı sebep tek `False`'a iniyordu, bu yüzden
> "koşul tutmadı" ile "böyle bir alan yok" ayırt edilemiyordu.
> `ALAN_YOK` artık hata sayılır ve strateji **kaydedilirken** reddedilir.

---

## 5. HTTP uçları

46 uç: 27 GET + 19 POST (05.10.2026, `routes.py` sayıldı). <!-- YAPAY ZEKA MIMO: 39→42 --> Eski sistemde ikisi de tek dev `if/elif` zinciriydi
(`do_GET` 615 satır, `do_POST` 330 satır); burada `router.py` içinde tablo.

> Tam tablo (yol, yöntem, girdi, çıktı, işleyici) Faz 4'te buraya girecek.
> İşleyici dağılımı `FONKSIYONLAR.txt` → `app/web/handlers/` bölümünde.

**Statik servis:** yalnız beyaz listedeki dosyalar (`index.html`,
`telefon_onizleme.html`, `fonts/*.woff2`). Eski sistem kökü olduğu gibi
servis ettiği için `/gizli/binance.json` tarayıcıdan **HTTP 200** dönüyordu.

---

## 6. Emir yaşam döngüsü

```mermaid
sequenceDiagram
    participant U as Arayüz
    participant H as orders_api
    participant O as order_service
    participant E as exit_rules
    participant X as binance_rest
    participant L as ledger

    U->>H: POST /yerel/emir
    H->>O: place_entry_order()
    O->>X: fetch_order_book() → limit fiyatı
    O->>X: submit_order() (newClientOrderId)
    X-->>O: dolum
    O->>E: plan_for_source(buton)
    E-->>O: {kar_al, stop, merdiven, trailing}
    O->>L: append_order()  (kilit içinde)
    Note over E,L: kar_al'ı YALNIZ exit_rules yazar
```

**Buton → plan eşlemesi**

| Buton | Plan | Stop | Hedef |
|---|---|---|---|
| **AL** | `build_manual_plan` | `al_stop` + iki kademeli merdiven + dinamik takip | trailing |
| **AL TAKIP** | `build_follow_plan` | `bot_cikis_stop` + merdiven + ivme genişletmesi | trailing |
| **ALSAT 1/2/3** | `build_scalp_plan` | `alsat_stop` + kilit | sabit `alsat_hedef_N` |
| **BOT** | `build_bot_plan` | AL TAKIP ile aynı | trailing |

> **Eski sistemdeki çakışma:** girişte ham stratejinin hedefi `kar_al`'a
> yazılıyor, çıkışta o strateji yok sayılıyordu — ama 1 saniyelik takipçi
> yazılmış `kar_al`'ı okuyup satıyordu. Sonuç: `bot_cikis_esik: 5.0` ayarı
> hiç çalışmıyor, pozisyon +%1.89'da kapanıyordu. Burada `kar_al`'ın **tek
> yazıcısı** `exit_rules`.

> **Düzeltme (26.09.2026):** `kar_al`'ı hiçbir karar kodu okumuyor.
> `decide_exit` **plan sözlüğünü** okur (`strategy/exit.py`) ve plan her 5 sn'de
> **o anki ayarlar + ŞU AN AKTİF strateji** ile yeniden kurulur
> (`trade_loop.py`, `get_active_strategy`). Yani bot pozisyonu, onu AÇAN
> stratejinin değil, **şu an aktif** stratejinin kurallarıyla kapanır.
> `exit_rules.plan_for_source` stratejideki `cikis`/`stop` alanlarını global
> planın üstüne yazar. Canlıda emir LIMIT GTC'dir; dolum çoğunlukla sonradan
> `refresh_order_statuses` (60 sn, `borsa_senkron`) ile işlenir.

---

## 7. Doğrulama

Gerçek para olduğu için yeni sistem, fark testi temiz geçmeden canlıya
alınmaz.

| Adım | Ölçüt |
|---|---|
| İzole çalışma | Port 7801, `canli=false`, defterlerin **kopyası** *(26.09.2026 itibarıyla GEÇERSİZ — 7801 canlıda, bkz. baş)* |
| Uç karşılaştırması | 22 salt-okunur GET ucu eski sistemle **bire bir** |
| Kural motoru | Aynı `rank.sqlite` satırlarıyla **213 sembolün tamamında** aynı karar |
| Geriye-test | Aynı sembol+strateji için aynı tetiklenme noktaları |
| Emir yolu | Yalnız kâğıt; test kurulumunda API anahtarı **silinir** |
| Arayüz | 10 sayfa + dikey mod (360×780) karşılaştırması |

---

## 7.1 Yapılan eşdeğerlik ölçümleri

Her faz, eski sistemin **kendi modüllerini import edip** aynı girdiyle
karşılaştırılarak doğrulanır. Ölçülen sonuçlar:

| Ne | Sonuç | Betik |
|---|---|---|
| Gösterge değerleri (`gostergeler.py`, `toplayici.py` ile) | **15/15 birebir eşit** | `smoke_faz1d.py` |
| Şema sözleşmesi ↔ canlı `rank.sqlite` | **UYUMLU** (51 sütun / 50 kayıt + `ts`) | `smoke_faz1b.py` |
| Kural motoru — 210 sembol | **210/210 aynı karar** | `smoke_faz2a.py` |
| Çıkış kararı — 7 yapılandırma × fiyat/tepe/hız/ATR/ivme taraması | **171.360/171.360 birebir** | `smoke_faz2b.py` |
| Aday seçimi | **aynı küme ve aynı sıra** (9 aday) | `smoke_faz2c.py` |

Gösterge eşitliği ilk turda **5 gerçek algoritma farkı** ortaya çıkardı ve
düzeltildi: `hiz` penceresi, Heikin Ashi'nin 30 mumluk penceresi, ortanca
tanımı (çift sayıda elemanda ortalama), yeşil mum testinin `>=` olması ve
`round(...,4)`. "Aynı formül" yetmiyor; pencere, yuvarlama ve eşik yönü de
eşleşmeli.

## 7.3 Para güvenliği — Faz 3'te ölçülenler

Defterlerin **kopyası** üzerinde, eşzamanlı iş parçacıklarıyla:

| Kusur | Sınama | Sonuç |
|---|---|---|
| **B1** SIFIRLA gerçek defteri siliyordu | `ayar.canli=true` iken `reset_ledger(live=False)` | Kâğıt 9→0, **gerçek 174 kayıtla korundu**, yedek alındı |
| **B2** Çifte MARKET SELL | 4 iş parçacığı aynı pozisyonu eşzamanlı kapatmaya çalıştı | **Borsaya giden satış: 1**, üçü engellendi |
| **B4** Kayıp güncelleme | 3 iş parçacığı × 40 güncelleme | Sayaçlar tam (80/40), kayıp yok |
| Çıkış planları | 6 yapılandırma, alan alan | **6/6 eski `el_strateji` ile birebir** |
| Bakiye kontrolü | 30 USDT bakiyeyle 9999 USDT emir | Reddedildi *(eski sistemde bu kontrol yoktu)* |

`live` parametresi artık **her imzada zorunlu** — `get_ledger_path(None)`
`TypeError` fırlatır. B1'in kökü, argümanın verilmediğinde `ayar["canli"]`'ya
düşmesiydi.

## 7.2 Geriye-test artık iyimser değil

Eski `/yerel/gecmis-sinyal`, tek sembolün geçmişinden **yeniden
kurulamayan** alanları (`rank`, `rank_atr`, `iz_yon`, `hacim_x_1h/4h`,
üst zaman dilimi HA'ları) sessizce "geçti" sayıyordu. Sonuç sistematik
olarak canlıdan iyimserdi.

Yeni `strategy/backtest.py` bunları `UNTESTABLE_FIELDS` olarak işaretler,
"geçti" saymaz ve sonuca açık bir uyarı ekler:

> Bu sonuç EKSİK: şu kurallar geçmişte yeniden kurulamadığı için sınanmadı.

## 7.4 Faz 4 — çalışan sunucu

Yeni arka yüz **port 7801'de ayakta** ve mevcut arayüzü servis ediyor.
*(Faz 4 anındaki hâl:)* defterlerin kopyası, `rank` dizini ayrı (`panel_ayar.json`
kopya, `rank.sqlite` sembolik bağ), API anahtarı yok, kâğıt mod.
**26.09.2026'dan beri:** gerçek veri aktarıldı, `canli=true`, anahtar yüklü.

| Sınama | Sonuç |
|---|---|
| 20 GET ucu | hepsi **HTTP 200**, anlamlı veri |
| Statik beyaz liste | `gizli/binance.json`, `ayar.json`, `defter_*.json`, `*.py`, `/../ayar.json` → **403**; arayüz + fontlar → 200 |
| Arayüz uyumu | `index.html`'in çağırdığı **26 ucun hepsi kayıtlı** |
| Güvenlik kapıları | anahtarsız canlı mod → 409, defter belirtmeden kapatma → 400, `ema4` stratejisi → 400 |
| `POST /yerel/bot {sifirla}` | kâğıt defter 9→0, **gerçek defter 174 kayıtla korundu**, yedek alındı |
| `kaynak=dry` vs `kaynak=canli` | farklı veri döner *(eski sistem ikisinde de canlı istatistik dönüyordu)* |
| Çalışma | 0 hata, 3/3 iş çalışıyor, websocket canlı, ağırlık **72/6000** |

**Yeni uçlar:** `/yerel/saglik` (hangi işler çalışıyor, websocket bayat mı,
Binance ağırlığı ve çağrı dağılımı, şema uyumu) ve `/yerel/uclar`.
Eski sistemde bu görünürlük hiç yoktu — `takipci`'nin aylarca
başlatılmamış olması bu yüzden fark edilmemişti.

### Faz 4 testinin yakaladığı üç kusur

1. **`watcher` tepe/dip'i her 2 saniyede sıfırlıyordu.** Önceki sembol
   kümesi var olmayan bir alandan okunmaya çalışılıyordu, hep boş dönüyordu.
   Böyle bir sistemde **iz süren stop asla tetiklenemez**: tepe sürekli
   anlık fiyata çekilir, "tepeden geri çekilme" hiç oluşmaz. Sessiz ve
   ölümcül olurdu.
2. **Hız sınırı sabiti yanlıştı** (1200). Gerçek sınır **6000/dk** ve artık
   açılışta `exchangeInfo`'dan okunuyor. Sağlık ucu "2534/1200" diye yanlış
   alarm veriyordu.
3. **Test `panel_ayar.json`'a yazdı** — o dosya `hermes-rank` ile PAYLAŞILAN
   bir dosya ve `NEWTRADE_DATA_DIR` ile izole edilmiyor. Gerçek hariç listesi
   267→2'ye düştü, aynı günün yedeğinden geri yüklendi. Test ortamı artık
   `NEWTRADE_RANK_DIR` ile de izole; `exclusions.py`'ye uyarı yazıldı.

## 7.5 Ön yüz — modül yapısı ve doğrulama

`index.html` 6.646 satırdı (CSS + HTML + 130 fonksiyonluk JS tek dosya).
Şimdi:

| | Dosya | Satır |
|---|---:|---:|
| `index.html` (yalnız iskelet) | 1 | 795 |
| `css/` | 19 | 1.760 |
| `js/` | 30 | ~3.700 |

**Görünüm birebir korundu** — CSS kuralları `tools/bol_onyuz.py` ile olduğu
gibi taşındı, yeniden tasarım yapılmadı. Bilerek değiştirilen kurallar
`css/99-duzeltme.css` içinde, her biri gerekçesiyle.

### Otomatik denetimler

Üç araç, üç ayrı "sessizce ayrışma" sınıfını kapatıyor:

| Araç | Neyi yakalar |
|---|---|
| `tools/check_unique_names.py --kod` | Kodda olup listede olmayan ad (Python **ve** JS). Şu an **0/0** |
| `tools/css_denetim.py` | JS'in ürettiği ama CSS'i olmayan sınıf |
| `tools/gen_js_listesi.py` | `FONKSIYONLAR.txt`'nin JS bölümünü **koddan üretir** |
| `tools/js_sozdizimi.py` | Tüm JS modüllerini `node --check` ile doğrular |

Sabitler için kural **asimetrik**: fonksiyon/sınıf listede olmak zorunda,
sabit isteğe bağlı — ama listeye yazıldıysa kodda bulunmalı. Aksi halde
`EPS`, `BASE_URL` gibi iç ayrıntılar sözleşmeyi gürültüye boğar.

### Zamanlayıcılar sayfaya bağlıdır

**Bu bir kilitlenme düzeltmesidir.** İlk yazımda kayıtlı her iş sonsuza
kadar dönüyordu; sayfadan çıkınca durmuyordu. Tüm sayfalar gezildikten
sonra **aynı anda 12 döngü** dönüyordu: ana tablo 10 sn'de bir 213×28
hücre, işlem sayfası 2016 mum, kazananlar 12 ayrı mum isteği. Tarayıcı
kilitleniyordu — sunucu ise %0.4 CPU'da boş duruyordu.

`registerPoll(ad, sn, fn, { sayfa })` — iş artık bir sayfaya bağlı:

- Yalnızca o sayfa açıkken döner (`setActivePage` ile).
- `sayfa` verilmeyen işler (ayar) her zaman döner.
- Sekme arka plana alınınca (`document.hidden`) **hepsi** durur.
- Sayfaya girince hemen bir tur atar (bayat veri gösterilmez).

Durum satırında kaç işin döndüğü yazar: `▤ANASAYFA · 2 is`.
Konsoldan `__cn.durum()` ile ayrıntısı görülebilir.

| Sayfa | Dönen iş |
|---|---:|
| anasayfa, seçilenler, kazananlar, cüzdan, bot, notlar, ayarlar | 2 |
| heatmap | 1 |
| stratejiler, trade | 3 |

### HEATMAP sayfası (YAPAY ZEKA MIMO)

Menüdeki **GÜNLÜK** (uzlaştırma kayıtları) kaldırıldı; yerine **HEATMAP** geldi.

- **Endeksler:** USDT/USDC 24s hacim (Binance `ticker/24hr`), TOTAL3 proxy (BTC/ETH dışı altcoinlerin hacim ağırlıklı ort. `deg24`), genişlik (yeşil coin oranı), BTC/ETH hacim payı.
- **KAC-Index mantığı:** her karoda `endeks = deg24 − total3` — coin altcoin evrenini yeniyor mu (KAC v1 TOTAL3 endekslemesinin Binance karşılığı).
- **Akış rozeti:** USDT hacmi ↓ + genişlik ↑ → "para coinlere akıyor"; tersi → "USDT'ye park".
- **Zamanlama:** 5 dakikada bir, pencere bitimine **40 sn kala** (örn. 12:04:20) yenilenir; ayrıca sayfaya girince/elle yenilemede anında çeker.
- **Kapsam:** anasayfa listesi (~210) + BTC/ETH karo; tavan yok.
- **Sıralama:** varsayılan `deg24` azalan (chip: 24s/5dk/1h/hacim).
- **CCI filtresi:** switch — CCI 5 dk öncekiye göre yükselenler (+ BTC/ETH hep görünür). Varsayılan **kapalı** (`heatmap_cci_acik`).
- Ayarlar kartı: `heatmap_cci_acik`, `heatmap_siralama`, `heatmap_btc_eth`.
- Uç: `GET /yerel/heatmap` · JS: `pages/heatmap.js` · CSS: `98-heatmap.css`.

Canlı akış da sayfaya bağlı: anasayfadan çıkınca ilk-30 aboneliği bırakılır,
geri dönünce **yeniden abone olunur**.

### Canlı fiyat (websocket) nasıl çalışır

Anasayfada tablodaki **ilk 30 coin** Binance aggTrade akışına abone olur ve
`CANLI%` kolonu ile fiyat hücresi canlı güncellenir. Rozet: `canli (30)`.
Düşük hacimli coinler her saniye işlem görmediği için hepsi anında dolmaz.

İşlem sayfasında yalnızca **seçili coin** abone olur.
İki ayrı yönetici yerine tek `live/socketManager.js` kullanılır
(eski sistemde `POZ_WS` ve `ANA_WS` aynı deseni iki kez yazıyordu).

### Ön yüz testi (konteynerden)

Chrome köprüsü eklentisi bağlı değilse **host üzerinde** headless shell:

```bash
hostcmd run "~/.cache/ms-playwright/chromium_headless_shell-1234/\
chrome-headless-shell-linux64/chrome-headless-shell --headless=new \
--no-sandbox --virtual-time-budget=12000 --enable-logging=stderr --v=0 \
--dump-dom|--screenshot=X.png http://127.0.0.1:7801/#sayfa"
```

`stderr` **mutlaka** yakalanmalı: tek bir `SyntaxError` tüm modül grafiğini
düşürür ve sayfa hiç render olmaz — `--dump-dom` o zaman ham HTML döndürür,
"çalışıyor" gibi görünür.

`#sayfa` ve `#islem/SEMBOL` ile doğrudan sayfa açılabilir (yeni özellik).

### Ön yüzde düzeltilen davranışlar

| Eski | Yeni |
|---|---|
| `gecmisSinyalYukle` 60 sn'de bir kullanıcının STRATEJI tercihini eziyordu | Kullanıcı tercihleri `store.js`'te **ayrı** tutulur; yenileme döngüleri onlara yazamaz |
| `/yerel/emirler` iki bağımsız kanaldan çekiliyordu | `poll.js`: bir uç **en fazla bir** yerden, yanıt paylaşılır |
| 27 `fetch`'ten 19'unda `r.ok` yok, hata `catch(_){}` ile yutuluyordu | `api.js` tek giriş; her hata toast ile **görünür** |
| Üç ayrı Escape dinleyicisi tüm katmanları birden kapatıyordu | `keys.js` modal yığını: Escape **yalnız en üsttekini** kapatır |
| Zoom sınırı çelişkisi (2–22 vs 88/0.02) → pinch'te sıçrama | `chart/zoom.js` tek sınır kümesi, tüm yazıcılar aynı klempten geçer |
| Dikey modda sayfa tek satırlık JS ile kaydırılıyordu (momentum yok) | `touch-action: pan-y` — dikey kaydırma **tarayıcıya** bırakıldı |
| `limitTutamacBagla` her çağrıda `window`'a dinleyici ekliyor, kaldırmıyordu | Tüm dinleyiciler `AbortController`'a bağlı |
| Tam ekran (yatay) dikey düzeni bırakıyordu | `#tamekran` artık düzeni de yataya alır |

## 7.6 Takip edilmeyen varlıklar

İki ayrı liste vardır ve **farklı şey yaparlar**:

| Liste | Dosya | Etkisi |
|---|---|---|
| `haric` | `rank/panel_ayar.json` | Coin **tablosundan** eler — aday olmaz |
| `pozisyon_haric` | `ayar.json` | Borsa–defter **uzlaştırmasında** pozisyon sayılmaz |

`BNB` ve `USDT` her ikisinde de. `USDT` kotasyon birimi olduğu için kodda
zaten yapısal olarak eleniyor (`reconcile.fetch_exchange_holdings`), ama
açıkça yazılı olması ileride kod değişirse de korur.
Aracı: `tools/haric_ekle.py` (yedek alır, sonra doğrular).

### Borsadaki varlıklar otomatik takibe alınır

`reconcile_positions` artık yalnızca elle satılanları kapatmakla kalmaz;
borsada olup **defterde hiç yer almayan** varlıkları da takip listesine
yazar (`adopt_untracked_holdings`).

- **Ne zaman:** "CUZDANI SIMDI KONTROL ET" butonu ve `borsa_senkron`
  işi (60 sn). Canlı defterde açık emir **olmasa da** senkron çalışır.
- **Kapsam:** `pozisyon_haric` (BNB, USDT) `fetch_exchange_holdings`
  içinde zaten elenir; **1 USDT altı toz** da alınmaz.
- **Plan:** AL butonuyla aynı — `build_manual_plan` (kademeli stop).
- **Kayıt:** `el_kaynak: "al"`, `durum: DOLDU`, `borsa_durum: ADOPTED`;
  uzlaştırma günlüğüne `tur: takibe_alindi` satırı düşer.

Ölçüldü (24.09.2026): PROM (11.07) ve CELR (9.96) otomatik alındı;
BNB/USDT/ASTR(toz) alınmadı; tekrar çağrıda listeye ikinci kez girmedi.

## 7.7 Panele nasıl erişilir — iki yol, tek kod

Panel **iki ayrı adresten** servis edilir ve ikisi de aynı süreci gösterir:

| Yol | Adres | Kimlik doğrulama | Ne zaman |
|---|---|---|---|
| Doğrudan | `http://<host>:7801/` | yok | yerel ağda hızlı bakış |
| Panel4 üzerinden | `http://<host>:7093/cn/` | panel4'ün basic auth'u | kontrol panelinin sağ alt bölmesi |

**Neden ikinci yol var.** Panel4'ün bölmesine önce sabit bir adres
(`http://100.120.1.56:7801/`) yazılmıştı. Bu adres yalnız **Tailscale ağındaki**
cihazdan açılır; kullanıcı panele LAN'dan (`192.168.1.71:7093`) bağlandığında
iframe o IP'ye ulaşamadığı için bölme **boş kalıyordu**. Tersi de geçerliydi:
LAN adresi yazılsaydı Tailscale'den açılmayacaktı. Bölmeye **göreli** bir adres
(`/cn/`) yazılınca iframe her zaman sayfanın kendi kaynağını kullanır — panel
hangi ağdan açılırsa açılsın çalışır, üstelik aynı kaynak olduğu için ikinci kez
şifre sorulmaz ve `X-Frame-Options` / CORS sorunu doğmaz.

**Nginx tarafı** (`dockhand/stacks/ismail ubuntu/panel-gateway/nginx.conf`):

```nginx
location /cn/ {
    proxy_pass http://127.0.0.1:7801/;   # sondaki / oneki kirpar
    ...
}
```

**Uygulama tarafı — tek satır.** Varlıkların tamamı zaten göreliydi
(`css/00-temel.css`, `js/giris.js`, fontlar `../fonts/...`). Mutlak olan tek
şey API yollarıydı (`/yerel/...`) ve hepsi `api.js`'teki **tek** `TABAN`
sabitinden geçiyordu:

```js
const TABAN = location.pathname.replace(/\/[^/]*$/, "").replace(/\/+$/, "");
```

`/` altında `""`, `/cn/` altında `"/cn"` üretir; aynı kod iki adreste de
çalışır. Sayfa yönlendirmesi hash tabanlı olduğu için (`#kazananlar`) bu
türetmeyi etkilemez.

**Ölçülen doğrulama** (başsız Chromium, CDP):

| Sayfa | Adres | Konsol hatası | Ağ hatası |
|---|---|---:|---:|
| Anasayfa (213 coin, canlı veri) | `7093/cn/` | 0 | 0 |
| Kazananlar (kartlar + mumlar) | `7093/cn/#kazananlar` | 0 | 0 |
| Cüzdan (regresyon) | `7801/#cuzdan` | 0 | 0 |

(Ölçümdeki tek uyarı `[ayar] kullanılmayan anahtarlar` — o **kasıtlı**;
`DEAD_SETTINGS` denetimi, bkz. §99.)

Araç: `tools/cdp_denetim.py` — bağımsız, bağımlılıksız CDP istemcisi
(websocket çerçevelemesi elle yazılmış). Sayfayı açar, konsol hatalarını ve
400+ dönen istekleri toplar, ekran görüntüsü alır.

## 7.8 Trade ekranı — ölçülen kilitlenme ve grafik düzeltmeleri

23.09.2026'da İsmail yedi ayrı belirti bildirdi. Hepsi **ölçülerek** teşhis
edildi; hiçbiri tahminle kapatılmadı.

### Kilitlenme — sebep tahmin edilmedi, profille bulundu

İlk hipotezim "websocket sürekli yeniden bağlanıyor" idi. `tools/ws_olc.py`
(sayfa yüklenmeden önce `window.WebSocket`'i saran CDP ölçümü) bunu
**çürüttü**: 50 saniyede **1** bağlantı, 0 kopma.

Asıl sebebi CDP örnekleyici profili gösterdi (`tools/profil.py`):

| Fonksiyon | Önce | Sonra |
|---|---:|---:|
| `getBoundingClientRect` (yerleşim) | **%30.4 — 10 729 ms** | %0.9 — 285 ms |
| `canliYaz` → `hucreyeYaz` | %5.7 — 2 030 ms | %1.9 — 576 ms |
| 200 ms+ donma (50 sn'de) | **5 kez, en uzun 2 678 ms** | **0 kez** |

İki kök neden:

1. **`alignStickyHeader` yerleşim çarpışması.** Her satırın her hücresinde
   ÖNCE yazıp SONRA ölçüyordu (`style.left = …` ardından
   `getBoundingClientRect()`), yani 213 satır × 5 hücre = **1065 zorunlu
   yerleşim hesabı**. Kolon genişlikleri tüm satırlarda aynı olduğundan bir
   kez ölçmek yeter: önce 5 ölçüm, sonra saf yazma. **1065 → 5.**
   Ayrıca `scroll` olayına bağlıydı; `position:sticky` zaten konumu koruduğu
   için o bağlantı tamamen kaldırıldı.
2. **Her tick'te DOM yazımı.** aggTrade saniyede ~20 mesaj getiriyor ve her
   biri için `querySelector` + hücre güncellemesi yapılıyordu. Artık gelen
   fiyatlar biriktirilip **kare başına tek kez** yazılıyor.

### Diğer altı düzeltme

| Belirti | Ölçülen sebep | Düzeltme |
|---|---|---|
| "websocket sürekli bağlanmıyor" | `islem.js` `createSocketManager`'a **`onDurum` vermiyordu**; soket çalışsa bile `#wsDurum` sonsuza kadar "baglanmadi" kalıyordu (anasayfada bağlıydı, işlem ekranında değil) | `onDurum: renderConnectionBadge`. Ölçüldü: artık `canli (1)` |
| "5m'nin son mumunu gösteriyordu, o da çalışmıyor" | `canliBarCiz` bir CSS değişkenine (`--oran`) indirgenmişti; `.canliBar` ise içine **SVG** bekliyor → kutu boş | Eski davranış geri: büyütülmüş son mum + yüzde çizgileri + limit çizgisi. Açık mumun tepe/dibi artık websocket'ten de genişliyor |
| "mumun yanındaki fiyatı kaldır, mumlar gözükmüyor" | Fiyat ekseni için sağda **52 px** ayrılıyordu; 150 px'lik mini kartta bu alanın üçte biri | `renderMiniChart` → `eksen: false` (sağ kenar 2 px) |
| "soldaki grafiklerin isimlerini küçült" | Mini kart başlıkları ana grafikle aynı 10 px'teydi | Sol sütun başlıkları 8 px |
| "fiyattaki aşırı küsurat" | `formatPrice` büyüklüğe göre **sabit** ondalık kullanıyordu (`toFixed`) → 74.8600, 1.4670 | Anlamlı basamak + sondaki sıfırları at → 74.86, 1.467 |
| "arkada %1'lik ızgara vardı" | Yeni çizici 4 eşit aralıklı **doğrusal** çizgi koyuyordu | Çarpımsal %1 ızgarası geri (aşağıda) |
| "dokunduğumda dikey çizgi olsun" | Yoktu | `renderCrosshair` — yalnızca basılıyken, mum merkezine oturur |

### %1 ızgarası — neden çarpımsal

Yüzde çarpımsaldır. Sabit adım (`ortalama × 0.01`) yalnızca grafiğin
ORTASINDA %1 tutar; aşağıda %1'den büyük, yukarıda küçük çıkar. Eski
sistemde ölçülmüştü (ZEC 1000–1400):

| Konum | Adım | Gerçek yüzde |
|---|---|---:|
| altta | 1008 → 1020 | %1.19 |
| ortada | 1200 → 1212 | %1.00 |
| üstte | 1380 → 1392 | %0.87 |

Doğrusu: her çizgi bir öncekinin **1.01 katı**. Buna 23.09.2026'da bir ek
yapıldı: adım her zaman %1 kalırsa geniş aralıklarda (1D mini grafikte %30
menzil) çizgiler 2 px'e sıkışıp zemini boyuyor. Adım artık %1'in
katlarından (**1 · 2 · 5 · 10 · 25**) seçilir; en az 6 px aralık bırakan
ilk kat kullanılır — dar grafikte gerçek %1, geniş olanda daha kaba.

**CSS tuzağı:** ızgara ilk denemede çiziliyor ama **görünmüyordu**.
`99-duzeltme.css` içindeki `.mumSvg .gridCizgi` kuralı iki seçicili olduğu
için tek sınıflı `.yuzdeCizgi` kuralını eziyor ve çok koyu `--izgara`
rengini dayatıyordu. Stil aynı özgüllükte ve `--izgara-cizgi` rengiyle
yeniden yazıldı. Ölçüldü: 23 yatay + 27 dikey çizgi, `rgb(29,67,82)`.

### Doğrudan `#islem` açılışı

Panel, adres çubuğundan doğrudan `#islem` ile açıldığında **tamamen ölü**
geliyordu: dört mini grafik de, 5M de "COIN SECILMEDI", websocket
"baglanmadi". Profil bunu net gösterdi: **%99.8 boş**.

Sebep: `satirlar` listesini yalnızca ANASAYFANIN zamanlayıcısı doldurur; o
sayfaya hiç uğranmadığında liste boş kalıyor ve `seciliSembolDegisti`
sembol bulamadan dönüyordu. Artık liste boşsa `/yerel/ozet` ucunu panelin
kendisi bir kez çekiyor.

### Doğrulama

`tools/cdp_denetim.py` ile üç sayfa, `tools/imlec_test.js` ile dokunma:

| Ölçüm | Sonuç |
|---|---|
| Dikey imleç: basmadan / basılıyken / bıraktıktan sonra | 0 / 1 / 0 |
| İmlecin mum merkezine oturması | dokunulan 444.76 px → çizgi 447.7 px (2.9 px hizalama) |
| Canlı bar SVG'si | çiziliyor, 5 çizgi |
| Soket durumu (işlem ekranı) | `canli (1)` |
| Konsol / ağ hatası (3 sayfa) | 0 / 0 |

"Kazananlar" kartlarındaki mum sayısı, İsmail'in isteği üzerine 24'ten
**20**'ye indirildi (`KART_MUM`).

### Takip edilmeyenler gerçekten süzülüyor mü — ölçüldü

İstek üzerine kontrol edildi; kod zaten doğruydu, değişiklik gerekmedi:

| Uç | Dönen | Hariç listesinden sızan |
|---|---:|---:|
| `/yerel/ozet` | 216 | **0** |
| `/yerel/kazananlar` | 11 | **0** |
| `/yerel/aday` (stratejinin seçtikleri) | 12 | **0** |

Süzme tek yerde: `rank_repository.fetch_latest_snapshot`. Üç uç da onu
kullanır. `save_excluded_symbols` yazarken önbelleği hemen geçersiz kılar,
dolayısıyla listeye eklenen coin bir sonraki turda düşer.

## 7.9 Cüzdan, bot ve kilitlenme — ikinci tur

### Cüzdan artık her iki modda da GERÇEK parayı gösterir

İsmail: *"cüzdan canlı modda da olsa dry run da da olsa gerçek değeri ve
mevcut coinlerimizi gösterecek … dry run da bile olsak ben binance'den coin
alır isem cüzdanda onu takip edecek."*

Önceki davranış: sayfa aktif moda bakıp `kaynak=dry` ya da `kaynak=canli`
istiyordu; kâğıt modda gerçek bakiye **hiç** görünmüyordu.

| Katman | Değişiklik |
|---|---|
| `wallet.get_wallet_overview` | Gerçek **ve** kâğıt cüzdanı birlikte döndürür |
| `/yerel/bakiye` | Artık bu görünümü döndürür (`gercek`, `kagit`, `gercek_hata`) |
| `pages/wallet.js` | Bakiye, K/Z, pozisyonlar ve geçmiş **her zaman** canlı deftere bakar |

**Değiştirilmeyen:** `get_wallet(live)` ve `get_free_quote_balance`. Emir
yolundaki bakiye kontrolü moda bağlı kalmalı — kâğıt modda gerçek parayla
sınırlanmak yanlış olurdu. Bu yüzden görünüm ayrı bir fonksiyona alındı.

Ölçüldü (dry run modunda): toplam **33.57 USDT**, 3 varlık (USDT / BNB /
ASTR) panelde görünüyor.

### Giriş ve çıkış anının piyasa görüntüsü kaydediliyor

İsmail: *"giriş detayları çıkış detayları hepsi olmalı ki ilerde bize
strategy yazarken lazım olabilir."*

Defterde bugüne kadar yalnızca fiyat/zaman/miktar vardı; **hangi koşulda
girildiği kayıtlı değildi**, dolayısıyla geçmiş işlemlerden kural çıkarmak
imkânsızdı. Artık:

- `rank_repository.capture_market_snapshot(sembol)` o turun 52 alanını alır
- `order_service.place_entry_order` → `giris_piyasa`
- `position_service.record_position_close` → `cikis_piyasa`
  (görüntü **kilidin dışında** alınır; kilit içinde yalnızca oku-değiştir-yaz kalır)

Rank veritabanı okunamazsa emir yolu çalışmaya devam eder (`None` döner).
**Eski kayıtlarda bu alanlar yoktur — uydurulmaz, sadece gösterilmez.**

### Kapanmış işlem kartı ve detay satırları

`ui/positionTable.js` iki yeni çizici kazandı; cüzdan ve bot **aynı** kodu
kullanır (ikinci kopya yok):

- `renderPositionTable` → her pozisyonun altına **ikinci satır**: iz, ATR,
  RSI, CCI, KDJ-J, xH, OBV, HA, sHIZ, sATR — anasayfadakiyle aynı alanlar
- `renderClosedTrades` → coin adı üstte, altında GİRİŞ / ÇIKIŞ / PLAN
  blokları; `giris_piyasa`/`cikis_piyasa` varsa o anın göstergeleri

Gösterge hücrelerinin tek kaynağı `ui/marketDetail.js`. `trade.js`'teki iz
çizimi de oraya taşındı — **tek uygulama**.

`/yerel/emirler` artık yanıtına `piyasa` haritası ekliyor: yalnızca defterde
geçen sembollerin anlık satırları. Böylece cüzdan/bot ekranı 400 satırlık
özeti çekmek zorunda kalmıyor.

### İz artık yeşil / kırmızı

İsmail: *"anasayfada iz yeşil yada kırmızı olmalı."* Önceden yön sadece
**opaklıkla** belirtiliyordu (yükselen 1.0, düşen 0.55) — pratikte ikisi de
aynı renkti. `sira_izi` bir RANK dizisidir; rank küçülürse coin tırmanıyor
demektir, bu yüzden yön = ilk − son. Tırmanan yeşil, gerileyen kırmızı.

### DRY RUN rozeti: buton değil, gösterge

İsmail: *"pencerenin üstünde dry run buton değil buton gibi duracak sadece,
dry run'da gri canlı modda yeşil olacak, canlı moda ayarlardan geçilebilir
sadece, canlıya geçerken de emin misiniz çıkarken de emin misiniz."*

- `#btnMod` → `#modRozet`: `<span>`, `cursor:default`, tıklama bağlantısı yok
- Mod değişimi yalnızca Ayarlar sayfasındaki düğmeden
- **Her iki yön de onaylı** — önceden canlıdan çıkış hiç onay sormadan oluyordu

**Ayrıca bulunan sessiz hata:** eski CSS `#btnMod[data-mod="canli"]` seçiyordu
ama JS hiç `data-mod` yazmıyordu — `renderModeBadge` **sınıf** değiştiriyor.
Yani rozet pratikte **hiç yeşile dönmüyordu**. Seçici JS'in gerçekte yazdığına
göre düzeltildi.

### "Hâlâ kilitleniyor" — ölçüm turu

İsmail: *"sayfalar arası geçiş yaparak test et."* Doğru ipucuydu; önceki
ölçümüm tek sayfada duruyordu.

**Önce iki kez yanlış ölçtüm, ikisini de not ediyorum:**

1. `setInterval` **çağrılarını** saydım, yaşayan zamanlayıcıları değil.
   "Her turda +22 sızıntı" göründü; `poll.js` zaten `clearInterval` yapıyor.
2. `window.WebSocket` sarmalını sayfa **yüklendikten sonra** kurdum;
   açılışta kurulan soket sayılmadı ve "anasayfa soketi hiç açılmıyor"
   sonucuna vardım. Doğrudan sonda: `canli (30)`, 30 hücre canlı.

Doğrusu: kanca **yükleme öncesi** kurulmalı
(`Page.addScriptToEvaluateOnNewDocument`). Araç: `tools/gezinti_olc.py`.

**Düzeltilen gerçek kusurlar:**

| Kusur | Ölçüm |
|---|---|
| Sayfa geçişinde websocket kurulup kapanıyordu | 8 turda **16 → 2** soket; `BOSALTMA_GECIKME_MS = 20000` ile boşalan abonelik hemen kapatılmaz |
| Bağlantı rozeti yalan söylüyordu | İki soket yöneticisi aynı `#wsDurum`'a yazıyordu; işlem sayfasınınki "kapali" yazıp anasayfanınkini eziyordu. Veri akarken (5000+ tick) rozet "kapali" görünüyordu. Artık yalnızca **aktif sayfanın** soketi yazar ve sayfaya girince rozet tazelenir |
| Zoom 30 saniyede bir sıfırlanıyordu | Periyodik mum yenilemesi `fitRecentCandles` çağırıyordu: "TUMU"dan 30 sn sonra görünüm kendiliğinden varsayılana dönüyordu (mum katmanı 1673 → 230 düğüm). Artık yalnızca **coin değişince** sığdırılır |

**Gezinti yük testi sonucu** (8 tur × 10 sayfa, 700 ms bekleme):

| Ölçüt | Sonuç |
|---|---|
| Yaşayan `setInterval` | 3 — sabit |
| Net dinleyici | 125 — 1. turdan sonra sabit |
| DOM düğümü | ~15 900 — sabit |
| Websocket | 2 kuruldu, 2 açıldı, tick akışı sürekli |
| En uzun görev | 157 ms |
| Toplam bloklama | 1.5 sn / 90 sn (%1.7) |

En ağır durumda da (2016 mum + 7 gösterge = **3511 SVG düğümü**) uzun görev
sayısı artmadı.

**Dürüst sonuç:** bu düzeltmelerden sonra kendi ölçüm ortamımda donmayı
**yeniden üretemedim**. Bulduğum gerçek kusurlar düzeltildi. Donma tekrarlarsa
kanıt toplansın diye kalıcı bir kaydedici eklendi: 250 ms'den uzun her kare
sayfa adı ve saatiyle birlikte tutulur, konsoldan okunur:

```js
__cn.donma()     // [{ms: 812, sayfa: "islem", saat: "17:42:10"}, ...]
__cn.durum()     // aktif sayfa + dönen işler
```

### Araçlar

| Araç | Ne ölçer |
|---|---|
| `tools/gezinti_olc.py` | Sayfa geçişlerinde sızıntı, soket, uzun görev |
| `tools/senaryo_olc.py` | Verilen JS senaryosunu yükleme-öncesi kancayla koşturur |
| `tools/profil.py` | Fonksiyon başına CPU (örnekleyici profil) |
| `tools/ws_olc.py` | Websocket bağlantı sayısı ve tick akışı |
| `tools/cdp_denetim.py` | Konsol/ağ hatası + ekran görüntüsü |

## 7.10 Trade ekranı — grafik geometrisi, başlık ve dijital yazı tipi

### Son mum görünmüyordu — ölçülen sebep

`scrollToEnd` kaydırma tavanını `toplam*gen − kapGenislik` olarak
hesaplıyordu; fiyat ekseninin kapladığı **52 pikseli hesaba katmıyordu**.
Sona kaydırıldığında son mumun merkezi `W − gen/2`'ye düşüyor ve eksenin
altında kalıyordu.

Düzeltme: ölçü artık **tek yerde** (`zoom.SAG_EKSEN_PX`) ve tavan
kullanılabilir genişliğe göre hesaplanıyor. Üstüne `BOSLUK_MUM = 3` kadar
nefes payı ekleniyor. `gestures.js` de aynı `maxScrollX`'i kullanır —
önceden orada ayrı bir formül vardı.

**Ölçüldü** (888 px kap): ayırıcı 836 px = 888 − 52; son mum 811.6 px;
boşluk **24.4 px ≈ 3.4 mum**.

### Açık mum, ayırıcı ve ortalanmış fiyat etiketi

| İstek | Çözüm |
|---|---|
| "son mumun içini boş yap" | Son muma `mumAcik` sınıfı; gövde saydam, kenar renkli |
| "fiyat ile mumlar arasına çizgi" | `eksenAyirici` — `W − sagKenar` noktasında dikey çizgi |
| "switch'i açınca fiyat ortada dursun" | Etiket `x=(W−sag)/2`, `text-anchor:middle`. Ölçüldü: x=418 |

### LIMIT çizgisi hiç çizilmiyordu

`refreshLimitSlider` gövdesinde **kullanmadığı** bir değere (`getChartScale`)
bakıp "ölçek yoksa dön" diye erken çıkıyordu. Mum verisi yüklendiğinde
grafik henüz çizilmemiş olduğu için ölçek `null` dönüyor, fonksiyon hiçbir
şey yapmadan çıkıyor ve `_fiyat` ilk 30 saniye boyunca `null` kalıyordu —
kullanıcı LIMIT anahtarını açsa bile **çizgi görünmüyordu**.

Ölçüm: anahtar açık, kaydırıcı görünür, üst katman **boş (0 öğe)**.
Gereksiz bağımlılık kaldırıldı; ayrıca anahtar açılırken fiyat hâlâ yoksa
kaydırıcı değerinden başlatılıyor. Etiket artık `formatPrice`'tan geçiyor
(ham sayı tüm ondalıklarıyla yazılıyordu).

### Fiyat ekseni küsuratı

Eksen kendi sabit ondalık kurallarını kullanıyordu (`0.041745`). Artık
`formatPrice(v, 4)` — arayüzün geri kalanıyla aynı biçimleyici:
`0.05169 · 0.04944 · 0.0472 · 0.04495 · 0.0427`.

### Başlık hiyerarşisi ve kutucuklar

İsmail: *"coin adından büyük olmasın, seçiciliği arttırmak adına hizalama ve
konuma dikkat et … hatta onları küçük kutucukların içine al."*

```
coin adı (18px, neon)  >  fiyat (17px)  >  yüzde kutuları (11px)
```

Önceden fiyat **19px** ile coin adından (17px) büyüktü. Öğe boyları karışık
olduğu için hizalama `baseline` yerine `center` — kutucuklar fiyatın
ortasına oturur, satır zikzak yapmaz.

`24s` ve `gun` artık kenarı değerin işaretine göre renklenen kutucuklarda.

**Elde pozisyon varken K/Z:** kontrol edildi, çalışıyor; sağ köşede ayrı
kutuda. Fakat `.trKutu{display:inline-flex}` tarayıcının varsayılan
`[hidden]{display:none}` kuralını **eziyordu** — pozisyon yokken kutu
"K/Z ·" olarak görünüyordu (ekran görüntüsünde yakalandı, `.trKutu[hidden]`
ile geri alındı). Ölçüldü: pozisyon yokken `kzGizli: true`.

### Dijital yazı tipi

*"android ve pc de çalışan bi şey olsun."*

**Share Tech Mono** (SIL Open Font License, 13.5 KB latin alt kümesi) —
`fonts/ShareTechMono-400-latin.woff2` olarak **kendi sunucumuzda**
barındırılır; dış CDN yok, çevrimdışı da çalışır, Android ve masaüstünde
aynı görünür. Sabit genişlikli olduğu için sayı sütunları hizalı kalır.

`applyFont` artık yedek zincir de yazıyor (`ui-monospace, "Roboto Mono",
"DejaVu Sans Mono", monospace`) — woff2 yüklenemezse arayüz biçimsiz
kalmaz. Yazı tipi düğmesi de seçili olanı gösteriyor; `index.html`'de
"INTER" sabit yazılıydı ve hiç güncellenmiyordu.

| Seçenek | Düğmede |
|---|---|
| Inter · IBM Plex Sans · Roboto · Liberation Sans | INTER · PLEX · ROBOTO · LIBER |
| **Share Tech Mono** | **DIJITAL** |

### Temizlik

Yama yedekleri (`*.oncesi_*`, 18 dosya) statik ağaçtan `_yedek/` altına
taşındı — servis edilen dizinde yalnızca gerçek varlıklar kalsın
(59 dosya).

## 7.11 Bot modu, panel modu ve kapsam denetimi

### İki mod BAĞIMSIZDIR — ölçüldü

İsmail: *"bottaki canlı ve dry run ile ayarlardaki canlı ve dryrun ayrı
işlemler biliyorsun değil mi"* ve *"ben ayarlardan canlıyı açtığımda botta
canlıya geçti, bu olmamalı asla; ben açar isem bot canlıya geçmeli."*

Kod zaten ayrıydı (`trade_loop` yalnız `bot_canli`, elle emirler yalnız
`canli` okur). Ölçüldü:

| Adım | ayar.canli | bot_canli |
|---|---|---|
| başlangıç | False | False |
| botu canlıya al | False | **True** |
| **ayarlardan canlıyı aç** | True | **True (değişmedi)** |
| ayarlardan dry run'a dön | False | **False (çekildi)** |

Kullanıcının gördüğü, üst bardaki rozetin yeşile dönmesiydi; o rozet
**yalnızca panelin** modunu gösteriyordu. Eksik olan görünürlüktü.

**Tek bağlantı** şu yönde: panel dry run'a dönerse bot da kâğıda çekilir —
panel kâğıt derken botun gerçek para harcaması kabul edilemez. Yanıt
`bot_kagida_alindi: true` ile bunu bildirir. Ters yön **yoktur**.

> **Açık (26.09.2026):** kod bunu her yolda garanti ETMİYOR —
> `POST /yerel/bot {bot_canli:true}` yalnız anahtara bakar, `canli`'ya bakmaz;
> anahtar silinince `canli` false yapılır ama `bot_canli` çekilmez.

### Üst bardaki "B" rozeti

Panel rozetinin yanında ikinci gösterge: bot kâğıt modda **solgun gri**,
gerçek parada **yeşil**. Tıklanmaz; bot modu BOT sayfasından değişir.

### Açık pozisyonlar artık HER KOŞULDA yönetiliyor

İsmail: *"takip her durumda devam edecek, hangisi ile alındı ise onun
ayarına göre satışını yapacak."*

**Bulunan kusur:** `run_bot_cycle` yönetimi de `live = bot_canli` ile
**tek deftere** uyguluyordu. Bot canlıyken pozisyon açılıp sonra kâğıda
alınırsa, açık **gerçek** pozisyon bot döngüsünün dışında kalıyor;
stop/hedef kararları hiç uygulanmıyordu. `watcher` iki defteri de besliyor
ama karar vermiyor (B3 düzeltmesi), dolayısıyla pozisyon korumasız kalıyordu.

Artık **giriş** botun o anki moduna, **yönetim** her iki deftere uygulanır;
her pozisyon kendi defterinin kurallarıyla kapanır. Ölçüldü: bot turu
6 tur, 0 hata.

### Strateji sayfasında botun parası

Bot giriş tutarını **stratejiden** alır
(`try_strategy_entry`: `st.tutar` varsa o, yoksa genel `ayar.tutar`).
Sayfada bu bilgiye dair hiçbir şey yoktu. Eklendi:

| Satır | Örnek |
|---|---|
| bot cüzdanı | 30.00 USDT (kâğıt) — bot canlıysa gerçek bakiye |
| işlem tutarı | 9.00 USDT (`tutar_yuzde` doluysa yüzdeden hesaplanır) — **YALNIZ EKRANDA**, bot bunu okumuyor, bkz. §99 |
| bağlanabilir | 27.00 USDT (3 pozisyon) |

### Mini grafikte muma tıklama

*"20 mum gösteren 4 grafikte bir muma tıkladığımda o mumun değişim
yüzdesini görmek istiyorum."* Kutular sabit genişlikte çizildiği için mum
sırası doğrudan yatay konumdan bulunur; ölçek `getChartScale`'den okunur —
çizimle aynı kaynak, ikinci bir hesap yok. Ölçüldü: `#7 0.05073 -0.55%`,
ipucunda OHLC ve gövde/menzil oranı.

### Başlık artık oynamıyor

*"fiyat oynadıkça 24 saat göstergesi ve yanındaki butonlar sağa sola
oynuyor."* Fiyat alanına sabit genişlik (`10ch`), kutu değerlerine `6ch`
verildi. Ölçüldü: beş farklı fiyat dizgisinde kutunun sol kenarı
**549 px'de sabit**.

K/Z kutusu istendiği gibi **gri ve solgun**; işaret bilgisi yalnızca
değerin renginde taşınır (ölçüldü: kenar `rgb(16,48,60)`, değer yeşil).

### Bot sayfası düzeni

- Çalışan işler artık **sabit sütunlu, sönük bir tabloda**. Önceden satır
  içi rozetlerdi; iş adları farklı uzunlukta olduğu için sayılar hiçbir
  yerde alt alta gelmiyordu.
- **Bulunan sessiz hata:** kod `aktif` sınıfı yazıyordu ama CSS
  `.modBtn.se` bekliyordu — seçili mod **hiçbir zaman** işaretlenmiyordu.
  Sınıf eşlendi, seçili düğmeye "● AKTIF" yazısı eklendi.
- Mod geçişi **iki yönde de** onay ister; önceden yalnızca canlıya geçiş
  soruyordu.

### İşlem geçmişi kartı

*"yazılar çok düzensiz gibi duruyor."* Haklıydı: satırlar `flex-wrap` ile
akıyordu, hiçbir şey hizalanmıyordu. Artık **sabit sütunlu ızgara**:
1. sütun etiket (GIRIS/CIKIS/PLAN), 2-5. sütunlar değer; aynı sütun her
satırda aynı anlamı taşır ve kartlar arasında da alt alta gelir.

> Ara hata: ilk denemede **6 sütun** tanımlayıp satır başına **5 hücre**
> yazdım. CSS ızgarası hücreleri sırayla yerleştirdiği için 5. hücreden
> sonra 6. sütuna geçiyor ve tüm satırlar kayıyordu. Sütun sayısı hücre
> sayısına eşitlendi.

> İkinci ara hata: `30-tablo.css` tüm `td`leri sağa yaslıyor (coin tablosu
> için) ve bu kural bot iş tablosuna da sızıyordu; ad sütunu açıkça sola
> alındı.

### Kapsam denetimi — `tools/kapsam_denetim.py`

İsmail: *"dokümantasyona ve fonksiyonlara eklemediğin fonksiyon ya da
çakışan fonksiyon var mı kontrol et."*

| Denetim | Sonuç |
|---|---|
| Çakışan ad | **0** — 498 adın hepsi tek yerde tanımlı |
| Listede olup kodda yok | **0** |
| Kodda olup listede yok | **0** |
| Listede bölümü olmayan modül | **0** (2 tanesi bu turda bulundu) |
| Belgede geçmeyen paket | **0** |

**Bulunan iki gerçek boşluk:**

1. `register_all_routes` listede **yanlış modülde** (`router.py`) yazılıydı;
   gerçekte `routes.py`'de. Düzeltildi.
2. `giris.js` listede **hiç yoktu**: üreteç yalnızca `export`'lara bakıyor,
   giriş noktası modülü hiçbir şey dışa açmıyor. Hem `gen_js_listesi.py`
   hem `check_unique_names.py` artık export'u olmayan modüllerde üst düzey
   `function` bildirimlerini sayıyor — **aynı kural, iki araçta**.

**Ölü kod adayları** (bilgi olarak; silinmedi):

| Taraf | Hiçbir yerden çağrılmayan |
|---|---:|
| JS export | 14 |
| Python fonksiyon | 28 |

> **05.10.2026:** bu liste §7.44'te temizlendi (çağrılmayan 42+3 fonksiyon silindi, tarama artık 0).

Bunların bir kısmı bilinçli API yüzeyi (`stop_all_jobs`, `describe_setting`),
ama ikisi dikkat çekici: `daily_archive.append_daily_snapshot` ve
`ticks.flush_ticks_to_disk` çağrılmıyor — yani günlük arşiv ve tick yazımı
fiilen **kapalı**. Planın B14 maddesi "ya canlandır ya kapat" diyordu;
şu an kapalı durumda ve bu bilinçli bir karar olarak kayda geçiyor.

## 7.12 "Son mum devasa, diğerleri nokta" — eskimiş yanıt yarışı

İsmail: *"sanırım trade ekranında mumlarda bi hata yaptın, aniden son mum
devasa diğerleri nokta gibi oluyor, gezinerek test et."*

### Ölçüm

`tools/senaryo_olc.py` ile gezinti + coin değiştirme senaryosu koşuldu;
her adımda grafiğin dikey ölçeği ve en uzun mum gövdesi örneklendi:

| Adım | En uzun gövde | Dikey aralık |
|---|---:|---|
| ilk açılış | 121 px | 0.0427 … 0.0517 |
| sayfa geçişleri (3 tur) | 121 px | değişmedi |
| **coin değişimi** | **633 px** | **0.0245 … 0.3729** |
| 30 sn'lik yenilemeden sonra | 153 px | 0.3434 … 0.4168 |

Coin değişiminden hemen sonra dikey aralık **15 katına** çıkıyor: bir mum
633 piksel, diğerleri noktaya iniyor. Sonraki yenilemede kendiliğinden
düzeldiği için belirti "aniden" görünüyordu.

### Sebep

30 saniyelik `islemMum` döngüsü **eski coin için bir istek yoldayken**
kullanıcı başka bir coine geçiyor. `anaMumlariYukle` yanıtın hâlâ geçerli
olup olmadığını **kontrol etmiyordu**: geç dönen yanıt `_mumlar`'ı ESKİ
coinin mumlarıyla dolduruyor, üzerine websocket'ten YENİ coinin fiyatı
binince son mumun tepe/dibi devasa açılıyor ve ölçek tüm grafiği eziyordu.

Eski sistemde bu kontrol **vardı** — yeniden yazarken düşmüş.
`sunucu.py` yorumu aynen şunu diyordu: *"canliMumlar o an YENI coine ait
olabilir – sembol eslesmezse…"*.

### Düzeltme

1. **Eskimiş yanıt koruması:** istek atılırken sembol saklanır, yanıt
   gelince `istenen !== _sembol` ise yanıt atılır. Aynı koruma
   `anaMumlariYukle`, `miniYukle` ve `izleriYukle` için de eklendi.
2. **Fiyat makuliyet kontrolü:** websocket'ten gelen fiyat son mumun
   açılışının yarısı ile iki katı arasında değilse tepe/dip açılmaz —
   yanlış coinin fiyatı mumu şişiremez.
3. **Coin değişince tuval boşaltılır:** `anaCiz` mum dizisi boşken erken
   dönüyor, dolayısıyla eski SVG ekranda kalıyordu; başlık yeni coini
   yazarken grafik hâlâ eskisini gösteriyordu (ölçüldü: başlık SENTUSDT,
   aralık başka coine ait). Artık yeni veri gelene kadar "YUKLENIYOR"
   görünür, yanlış coin hiç gösterilmez.

### Doğrulama

Aynı senaryo, üstüne 5 kez hızlı coin değiştirme eklenerek tekrarlandı
(bazı geçişler yanıt dönmeden yapıldı):

| Ölçüt | Sonuç |
|---|---|
| Bozuk ölçüm (dikey aralık > %60) | **0** |
| Dikey aralık | her örnekte %17–20 (sağlıklı) |
| Hızlı geçiş anında | "YUKLENIYOR" — yanlış coin gösterilmiyor |
| Oturduğunda | aralık sembolle uyumlu (SENTUSDT %17.3) |

## 7.13 Emir butonları hiç çalışmıyordu + tutar artık cüzdandan

### Butonlar: yedi ölü dinleyici

İsmail: *"ayarlardan canlıyı aktif ettim ama butonlar kapalı geldi."*

**Bulunan:** yedi işlem butonunun (`btnAl`, `btnAlTakip`, `btnAlSat1-3`,
`btnDryrunGiris`, `btnSat`) hepsi `index.html`'de `disabled` yazılıydı ve
JS'te onları **açan tek bir satır yoktu**. Yani butonlar yalnızca canlı
modda değil, **dry run'da da hiçbir zaman çalışmıyordu**; `mountTradePanel`
içindeki yedi tıklama dinleyicisi de ölüydü.

Panelin asıl işi emir göndermek; bu, yeniden yazımın en ciddi eksiğiydi.
Markup'ı "henüz coin seçilmedi" varsayımıyla `disabled` yazmışım, karşılığı
olan etkinleştirme mantığını hiç yazmamışım.

**Kural artık tek yerde** (`butonlariTazele`):

| Buton | Açılma koşulu |
|---|---|
| AL · AL TAKIP · ALSAT 1-3 | coin seçili **ve** tutar > 0 **ve** (kâğıt mod **veya** API anahtarı var) |
| DRYRUN GIRIS | coin seçili ve tutar > 0 (her zaman kâğıt) |
| SAT | o coinde **açık pozisyon** var |

Butonların altındaki not kapalı olma sebebini yazar ("once coin sec",
"yetersiz bakiye", "canli mod icin API anahtari gerekli"); her şey hazırsa
boştur ve yer kaplamaz. Mod veya anahtar değişince `subscribeState("ayar")`
ile **anında** tazelenir.

### İşlem tutarı cüzdandan hesaplanıyor

İsmail: *"işlem tutarı cüzdanımızda bulunan USDT'nin 1 dolar altını
bölmesi lazım."*

```
tutar = (serbest USDT − REZERV_USDT) × seçilen yüzde
REZERV_USDT = 1
```

Taban **gerçek bakiyedir**: önce Binance'deki serbest USDT, gerçek bakiye
yoksa kâğıt cüzdanın serbest bakiyesi (`islem.js serbestBakiye`, §7.14). Bakiye henüz bilinmiyorsa tutar
`null` döner, alış butonları kapalı kalır ve emir **gönderilmez** — gerçek
parada "bilmiyorsam denemem" daha güvenli.

**Önceki davranış:** sabit `ayar.tutar` (30 USDT) yüzdeyle çarpılıyordu;
cüzdanda 5 USDT olsa bile 30 USDT'lik emir deneniyor, borsa reddediyordu.

Ölçüldü:

| Mod | Serbest | Yüzde | Tutar | İpucu |
|---|---:|---:|---:|---|
| CANLI | 28.95 | %20 | **5.59 USDT** | serbest 28.95 − 1 rezerv = 27.95 bölünüyor |
| DRY RUN | 30.00 | %20 | **5.80 USDT** | serbest 30.00 − 1 rezerv = 29.00 bölünüyor |

Butonlar aynı ölçümde: AL/ALSAT/DRYRUN **açık**, SAT **kapalı** (o coinde
pozisyon yok) — beklenen davranış.

> **Dikkat:** Binance'in asgari emir tutarı çoğu çiftte ~5 USDT. Küçük
> yüzdelerde emir borsadan "tutar asgari altinda" hatasıyla dönebilir;
> `place_entry_order` bunu gönderim öncesi kontrol eder ve açık mesajla
> reddeder.

### Bakiye bu sayfada da çekiliyor

Tutar gerçek bakiyeden hesaplandığı için işlem ekranı `/yerel/bakiye` ucunu
20 saniyede bir çeker. Zamanlayıcı **sayfaya bağlıdır** (`sayfa: "islem"`):
başka sayfalardayken Binance hesap sorgusu atılmaz.

### `tutar` ayarının etiketi düzeltildi

Panel artık tutarı cüzdandan hesapladığı için `ayar.tutar` **yedek** rolde
kaldı: stratejide `tutar` yoksa bot onu kullanır, ayrıca tutar vermeden
gelen API istekleri için varsayılandır. Etiketi buna göre değiştirildi
("Yedek islem tutari — strateji/API tutar vermezse"). Eski etiket "Elle
islem tutari" yazarken panelde hiçbir etkisi olmaması, yeniden yazımın
ortadan kaldırmaya çalıştığı **ölü ayar** sınıfının (B6) ta kendisi olurdu.

## 7.14 Kaza: test sırasında gerçek emir + ortaya çıkan uzlaştırma hatası

### Ne oldu

23.09.2026 20:45:20'de, canlı mod açıkken panel üzerinde otomatik ölçüm
koşarken **gerçek para ile bir emir açıldı**: SAGAUSDT, AL TAKIP,
5.58714 USDT, LIMIT 0.0507.

| Adım | Sonuç |
|---|---|
| Emir dolumu | **0** — hiç dolmadı (`executedQty 0`) |
| İptal | 20:53, `orderId 2154174858` → `CANCELED` |
| Bakiye | 28.9505 USDT — kilitlenmeden önceki değerin aynısı |
| **Para kaybı** | **yok** |

Emri hangi ölçüm betiğinin tetiklediği **kesin olarak saptanamadı**.
Betiklerin hiçbiri alış butonuna tıklamıyor; emir gönderen tek yol
`btnAl*` tıklama dinleyicileridir. Tahminle doldurulmadı.

**Alınan önlem (süreç):** canlı mod açıkken panel üzerinde otomatik
ölçüm koşturulmayacak. Arayüz testleri `canli=false` ile yapılır; canlı
moda özgü görünüm (buton durumu, tutar) gerekiyorsa ölçüm yalnızca DOM
okur ve olay göndermez.

### Kazanın ortaya çıkardığı GERÇEK hata

Emir borsada beklerken, 60 saniyelik uzlaştırma turu onu defterden
**"ELLE_SATILDI" diye kapattı** ve **uydurma bir kâr/zarar yazdı**
(`kar_brut_p: 0.434`, `kar_p: -0.066`). Emir Binance'te durmaya devam
etti; defterde izi kalmadığı için panel onu artık **takip edemez** hale
geldi ve 5.59 USDT kilitli kaldı.

**Sebep:** `detect_manual_sells`, `list_open_orders`'ın döndüğü **her**
kaydı pozisyon sayıyordu — henüz dolmamış limit emirleri dahil. Dolmamış
bir alış emrinin karşılığı borsada henüz yoktur (`dolan_miktar = 0`),
dolayısıyla "borsada yok → elle satılmış" sonucuna varılıyordu.

**Bu kaza olmasa da kullanıcıyı vururdu:** 60 saniye içinde dolmayan her
limit emri defterden silinecek, uydurma bir sonuçla istatistiğe girecek ve
emir borsada sahipsiz kalacaktı.

**Düzeltme:** bekleyen emir pozisyon değildir. Uzlaştırmaya yalnızca
dolumu olan (`dolan_miktar > 0` **ve** `durum ∈ {DOLDU, KISMI}`) kayıtlar
girer. Ayrıca kıyas miktarı nominal `miktar` yerine **gerçek dolum**
üzerinden yapılır (kısmi dolumda nominal miktar yanlış kıyas verir).
Bekleyen emirlerin takibi `sync_with_exchange`'in işidir.

**Gerileme testi:** `tools/uzlastirma_testi.py` — geçici dizinde üç kayıtlı
bir defter kurar (bekleyen emir / borsada duran pozisyon / gerçekten
satılmış pozisyon) ve yalnızca sonuncusunun uzlaştırmaya girmesini
doğrular. Gerçek deftere dokunmaz.

**Temizlik:** hiç dolmamışken "ELLE_SATILDI" diye kapatılmış kayıt
defterden çıkarıldı (175 → 174); istatistik 161 işleme döndü. Yedek:
`defter_canli.json.<ts>.yedek`.

### Aynı turda düzeltilen üç arayüz kusuru

| Belirti | Sebep | Durum |
|---|---|---|
| "butonlar aktif değil" | Ölçüldü: yeni kodda 3. saniyeden itibaren **açık** (yalnız SAT kapalı — pozisyon yoktu). Kullanıcının açık paneli eski sayfayı tutuyordu | panel4 bölmesi sürüm damgalı adrese çevrilip yeniden yüklemeye zorlandı |
| "kaydırma çubuğu yok" | CSS `.limitKaydirici.acik` bekliyordu, JS `hidden` niteliğini değiştiriyordu — çubuk **hiç** görünmüyordu | Sınıf eşlendi. Ölçüldü: LIMIT açıkken 16×748 px |
| "çizgi son mumu takip etmiyor" | `_elle` bayrağı vardı ama **hiçbir yerde okunmuyordu**; çizgi kurulduğu fiyatta çakılı kalıyordu | `followPrice` eklendi: kullanıcı sürüklemediği sürece çizgi anlık fiyatı izler, sürükleyince takip durur |

`.limitKaydirici` olayı, bot modundaki `aktif`/`se` karışıklığıyla **aynı
sınıftan** üçüncü hata: CSS bir sınıf bekliyor, JS başka bir şey yazıyor.
`tools/css_denetim.py` yalnızca "JS'in ürettiği sınıfın CSS'i var mı"
diye bakıyor; tersini (CSS'in beklediği sınıfı JS yazıyor mu) görmüyor.

### İşlem tutarının tabanı: her zaman GERÇEK bakiye

İsmail: *"28.95 USDT var ama üstteki işlem miktarı 29 dolar diyor."*

İlk uygulamada taban aktif moda göre seçiliyordu: dry run'da **kâğıt**
cüzdanın serbest bakiyesi (30 USDT) → 30 − 1 = **29**. Oysa ekranda
kullanıcının gördüğü rakam gerçek bakiyesi (28.95).

Cüzdan sayfası zaten her iki modda da gerçek parayı gösteriyor (§7.9);
emir tutarı da aynı rakamdan türetilmeli ki **görülen ile hesaplanan aynı
olsun**. Gerçek bakiye okunamazsa (anahtar yok / Binance'e ulaşılamadı)
kâğıt cüzdana düşülür.

Ölçüldü (DRY RUN modunda, gerçek serbest 28.95):

| Yüzde | Tutar |
|---:|---:|
| %100 | 27.95 USDT |
| %80 | 22.36 USDT |
| %50 | 13.98 USDT |
| %20 | 5.59 USDT |

**Not:** kâğıt modda sunucu tarafındaki bakiye kontrolü yine kâğıt cüzdana
bakar (`get_free_quote_balance(live=False)`); gerçek bakiye kâğıt ana
paradan büyükse emir oradan reddedilir ve sebebi açıkça bildirilir.

### Çalışma modu dosyada tutulur

`canli` ve `bot_canli` `ayar.json`'a yazılır ve yeniden başlatmayı aşar;
`SETTING_SCHEMA` üzerinden doğrulanır. 23.09.2026'da modun kapalı
bulunmasının sebebi ayarın kaybolması değil, **kazayla açılan gerçek emrin
ardından güvenlik için canlı modun kapatılmasıydı** (bkz. §7.14).

## 7.16 Cüzdan kullanılabilir hale geldi + dolum takibi hatası

### AL doldu ama takibe geçmiyordu — sebep

İsmail: *"AL dedim, aldı gözüküyor; aldı madem takibe alması lazım,
takibe almıyor."*

`main.py/_borsa_senkron` içinde `live = bool(a.get("bot_canli"))` yazıyordu:
senkron **yalnızca botun o anki moduna ait defteri** tarıyordu. Bot kâğıt
modda olduğu için kullanıcının **elle açtığı CANLI emir hiçbir zaman
kontrol edilmiyordu**.

Ölçüldü: Binance'de açık emir **0**, hesapta **536.7 SAGA** duruyordu;
defter ise hâlâ `durum: ACIK`, `dolan_miktar: 0`, `borsa_durum: NEW`
diyordu.

`run_bot_cycle` aynı hatayı taşıyordu ve §7.11'de düzeltilmişti; bu iş
atlanmış. Emir durumu takibi **botun modundan bağımsızdır**: hangi
defterde açık emir varsa o kontrol edilir. Düzeltmeden sonra kayıt anında
`DOLDU / FILLED` oldu ve takip listesine geçti.

> Yan etki: canlı defter artık gerçekten taranıyor, dolayısıyla
> `emir_asim_dk` (6 dk) zaman aşımı da işliyor — bu sürede dolmayan
> bekleyen emirler otomatik iptal edilir.

### Strateji/bot ile cüzdan/canlı AYRI

İsmail: *"strategy bot — cüzdan canlı, bunlar farklı şeyler."*

| Sayfa | Ne gösterir |
|---|---|
| **CÜZDAN** | Gerçek para, **ELLE** açılanlar (AL / AL TAKIP / ALSAT) |
| **BOT** | Botun açtıkları — hangi modda çalışıyorsa |

Cüzdan hem pozisyonlarda hem geçmişte `el_kaynak` süzgeci kullanır.
Ölçüldü: geçmişte 55 elle işlem, **bot sızıntısı 0**.

### Satır eylemleri

Önceden satırın **herhangi** bir yerine tıklamak yöntem seçicisini
açıyordu; coine gitmenin ya da emri iptal etmenin yolu **yoktu**.

| Öğe | Davranış |
|---|---|
| Sembol (neon) | O coinin **işlem ekranını** açar |
| YONTEM | Çıkış yöntemini değiştirir |
| KAPAT | Takipteki pozisyonu piyasadan kapatır (onaylı) |
| IPTAL | Bekleyen emri borsadan iptal eder (onaylı) |

`/yerel/emir/iptal` ucu **zaten vardı** ama arayüzde hiçbir yerden
çağrılmıyordu (İsmail: *"vazgeçtim diyelim nasıl kapatacağım"*).

### Açık emirde K/Z gösterilmez

İsmail: *"açık emir -1.4 yazdı, madem öyle alış fiyatını aşağı çek o
zaman."* Haklı: emir **dolmadığı** için kâr/zarar diye bir şey yok; o
rakam limit fiyatı ile piyasayı kıyaslıyordu. Bekleyen emirlerde artık
**FARK** sütunu var: piyasa limitin üstündeyse kırmızı ("emir bekliyor"),
altındaysa yeşil ("dolmak üzere"). Sütun başlıkları da bekleyen/dolmuş
durumuna göre değişir.

### Websocket ile canlı takip

İsmail: *"cüzdanda açık emirleri websocket ile takip edecektik."*
Cüzdan sayfası kendi soket yöneticisini kurar; elle açılmış canlı
kayıtların sembollerine abone olur ve **yalnızca SIMDI / K/Z hücrelerini**
tazeler — tabloyu yeniden çizmez (tıklamayı bozmamak ve maliyet için).
Sayfadan çıkınca abonelik bırakılır.

Ölçüldü: `0.0508 → 0.05076`, K/Z `-2.44% → -2.52%` — canlı akıyor.

### Alım tostu

İsmail: *"aldığımızda tost geliyor değil mi?"* Evet. `emirGonder`
başarıda `showToastDetail` ile "AL GONDERILDI · SEMBOL · tutar USDT"
gösterir (canlı modda `alis` sınıfıyla). Ölçüldü: toast öğesi
`class="toast alis"` ile görünüyor. Hata durumunda da `api.js` her
başarısız isteği toast ile bildirir.

## 7.17 "Takılıyor" — ölçüm, çizim yolu ve canlı başlık

### Ölçüm: takılma yeniden üretilemedi

İsmail: *"niye takılıyor ya, eski sistemde takılmıyordu, fişek gibiydi."*

Kare süreleri iki ortamda da ölçüldü (25 saniye, `tools/senaryo_olc.py`):

| Ortam | Ortalama | %95 | En kötü | **Takılan kare** |
|---|---:|---:|---:|---:|
| Uygulama tek başına (`/cn/#islem`) | 16.7 ms | 16.9 ms | 25.4 ms | **0** |
| **panel4 içinde, 4 bölme birden** | 16.7 ms | 16.9 ms | 26.0 ms | **0** |

İkisi de kilitli 60 fps. CPU profili de aynı yönde: %96.9 boş.
**Bu ortamda takılma yeniden üretilemedi**; fark İsmail'in kendi
tarayıcısında (gerçek GPU, eklentiler, Tailscale gecikmesi, CDP tarayıcı
bölmesinin gerçekten yayın yapması) olmalı.

### Yine de gerçek bir israf vardı: her tikte TÜM SVG

Websocket tiki geldiğinde `renderCandleChart` çağrılıyordu; o da ızgarayı,
mumları, gösterge çizgilerini ve alt panelleri **baştan** kuruyordu
(~350 SVG düğümü). Saniyede ~20 tik gelince saniyede 60'a kadar tam
yeniden çizim oluyordu. JS ucuz ama tarayıcı her karede tüm SVG için
stil + yerleşim + boyama yapmak zorunda.

Tik geldiğinde **değişen tek şey son mumun kapanışı** (ve tepe/dibi).
`updateLastCandle` yalnızca o mumun iki öğesini oynatır; fiyat ölçeğin
dışına taşarsa tam çizime düşülür.

Ayrıca `canliBarCiz` her karede `getBoundingClientRect()` çağırıyordu —
`alignStickyHeader` vakasındaki (§7.8) aynı zorunlu yerleşim maliyeti.
Yükseklik artık yalnızca değiştiğinde yazılıyor.

**Ölçüldü** (`__cn.cizim()`, 30 saniye):

| | Önce | Sonra |
|---|---:|---:|
| Tam çizim | her tik (~20/sn) | **4** |
| Hafif güncelleme | — | **17** |
| Ölçek taşması | — | 0 |

> **Ajax kütüphanesi bunu çözmez.** Takılma HTTP katmanından gelmiyordu;
> veri zaten websocket'ten akıyor ve fetch'ler 10-30 saniyede bir. Sorun
> gelen veriyle ekranın nasıl çizildiğiydi — "sadece veri değişsin"
> yaklaşımının kodda karşılığı tam olarak yukarıdaki hafif yoldur.

### Sayaçlar kalıcı

"Takılıyor" şikâyeti bundan sonra ölçülebilir:

```js
__cn.cizim()   // {tam: 4, hafif: 17, tasma: 0}
__cn.donma()   // 250 ms'den uzun kareler (sayfa + saat)
__cn.durum()   // aktif sayfa + dönen işler
```

`tam` sayısının yüksek olması grafiğin her tikte baştan kurulduğunu
gösterir.

### Üstteki 24s ve gün yüzdesi artık canlı

İsmail: *"o üstteki 24h'yi ve günü websockete bağlasana, zaten veri
geliyor, hareket etmiyor duruyor."*

Haklıydı: bu değerler `getState("satirlar")` içinden okunuyordu; o liste
**anasayfanın** zamanlayıcısıyla doluyor ve işlem ekranındayken hiç
yenilenmiyor — yani girdiğin andaki değerde **donuyordu**.

Artık elimizdeki 5m mumlardan ve websocket fiyatından hesaplanıyor:

| Alan | Tanım |
|---|---|
| gün | UTC gününün **ilk 5m mumunun açılışına** göre — toplayıcıyla aynı tanım |
| 24s | 288 mum (= 24 saat) geriye göre |

Mum yoksa özet satırındaki değere düşülür. Ölçüldü: 30 saniyede
`+37.3% → +37.0%` ve `+26.5% → +26.2%` — ikisi de hareket ediyor.

### YENILE düğmesi dönüyor

İsmail: *"yenileye bastığımda ekranda loading dönsün ya."*
`refreshNow` artık **söz (Promise)** döndürüyor; düğme işler **gerçekten**
bitene kadar döner — sahte bir süre kullanılmaz. En az 400 ms görünür
kalır, yoksa hızlı dönen turlarda göz fark etmiyor.

## 7.18 Websocket: bağlantıyı kesmeden abone ol / çık

İsmail: *"anasayfada 30 değil 10 tanesi websocket olsun bari, biraz
hızlanır belki; bir de websocketi kapatmadan ekle websocket'e."*

### Abonelik artık canlı bağlantı üzerinden

Önceki sürümde akış listesi **adreste** taşınıyordu
(`/stream?streams=a@aggTrade/b@aggTrade`), dolayısıyla kümedeki her
değişiklikte soket **kapatılıp yeniden açılıyordu**: el sıkışma boyunca
(~300-800 ms) fiyat akmıyor, Binance'e gereksiz bağlantı gidiyordu.

Binance birleşik akış zaten canlı bağlantı üzerinde abonelik
değişikliğini destekler. Artık soket `/stream` adresine **bir kez**
bağlanır; küme değişince yalnızca **fark** gönderilir:

```
{"method":"UNSUBSCRIBE","params":["xxx@aggTrade"],"id":N}
{"method":"SUBSCRIBE",  "params":["yyy@aggTrade"],"id":N+1}
```

Yönetici iki küme tutar: `semboller` (istenen) ve `abone` (telde geçerli).
Soket açıksa fark tel üzerinden uygulanır; gönderilemezse yeniden
bağlanmaya düşülür. Kontrol yanıtları (`{"result":null,"id":N}`) veri
sanılmasın diye ayıklanır.

**Ölçüldü** (anasayfada 22 saniye + işlem ekranına gidip dönüş):

| | Sonuç |
|---|---|
| Anasayfa soketi | **1** kuruldu, **0** kapandı |
| Tick akışı | kesintisiz (75 → 240 → 328) |
| Canlı hücre | **10** |
| Rozet | `canli (10)` |

### Anasayfada 10 sembol

`CANLI_SEMBOL_SAYISI = 30 → 10`. Her abonelik saniyede birkaç aggTrade
mesajı demek; 30 sembolde gelen tik sayısı ve her tik için yapılan hücre
güncellemesi üç katına çıkıyordu. Tablonun üst sıraları zaten en çok
bakılan yer.

### Telefon yatayda başlık tek satıra sığıyor

İsmail: *"24 saat ve gün sayılarını yüzde 15 küçült, ekrana sığsın,
yatayda telefon ekranına sığmıyor."*

Değer 11 → **9.4px**, etiket 8 → **6.8px** (tam %15), iç boşluk ve sabit
en de aynı oranda.

Bu tek başına yetmedi: ölçümde içerik **382px** + boşluklar **25px** =
407px, kap **408px** çıktı — yalnızca 1 piksel pay kaldığı için K/Z kutusu
alt satıra düşüyordu. Dar ekran (≤1100px) için bilgi kaybetmeden ~15px
açıldı: boşluk 5→4, ad 15→14px, fiyatın sabit eni 8ch→7ch, HARIC TUT
yalnızca simge, K/Z kutusu `margin-left:auto` yerine sabit boşluk.

**Ölçüldü:**

| Ekran | Başlık yüksekliği | Taşma | İki satır |
|---|---:|---|---|
| 780×360 (telefon yatay) | **17px** (önce 40px) | yok | **hayır** |
| 900×420 | 17px | yok | hayır |
| 1600×1000 | 18px | yok | hayır |

### Araçlar

`tools/senaryo_olc.py` ve `tools/cdp_denetim.py` artık pencere ölçüsü
alıyor (`780x360` gibi) — telefon yatay yerleşimi ölçülebilir.

## 7.19 Fiyat ekseni artık sütun kaplamıyor

İsmail: *"trade'de 5m'de sağda fiyatlar var ya, yukarı doğru kaldır,
orası ekranı küçültüyor."*

Fiyat etiketleri için sağda **52 piksellik bir sütun** ayrılıyordu ve
mumlar oraya hiç girmiyordu. Orta sütun telefon yatayda zaten dar
olduğundan bu ciddi bir kayıptı.

Etiketler artık ayrı sütunda değil, grafiğin **sağ kenarına bindirilmiş**
durumda — gerçek borsa grafiklerindeki gibi. `SAG_EKSEN_PX` 52 → **0**.
Okunabilirlik için her etiketin arkasına ince, yarı saydam bir zemin
konur (`.eksenZemin`, opaklık .88 + ince kenar); son mumun etiketlerin
altında kalmaması `BOSLUK_MUM` (3 mum) ile sağlanır.

Ayrılan sütun kalmadığı için "mumların bittiği yeri gösteren dikey
ayırıcı" da kaldırıldı — artık mumlar kenara kadar gidiyor, ayıracak bir
sınır yok.

**Ölçüldü:**

| | Önce | Sonra |
|---|---:|---:|
| Çizim alanı (1600px ekran) | 836 px | **888 px** |
| Ayrılan sağ sütun | 52 px | **0** |
| Son mumun kenara uzaklığı | — | 25.9 px (3 mumluk pay) |
| Etiket hizası | sola, sütun içinde | sağa yaslı, bindirmeli |

Kaydırma sınırları (`maxScrollX`, `scrollToEnd`, `fitAllCandles`) aynı
sabitten beslendiği için tek değişiklikle tutarlı kaldı — ölçü iki yerde
yazılmıyor (bkz. §7.10'daki son mum hatası).

## 7.20 "-57 zarar" ve pozisyon kartı düzeni

### Günlük yüzde yanlış hesaplanıyordu

İsmail: *"cüzdanda -57 zarar yazıyor, bu ne demek ya."*

`build_daily_pnl`, günün işlemlerinin `kar_p` değerlerini **topluyordu**.
Farklı büyüklükteki işlemlerin yüzdelerini toplamak matematiksel olarak
anlamsızdır: o günün beş işleminin (−0.62, −30.28, −38.69, −4.19, +16.08)
toplamı **−57.7** çıkıyordu. Aynı satırda USDT karı **0.0** yazıyordu —
iki rakam birbirini tutmuyordu ve bu tutarsızlık hatayı ele veriyordu.

Doğrusu **sermaye ağırlıklı** getiri:

```
gunluk_p = (günün toplam kârı USDT / günün bağlanan toplam USDT) × 100
```

Böylece büyük pozisyonun sonucu küçüğünkinden ağır basar ve sonuç
gerçekten "o gün paranın yüzde kaçı kazanıldı" olur.

Ayrıca bazı eski kayıtlarda `kar` (USDT) boş, yalnızca `kar_p` var; USDT
karşılığı `tutar × kar_p / 100` ile **türetiliyor** — aksi halde günün
USDT toplamı 0 görünüyordu.

### Cüzdan istatistiği de artık yalnızca ELLE işlemler

Aynı ayrım (§7.16) kâr/zarar tarafına da uygulandı: `/yerel/pnl` ve
`compute_ledger_stats` `sadece=el|bot` alıyor; cüzdan `el`, bot sayfası
`bot` kullanır.

**Ölçüldü:**

| | Önce | Sonra |
|---|---|---|
| Bugün | **−57.707%** | **0.00%** (bugün elle işlem yok) |
| 21.09 | −4.307% | −0.274% |
| 22.09 | +9.712% | +0.535% |
| İstatistik | 161 işlem (bot dahil) | **156 işlem**, isabet %69.23, toplam −5.468% |

### Pozisyon satırı → 3 satırlı kart

İsmail: *"takip edilende sayılar birbirine giriyor ya, olmaz böyle,
düzenli olmalı; 3 satır yap ama düzenli olsun, sol en başta sadece coinin
adı olsun, sonra diğer değerler olsun."*

Tablo biçimi bırakıldı — 10-11 sütun dar ekranda birbirine giriyordu.
Açık emir, takipteki pozisyon ve tamamlanan işlem artık **aynı** kart
düzenini kullanıyor:

| Satır | İçerik |
|---|---|
| 1 | **Coin adı yalnız başına solda**, sonra kaynak/mod etiketleri; sağda özet yüzde, süre ve YONTEM / KAPAT-IPTAL |
| 2 | Sabit sütunlu değer ızgarası: GIRIS (veya LIMIT) · saat · tutar · adet / SIMDI (veya PIYASA) · yüzde · stop · hedef |
| 3 | Anasayfadaki göstergeler (sıra, iz, ATR, RSI, CCI, KDJ-J, xH, OBV…) |

Sütunlar sabit genişlikte olduğu için değerler hem kart içinde hem
**kartlar arasında** alt alta gelir.

> Araç notu: `class="..."` niteliğinin içinde `oran == null` gibi bir ifade
> bırakınca `css_denetim.py` "null" adında bir sınıf üretildiğini sanıyordu
> (yanlış pozitif). Sınıf adları artık şablon dışında hesaplanıyor.

## 7.21 "BOTU CALISTIR"a bastım hiçbir şey gelmedi — iki ayrı sebep

### 1) Düğme ölüydü

İsmail: *"botu çalıştır dedim hiç bi şey gelmedi."*

`btnBotAc` ("BOTU CALISTIR") **STRATEJILER** sayfasında duruyor, ama
tıklama olayı **`botPage.js`'in `mountBotPage`** fonksiyonunda
bağlanıyordu — o da yalnızca **BOT** sayfasına girildiğinde çalışır.

Yani: stratejiler sayfasından basıldığında **hiçbir şey olmuyordu**.
Düğmenin yazısını (`BOTU CALISTIR` / `BOTU DURDUR`) `strategies.js`
güncelliyordu; işaretleme burada, olay orada olunca kimse fark etmemiş.

Bu, panelin işlem butonlarının `disabled` kalmasıyla (§7.13) **aynı
sınıf** hata: işaretleme bir yerde, davranış başka yerde.

**Yeni araç: `tools/id_denetim.py`** — HTML'deki her `id` için "hangi
sayfada duruyor / hangi modül işliyor" karşılaştırması yapar ve
"başka sayfanın modülünde işlenen id" listesi çıkarır. 246 id tarandı.

### 2) Sunucu yeniden başlayınca bot kapanıyor

`build_application` her açılışta güvenlik gereği `bot_acik = False`
yapıyor (bilinçli bir karar). Bu oturumda servis birkaç kez yeniden
başlatıldı; kullanıcı botu açmış olsa bile **restart sessizce
kapatıyordu**. Davranış doğru ama görünür değildi — açılış logunda
yazıyor, panelde bir iz yok.

### Bot aslında çalışıyor — ölçüldü

Açıldığı anda 3 saniye içinde 3 kâğıt pozisyon açtı
(SAGAUSDT, PORTALUSDT, TFUELUSDT; ~9 USDT). Sonraki turda `son_sebep`
doğru şekilde "maks pozisyon (3) dolu" oldu.

### Bot başlatma artık modu söyleyip onay istiyor

İsmail: *"emin misiniz dry run'da çalışacak, ya da emin misiniz canlıda
çalışacak desin."*

Uçtan uca ölçüldü (BOT sayfasına **hiç uğramadan**, stratejiler
sayfasından):

| Ölçüm | Sonuç |
|---|---|
| Onay başlığı | **BOT DRY RUN'DA CALISACAK** |
| Onay metni | "Emin misiniz? Bot KAGIT cüzdanla çalışacak, gerçek emir göndermeyecek. Strateji: HA Cok Zamanli N3" |
| Onay düğmesi | DRY RUN BASLAT |
| Onaydan sonra | `bot_acik=true`, 3 pozisyon |
| Düğme yazısı | BOTU DURDUR |

Canlı modda başlık ve metin "GERCEK PARA" uyarısına döner. Botu
**durdururken** de onay istenir ve açık pozisyonların kapanmayacağı,
stop/hedef takibinin süreceği açıkça yazılır.

### "100 dolar tanımlıyorum ama 30 yazıyor"

`#stAnaPara` kutusu yalnızca **okunuyordu** (`s?.ana_para`) — strateji
kaydında böyle bir alan **yok**, dolayısıyla kutu hep boş geliyordu; ve
`collectStrategyForm` onu hiç **toplamıyordu**, yani yazdığın değer
hiçbir yere gitmiyordu. Yardım metni "ayarlardaki aynı değerdir" diyordu
ama bağlı değildi.

Artık kutu `ayar.kagit_bakiye`'den dolar ve KAYDET'e basınca oraya yazar.

**Ölçüldü:** kutu 30 → 100 · `ayar.kagit_bakiye` = 100 · bot cüzdanı
`100.00 USDT (kagit)`, serbest 73.23 (3 pozisyonda 26.77).

### Mini grafiklerde yazılar mumları kapatıyordu

Bilgi kutusu 9.5 → **8px**, sol sütunda 7.5px ve sönükleştirildi;
başlıklar ("5M · 20 MUM") 8 → **7px**; konum sola/yukarı çekildi.

### Uç tarama: `symbol` / `sembol` tutarsızlığı

`/yerel/mum` `symbol`, `/yerel/tickler` `sembol` bekliyordu — aynı panelde
iki farklı ad. `handle_tick_archive` artık ikisini de kabul ediyor.
**20 ucun 20'si 200 döndü.**

### Tam sistem taraması

| Denetim | Sonuç |
|---|---|
| Python derleme | OK |
| JS sözdizimi (31 modül) | 0 hata |
| CSS karşılığı olmayan sınıf | 0 |
| Ad sözleşmesi (liste ↔ kod) | 0 / 0 |
| Modül ve paket kapsamı | 0 boşluk |
| Uzlaştırma gerileme testi | GEÇTİ |
| Arka plan işleri | 3/3 çalışıyor, 0 hata |
| Websocket | `canli`, 4 sembol, bayat değil |
| HTTP uçları | **20/20 = 200** |
| Sayfalar (10) | konsol 1 (kasıtlı uyarı), ağ 0 |

## 7.22 Üçüncü tema: cyberpunk HUD

**25.09.2026 — İsmail:** "bana 3. temayı oluştur cyberpunk hud tema
olarak" + "mavimsi olsun ama çok parlamasın".

### Tema CSS'te vardı ama SEÇİLEMİYORDU

`00-temel.css` içinde `html[data-tema="hud"]` bloğu **zaten yazılmıştı**
(koyu lacivert zemin, camgöbeği neon, kesik köşeler) — ayrıca `metalik` ve
`skeuo` blokları da. Ama `theme.js` → `TEMALAR = ["koyu", "acik"]` iki ad
saydığı için `applyTheme("hud")` sessizce `koyu`'ya düşüyordu; üst bardaki
`#btnTema` da `index.html`'de **"SIYAH" sabit** yazılmış, hiç
güncellenmiyordu.

| Değişiklik | Dosya |
|---|---|
| `TEMALAR = ["koyu", "acik", "hud"]` + `TEMA_KISA` | `js/ui/theme.js` |
| `#btnTema` etiketi artık o anki temayı yazar (`temaDugmesiniYaz`) | `js/ui/shell.js` |
| Parlama/renk ayarı | `css/00-temel.css` |

`metalik` ve `skeuo` blokları **bilinçli olarak** seçilebilir yapılmadı —
istemek ayrı bir iş.

### "Çok parlamasın" — ölçülen değerler

Parlaklık azaltılırken tema **mavimsi kimliğini korudu**; yalnızca ışık
miktarı düştü:

| Ne | Önce | Sonra |
|---|---|---|
| `--cerceve-parlama` | `0 0 15px rgba(47,214,255,.5)` | `0 0 8px rgba(47,214,255,.20)` |
| `#cerceve` dış parlama | `0 0 20px … .4` | `0 0 9px … .18` |
| `#ustbar` / `#altbar` gölge | `0 2px 15px … .30` | `0 1px 7px … .12` |
| `text-shadow` (marka/th/düğme/artı-eksi) | `.40 – .60` | `.14 – .22` |
| tarama çizgisi (`#cerceve::before`) | `opacity .40`, 4 sn | `opacity .10`, 7 sn |
| `.modal` / scrollbar / `.nokta` | `0 0 30px … .30/.50` | `0 0 14px … .15/.18` |

Zemin `#071322`, paneller `#0d2135`, neon `#2fd6ff` **değişmedi**.

### Renk kararları (kullanıcı seçimi)

- **Kâr camgöbeği** `#2fd6ff` — tüm tablo/mum/rozet `--arti` üzerinden.
- **Zarar koyu kırmızı-sarı** `#d4551f` (`--hud-sari`) — tek değişken,
  istediğinde oynanır.
- **Basılı/aktif düğme:** eskiden `--hud-sari` ile **kırmızıya** dönüyordu
  (hem şaşırtıcı hem zarar rengiyle karışıyordu). Artık diğer temalarla
  aynı konvansiyon: neon dolgu + koyu yazı.

### Doğrulama

| Denetim | Sonuç |
|---|---|
| JS sözdizimi (31 modül) | 0 hata |
| Ad sözleşmesi `check_unique_names.py --kod` | **0 / 0** (521 ad) |
| CSS karşılığı olmayan sınıf | 0 |
| CDP — anasayfa / işlem / ayarlar (`tema=hud`) | konsol **0**, ağ **0**, 3 ekran görüntüsü |
| Sunucu | yeniden başlatılmadı — statik her istekte diskten, `no-store` |

Yedekler: `_yedek/*.oncesi_tema3`.

### Sözleşme açığı da kapatıldı (temadan önce kırmızıydı)

`--kod` denetimi benim girmeden önce **5 eksik** veriyordu (24.09 MIMO
değişiklikleri listeye işlenmemişti). Kapatıldı:

- Listeye eklendi (5): `attach_market_fields`, `giris_kaydi_yaz`,
  `is_filter_reject`, `toggle_strategy`, `pozisyon_kapandi_bildir`.
- `heatmap.js`'teki 5 yerel fonksiyon (`pencereSaniye`, `hedefPenceresinde`,
  `sonrakiHedefTs`, `renkFor`, `karolariCiz`) listede olmasına rağmen
  `export` değildi — JS bölümü **export'tan üretildiği** için görünmüyorlardı.
  `export` edilip üstlerine açıklama yorumu kondu.
- §3'teki envanter sayacı bayattı (506) → **520** ile güncellendi.

## 7.23 Websocket: boş abonelikte sahte "bayat" alarmı + zombi koruması (01.10.2026)

**Şikâyet (Ismail):** "trade sayfasındaki websocket'e çare bul, fırsat kaçıyor".
Logda dakikada 30 satır `websocket bayat: N sn'dir veri gelmiyor`, N bir
noktada **4525 sn**'ye (75 dk) çıkmıştı.

**Ölçülen gerçek (zaman çizelgesi, defter + log):** bütün bayat dönemleri
AÇIK POZİSYON YOKKEN başlıyordu. Örnek: GTC 21:45:41'de kapandı → uyarılar
90 sn sonra 21:47:13'te başladı → ALICE 23:01:05'te açılınca veri geri geldi.
Gün boyunca soket yalnız BİR kez açılmıştı (12:25). Son pozisyon kapanınca
`subscribe_symbols(∅)` soketi KAPATMIYOR, sadece UNSUBSCRIBE gönderiyordu;
`durum="canli"` + 0 sembol + veri yok → `is_stream_stale()` sonsuza dek True.
**Yani bu alarmlar fırsat kaçırmadı** — pozisyon yokken boş soketin sesiydi.

**Asıl yapısal açık (aynı yerde):** `run_stream_loop` YALNIZCA `read_message()`
hata fırlatırsa yeniden bağlanıyordu. `is_stream_stale()` sadece RAPOR ediyordu.
Soket sessizce ölü kalırsa (NAT/ağ paket düşürür ama hata vermez) hiçbir şey
bağlantıyı yenilemezdi.

**Düzeltme:**
- `binance_ws.recover_if_stale()` — `durum=="canli"` ve son veri
  `STALE_AFTER_SN` (90 sn) üstündeyse: kilit İÇİNDE durumu
  "yeniden baglaniyor" yapar (tekrar çağrı ikinci soket AÇAMAZ), eski soketi
  kapatır, `_restart()`. 0 sembolde döngü soketi kapatıp `durum="kapali"`
  bırakır → alarm susar; yeni pozisyon açılınca `subscribe_symbols` soketi
  yeniden açar.
- `watcher.run_price_watch_loop` bayat görünce bunu çağırır (tek satır).
- `_send_control` docstring'i "yanıt doğrulanır" diyordu ama kod yanıtı
  OKUMUYOR (okuma döngüsü ayrı iş parçacığında). Metin gerçeğe göre
  düzeltildi; reddedilen abonelikte o sembolün fiyatı
  `STALE_SYMBOL_PRICE_SN` (20 sn) sonra REST'e düşer.

**Kanıt:** `tools/ws_zombi_sinama.py` — sahte soket, ağ yok, defter yok,
**18/18 GEÇTİ** (taze akış False; bayatta `_restart` TAM 1 kez; ikinci çağrı
False; gerçek `run_stream_loop` yeni soketle "canli"ya dönüyor ve fiyat
okunuyor; 0 sembolde soket kapanıyor, alarm duruyor, yeni soket açılmıyor).
Canlıda: restart (23:39:05) sonrası logda **0** bayat satırı (öncesi
dakikada 30), `/yerel/saglik` → `durum: kapali, bayat: false`.

**Aynı incelemede bulunan ASIL fırsat kaybı (websocket'le ilgisiz):**
`bot_turu` 23:08'de Binance'ten **-2010 "insufficient balance"** aldı.
`ayar.json`: `tutar=100` USDT, serbest bakiye 28.23 USDT; ayrıca
`bot_acik=false` (23:32'de değişmiş) ve `bot_canli=false`. Ayarlara
dokunulmadı (gerçek para) — kullanıcıya bildirildi.

## 7.24 Korku & Açgözlülük rozeti (01.10.2026)

Üst barda `B` rozetinin yanında **`KA nn`** (0-100). Vibe-trading'in
`sentiment/fear_greed_index` özelliğinin 7801'e KENDİ KODU olarak taşınması
(vibe çağrılmaz; vibe kaldırılacak).

- Kaynak: `api.alternative.me/fng/?limit=1` (anahtarsız). Borsa API'si DEĞİL.
- **Ban/yük koruması (Ismail: "api ban yer, sürekli sorgu atma"):** endeks
  günde bir güncellenir. `app/market/fear_greed.py` yanıtı kaynağın bildirdiği
  `time_until_update` kadar önbellekte tutar (en az 1 sa, en çok 24 sa) →
  dışarı **günde ~1 istek**. Hata olursa 10 dk hiç denemez. Kilit ağ
  çağrısını da kapsar (eş zamanlı iki istek dışarı iki kez gitmez).
  Tarayıcı alternative.me'ye HİÇ gitmez; 30 dk'da bir yalnız
  `GET /yerel/korku-acgozluluk` okur. Yanıttaki `dis_istek` sayacı korumayı
  ölçülebilir kılar.
- **Uydurma değer yok:** hiç veri alınamadıysa `endeks: null` → rozet
  `KA —`. Daha önce alınmış GERÇEK değer varsa kendi tarihiyle döner
  (tooltip'te tarih). Aralık dışı değer (ör. 150) reddedilir.
- **Renk eşiği uydurulmadı:** renk kaynağın KENDİ sınıfından gelir
  (`Extreme Fear / Fear / Neutral / Greed / Extreme Greed` →
  `asiriKorku / korku / notr / acgozluluk / asiriAcgozluluk`). Yalnız
  güvenli web renkleri, `font-weight` yok.

**Dosyalar:** yeni `app/market/fear_greed.py` (`fetch_fear_greed_index`,
`count_fear_greed_requests`); `market_api.handle_fear_greed`; `routes.py`
(44. uç); `ui/shell.js` `renderFearGreedBadge`; `giris.js` `korkuEndeksiKur`;
`index.html` `#fgRozet`; `97-kalan.css`; `tools/uc_denetim.py`.
Yedek: `_yedek/oncesi_korku_20261001_234254/`.

**Kanıt:** `tools/korku_sinama.py` **11/11 GEÇTİ** — gerçek değer 74 (Greed)
kaynağın kendisiyle birebir; 51 çağrıda dışarı **1** istek; önbellek 11716 sn;
ağ yokken `None`; hatadan sonra tekrar denemiyor; eski gerçek veri korunuyor;
150 reddediliyor. Canlı uç iki çağrıda `dis_istek: 1`. Headless render
1600x900 / 780x360 / 390x844: **0 Uncaught, 0 konsol hatası**; DOM'da
`class="acgozluluk"` + `KA 74`. Denetimler: `check_unique_names --kod` 0/0
(545 ad), `js_sozdizimi` 0, `css_denetim` 0 eksik, `id_denetim`'de yeni
uyarı yok.

**Not:** 390x844 dikeyde üst bar sığmıyor; `CANLI`, `B` ve `KA` ekran
dışında kalıyor. Bu ÖNCEDEN de böyleydi (CANLI/B zaten görünmüyordu).

## 7.25 İşlem günlüğü + davranış teşhisi (02.10.2026)

> **KALDIRILDI 05.10.2026** (§7.43, §7.44): sayfa, uç ve `journal_analysis.py` artık yok; aşağısı tarihçe.

Menüde **§ GUNLUK** sayfası. vibe-trading'in `analyze_trade_journal`
özelliğinin 7801'e KENDİ KODU olarak taşınması (vibe çağrılmaz).
Host'ta pandas yok → **saf Python**.

**Ne gösterir:** dönem, işlem (+/-/0), isabet, toplam K/Z USDT,
kazanç/kayıp oranı (ort. kazanç USDT / ort. kayıp USDT), kâr faktörü,
ort. kazanç/kayıp %, maks. düşüş, medyan süre, haftalık işlem; kapanış
sırasıyla birikimli **sermaye eğrisi**; **4 davranış teşhisi**; çıkış
sebebine göre ve coine göre (en kötü 8 / en iyi 8) sabit sütunlu tablolar.
Seçim: CANLI/KAĞIT defter, HEPSİ/ELLE/BOT, "toz dahil".

**Bilerek vibe'dan FARKLI olan:** vibe CSV'deki al/sat satırlarını FIFO
ile YENİDEN eşleştiriyordu → 303 işlemden 310 "roundtrip" üretip toplamı
-7.08 yerine +1.76 gösterdi. Defterde her kayıt zaten TAM bir işlem
(giriş + kapanış + gerçek `kar`); burada yeniden eşleştirme YOK.

**vibe ile BİREBİR olan:** dört teşhisin tanımı ve eşikleri (kaybedeni
tutma ≥1.2/≥1.5; aşırı işlem ≥0.3/≥1.0; pump kovalama ≥%40/≥%60; çapalanma
≥%33/≥%66), pandas davranışı dahil (çeyreklik = doğrusal ara değerleme,
std = örneklem, düşüş tepesi = ilk birikimli değer).

**İki veri gerçeği (ekranda yazar, gizlenmez):**
- **Toz:** `tutar < 1 USDT` olan **19** işlem (0.01-0.4 USDT, eski test
  artığı, bazıları ~1 yıl açık kaldı) varsayılan DIŞARIDA. Bunlar vibe'ın
  "kaybedeni tutma 2.73"ünü şişiriyordu: toz hariç gerçek oran **1.63**
  (kaybeden ort. 71 dk, kazanan 44 dk) — hâlâ YÜKSEK.
- **Türetilen K/Z:** 3 elle satışın (PHA, W, INIT — `ELLE_SATILDI`) `kar`
  alanı defterde boş; USDT karşılığı `tutar*kar_p/100` ile TÜRETİLİR
  (`pnl.build_daily_pnl` ile aynı kural) ve sayısı ekranda yazılır.

**AL anında pump uyarısı:** `islem.js` `warnIfChasingEntry(_mumlar)` — son
12 adet 5 dk mumda (1 saat) fiyat `> önceki × 1.03` ise onay penceresine
"UYARI: son 1 saatte +x% yükselmiş, pump sonrası giriyorsun" eklenir
(onaysız kâğıt modda toast). **Emri ENGELLEMEZ.** Eşik çarpım biçiminde:
ilk sürüm `(son/önceki-1)*100 > 3` idi, sınama tam %3'te kayan nokta
yüzünden (3.0000000000000027) yanlış uyarı verdiğini yakaladı, düzeltildi.

**Dosyalar:** yeni `app/reporting/journal_analysis.py` (10 fonksiyon),
`report_api.handle_journal_analysis` (`GET /yerel/gunluk-analiz?kaynak=&toz=&sadece=`,
45. uç), yeni `js/pages/journal.js`, yeni `js/ui/equityCurve.js`
(`drawEquityCurve` — günlük, geriye-test ve strateji paneli ORTAK),
`giris.js`/`shell.js` sayfa kaydı, `index.html` bölüm + menü, `97-kalan.css`
(`.gnTablo`: başlıklı, sabit sütun, **sayılar sağa, yazılar sola** —
`30-tablo.css`'in `tbody td` kuralı ilk çizimde yazıları da sağa yaslıyordu,
ekran görüntüsünde yakalandı). Yedek: `_yedek/oncesi_gunluk_20261002_071936/`.

**Kanıt:**
- `tools/gunluk_sinama.py` **18/18** — CSV kesimiyle (son kapanış
  GTC 18:45:41 UTC): 303 işlem; ortak 300 işlemin kârı CSV ile birebir
  (-7.0783); türetilen 3 = CSV'nin boş 3 satırı; STOP:baslangic 15 / -11.99;
  düşüş -23.0039 bağımsız hesapla aynı; pump kovalama **79/128** ve
  çapalanma **2/37 (GUSDT, FFUSDT)** vibe ile birebir; aşırı işlem yoğun
  eşiği **18** vibe ile aynı; toz 19 = CSV'deki tutar<1 sayısı.
- **Sınamanın yakaladığı kendi hatam:** sınama süreci `NEWTRADE_DATA_DIR`
  olmadan koşunca 7801'in değil ESKİ sistemin varsayılan defterini okudu
  (234 işlem). Artık sınama dosyası veri kökünü kendisi sabitliyor.
- `tools/pump_sinama.js` **8/8** (host node).
- Canlı uç: toz hariç 287 işlem, isabet %65.16, toplam -6.14 USDT,
  PF 0.93, düşüş -23.85. Headless 1600x1100 / 780x360 / 390x844 ve
  işlem/anasayfa/cüzdan: **0 Uncaught, 0 konsol hatası**. Denetimler temiz
  (`--kod` 0/0, JS 33 modül 0 hata, CSS 124 sınıf 0 eksik).

**Bilinen:** `牛来USDT` adı yazı tipinde Çince glif olmadığı için kutucuk
görünüyor (veri doğru; diğer sayfalarda da aynı).

## 7.26 Görsel geriye-test + ANINDA K/Z motoru (02.10.2026)

> **KALDIRILDI 05.10.2026** (§7.43, §7.44): GERİYE TEST sayfası, ANINDA K/Z paneli, `simulate_strategy_trades`,
> `backtest_report.py`, `tools/backtest_sinama.py` artık yok; aşağısı tarihçe. Grafikteki strateji
> noktaları (`replay_strategy_signals`, `/yerel/gecmis-sinyal`) KALDI.

**İstek (Ismail):** "strategyi yazar yazmaz anında kâr zarar hesabını gösteren
bi motor lazım" + "backtest motorunu görsel olarak ekleyecektin". Eski
`replay_strategy_signals` yalnız sinyal NOKTASI buluyordu, K/Z hesaplamıyordu.
Freqtrade ile karşılaştırma YOK — Freqtrade kaldırılıyor (çakışmasın).

### Motor: canlı botun AYNI yolu
`strategy/backtest.simulate_strategy_trades` (SAF, dosya/ağ yok):
- **giriş:** `entry.is_entry_allowed` (canlıyla aynı kural motoru) → adaylar
  `hiz`e göre azalan → `maks_pozisyon` sınırı → `coin_bekleme_dk`;
- **çıkış:** `exit.decide_exit` + `trading.exit_rules.plan_for_source(None, ayar,
  strategy=...)` — bot pozisyonunun planı (stratejinin `cikis`/`stop`'u global
  planın üstüne biner, TP kutusu dahil);
- **K/Z:** `net% = brüt% − komisyon_toplam` (`position_service` ile aynı; şu an %0.15).

**İleriye bakma yok:** sinyal bar t KAPANINCA bilinir → giriş bar t+1 AÇILIŞI.
Bar i içindeki çıkışta göstergeler (`atr_pct`, `deg5m`, `hacim_x`) bar i−1'in
satırından gelir.

**Bar içi sıra (temkinli):** 1) DÜŞÜK — önce stop (tepe bu barın yükseğini
henüz içermez; açılış stopun altındaysa açılıştan); 2) YÜKSEK — tepe güncellenir,
sabit HEDEF burada (açılış hedefin üstündeyse açılıştan); 3) KAPANIŞ — iz sürme,
kâr trailing, zaman, yükselen tepeyle yükselen stop (stop bar aralığındaysa stop
fiyatından). **Bilinen belirsizlik:** aynı barda önce yükseğe çıkıp sonra
yükselmiş stopun ALTINA inip kapanışta tekrar üstüne çıkan fiyat 5 dk mumda
görünmez → o çıkış kaçırılır (iyimser yön). 1 dk mum gerektirir; bilinçli sınır.

`decide_exit` / `check_time_stop`'a isteğe bağlı `now_ms_override` eklendi
(zaman aşımı mum saatine göre). **Eşdeğerlik:** `smoke_faz2b.py` çıktısı
değişiklik ÖNCESİ ve SONRASI `diff` ile **bit bit aynı** (6 yapılandırma ×
24.480 birebir; 7. "HAM STRATEJİ" ESKİ motorun içinde `KeyError: 'stop'` ile
çöküyor — aktif strateji dosyasında `stop` yok; değişiklikten ÖNCE de aynı).

### Hız: gösterge önbelleği (`reporting/backtest_report.py`)
Ölçüm: tek sembolün 2 günlük (576 bar, 300 bar pencere) gösterge satırı
**0.68 sn**, 20 sembol ~14 sn → her kural değişikliğinde hesaplanamaz.
Göstergeler STRATEJİDEN BAĞIMSIZ → bir kez hesaplanır, her yeni KAPANMIŞ
5 dk mumda yalnız o satır eklenir. Kural değişince yalnız kural değerlendirme +
simülasyon: **~180 ms** (uçtan uca, 20 coin, 576 bar).
- Soğuk dolum ve artımlı güncelleme TEK arka plan iş parçacığında, sırayla;
  **istek asla beklemez** (eksikse "hazırlanıyor k/n" döner, tarayıcı 3 sn sonra
  tekrar sorar). İlk dolum ~25-30 sn, sonuçlar kademeli gelir.
- **Ban koruması:** soğuk dolumda sembol başına TEK istek (877 mum); güncelleme
  ancak yeni mum kapandıktan sonra (≤ 5 dk'da bir) 5 mumluk istek; yanıtta
  `dis_istek` sayacı. Seri ucu ve hata yanıtları Binance'e GİTMEZ (ölçüldü).
- Eş zamanlılık: kayıt yerinde DEĞİŞTİRİLMEZ; güncelleme yeni liste kurar,
  kilit altında tek seferde koyar. Önbellek tavanı 80 sembol (LRU).
- Yalnız KAPANMIŞ mumlar (oluşan mum yeniden boyanır).

**Evren yanlılığı (ölçüldü, düzeltildi):** ilk sürüm toplayıcının RANK sırasını
(en çok yükselenler) aldı → "Hacim BB Tetik" %88 isabet gösterdi ama aynı 20 coin
2 günde al-tut ort. **+%13.2** yükselmişti (geçmişe bugünün kazananlarıyla
bakılıyordu). Evren artık **24s USDT hacmi** ile seçiliyor (al-tut +%6.5'e indi).
Tam yansız değil — ekranda **AL-TUT kıyası** ve bu not her zaman görünür.

**Yüzdeler toplanmaz** (bkz. `pnl.build_daily_pnl` "-57" dersi): getiri =
toplam USDT K/Z / (tutar × maks pozisyon) — "sermaye"; ayrıca işlem başı ort. net %.

### Arayüz
- **Strateji düzenleyicisi → "ANINDA KAR / ZARAR"** paneli: kural ekle/sil/aç-kapa,
  TP, zaman aşımı, tutar, maks pozisyon değişince 800 ms sonra **kaydedilmemiş
  taslak** gider; **son istek kazanır**, eski yanıtlar atılır. Hiçbir şey
  kaydedilmez. Sınanamayan kural varsa sarı **EKSİK** kutusu; bilinmeyen alan
  varsa **KURAL HATASI**.
- **Menü → % GERIYE TEST** sayfası: özet + sermaye eğrisi, çıkış sebebi tablosu,
  coin grafiği (giriş mavi, kârlı çıkış yeşil, zararlı kırmızı; işlem satırına
  tıkla), sabit sütunlu işlem tablosu. "AYRINTILI GERIYE TEST" düğmesi taslağı
  taşır; "AKTİF STRATEJİ" taslağı bırakır. "geniş (60 coin)" seçeneği.
- Uçlar: `POST /yerel/geriye-test` (`{strateji}` taslak | `{ad}` | `{}` aktif,
  `genis`), `GET /yerel/geriye-test/seri?sembol=` (önbellekten) — **47 uç**.

### Kanıt
- `tools/backtest_sinama.py` **20/20** — elle hesaplanmış sentetik mumlar: HEDEF
  102'den (yüksek 102.5 değil), STOP 99'dan, boşluklu açılışta 98'den; net
  +1.85/−1.15/−2.15; hız sırası + maks pozisyon (B atlanır), bekleme 10 dk ile
  ikinci giriş atlanır, deterministik, `rank` kuralı EKSİK uyarısı, kural yoksa
  0 işlem, giriş sinyalden SONRAKİ barda, zaman aşımı 11 dk SAT / 5 dk TUT.
- Gerçek veri: **sinyal eşdeğerliği** — canlıyla 120/120 doğrulanmış
  `replay_strategy_signals` 99 nokta, simülasyon aynı 99 (**fark 0**).
- `tools/bt_uc_sinama.py` **14/14** (canlı uç): 10 istek 177-208 ms; tekrarlarda
  dış istek SABİT (20); taslak çalışır; kapatılan kural yok sayılır; bozuk gövde
  400, geçersiz `maks_pozisyon` 400 (500 değil), olmayan ad 404, önbellekte
  olmayan sembol 404; `stratejiler.json` değişmedi.
- `tools/kz_cdp_sinama.py` **12/12** — gerçek tarayıcı (CDP): açılışta panel
  kendiliğinden doluyor; kural kapatınca **1.03 sn**'de güncellendi; tek
  değişiklik = tek istek; geri açınca aynı sonuç; **hızlı 5 değişiklikte TEK
  istek ve yalnız son durumun sonucu**; TP değişince 1.02 sn; AYRINTILI taslakla
  açılıyor; 69 işlem satırı + 20 grafik işareti; konsol hatası 0;
  `stratejiler.json` değişmedi.
- **Sınamanın yakaladığı kendi hatalarım:** (1) karşılaştırma metni "x ms" süre
  satırını da içerdiği için aynı sonuç farklı göründü — imza süre hariç
  alındı; (2) grafik `preserveAspectRatio="none"` ile daireleri elipse
  çeviriyordu — kabın gerçek pikselleriyle çiziliyor.
- 12 sayfa headless: 0 Uncaught / 0 konsol hatası; `uc_denetim` 0 başarısız;
  `--kod` 0/0 (574 ad), JS 34 modül 0 hata, CSS 135 sınıf 0 eksik.
- Yedekler: `_yedek/oncesi_backtest_20261002_072925/`,
  `_yedek/oncesi_geriyetest_ui_20261002_073518/`, `_yedek/exit.py.oncesi_saat_*`.

## 7.27 Freqtrade ve vibe-trading kaldırıldı (02.10.2026)

**Neden:** Ismail — "freqtrade'yi kaldır, çakışmasın" (geriye-test artık 7801'in
kendi motorunda, §7.26) ve "vibe'yi sileceğiz, 7801 kendi başına çalışacak".
7801'in HİÇBİR kodu ikisine bağlı değildi (grep: `Freqtradevenv|AppData/Freqtrade|vibe` → 0).
**Hiçbir şey silinmedi** — hepsi `*.kaldirildi_20261002` adıyla kenarda.

**Freqtrade:**
- Durdurulup disable edildi: `hermes-af` (`af_olcum.py`, `freqtrade test-pairlist`),
  `hermes-deney` (`deney.py`, `freqtrade backtesting` — kuyruk zaten bitmişti: 399/399).
- 14 unit dosyası → `~/.config/systemd/user/_kaldirildi_freqtrade_20261002/`
  (freqtrade-7075, hbot-* ×9, izleme-bot2, agefilter-lab, hermes-af, hermes-deney;
  hermes-af/deney dışındakiler zaten disable ve durmuştu).
- Klasörler: `/DATA/AppData/Freqtrade` (4.6G), `/DATA/AppData/Freqtradevenv` (1.9G),
  `~/freqtrade` → `.kaldirildi_20261002` (aynı disk, yeniden adlandırma).
- `rank/nobet.py`: 7075 sağlık kontrolü ve deney kuyruğunu doldurma çıkarıldı
  (yedek `nobet.py.oncesi_freqtrade_kaldir_*`); rapor üretimi aynen.
- **Dokunulmayan:** `hermes-rank` (7801'in toplayıcısı — Freqtrade kullanmıyor),
  `hermes-kollar`, `hermes-secici`, `ismailtr-api` (7092 — yalnız `ismailtr/veri`
  bağlı), `indicator-lab-app` (kendi `indicator-lab/freqtrade` veri indiricisi,
  bağımsız). Disable `ismailtr-*` hesaplama işleri Freqtrade mum verisini okuyordu;
  klasör adı geri çevrilmeden çalışmazlar.
- `panel_7102` nöbetçi kaydında değişiklikten ÖNCE de kapalıydı (03:10, 04:10Z).

**Veri analizi (kaldırmadan önce, vibe ile):** 13 dry-run bot / 443 işlem
vibe `analyze_trade_journal`'a verildi; 399 backtest deneyi özetlendi. Rapor:
`/DATA/AppData/Freqtrade.kaldirildi_20261002/ANALIZ_20261002.md`. Özet: isabet
%69-83 ama kazanç/kayıp 0.21-0.43 (7.26'daki STOP:baslangic deseninin aynısı);
380 deneyin %10'u kârda; T_Rsi4x14 backtest'te de dry-run'da da en iyi.

**vibe-trading:** `claude mcp remove vibe-trading -s local` (yedek
`~/.claude.json.oncesi_vibe_kaldir_20261002`); `vibe-trading-mcp` (7200) ve
`vibe-trading-web` (7201) durdurulup disable edildi, unit'ler
`_kaldirildi_vibe_20261002/`'ye; `~/vibe` (2.7G) ve `~/.vibe-trading` (2.5G)
→ `.kaldirildi_20261002`.

**Sonrası doğrulama:** bütün sınamalar yeniden koşuldu — `ws_zombi` 18/18,
`korku` 11/11, `gunluk` 18/18, `backtest` 20/20, `bt_uc` 14/14, `kz_cdp` 12/12;
`uc_denetim` 0 başarısız; `--kod` 0/0; JS 0 hata; CSS 0 eksik.
**`bt_uc_sinama`'da kendi varsayım hatam:** "kural eklenince İŞLEM azalır"
yanlış — portföyde `maks_pozisyon` doluyken elenen sinyaller yer açar, işlem
artabilir (ölçüldü: sinyal 2090 → 1659, işlem 12 → 13). Doğru değişmez:
**sinyal** sayısı artamaz. Ayrıca ~35 dk sonra ilk istek 20 sembolün artımlı
güncellemesini başlattığı için `dis_istek` bir kez arttı (61 → 80), sonra sabit
kaldı (80 → 80) — tasarlanan davranış.

**Projelerim:** `projects/2026-10-02-claudenewtra-vibe-ozellikleri/` (OZET + analiz).

## 7.28 Heatmap: büyük alan artık işarete göre ve HEPSİ (02.10.2026)

**Şikâyet:** canlıda coinlerin çoğu düşerken heatmap yeşil görünüyordu; Ismail:
"alttaki en çok düşenler, üstteki ise farklı — hepsini göstermesi gerekiyor".
**Sebep (`pages/heatmap.js`):** büyük alan YALNIZ yükselenleri (`deg24 > 0`)
alıyordu; ayrıca `okunurYerlesim` yazısı sığmayan küçük kutuları ATIYORDU.
Düşenler yalnız alttaki 9'luk şeritteydi.

**Düzeltme:**
- Büyük alan iki blok: yükselen (yeşil) + düşen (kırmızı); her bloğun alanı
  kendi toplam büyüklüğüne orantılı (yatayda yan yana, dikeyde üst üste).
  Renk ölçeği iki blokta ORTAK (aynı % aynı koyulukta). "hacim" sırasında boyut
  hacim, işaret 24s.
- **Hiç coin atılmaz:** büyük alan `squarifyTiles` ile HEPSİNİ yerleştirir;
  yazıya yer olmayan kutu yazısız çizilir (ad/yüzde `title`'da).
- Alttaki 9'luk düşen şeridi (26.09 isteği) özet olarak AYNEN kalır.
- Sayaç: "124 yükselen · 37 düşen / 161 · haritada 124+37".

**Kanıt:** `tools/hm_cdp_sinama.py` (gerçek tarayıcı) 1600x900 ve 390x844:
haritada **161/161** coin (sıfır değişim hariç hepsi); kırmızı alan payı
**%14.6** = verideki düşen büyüklük payı %14.6; kutu çakışması 0; kırmızı
kutuların hepsi negatif; konsol hatası 0. JS sözdizimi 0, `--kod` 0/0.
Yedek: `_yedek/heatmap.js.oncesi_isaret_*`.

## 7.29 Canlı mum aşağı-yukarı salınıyordu (02.10.2026)

**Şikâyet (Ismail):** "benim gördüğüm mum aşağı salınıyor, yükselirken de çıkarken de kararsız kalıyorum,
çıkıyor mu düşüyor mu". Masaüstündeki dış "SVG analiz raporu" bu hataları KAÇIRMIŞTI (17 maddesinin
hiçbiri gerçek hata değildi; ayrıntı konuşma kaydında).

**Üç gerçek sebep (`pages/islem.js` + `chart/renderer.js`):**
1. **HA açıkken:** grafik Heikin Ashi mumlarıyla çiziliyor, ama her websocket tikinde `updateLastCandle`
   son mumu HAM mumla güncelliyordu → tam çizim (HA) ile tik (ham) arasında iki şekil/renk gidip geliyordu.
2. **Yeni 5 dk dönemi:** tikler yeni mum AÇMIYOR, KAPANMIŞ mumu uzatıyordu (kapanış/tepe/dip bozuluyor);
   30 sn'lik `islemMum` yenilemesinde gerçek mumlar gelince geri zıplıyordu.
3. **Grafik geriye kaydırılmışken:** canlı mum ekranda yokken `kMum`'un son öğesi ESKİ bir mumdu ve canlı
   fiyatla bozuluyordu.

**Düzeltme:**
- `live/socketManager.js`: `onFiyat`'a 4. argüman Binance işlem zamanı (`T`) — geriye uyumlu.
- `pages/islem.js`: işlem zamanı son mumun dönemini aştıysa YENİ mum açılır (`MUM_MS = 300000`) ve tam
  çizim istenir; HA açıksa hafif güncelleme `heikinAshi(_mumlar).at(-1)` ile yapılır.
- `chart/renderer.js` `updateLastCandle`: canlı mum görünmüyorsa (`o.son < o.toplam`) dokunmaz;
  mum zamanı son çizilen mumla uyuşmuyorsa `false` → tam çizim.

**Kanıt:** `tools/mum_cdp_sinama.py` — gerçek tarayıcı + gerçek Binance akışı, HA AÇIK, 5 dk sınırını
kapsayan 338 sn, 1359 örnek: yeni mum sınırdan **0.9 sn** sonra açıldı (30 sn yenilemeyi beklemeden);
**49 tam çizimin 0'ında** son mumun rengi zıpladı; konsol hatası 0. JS sözdizimi 0, `--kod` 0/0.
Yedek: `_yedek/oncesi_canli_mum_20261002_212925/`.


## 7.30 Strateji noktası + dikey çizgi, 200M, hacim_3ort_x, grafikte 4h HA (02.10.2026)
- **Grafik:** strateji sinyali üçgen yerine strateji renginde NOKTA + noktadan geçen turkuaz (#00CCCC) DİKEY çizgi (`renderer.js` renderStrategyMarkers, `.sinyalNokta/.sinyalDikey`). Yeni **200M** düğmesi (`btnSon200`).
- **Yeni alan `hacim_3ort_x`** = bu 5m mumun hacmi / ÖNCEKİ 3 mumun ortalama hacmi (açık mum tam-mum karşılığına ölçeklenir; %20'den az dolmuşsa son kapanmış mum). 7801: `compute_prev3_volume_ratio` (indicators.py) + katalog + `build_indicator_frame`. Canlı: `rank/toplayici.py` ince_olc + `rank/db.py` EK_KOLON (INSERT 65 sütun). **Sıra:** önce hermes-rank, sonra claudenewtra yeniden başlar (aksi halde şema eksik).
- **Grafik 4h HA'yı sınayabiliyor:** `/yerel/gecmis-sinyal` strateji `ha_4h/1h/1d_ardisik_yesil` kullanıyorsa o dilimin mumlarını çeker (`fetch_higher_tf_candles`, 120 mum, 5 dk önbellek) → `replay_strategy_signals(higher_tf=…)` → `attach_higher_tf_fields`: her 5m satıra karar anında (5m kapanışı) KAPANMIŞ üst dilim mumlarından değer — toplayıcıyla aynı. Mum verilmeyen çağrılarda (geriye-test K/Z) eskisi gibi "sınanamaz".
- **Strateji "Hacim BB Tetik" (İsmail):** HA ardışık yeşil ≥1 VE ≤2, `hacim_3ort_x ≥ 3`, `ha_4h_ardisik_yesil ≥ 1`; kare128/cci_artis/hacim_x kapalı (silinmedi). ALGO 02.10: HA1-3 62 → HA1-2 47 → +hacim 9 → +4h 4 giriş (son 200 mum); grafik 4 nokta gösterdi.
- **Dry:** `kagit_bakiye` 30 → 2000 (tutar 100 > 30 olduğu için kâğıt girişler hep "yetersiz bakiye" ile reddediliyordu). Bot dry açık.
- Yedekler: `_yedek/oncesi_sinyal_dikey_*`, `oncesi_hacim3_*`, `oncesi_ust_dilim_*`, `stratejiler.oncesi_*`, `ayar.oncesi_kagit2000_*`; `rank/_yedek_oncesi_hacim3_*`.


## 7.31 h4_anlik_yesil, dipten_24s, grafikte giriş sonucu, zoom düzeltmesi (02.10.2026)
- **`h4_anlik_yesil`** (int): içinde bulunulan 4h dilim ŞU AN yeşil mi (son fiyat ≥ dilimin ilk 5m açılışı) — TM şeridiyle aynı tanım. `ha_4h_ardisik_yesil` bir ÖNCEKİ kapanmış HA mumuna baktığı için girişler TM şeridiyle uyuşmuyordu (İsmail fark etti). `compute_open_period_green`.
- **`dipten_24s`** (float): fiyat son 288 x 5m mumun en düşüğünden % kaç yukarıda. `compute_rise_from_low`. Toplayıcı (rank db.py EK_KOLON + toplayici.py, INSERT 67 sütun) ve 7801 birebir.
- **Grafikte sonuç:** `/yerel/gecmis-sinyal` her noktaya `sonuc` (hedef/stop/sure/acik) ekler — `measure_signal_outcome`: giriş = sonraki mum açılışı, önce +%2 mi −%2 mi, 48 mum. Dikey çizgi: yeşil (#33CC33) = önce +%2, kırmızı (#FF3333) = önce −%2, turkuaz = belli değil.
- **Zoom:** "−"/"+" yalnız mum genişliğini değiştiriyordu, kaydırma piksel olarak kalıyordu → 200M'den sonra "−" grafiği BOŞ bırakıyordu. Artık sağ kenardaki mum sabit, kaydırma yeni sınıra oturtulur (`zoomTusu`, islem.js).
- **Strateji "Hacim BB Tetik":** HA ≥1 ≤2, `hacim_3ort_x ≥ 3`, `dipten_24s ≤ 6`; `h4_anlik_yesil`, `ha_4h_ardisik_yesil` kapalı. ALGO 2 gün: 9 giriş, 7 +%2, 1 −%2, 1 açık; tepedeki 4 giriş elendi. 6 ay/179 coin backtestinde aynı kural rastgeleden ayrışmıyor (Projelerim `UST_DILIM_ANALIZI.md`).
- Yedekler: `_yedek/oncesi_h4anlik_*`, `oncesi_dipten_*`, `oncesi_zoom_*`, `stratejiler.oncesi_*`; rank `_yedek/oncesi_*`.


## 7.32 DENEME kopyası (7802) + pozisyon kendi stratejisiyle yönetilir + toplu defter yazımı (03.10.2026)
- **7802 `claudenewtra-deneme.service`**: aynı kod, `NEWTRADE_DATA_DIR=/DATA/AppData/_cn_deneme` (API anahtarı YOK, Telegram boş), `NEWTRADE_DENEME=1`, MemoryMax 800M. Kâğıt 10.000.000 USDT, işlem 100 USDT, bot_acik=False (giriş yalnız elle sinyal). Stratejiler `DENEME S1/S2/S4/S7/SATR` (`stop.baslangic` 1/2/4/7; SATR emre `stop_baslangic` = 4×ATR% [1,7], girişte sabit).
- **POST /yerel/deneme-sinyal** (`handle_trial_signal`): yalnız NEWTRADE_DENEME=1 ve kâğıt; gövde sembol/strateji/fiyat/tutar/stop_baslangic/etiket. 7801'de 403 döner. `place_entry_order(extra=…)` etiketi `deneme` alanına yazar.
- **trade_loop.manage_open_positions**: BOT pozisyonu ARTIK açıldığı stratejinin planıyla yönetilir (`get_strategy_by_name`, yoksa aktif); emirde `stop_baslangic` varsa o. Değişmeyen pozisyon yazılmaz; değişenler tur sonunda `update_orders_bulk` ile TEK yazım. (7801 bir sonraki yeniden başlatmada bu kodu alır.)
- Gönderici `~/gece_arastirma/deneme_sinyal.py` (`deneme-sinyal` birimi): kapanmış 5m mumlarla HA1/HA2, ZORUNLU grup SERT_DUSUS (3s içinde ≥%3 düşüş, dipten dönüş) / SIKISMA (BB genişliği son 200'ün en dar %20'si + orta üstü) / BTC_DONUS (gece araştırması finalisti); etiket KARE8/HIZLI/EN_DUSEN + 5 mum öncesi ölçümler. Rapor `deneme_rapor.py` saatte bir → Projelerim `GECE_ARASTIRMA/DENEME_RAPOR.md`.


## 7.33 "HA Kirilim S7" stratejisi botta (dry) + kirilim alanlari (03.10.2026)
- Yeni alanlar (toplayıcı EK_KOLON + INSERT 71 sütun, 7801 katalog): `ha_kapali_yesil` (KAPANMIŞ mumlarla HA ardışık yeşil, son 60), `dusus_3s`, `bbw_yuzdelik`, `kirilim_tetik` (SERT_DUSUS / SIKISMA / BTC_DONUS — VEYA önceden hesaplanır). Fonksiyonlar `count_closed_ha_streak`, `compute_drawdown_from_peak`, `compute_bb_width_percentile`. 7802 göndericisiyle eşitlik: 190 coinin 188'inde tüm değerler, 190/190 karar aynı; aynı turda toplayıcı 22 = gönderici 22.
- Geçmiş tarama (grafik) BTC_DONUS kolunu kuramaz (tek sembol) — grafikte o kol yok.
- Strateji "HA Kirilim S7": ha_kapali_yesil ≥1 ≤2, kirilim_tetik == 1, `stop.baslangic` 7, tutar 100, maks_pozisyon 300; aktif_dry. 7801 dry kâğıt 10.000.000. Canlı strateji değişmedi (Hacim BB Tetik), bot_canli=False.
- **Kapalı saatler** (03.10.2026, İsmail: "19-02 arası kapalı olsun, ben manuel yaparım"): stratejide `kapali_saatler: [[19, 2]]` (TR saati, baş dahil bit hariç, gece yarısını aşabilir) → `is_entry_hour_closed` yalnız BOT girişini durdurur; elle düğmeler ve pozisyon yönetimi etkilenmez. HA Kirilim S7 ve Hacim BB Tetik'e yazıldı. Gerekçe: 6 ayda HA girişinin en kötü saatleri 19-22 ve 00-02 (−%0.29/−%0.31).


## 7.34 TRADE ana grafiği → TradingView Lightweight Charts 4.2.0 (03.10.2026)
- İsmail: "trade ekranındaki paneli TradingView chart ile değiştirelim". Kütüphane YEREL: `static/js/vendor/lightweight-charts-4.2.0.js` (Apache-2.0, 163 KB; static_guard yalnız `/js/` altını servis eder), index.html'de `giris.js`'ten önce klasik `<script>`.
- `js/chart/tvChart.js`: `mountTvChart`, `drawTvChart` (mum/HA, hacim [HCM], EMA 7/20/48/99, BB 20/2, VWAP, strateji noktası + sonuca göre dikey çizgi [yeşil hedef / kırmızı stop / turkuaz belli değil — tam boy histogram, gizli ölçek], gerçek işlem izleri ok işareti, STOP/HEDEF/GIRIS/LIMIT fiyat çizgileri), `updateTvLastCandle` (websocket tiki), `showRecentTvCandles` / `showAllTvCandles` / `zoomTvChart` (50M/128M/200M/TÜMÜ/−/+). Eksen TR saati (zaman +3 saat kaydırılır).
- islem.js: `tvAcik()` (tercih `tvGrafik`, varsayılan AÇIK; kütüphane yoksa eski grafik), `tvCiz`. **TV** düğmesi (gösterge satırı başı) kapatınca eski SVG çizici (renderer.js silinmedi). Eski dokunma hareketleri TV modunda çizim tetiklemez (kaydırma/zoom grafiğin kendisinde).
- TV modunda HENÜZ YOK: TM zaman bantları, RSI/OBV/ATR alt panelleri, CHCM, mum bilgi kutusu/imleç, LIMIT çizgisini sürükleme (LIMIT fiyat çizgisi görünür, sağdaki kaydırıcı çalışır).
- Sınama (headless): TV kuruldu (7 canvas, 947×698), SVG yok; TV kapat → eski grafik (121 mum); tekrar aç → TV; konsol hatası 0. css_denetim vendor klasörünü atlar.


## 7.35 KARBON tema, TV algılama, %1 ızgara, TV logo, geriye giden veri koruması (03.10.2026)
- **TV grafiğinde %1 ızgara** (İsmail: "kesinlikle %1"): kütüphanenin yatay ızgarası kapalı; `yuzdeIzgarasiCiz` 1.01^k seviyelerinde createPriceLine (çarpımsal, adım HİÇ büyümez, yüklenen mum aralığının tamamı).
- **TradingView logosu** yarım boy + %40 opak (`#grafCanli #tv-attr-logo`) — lisans atfı yerinde.
- **KARBON tema** (`css/99-tema-karbon.css`, TEMALAR'a 5. tema): karbon siyah + metal gri çerçeve + amber köşe işaretleri + kesik köşe düğmeler; parlama/text-shadow/blur YOK (TV 1080→4K büyütmede bulanıklaşmasın); renkler güvenli palet (koyu tonlar #333333 saydamlığı). Örnekler: kullanıcının gönderdiği envato "Space GUI" + shutterstock "carbon black sci-fi frame". Google görsel araması otomatik tarayıcıya görsel vermedi (0 img).
- **TV algılama**: `applyDeviceClass` (theme.js) UA SMART-TV/Tizen/webOS → `data-cihaz="tv"` (çizgiler 2px). Ağdaki TV: Samsung UE50NU7090 (2018, Tizen, 4K 3840×2160, 192.168.1.55; SSDP + `:8001/api/v2/` salt okuma).
- **tvChart.js koruması**: mum kapanışında websocket yeni mumu ekledikten sonra 30 sn yenilemesi eski liste getirince seri geriye gidiyor, kütüphane ara sıra "Value is null" atıp o kareyi (saat ekseni/işaretler) çizmiyordu → geriye gidişte seriler boşaltılıp yazılır; eski zamanlı `update` yok sayılır. Tema değişince grafik yeniden kurulur (renkler).
- Sınama: telefon 384×832 dpr 2.8125 (S24 FE), PC 1920×1080, TV 1920×1080 Tizen UA → tema/TV grafiği yüklü, yatay taşma yok, düzeltme sonrası konsol hatası 0.


## 7.36 TV grafiği "Value is null" KÖK SEBEBİ, KARBON lacivert + açılı kenar, TV MODU (03.10.2026)
- **Kök sebep bulundu:** strateji dikey çizgileri tam boy HİSTOGRAM serisiydi; canlı mum `update` tikleriyle birlikte kütüphane (4.2.0 ve 4.2.3 aynı) mum renklendiricide olmayan çubuğu arayıp "Value is null" atıyor, o kareyi (saat ekseni, işaretler dahil) çizmiyordu. Ayırma (uygulamada): STRATEJİ kapalı → 0 hata; dikey seri kapalı → 0; işaretler kapalı → 8. Bağımsız sayfada üretilemedi. Çözüm: dikey çizgiler kütüphane DIŞINDA `.tvDikeyKat` üst katmanında (`dikeyleriKonumla`, x = `timeScale().timeToCoordinate`, kaydırma/zoom/ResizeObserver ile yeniden). 3 uzun turda 0 hata. (Önceki "geriye giden veri" koruması zararsız, kaldı.)
- **KARBON**: çapraz desen kaldırıldı → düz kopkoyu lacivert-antrasit (siyah üstüne #333366 saydam: zemin ~#141429, panel ~#1F1F3D); paneller sol-üst/sağ-alt PAH KIRILMIŞ (clip-path) + kesik kenarda amber çizgi, diğer köşelerde amber işaret, kenar #666666.
- **TV MODU**: üst barda **TV** düğmesi (`btnTvMod`, tercih `tvMod`; tercih yoksa TV tarayıcısı UA ile otomatik) → `data-cihaz="tv"`. `tools/tv_yazi_uret.py` CSS'teki her `font-size < 14px` kuralı için yalnız TV modunda 14px kuralı üretir → `css/99-tv-mod.css` (159 kural; CSS değişince yeniden çalıştır). TV grafiği yazısı TV modunda 14 (mod değişince grafik yeniden kurulur). Ölçüm: TV modu 124 görünen yazının en küçüğü 14px (14 altı 0); PC/telefon değişmedi (en küçük 8px).
- **TV MODU tam ekran** (İsmail: "TV modu tüm ekranı kapsamalıydı"): TV düğmesi açınca `enterFullscreen` (kapatınca çıkış); islem ızgarasının PC 840px tavanı TV modunda kalkar (trWrap 840→1004px, 5m grafik 699→863px); çizgiler 2px (TV grafiği %1 çizgileri, dikey katman, mini SVG fitil/ızgara) — TV 1080→4K 2 kat büyütmede 1px yumuşuyor, 2px net.


## 7.37 STP — elle stop sürükleme (03.10.2026) + API anahtarı arayüz hatası
- İsmail: "aldıktan sonra stop'u her coin için ekranda kaydırarak belirlemek istiyorum; STP adında düğme, açıkken kaydırma açık, kaydırınca emin misin desin, evet deyince o noktaya; her coin için ayrı; dokunmazsam Ayarlar'daki geçerli".
- **STP düğmesi** (gösterge satırı, tercih `stpAcik`): açıkken TV grafiğinde STOP çizgisi kalın + `STOP x.xx%` etiketli ve sürüklenebilir (fare + dokunma; olaylar grafik kutusunda YAKALAMA aşamasında tutulur, grafik kaymaz; sürüklerken 30 sn yenilemesi çizgileri yeniden kurmaz). Bırakınca onay ("EVET, AYARLA"); vazgeçilirse çizgi geri döner. `tvChart.setTvStopDragHandler`, `islem.stopSurukleBagla`.
- **POST /yerel/emir/stop** (`handle_manual_stop`): {canli, id, fiyat} → emre `stop_elle`; fiyat boş → kaldırılır. Koruma: stop anlık fiyatın ALTINDA olmalı (400). 49 uç.
- **Yönetim döngüsü**: `stop_elle` varsa başlangıç stopu ona eşitlenir (gevşetme dahil), karar sonrası TABAN uygulanır (merdiven/iz daha yukarı çekerse o geçerli, elle stopun altına inmez); vurduğunda sebep `STOP:elle`. `decide_exit`'e dokunulmadı (171.360 eşitliği korunur). Yalıtılmış sınama (geçici veri kökü, sahte defter/fiyat): 8 senaryo beklenen sonuç.
- **API anahtarı uyarısı**: POST /yerel/ayar cevabında `anahtar_var` yok; shell.js (dry/canlı geçişi) ve strategies.js ayar durumunu ÜZERİNE yazıyordu → arayüz "anahtar yok" sanıp "Önce Binance API anahtarını kaydet" diyordu. Artık birleştirir. Anahtar dosyası hiç değişmedi.


## 7.38 Trade websocket kesintileri + ENGELLE durum düğmesi (03.10.2026)
- İsmail: "websocket trade ekranında sürekli kesiliyor; trade ekranına geçince kesilmesin".
  1. **Binance 5 mesaj/sn sınırı**: her coin değişimi UNSUB+SUB = 2 mesaj; hızlı gezinmede sınır aşılıp Binance bağlantıyı KESİYORDU. Abonelik farkı `FARK_BEKLE_MS`=600 ms toplanıp tek seferde gönderilir.
  2. Bağlantı KURULURKEN coin değişince soket kapatılıp baştan açılıyordu → artık beklenir, onopen tüm kümeye abone olur.
  3. **Nabız + bekçi**: her bağlantıya `btcusdt@kline_1m` (~2 sn'de bir veri, fiyat olarak kullanılmaz); 45 sn hiç mesaj yoksa ölü sayılıp yeniden kurulur; `visibilitychange`/`online` olayında bağlı değilse hemen yeniden bağlanır. Yeniden deneme tavanı 30 sn → 8 sn.
  4. Trade ekranının soketi sayfadan çıkınca KAPATILMAZ (`unmountTradePanel` boş) — dönüşte kesintisiz.
  Sınama (WebSocket sayacı): trade aç → anasayfada 26 sn → dönüş → 4 hızlı coin değişimi: TEK soket, konsol hatası 0 (öncesinde hızlı değişimde 2. soket açılıyordu).
- **ENGELLE** (İsmail: "engellenmiş coinde farklı gözükmeli"): düğme AÇ/KAPA — haric listesinde ise kırmızı "🚫 ENGELLİ" (`.ekli`), basınca engel kalkar. Liste coin'i "ADA" ya da "ADAUSDT" yazmış olabilir (sunucu `expand_symbol_forms` ikisini de kabul ediyor) — `engelBicimleri` ikisini tanır/siler. Sınama: BNB/PORTAL → ENGELLİ, ADA → ENGELLE.


## 7.39 Strateji kaydı ayar siliyordu + bot neden seçim yapmıyor (04.10.2026)
- İsmail: "engelli coinlere nasıl giriyor; hiç seçim yapmıyor, hesaplamada sıkıntı mı".
- **Kök sebep**: strateji DÜZENLEYİCİSİ yalnız formdaki alanları gönderiyor; `save_strategy` kaydı bütünüyle değiştirdiği için `stop`, `cikis`, `kapali_saatler` her ekran kaydında SİLİNİYORDU. 03.10 21:17'de (CCI kaldırma) kapalı saatler vardı; 21:17–22:12 arasında ekrandan kayıt → silindi → TFUEL 22:12'de (kapalı saatte) girdi. 04.10 17:07'de ekrandan yeni kurallar kaydedildi (ha_kapali 1–2, deg5m ≥ 0.5, hız yukarı, kare128 > 5) → %7 stop ve 19–02 yine silindi. Saat kontrolü (`is_entry_hour_closed`) doğru çalışıyor.
- **Düzeltme**: `registry.KORUNAN_ALANLAR = ("stop", "cikis", "kapali_saatler")` — gelen veride yoksa mevcut kayıttan taşınır (geçici kopyada sınandı). Kayıp stop %7 + kapalı 19–02 geri yazıldı; İsmail'in 17:07 kuralları DEĞİŞMEDİ.
- **Engelli coin**: anlık satırlar (`fetch_latest_snapshot`) haric listesini (617 biçim) eliyor; şu an adaylarda engelli yok. SHAZB 03.10 16:16'da girdi, sonradan engel listesine eklenmiş görünüyor (eski panel_ayar yedeğinde yok); engel açık pozisyonu KAPATMAZ, yalnız yeni girişi engeller.
- **Seçim yok**: kâğıt cüzdan 29.55, SHAZB 14.90 kilitli → serbest 14.65 < tutar 15 → her giriş "yetersiz bakiye" (son giriş 08:35 PHA). Hesap hatası değil, tutar/bakiye oranı.


## 7.40 Strateji HA 2–3 + 1h HA, mini grafiklerde sinyal, KARBON → çelik mavisi HUD (04.10.2026)
- **Strateji** (İsmail: "HA 2. ve 3. mum yapalım, 1h Heikin Ashi'yi de ekle"): ha_kapali_yesil ≥2 ≤3, `ha_1h_ardisik_yesil ≥ 1` eklendi; deg5m ≥ 0.5, hız yukarı, kare128 > 5 aynen. Kayıt düzeltmesi canlıda çalıştı (stop %7 + kapalı 19–02 korundu). GTC 11:50 incelemesi: HA1 mumunu "hız yukarı" (= son 1 saat değişim > 0) eliyordu; düşüş sonrası ilk mumda hız hep eksi.
- **Mini grafikler** ("strateji aktifken soldaki 1d 4h 1h 5m'de nerelere denk geliyor göstersin"): `renderStrategyMarkers(..., {kapsayan:true})` — 5m sinyal onu İÇİNE ALAN mumun (t ≤ ts olan son) üstüne, aynı mumdaki sinyaller tek çizgi; `miniSinyalCiz` (miniTekCiz + izleriCiz). GTC sınaması: 5M 2, 1H 10, 4H 11, 1D 4 çizgi, konsol 0.
- **KARBON tema → çelik mavisi HUD** (referans: Shutterstock "motion graphic blue digital money logo head", kapak kareleri CDN'den; sayfa bot korumalı). opencode ile 3 modele soruldu (big-pickle, longcat-2.5, nemotron-3-ultra; cevaplar /tmp/tema_ai): ortak öneriler (koyu lacivert/petrol, #003366 saydam panel, camgöbeği çizgi, 2'nin katı periyotlu ızgara, köşe parantezi, cetvel çentiği) alındı; animasyonlu tarama TV'de titrediği için alınmadı. Zemin siyah+#336699 %20 + 32px camgöbeği ızgara; panel #336699 %34; kenar #336699; köşe parantezi/pah/başlık #66CCCC; metin #CCFFFF; marka #FF9933 (nadir turuncu); altta 8px cetvel çentikleri. PC + S24 FE görüntüsü, konsol 0.


## 7.41 1h HA 1–3, TradingView'de TM bantları, %1 çizgileri %50 soluk (04.10.2026)
- Strateji: `ha_1h_ardisik_yesil ≤ 3` eklendi (1h HA 1./2./3. mum). stop %7 + kapalı 19–02 korundu.
- **TM (TV grafiği)**: `tvChart.zamanBantlariniKonumla` — `.tvZamanKat` üst katmanı (z 2, dikey çizgilerin altında): 1 saat arka plan bantları (%3/%6) + 4 saat üst şerit (yükseklik %5, %20/%40), kendi rengiyle (kapanış ≥ açılış), son/canlı mum hariç — renderer.periyotGruplariniBul ile aynı kural (`periyotGruplari`). Kaydırma/zoom/boyutta yeniden (`ustKatmanlariKonumla`). Sınama GTC: 168 saatlik bant + 43 dört saatlik şerit, konsol 0.
- **%1 yatay çizgiler %50 soluk**: `yariSoluk` (#RRGGBB → rgba(...,0.5)); ızgara anahtarı tema rengini de içerir (tema değişince yeniden kurulur).


## 7.42 STOP etiketi, TV'de LIMIT sürükleme, DRYRUN sabit 30, bot kapat düğmesi, (toplam−1)/2 tutar (04–05.10.2026)
- STOP fiyat çizgisi etiketi: `STOP fiyat (girişe göre %)`.
- **LIMIT TV grafiğinde sürüklenir** (İsmail: "limit çizgisi iğnenin ucunda, aşağı inmiyor"): eski tutamaç SVG ölçeği kullanıyordu. tvChart sürükleme sistemi STOP + LIMIT (`setTvLimitDragHandler`, en yakın çizgi seçilir); bırakınca `setLimitPrice(elle)` + kaydırıcı. Onay yok. `tvPriceToY` (sınama yardımcısı). Gerçek fare sürüklemesi: FET 0.2529 → 0.2442.
- **DRYRUN düğmesi**: sabit 30 USDT, kâğıt bakiye kontrolü yok (`bakiye_kontrol:false` → `place_paper_entry(check_balance=False)`), fiyat anlık (LIMIT yok). Yan etki: kâğıt serbest bakiye eksiye inebilir → dry bot girişleri durur.
- **Bot kapat**: `btnBotAc`'a botPage.js VE strategies.js tıklama bağlıyordu → tek tıkta iki çağrı (biri durdurur, diğeri "çalıştır" sorar). `botuAcKapat` artık eşzamanlı tek çağrı.
- **Bot sayfası KAPAT/İPTAL/YÖNTEM** (İsmail: "shazb kapat düğmesine basıyorum kapatmıyor"): positionTable düğmeleri çiziliyordu ama tıklama dinleyicisi yalnız cüzdan sayfasında vardı. botPage.js'e `botPozisyonKapat` / `botEmirIptal` / openMethodPicker bağlandı (bot poll'unun son emir listesi `_sonEmirler`). Sınama: SHAZB (kâğıt) KAPAT → onay → KAPANDI, +%0.34.
- **Strateji sinyalleri tazelenir** (İsmail: "1h HA'ları kaldırdım ama soldaki panelde hâlâ görünüyor"): `sinyalleriYukle` yalnız coin değişince çalışıyordu → strateji değişince eski kuralların noktaları kalıyordu. `registerPoll("islemSinyal", 60)` (STRATEJİ açıksa). Sınama: açılışta 1 istek, 65 sn sonra 2. Not: `total3_5m` geçmişte kurulamaz → grafik bu kuralı yok sayar (bot canlıda uygular).
- **Tutar = (toplam − 1)/bölen**: strateji `tutar_bolen` (HA Kirilim S7 = 2) → `resolve_entry_amount` (kâğıt kipte kâğıt cüzdan, canlıda gerçek toplam); KORUNAN_ALANLAR'a eklendi. Bot durum satırı: "X aday, Y açıldı, tutar Z — son ret: …".
- Seçilenler = /yerel/aday = botun listesi (aktif strateji, haric elenmiş, hıza göre sıralı; bot en üstten girer). 05.10 07:36: 153 coin, tüm kuralları geçen 0 (son kural 1h HA ≤ 3 son adayı eledi) — boş liste hata değil.


## 7.43 TV ekseni Binance saati (UTC) + GERİYE TEST ve GÜNLÜK kaldırıldı (05.10.2026)
- **Eksen UTC** (İsmail: "saatleri eşitle"): tvChart `TR_SN = 0`. Mumlar UTC'ye göre açılır; TR (+3) eksende 4h TM sınırları 03/07/11'de görünüyordu. Artık eksen = Binance saati, 4h şerit 00/04/08… sınırlarında (ekran görüntüsünde ölçüldü). Üst bardaki saat TR.
- **Kaldırılanlar** (İsmail: "geriye test olayını kaldır, sistemi yormasına gerek yok; günlük yazanı da kaldır"): menüden GERİYE TEST ve GÜNLÜK; index.html bölümleri; strateji ekranındaki ANINDA K/Z paneli (`scheduleLiveBacktest` boş — çağıranlar bozulmasın); giris.js kayıtları; shell.js sayfa listesi; rotalar `/yerel/geriye-test`, `/yerel/geriye-test/seri`, `/yerel/gunluk-analiz` (46 uç). `pages/backtest.js`, `pages/journal.js` silinmedi → `_yedek/oncesi_geriye_gunluk_kaldir_*/kaldirilan/`. Sunucu tarafı modüller (backtest_report, journal_analysis) aynı gün §7.44'te kaldırıldı. Grafikteki strateji noktaları (`/yerel/gecmis-sinyal`) KALDI. uc_denetim'den günlük ucu çıkarıldı (0 hata).

## 7.44 Dokümantasyon denetimi + fazla kod temizliği (05.10.2026)
İsmail: "dökümantasyonumuz doğru mu kontrol et, fonksiyonlarımız fazlalık kod olmasın".
- **Tarama** (`/tmp/olu_kod.py`): her üst düzey Python/JS fonksiyonunun tanımı dışında kaç yerde geçtiği (app + static/js + index.html). 0 referans = ölü.
- **Silinen 42 fonksiyon** (yalnız tanım + üstündeki yorum; `_yedek/oncesi_olu_kod_20261005_114703`): Python — `stop_all_jobs`, `list_setting_keys`, `describe_setting`, `is_live_trading_enabled`, `get_exit_geometry`, `get_repeat_count`, `utc_day_start_ms`, `align_to_bucket_ms`, `format_duration`, `reset_request_counts`, `fetch_my_trades`, `is_symbol_tradable`, `get_column_meta`, `describe_price_source`, `fetch_symbol_series`, `fetch_db_coverage`, `flush_ticks_to_disk`, `summarize_trades`, `mark_unavailable_fields`, `simulate_strategy_trades`, `explain_entry_rejection`, `explain_rule_outcome`, `build_target_plan`, `iter_orders`, `is_position_still_open`, `_acik_tutar`, `handle_journal_analysis`, `handle_backtest_run`, `handle_backtest_series`, `suppress_client_disconnect`; JS — `apiHataSayisi`, `withAbort`, `tvPriceToY`, `formatCell`, `formatPercent`, `listModalLayers`, `renkFor`, `stopPolling`, `closeConfirm`, `baglaTamEkran`, `isPerdeOpen`.
- **2. tur** (silinenlerin yetim bıraktıkları; `_yedek/oncesi_olu_kod2_*`): `backtest._cikis_fiyati` + simülasyon başlık bloğu + `BAR_MS`; `ticks.buffer_tick` / `is_duplicate_tick` (tick YAZAN kimse yoktu; okuma `read_tick_archive` duruyor).
- **Taşınan dosyalar** (silinmedi → `_yedek/oncesi_olu_kod_20261005_114703/tasinan/`): `app/reporting/journal_analysis.py`, `app/reporting/backtest_report.py`, `js/ui/equityCurve.js`, `tools/backtest_sinama.py`, `tools/bt_uc_sinama.py`, `tools/gunluk_sinama.py`, `tools/kz_cdp_sinama.py`.
- `smoke_faz*.py`: silinen adları çağıran satırlar çıkarıldı.
- **Kanıt:** `py_compile` tüm app + smoke temiz; 65 modül import OK; `check_unique_names.py --kod` **538 ad, 0/0**; ikinci tarama **0 aday**; `js_sozdizimi` 0, `css_denetim` 0, `uc_denetim` başarısız uç 0; 10 sayfa (`islem, trade, secilenler, bot, stratejiler, ayarlar, heatmap, cuzdan, kazananlar, notlar`) CDP ile açıldı: konsol hatası **0**, ağ hatası **0** (islem'de yalnız bilgi uyarısı "gecmis-sinyal EKSIK").
- Smoke `faz2b`/`faz2c`/`faz3b` kırmızı ama temizlikten değil: canlı veriye bağlılar (aktif stratejide `stop` anahtarı yok — stop Ayarlar'dan; açık kâğıt pozisyon yok).
- Silinen kod çalışan süreçte hiç çağrılmadığı için 7801 yeniden başlatılmadı; disk sürümü bir sonraki başlatmada yüklenir.

## 8. Kod içi kurallar

1. Her fonksiyonun üstünde **bir satırlık Türkçe yorum**.
2. Neden öyle yapıldığı kritikse kısa docstring — özellikle bir ölçüme
   dayanıyorsa (İsmail'in eşik/parametre birikimi **korunur ve taşınır**).
3. Tanımlayıcılar İngilizce, yorum ve arayüz metni Türkçe.
4. Aynı ad iki modülde geçmez; `check_unique_names.py` bunu doğrular.
5. Kilit içinde ağ çağrısı yasak (`assert_no_network_in_lock`).
6. `live` / `canli` parametresi asla varsayılandan türetilmez — **her zaman
   açıkça verilir.** (Eski sistemde SIFIRLA bu yüzden gerçek defteri siliyordu.)


---

## 98. Trade ekranı arayüz sözleşmesi (26.09.2026)

Ismail'in kararları. **Tek tanım yeri:** `app/web/static/css/90-islem.css`
dosyasının sonundaki "TRADE EKRANI -- TEK TANIM" bloğu. Bu öğeler için başka
dosyaya kural eklenmez, `!important` kullanılmaz. Değişiklik yapılınca bu
tablo da güncellenir.

| Öğe | Karar |
|---|---|
| Temalar | SİYAH · AÇIK · HUD · **GÖZ DOSTU** (üst bardaki tema düğmesiyle sırayla). GÖZ DOSTU: zemin `#333333`, yazı `#CCCCCC` (7.9:1, SİYAH'ta 18:1), soluk `#CC9966`, vurgu amber `#CC9933`, **neon parlama yok**, eksi `#FF6699` (koyu grilikte okunsun diye). Tanım: `00-temel.css` sonu |
| Yazı tipi | Share Tech Mono (ğ Ğ ş Ş İ eklenmiş sürüm), tek ağırlık 400, **sahte kalın yok** |
| Renkler | yalnız **216 güvenli web rengi** (bileşenler 00/33/66/99/CC/FF), kontrast ≥ 4.5:1 |
| Sol 4 mini grafik başlığı | solda yalnız **5M / 1H / 4H / 1D** (mum adedi yazılmaz), sağda yalnız **oran** (%). Dördü de aynı punto: **9px**. Renk `#CCCCCC`, artı/eksi tek yeşil/kırmızı |
| Mini grafikte muma tıklama | o mumun yüzdesi sağdaki oranın **yerine** yazılır, altı `#3399CC` çizgili; fiyat/açılış/kapanış ipucunda |
| Üst kutular | **24s / gün / FARK** küçük (9px). **Y/K kutusu yok.** |
| Sağ sütun (İŞLEM) | sol sütunla **aynı genişlik** (grid `.54fr 2.10fr .54fr`); düğmeler tek satır, alt açıklamalar ipucunda |
| WebSocket göstergesi | **üst satırda** (coin adı / 24s / gün / FARK), en sağda **`ms:55`** (oyunlardaki ms/FPS gibi), dar ekranda da görünür. <150 ms tek yeşil, <500 sarı `#FFCC66`, üstü / 5 sn veri yok (`ms:--`) tek kırmızı. Hesap: tarayıcı saati − Binance olay zamanı `E`, yumuşatılmış, saniyede bir |
| **TEK YEŞİL / TEK KIRMIZI** | Sayfadaki **tüm** kâr/zarar, AL/SAT, mum, hacim, rozet, bildirim, ms, ısı haritası renkleri `--arti` **#33CC99** / `--eksi` **#FF3366** (SİYAH ve HUD tema). Eski (#2FE08A/#FF4D6A) ile Binance (#2EBD85/#F6465D) ortasının en yakın güvenli web rengi. Renk **yalnız** `00-temel.css` tema bloklarında tanımlı; başka yerde yeşil/kırmızı sabit yazılmaz. AÇIK tema kendi koyu tonlarını korur (açık zeminde okunsun). Yeşil zemin üstü yazı `#003333`. EMA/OBV/ATR çizgi renkleri anlam taşımadığı için ayrı |
| Hacim çubukları | mumla aynı renk, opaklık .55 (eskiden .22, kayboluyordu) |
| Engelle düğmesi | üst satırda `🚫 ENGELLE` — simgenin yanında yazı **her ekranda** görünür (eski adı HARİÇ TUT; aynı liste) |
| Sol kenar düğmeleri | **tek tutamak** 44×44 (›). Basınca tam ekran / menü / dikey **48×48** açılır; birine basınca ya da dışarı dokununca kapanır. Her modda aynı ölçü (eski: yatayda 40×120+84+84, tam ekranda 26 px — basılamıyordu). Tek tanım: `css/40-kenar-tuslari.css` |
| Hata bildirimi | yalnız **kendi dosyalarımızdan** (`/js/` altı) gelen hata gösterilir; sayfa adresinin kendisinden gelen hata (satır içi betik — bizde yok) dış kaynaklı sayılır, **Türkçe** ve `dosya:satır` ile (`translateError`). Eklenti kaynaklı hatalar (ör. "tv is not defined") ekrana çıkmaz, konsola düşer; son 20 hata `__cn.hatalar()` |
| LIMIT çizgisi tavanı | LIMIT açıkken sarı çizgi **anlık fiyatın en fazla `limit_ust_yuzde` % üstüne** çıkabilir (varsayılan **0.4**). Sürükleme, kaydırıcı ve fiyat düşüşünde de kırpılır. Ayar: AYARLAR › İŞLEM AYARLARI › "LIMIT cizgisi en fazla fiyatin ustune %" |
| Cüzdan varlık satırı | ad · miktar · **bugünkü değişim %** (UTC gün açılışına göre, `/yerel/mum 1d`) · USDT değeri |
| SEÇİLENLER tablosu | **anasayfa tablosunun AYNISI**: aynı 31 kolon, aynı hücreler, aynı CSS (`trade.js buildTableHead / buildTableRows / alignStickyHeader`). Ayrı kopya YAZILMAZ. En başta **NO** (1'den, gösterilen sıraya göre), sonra **ANA #** (anasayfa rank). Başlığa tıklayınca anasayfayla aynı sıralama (`sortRows`); NO'ya tıklayınca stratejinin aday sırası. Bilgi satırı: taranan · elenen · **SEÇİLDİ** (tüm adaylar, 30 sınırı yok). CANLI% ve FİYAT kendi websocket aboneliğiyle (sayfadan çıkınca bırakılır) |
| Üst bardaki YENİLE | **sayfanın tamamını yeniler** (`reloadPage`); açık sayfa (#islem/SEMBOL) korunur. `R` tuşu yalnız veriyi yeniler (`manualRefresh`) |
| Emojiler | `fonts/CNEmoji.woff2` + `fonts/CNSembol.woff2` (kendi sunucumuz). Yeni emoji eklenirse bu alt kümeler yeniden kesilir |

---

## 99. Denetim — 26.09.2026

Salt okunur iki ayrı denetim (formül + belge) ve ekran ölçümüyle bulundu.

### Bu turda düzeltilenler
| Konu | Ne yapıldı | Kanıt |
|---|---|---|
| Yazılar bulanık | Share Tech Mono varsayılan; fontta OLMAYAN ğ Ğ ş Ş İ fontun kendi parçalarından eklendi (`fonts/ShareTechMono-400-tr.woff2`); **sahte kalın kapalı** (`font-weight:400`, `font-synthesis:none`); 9px altı 39 punto 9px'e | 4 sayfa headless render, 0 konsol hatası |
| Kontrast | soluk metin: SIYAH 4.23→4.74, ACIK 3.84→4.73, HUD 3.36→4.68; HUD zarar rengi 3.19→4.64; CANLI rozeti 5.12 | WCAG oranı hesaplandı |
| Emojiler kutu (▯) | kullanılan 8 emoji Noto Color Emoji'den, 21 işaret DejaVu Sans'tan kesildi, kendi sunucumuzdan (`CNEmoji.woff2`, `CNSembol.woff2`) | render |
| Cüzdan "serbest" | KÂĞIT cüzdan toplamını "serbest" diye gösteriyordu (eski 7777 index.html'den) — kaldırıldı | — |
| Bot sayfası "anahtar" | kaldırıldı; anahtar durumu AYARLAR › BINANCE API'de | — |
| Geriye-test ≠ canlı | 300 mum penceresi, `obv_aci`/`kdj_j_aci` = `gostergeler.aci` birebir, `hacim` = 24s USDT (m[7]) | **120/120 bar birebir**, smoke_faz1d 15/15 |

### 26.09.2026 akşam — ek düzeltme
- **KISMI emir hiç yenilenmiyordu** (`order_service.refresh_order_statuses` yalnız `ACIK`'a bakıyordu). RARE id=500: borsada 1192.5'in tamamı dolmuşken defter 592 sanıyordu → stop yalnız 592 satardı. Düzeltildi, servis yeniden başlatıldı, RARE `DOLDU 1192.5/1192.5`. KISMI emre zaman aşımı iptali uygulanmaz.
- Saat uyarısı (-1021): sunucu saati NTP senkron, Binance farkı 30–290 ms. Sebep ağ gecikmesi (gidiş-dönüş 0.36–0.86 sn); kod saati yeniden ölçüp tekrar dener.

### 27.09.2026 — tam ekranda JS hatası
`trade.js` içinde `window.addEventListener("resize", alignStickyHeader)` olay nesnesini
`govdeId` parametresi olarak geçiriyordu → `querySelector('#[object Event] tr')` SyntaxError.
Tam ekran pencere boyutunu değiştirdiği için her geçişte (ve her sayfada, dinleyici kalıcı) hata
toast'u çıkıyordu. Düzeltme: `() => alignStickyHeader()`. Kanıt: headless Chromium, 10 sayfa ×
(3 boyut + tam ekran aç/kapa) → `__cn.hatalar()` boş. **Kural:** parametreli fonksiyon olay
dinleyicisine çıplak verilmez. Bilinen eksik: SEÇİLENLER tablosu (`secGovde`) yeniden boyutlanınca
yeniden hizalanmıyor.

### 27.09.2026 — İŞLEM grafiğinde BOT/CÜZDAN/STRATEJİ işaretleri ayrıldı
Kullanıcı: "çok karışıyor" — `STRATEJİ` düğmesi bir önceki turda ESKİ işlevinin
(geçmiş kağıt işlem noktaları) üstüne yazılmıştı. Ayrıştırıldı:
- **CÜZDAN düğmesi**: GERÇEK giriş/çıkış noktaları, iki renk bir arada —
  ayırıcı alan `el_kaynak` (varsa → cüzdan/el: AL/AL TAKIP/ALSAT, yoksa →
  BOT). Bu ayrım canlı/kâğıt (`_live`) ayrımından **BAĞIMSIZ**
  (`app/trading/wallet.py:29-31`'deki `sadece=="el"/"bot"` filtresiyle aynı).
- **STRATEJİ düğmesi**: stratejinin geçmiş mumlarda NEREDE GİRECEĞİ (hipotez,
  `/yerel/gecmis-sinyal` replay, mavi üçgen) — gerçek işlem DEĞİL. İki düğme
  artık birbirini bozmadan aynı anda açık kalabiliyor (test: SAGAUSDT'de
  turuncu+sarı daire aynı anda, STRATEJİ açılınca daireler değişmedi).
- Gerçek girişlerden (bot+cüzdan, sadece "giriş" noktaları) sağa doğru,
  giriş fiyatı+%1.2'yi geçen ilk muma kadar (en fazla **10 mum**, daha
  ileri UZAMAZ) kesikli yatay çizgi — hız karşılaştırması, gerçek kapanış
  zamanından/sebebinden bağımsız salt görsel bir ölçüm.
- Üç rengi de (`renk_bot_giris` #FF9900, `renk_cuzdan_giris` #FFCC00,
  `renk_strateji_sinyal` #3399CC) AYARLAR › GRAFİK'ten değiştirilebiliyor
  (`app/config/settings.py`, `type="color"` input — projede ilk kullanım).

### 28.09.2026 — 5m grafikte "TM" zaman bandı katmanı eklendi
Kullanıcı: 12 mumun (5m) GERÇEK saat sınırına, 48 mumun (5m) GERÇEK 4-saat
sınırına oturan renkli bantlar istedi — HA butonunun soluna yeni bir "TM"
düğmesi. `chart/renderer.js`'e `renderTimeBands(kutuId, mumlar)` eklendi:
- **Saatlik bant**: her GERÇEK UTC saatinin KENDİ yönüne (o saatteki ilk
  açılış vs son kapanış) göre yeşil/kırmızı, `fill-opacity:.1` (**%10
  görünür**), ana grafiğin tam yüksekliğini kaplıyor, `kZaman` katmanı
  (mumların ALTINDA).
- **4H üst şerit**: grafiğin en üstünde, yükseklik `anaYuk × 0.05`
  (**%5**), aynı yön kuralıyla renklenen kareler, `kZamanUst` katmanı
  (mumların ÜSTÜNDE, `fill-opacity:.6`).
- **Canlı mum HARİÇ**: dizinin son elemanı (`mumlar.length-1`) hesaba HİÇ
  katılmıyor (`periyotGruplariniBul`, `kapaliSon = n-2`).
- **"Taze dilim" koruması**: yeni başlayan (en güncel) saat/4-saat dilimi
  en az 2 KAPANMIŞ mum içermiyorsa o dilim HİÇ ÇİZİLMEZ — Ismail: "açılan
  mum da 1-2 mum beklesin, hatasız olsun".
- Görünür alan dışındaki bantlar (`x1<0 || x0>o.W`) DOM'a hiç eklenmiyor
  (performans).
- `pages/islem.js`'de `gosterge().tm` ile açılıp kapanıyor, `anaCiz()`
  içinde `renderCandleChart`'tan hemen sonra çağrılıyor — HA dönüşümünden
  ETKİLENMEZ, ham `_mumlar` (gerçek 5m zaman damgaları) kullanılır.
- Uygulamadan ÖNCE yedek alındı: `_yedek/{islem.js,renderer.js,index.html,
  90-islem.css,99-duzeltme.css}.oncesi_TM_20260928_1735`.
- Doğrulama (Playwright, BTCUSDT): kapalıyken katmanlar boş (0/0 çocuk),
  açılınca saatlik 10 bant + 4H 3 kare çiziliyor, bant genişlikleri mum
  adımının TAM KATI (88.2px = 12×7.35, 352.8px = 48×7.35 — saat sınırına
  doğru oturduğunun kanıtı), tekrar kapatılınca katmanlar yeniden boşalıyor,
  konsol hatası **0**.

### 28.09.2026 — "128M"/"50M" butonları eksik mum gösteriyordu (-3 mum)
Kullanıcı: "128m mumu 128 mum mu gösteriyor". Playwright ile ölçüldü:
128M tıklanınca ekranda GERÇEKTE **125** mum vardı, 50M ise **47**.
Sebep: `chart/zoom.js`'deki `fitRecentCandles(n, ...)` mum genişliğini
SADECE `n`e göre ayarlıyordu (`kullanilabilir/n`), ama sona kaydıran
`scrollToEnd` sağda `BOSLUK_MUM=3` (nefes payı) kadar ekstra boşluk da
bırakıyordu — bu boşluk AYNI n-mumluk genişlik bütçesinden ÇALINIYORDU.
`fitAllCandles` (TÜMÜ butonu) bu payı zaten doğru hesaplıyordu
(`toplam+BOSLUK_MUM`), `fitRecentCandles` etmiyordu — asimetri.
**Düzeltme:** `fitRecentCandles` de aynı deseni kullanır oldu
(`kullanilabilir/(n+BOSLUK_MUM)`). Playwright ile doğrulandı: 128M → tam
128 mum, 50M → tam 50 mum, varsayılan açılış → tam 120 mum, konsol
hatası **0**. Bu fonksiyon `btnSon25` (50M), `btnSon128` (128M) VE
sayfa ilk açılışının kendisi (`anaMumlariYukle`, 120 mum) tarafından
paylaşıldığı için üçü de aynı anda düzeldi.

### AÇIK — henüz düzeltilmedi
1. ~~`tutar_yuzde` bot tarafından okunmuyordu~~ — **26.09.2026 DÜZELTİLDİ**: `trade_loop.resolve_entry_amount`
   = botun kendi modundaki cüzdan toplamı × yüzde (ekranla aynı tanım); canlıda cüzdan
   okunamazsa giriş yapılmaz. Yüzde boşsa eskisi gibi sabit `tutar`.
2. **Etkisiz ayarlar** (şemada var, backend okumuyor): `kar_al`, `stop` (canlıda 7.0),
   `sat_sira`, `alsat_sira`, `bot_bekleme_sn`. `DEAD_SETTINGS` yalnız 6 eski anahtarı sayıyor.
3. `compute_ledger_stats` hâlâ `toplam = sum(kar_p)` hesaplıyor. Cüzdanda "tüm zamanlar %"
   olarak görünen rakam yüzdelerin toplamıdır, bileşik getiri değil.
4. Kural eşiği metni 1 ondalığa yuvarlanıyor (`0.04` → "0.0"); karar ham değerle verildiği için doğru.
5. Trailing geri çekilme `(tepe/fiyat−1)×100` ile hesaplanıyor (standart `1−fiyat/tepe`);
   zaman aşımı brüt kârla. İkisi de eski sistemden birebir devralındı.
6. `main.py` ölü ayarları temizlerken `ayar.json`'a atomik olmayan `write_text` ile yazıyor.

### Sayılar (26.09.2026 ölçümü)
521 fonksiyon adı / 81 modül (`check_unique_names.py --kod` temiz), **42 uç** (25 GET + 17 POST),
**01.10.2026:** 545 ad (`--kod` temiz), **44 uç** (yeni: `/yerel/korku-acgozluluk`).
**02.10.2026:** **45 uç** (yeni: `/yerel/gunluk-analiz`); sonra **47 uç** (`/yerel/geriye-test`, `/yerel/geriye-test/seri`), 574 ad.
**05.10.2026:** GERİYE TEST + GÜNLÜK kaldırıldı → **46 uç** (27 GET + 19 POST); ölü kod temizliği → **538 ad / 83 modül**, `--kod` 0/0.
ESLESTIRME 140 benzersiz eşleşme + 381 yeni ad, `CANLI_SEMBOL_SAYISI = 10`.
