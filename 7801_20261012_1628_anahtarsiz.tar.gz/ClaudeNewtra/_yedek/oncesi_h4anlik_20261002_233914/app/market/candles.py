"""Mum (kline) verisi ve gosterge satiri uretimi.

ONEMLI: geriye-test artik KENDI gosterge kodunu yazmiyor. Eski sistemde
`/yerel/gecmis-sinyal` RSI/HA/EMA/gun_pct'i `do_GET` ICINDE, 365 satirlik bir
blokta yeniden hesapliyordu -- `gostergeler.py`'nin kendi docstring'i bunu
acikca yasakliyordu: "Iki yerde ayri yazilirsa sinamanin olctugu sey ile
ekranda gorunen sey sessizce ayrisir." Burada tek kaynak `market.indicators`.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Any

from app.core.timeutil import now_ms
from app.exchange import bybit_rest, gateio_rest, mexc_rest, okx_rest
from app.exchange.binance_rest import fetch_klines
from app.exchange.symbol_rules import normalize_symbol
from app.market import indicators as IND

MAX_PAGE = 1000


# Tek sayfa mum ceker (ham Binance bicimi).
def fetch_candle_page(symbol: str, interval: str, *, limit: int = 500,
                      start_time: int | None = None,
                      end_time: int | None = None) -> list[list]:
    return fetch_klines(normalize_symbol(symbol), interval,
                        limit=min(limit, MAX_PAGE),
                        start_time=start_time, end_time=end_time)


# Sayfalayarak genis aralik ceker (panel 2016 mum = 7 gun istiyor).
def fetch_candle_range(symbol: str, interval: str, *, total: int,
                       end_time: int | None = None) -> list[list]:
    s = normalize_symbol(symbol)
    bitis = end_time or now_ms()
    toplanan: list[list] = []
    while len(toplanan) < total:
        istenen = min(MAX_PAGE, total - len(toplanan))
        sayfa = fetch_candle_page(s, interval, limit=istenen, end_time=bitis)
        if not sayfa:
            break
        toplanan = sayfa + toplanan
        bitis = int(sayfa[0][0]) - 1
        if len(sayfa) < istenen:
            break
    return toplanan[-total:]


# 29.09.2026, Ismail: "trade ekranindaki hacim barinda her borsaninki farkli
# renk olsun" (CHCM ozelligi) -- Binance disindaki 4 borsanin AYNI sembol/
# interval icin hacmini ceker, zaman damgasina (ms) gore birlestirir. Her
# borsa BAGIMSIZ try/except: biri hata verir/coin orada yoksa o borsa
# SESSIZCE ATLANIR, digerleri etkilenmez (toplayici.py'nin coklu zaman
# dilimi HA dongusundeki desenle AYNI ilke). Zaman damgalari 5 borsada da
# BIREBIR AYNI (29.09.2026 curl ile dogrulandi) -- floor/yaklasik eslestirme
# GEREKMEZ, dogrudan ts anahtariyla birlestirilir.
_COKLU_BORSALAR = {
    "bybit": bybit_rest.fetch_klines,
    "okx": okx_rest.fetch_klines,
    "mexc": mexc_rest.fetch_klines,
    "gate": gateio_rest.fetch_klines,
}


def fetch_multi_exchange_volume(symbol: str, interval: str = "5m",
                                *, limit: int = 288) -> dict[int, dict[str, float]]:
    """{ts_ms: {"bybit": hacim, "okx": hacim, "mexc": hacim, "gate": hacim}}.
    Binance'in kendi hacmi buraya DAHIL DEGIL -- o zaten mevcut /yerel/mum
    yanitinda var, cagiran taraf iki yaniti ts uzerinden birlestirir."""
    s = normalize_symbol(symbol)

    def _cek(kv):
        ad, fn = kv
        try:
            return ad, fn(s, interval, limit=limit)
        except Exception:
            return ad, None

    sonuc: dict[int, dict[str, float]] = {}
    with ThreadPoolExecutor(max_workers=len(_COKLU_BORSALAR)) as p:
        for ad, mumlar in p.map(_cek, _COKLU_BORSALAR.items()):
            if not mumlar:
                continue
            for m in mumlar:
                sonuc.setdefault(int(m[0]), {})[ad] = float(m[5])
    return sonuc


# Canli toplayicinin 5m gosterge penceresi (toplayici.py PENCERE["5m"]).
CANLI_PENCERE = 300


def _kolonlar(candles: list[list]) -> dict[str, list[float]]:
    """Ham kline dizisini acilis/yuksek/dusuk/kapanis/hacim serilerine ayirir."""
    return {
        "open": [float(m[1]) for m in candles],
        "high": [float(m[2]) for m in candles],
        "low": [float(m[3]) for m in candles],
        "close": [float(m[4]) for m in candles],
        "volume": [float(m[5]) for m in candles],
        # m[7] = quote (USDT) hacmi. Canlidaki `hacim` alani 24s QUOTE hacmi.
        "quote_volume": [float(m[7]) if len(m) > 7 else float(m[5]) * float(m[4])
                         for m in candles],
        "ts": [int(m[0]) for m in candles],
    }


# Mum serisinden, kural motorunun anlayacagi gosterge satiri uretir.
# Geriye-test bunu kullanir; canli veriyle AYNI fonksiyonlardan hesaplanir.
def build_indicator_frame(candles: list[list], *, upto: int | None = None) -> dict[str, Any]:
    if not candles:
        return {}
    n = len(candles) if upto is None else min(upto, len(candles))
    # 26.09.2026: canli toplayici her olcumu SON 300 MUMLA yapiyor
    # (toplayici.py PENCERE["5m"]=300). Geriye-test eskiden basindan i'ye
    # kadar BUYUYEN seriyi veriyordu -> tum seriden ortanca alan hacim_x /
    # hiz canlidan sapiyordu (barlarin %70'inde hacim_x >%5 fark). Ayni
    # pencere verilince iki taraf birebir esit.
    k = _kolonlar(candles[max(0, n - CANLI_PENCERE):n])
    kapanis, yuksek, dusuk, hacim = k["close"], k["high"], k["low"], k["volume"]
    ohlc = list(zip(k["open"], yuksek, dusuk, kapanis))

    def geri(bar: int) -> float | None:
        if len(kapanis) <= bar or not kapanis[-bar - 1]:
            return None
        return (kapanis[-1] / kapanis[-bar - 1] - 1) * 100.0

    rsi, rsi_egim = IND.compute_rsi(kapanis)
    obv = IND.compute_obv(kapanis, hacim)
    obv_sinyal = IND.compute_obv_signal(obv) if obv else []
    ha = IND.build_heikin_ashi(ohlc)
    ema7 = IND.compute_ema(kapanis, 7)
    ema20 = IND.compute_ema(kapanis, 20)
    ema48 = IND.compute_ema(kapanis, 48) if len(kapanis) >= 49 else []
    son = kapanis[-1]

    satir: dict[str, Any] = {
        "ts": k["ts"][-1], "fiyat": son,
        "deg5m": geri(1), "deg10m": geri(2), "deg15m": geri(3), "deg20m": geri(4),
        "deg30m": geri(6), "deg35m": geri(7), "deg40m": geri(8), "deg45m": geri(9),
        "deg50m": geri(10), "deg55m": geri(11),
        "deg1h": geri(12), "deg2h": geri(24), "deg4h": geri(48), "deg8h": geri(96),
        "rsi": rsi, "rsi_egim": rsi_egim,
        "atr_pct": IND.compute_atr_percent(yuksek, dusuk, kapanis),
        "cci": IND.compute_cci(yuksek, dusuk, kapanis),
        # 27.09.2026: cci_artis = cci_simdi - cci_7_once (MUTLAK puan farki,
        # yuzde degil -- toplayici.py ile AYNI formul/pencere, bkz. oradaki
        # yorum). len<27 (20 cci penceresi + 7 geri bakis) ise None.
        "cci_artis": (IND.compute_cci(yuksek, dusuk, kapanis)
                      - IND.compute_cci(yuksek[:-7], dusuk[:-7], kapanis[:-7])
                      if len(kapanis) >= 27
                      and IND.compute_cci(yuksek, dusuk, kapanis) is not None
                      and IND.compute_cci(yuksek[:-7], dusuk[:-7], kapanis[:-7]) is not None
                      else None),
        "kdj_j": IND.compute_kdj_j(yuksek, dusuk, kapanis),
        "obv": obv[-1] if obv else None,
        "obv_sinyal": obv_sinyal[-1] if obv_sinyal else None,
        "obv_kesim": IND.compute_cross_age(obv, obv_sinyal) if obv_sinyal else None,
        "obv_aci": IND.compute_slope_angle(obv) if obv else None,
        # 26.09.2026: eskiden hep None idi -> bu alani kullanan kural
        # geriye-testte HIC tetiklenmiyordu. Canlidaki gibi J serisinin acisi.
        "kdj_j_aci": IND.compute_slope_angle(
            IND.compute_kdj_j(yuksek, dusuk, kapanis, return_series=True)),
        # 26.09.2026: eskiden BAZ varlik hacmi (m[5]) toplaniyordu; canli
        # alan 24s USDT hacmi. 288 x 5m = 24 saat, quote hacim.
        "hacim": sum(k["quote_volume"][-288:]) if k["quote_volume"] else None,
        "hacim_x": IND.compute_volume_ratio(hacim),
        "hacim_3ort_x": IND.compute_prev3_volume_ratio(hacim),
        "hacim_x_1h": None, "hacim_x_4h": None,
        "hiz": IND.compute_normalized_momentum(kapanis, change_pct=geri(12)),
        "ha_ardisik_yesil": IND.count_consecutive_green_ha(ohlc),
        "ha_yesil_yukselis": IND.measure_green_ha_gain(ohlc),
        "yesile_donus_mum": IND.count_bars_since_green_flip(ohlc),
        "ema7": ema7[-1] if ema7 else None,
        "ema20": ema20[-1] if ema20 else None,
        "wma48": IND.compute_wma(kapanis, 48),
        "ema20_uzak": ((son / ema20[-1] - 1) * 100.0) if ema20 and ema20[-1] else None,
        "ema48_uzak": ((son / ema48[-1] - 1) * 100.0) if ema48 and ema48[-1] else None,
    }
    if ema7 and ema20:
        ema4 = IND.compute_ema(kapanis, 4)
        dizilim = 1 if (ema4[-1] > ema7[-1] > ema20[-1]) else 0
        onceki = (1 if len(ema4) > 1 and ema4[-2] > ema7[-2] > ema20[-2] else 0)
        satir["ema_dizilim"] = dizilim
        satir["ema_kesim"] = 1 if (dizilim and not onceki) else 0

    # 29.09.2026, Ismail: "fiyat boiler band orta cizgisini yukari kesti" /
    # "orta cizginin uzerinde" -- toplayici.py ile AYNI desen (ema20_uzak/
    # ema_kesim), Bollinger ORTA cizgisi (SMA20) icin. "Uzerinde" ayri alan
    # DEGIL -- bb_orta_uzak > 0 zaten bunu ifade eder.
    bb_orta_serisi = IND.compute_sma(kapanis, 20)
    if len(bb_orta_serisi) >= 2 and bb_orta_serisi[-1] and bb_orta_serisi[-2]:
        bb_orta, bb_orta_onceki = bb_orta_serisi[-1], bb_orta_serisi[-2]
        satir["bb_orta_uzak"] = ((son / bb_orta) - 1) * 100.0
        satir["bb_orta_kesim"] = (1 if (kapanis[-1] > bb_orta
                                        and kapanis[-2] <= bb_orta_onceki)
                                  else 0)
    else:
        satir["bb_orta_uzak"] = None
        satir["bb_orta_kesim"] = 0

    # 29.09.2026, Ismail: "hacim yesil ya da 2x uzeri VEYA boiler bandi
    # kesince giris" -- toplayici.py ile AYNI OR-onceden-hesaplama deseni.
    satir["hacim_bb_tetik"] = 1 if (
        (satir.get("hacim_x") is not None and satir["hacim_x"] >= 2.0)
        or satir.get("bb_orta_kesim") == 1
    ) else 0

    # 26.09.2026, Ismail: son 128 mumun yeşil/kırmızı sayimi + CHANGE.
    # 26.09.2026 (2. tur, Ismail): HER MUMUN degisimi onceki kapanisa gore
    #   -> yesildeg / kirmizideg / fark128 / kare128 / yukselis128.
    # Canli taraftaki toplayici.ince_olc ile AYNI pencere: 129 kapanmis 5m mum
    # (128 degisim icin bir onceki kapanis gerekir). 129'den az bar varsa NULL
    # -- uydurma veri yok (ayni kural DB'de de gecerli).
    _ad128 = ("deg128m", "coingreen", "coinsay", "yesildeg", "kirmizideg",
              "fark128", "kare128", "yukselis128")
    if len(kapanis) >= 129:
        ac128, kp128 = k["open"][-128:], kapanis[-128:]
        oncekiKp = kapanis[-129]
        yesil = kirmizi = 0
        yesilTop = kirmiziTop = 0.0
        for a, c in zip(ac128, kp128):
            renk = 1 if c > a else (-1 if c < a else 0)
            if renk > 0:
                yesil += 1
            elif renk < 0:
                kirmizi += 1
            if renk and oncekiKp:
                deg = (c / oncekiKp - 1) * 100.0
                if renk > 0:
                    yesilTop += deg
                else:
                    kirmiziTop += deg
            oncekiKp = c
        enYuksek, enDusuk = max(yuksek[-128:]), min(dusuk[-128:])
        satir["deg128m"] = ((kp128[-1] / kp128[0] - 1) * 100.0) if kp128[0] else None
        satir["coingreen"] = yesil
        satir["coinsay"] = yesil - kirmizi
        satir["yesildeg"] = yesilTop
        satir["kirmizideg"] = kirmiziTop
        satir["fark128"] = yesilTop - abs(kirmiziTop)
        satir["kare128"] = ((enYuksek / enDusuk - 1) * 100.0) if enDusuk else None
        # Son kapanan (degerlendirilen) mumun en yuksek degeri dibinden ne kadar?
        _sonYuksek = yuksek[-1]
        satir["yukselis128"] = ((_sonYuksek / enDusuk - 1) * 100.0) \
            if (enDusuk and _sonYuksek) else None
    else:
        for _ad in _ad128:
            satir[_ad] = None

    for renk, kaynak in IND.COLOR_SOURCE.items():
        satir[renk] = satir.get(kaynak)
    return satir
