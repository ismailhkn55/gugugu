"""Emir uclari: listeleme, gonderme, kapatma, iptal, yontem degistirme."""
from __future__ import annotations

from app.config.settings import load_settings
from app.core.errors import ExchangeError, LedgerConflictError, OrderRejectedError
from app.market.price_source import get_prices
from app.market.rank_repository import fetch_latest_snapshot, fetch_rows_for_symbols
from app.strategy.registry import get_active_strategy
from app.trading import ledger as LD, order_service as OS, position_service as PS
from app.web.router import query_int, query_live


# YAPAY ZEKA MIMO (24.09.2026): elle kapatmada da Telegram bildirimi gonder.
# Derin inceleme yuksek oncelik #1: on_closed hic baglanmamisti.
def _bildir_kapanis(kapanan: dict) -> None:
    from app.notify.telegram_client import is_telegram_configured, send_message
    a = load_settings()
    if not is_telegram_configured(a):
        return
    kar = kapanan.get("kar_p")
    sebep = (kapanan.get("kapanis") or {}).get("sebep") or "?"
    try:
        kar_s = f"{kar:+.2f}%" if kar is not None else "?"
        send_message(a, f"KAPANDI {kapanan.get('sembol')}: {kar_s} ({sebep})")
    except Exception:
        pass


def _hata(e):
    if isinstance(e, OrderRejectedError):
        return 400, {"hata": str(e)}
    if isinstance(e, LedgerConflictError):
        return 409, {"hata": str(e)}
    if isinstance(e, ExchangeError):
        return 502, {"hata": str(e)}
    return 500, {"hata": f"{type(e).__name__}: {e}"}


# GET /yerel/emirler -- iki defter birlestirilir, her kayit KAYNAGINI tasir.
def handle_order_list(req):
    acik = LD.list_open_orders(None)
    kapali = []
    for live in (True, False):
        for e in LD.list_closed_orders(live, limit=query_int(req["params"], "n", 60)):
            kapali.append({**e, "_kaynak": "canli" if live else "dry", "_live": live,
                           "_anahtar": LD.make_order_key(live, e.get("id", -1))})
    kapali.sort(key=lambda e: (e.get("kapanis") or {}).get("ts") or 0, reverse=True)
    # Ilgili sembollerin ANLIK piyasa satirlari da gonderilir: cuzdan ve bot
    # ekranlari boylece anasayfadaki gostergelerin (iz, ATR, RSI, hacim...)
    # AYNISINI gosterebilir -- Ismail: "bot da da cuzdan da detaylari
    # gorunmeli yani iz nerde atr nerde ayni ana sayfadaki gibi".
    semboller = {e.get("sembol") for e in acik} | {e.get("sembol") for e in kapali}
    piyasa = fetch_rows_for_symbols(semboller)
    return 200, {"acik": [p for p in acik if p.get("durum") == "ACIK"],
                 "takip": [p for p in acik if p.get("durum") in ("DOLDU", "KISMI")],
                 "kapali": kapali, "hepsi_sayi": len(acik) + len(kapali),
                 "piyasa": piyasa}


# POST /yerel/emir -- AL / AL TAKIP / ALSAT.
def handle_place_order(req):
    g = req["body"]
    a = load_settings()
    sembol = g.get("sembol") or g.get("symbol")
    if not sembol:
        return 400, {"hata": "sembol gerekli"}
    kaynak = (g.get("kaynak") or g.get("dugme") or "al").lower()
    live = bool(g["canli"]) if "canli" in g else bool(a.get("canli"))
    anlik = {r["sembol"]: r for r in fetch_latest_snapshot(limit=400)["satir"]}
    o = anlik.get(sembol.upper(), {})
    try:
        emir = OS.place_entry_order(
            sembol, live=live, settings=a, source=kaynak,
            quote_amount=float(g.get("tutar") or a.get("tutar", 30.0)),
            limit_price=float(g["limit"]) if g.get("limit") else None,
            strategy=get_active_strategy(live=live),
            atr_pct=o.get("atr_pct"), speed=o.get("hiz"),
            reference_price=o.get("fiyat"))
        return 200, {"ok": True, "emir": emir}
    except Exception as e:
        return _hata(e)


# POST /yerel/deneme-sinyal -- 02.10.2026, Ismail: "dryrun botuna manuel sinyal
# at, aldi desin ve takip etsin". YALNIZ ayri deneme kopyasinda (NEWTRADE_DENEME=1)
# calisir, HER ZAMAN KAGIT. Govde: sembol, strateji (ad), fiyat, tutar,
# stop_baslangic (istege bagli, %), etiket (dict). Strateji BOT plani gibi
# yonetilir (el_kaynak yok), stop o stratejinin `stop` alanindan gelir.
def handle_trial_signal(req):
    import os
    from app.strategy.registry import get_strategy_by_name
    if os.environ.get("NEWTRADE_DENEME") != "1":
        return 403, {"hata": "yalniz deneme kopyasinda"}
    g = req["body"] or {}
    a = load_settings()
    if a.get("bot_canli"):
        return 409, {"hata": "deneme kopyasi canli modda -- kapali"}
    st = get_strategy_by_name(g.get("strateji"))
    if not st or not g.get("sembol") or not g.get("fiyat"):
        return 400, {"hata": "sembol, fiyat ve gecerli strateji gerekli"}
    ekstra = {"deneme": dict(g.get("etiket") or {})}
    if g.get("stop_baslangic") is not None:
        sb = float(g["stop_baslangic"])
        st = {**st, "stop": {**(st.get("stop") or {}), "baslangic": sb}}
        ekstra["stop_baslangic"] = sb
    try:
        fiyat = float(g["fiyat"])
        emir = OS.place_entry_order(
            g["sembol"], live=False, settings=a, source=None,
            quote_amount=float(g.get("tutar") or st.get("tutar") or 100.0),
            limit_price=fiyat, reference_price=fiyat, strategy=st,
            atr_pct=g.get("atr_pct"), extra=ekstra)
        return 200, {"ok": True, "id": emir.get("id"), "stop": emir.get("stop")}
    except Exception as e:
        return _hata(e)


# POST /yerel/dryrun_giris -- her zaman KAGIT.
def handle_paper_entry(req):
    g = req["body"]
    a = load_settings()
    sembol = g.get("sembol")
    if not sembol:
        return 400, {"hata": "sembol gerekli"}
    try:
        emir = OS.place_paper_entry(sembol, settings=a,
                                    source=(g.get("kaynak") or "al").lower(),
                                    quote_amount=g.get("tutar"),
                                    strategy=get_active_strategy(live=False))
        return 200, {"ok": True, "emir": emir}
    except Exception as e:
        return _hata(e)


def _live_ve_id(g):
    """`canli` ZORUNLU -- yanlis defterdeki pozisyonu kapatma riski yok."""
    if "canli" not in g and "kaynak" not in g:
        return None, None, (400, {"hata": "canli/kaynak belirtilmeli (hangi defter?)"})
    live = bool(g["canli"]) if "canli" in g else (g.get("kaynak") == "canli")
    try:
        return live, int(g["id"]), None
    except (KeyError, TypeError, ValueError):
        return None, None, (400, {"hata": "id gerekli"})


# POST /yerel/emir/kapat
def handle_close_one(req):
    live, oid, hata = _live_ve_id(req["body"])
    if hata:
        return hata
    a = load_settings()
    emir = LD.find_order(live, oid)
    if not emir:
        return 404, {"hata": "emir bulunamadi"}
    f, _k = get_prices([emir["sembol"]]).get(emir["sembol"], (None, "yok"))
    if not f:
        return 502, {"hata": "fiyat alinamadi"}
    try:
        kapanan = PS.close_position(
            live, oid, price=float(f), reason=req["body"].get("sebep") or "ELLE",
            sell=(lambda e: OS.place_exit_order(e, live=live)) if live else None,
            commission_pct=float(a.get("komisyon_toplam", 0)),
            on_closed=_bildir_kapanis)
        return 200, {"ok": True, "emir": kapanan}
    except Exception as e:
        return _hata(e)


# POST /yerel/emir/hepsini-kapat
def handle_close_all(req):
    g = req["body"]
    a = load_settings()
    live = bool(g["canli"]) if "canli" in g else bool(a.get("canli"))
    acik = LD.list_open_orders(live)
    if not acik:
        return 200, {"ok": True, "kapanan": 0}
    fiyatlar = get_prices([p["sembol"] for p in acik])
    sonuc = PS.close_all_positions(
        live, fiyatlar, reason="HEPSINI_KAPAT",
        sell=(lambda e: OS.place_exit_order(e, live=live)) if live else None,
        commission_pct=float(a.get("komisyon_toplam", 0)),
        on_closed=_bildir_kapanis)
    return 200, {"ok": True, **sonuc}


# POST /yerel/emir/iptal
def handle_cancel_order(req):
    live, oid, hata = _live_ve_id(req["body"])
    if hata:
        return hata
    try:
        return 200, {"ok": True, "emir": OS.cancel_open_order(live, oid)}
    except Exception as e:
        return _hata(e)


# POST /yerel/yontem-degistir
def handle_change_method(req):
    g = req["body"]
    live, oid, hata = _live_ve_id(g)
    if hata:
        return hata
    kaynak = (g.get("yontem") or g.get("kaynak_yontem") or "").lower()
    if kaynak not in ("al", "altakip", "alsat1", "alsat2", "alsat3"):
        return 400, {"hata": f"gecersiz yontem: {kaynak!r}"}
    try:
        return 200, {"ok": True, "emir": PS.change_exit_method(live, oid, kaynak,
                                                               load_settings())}
    except Exception as e:
        return _hata(e)


# POST /yerel/defter-temizle -- kapanmislari siler, aciklari korur.
def handle_purge_ledger(req):
    g = req["body"]
    if "canli" not in g and "kaynak" not in g:
        return 400, {"hata": "canli/kaynak belirtilmeli (hangi defter?)"}
    live = bool(g["canli"]) if "canli" in g else (g.get("kaynak") == "canli")
    return 200, {"ok": True, **LD.purge_closed_orders(live)}
