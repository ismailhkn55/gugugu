// shell.js -- uygulama kabugu: gezinme, menu, saat.
import { iptalEtHepsini } from "../api.js";
import { registerShortcut, pushModalLayer } from "../keys.js";
import { listPolls, refreshNow, setActivePage } from "../poll.js";
import { getState, setState, getTercih, setTercih } from "../store.js";
import { TEMA_KISA, YAZI_KISA, applyPortraitMode, applyFont, applyTheme, TEMALAR, YAZITIPLERI,
         setTvMode } from "./theme.js";
import { formatClock } from "../format.js";
import { enterFullscreen, exitFullscreen } from "./fullscreen.js";
import { showToast } from "./toast.js";
import { apiPost } from "../api.js";
import { askConfirm } from "./confirm.js";

const SAYFALAR = ["trade", "islem", "secilenler", "kazananlar", "cuzdan",
                  "heatmap", "stratejiler", "bot", "notlar", "ayarlar", "gunluk", "geriyetest"];
const _mount = new Map();      // sayfa -> kurucu fonksiyon
const _unmount = new Map();    // sayfa -> temizleyici (websocket vb.)
let _menuKapat = null;

// Bir sayfanin kurucusunu (ve istege bagli temizleyicisini) kaydeder.
export function registerPage(ad, kurucu, temizleyici) {
  _mount.set(ad, kurucu);
  if (temizleyici) _unmount.set(ad, temizleyici);
}

// Sayfa gecisi.
//
// ESKI SISTEM: `sayfaGit` zaten interval'de olan yenileyicileri TEKRAR
// cagiriyordu (`botYenile`, `bakiyeYenile`, `gecmisYenile`, ...); menude
// hizli gezinince ayni uca art arda istek gidiyordu. Burada sayfa
// degisimi yalnizca ILGILI zamanlayiciyi tetikler ve acik istekleri iptal eder.  (eski: sayfaGit)
// Verilen sayfaya gecer: gorunumu, zamanlayicilari ve adresi gunceller.
export function navigateToPage(ad, ek) {
  // "#islem/BTCUSDT" bicimi: sayfa + hedef coin.
  if (ad && ad.includes("/")) {
    const [s, e] = ad.split("/");
    ad = s; ek = ek || e;
  }
  if (!SAYFALAR.includes(ad)) return;
  if (ek) setState({ seciliSembol: ek.toUpperCase() });
  // AKTIF SAYFAYI HER ZAMAN bildir -- erken donusten ONCE.
  // Baslangicta magazadaki sayfa zaten "trade" oldugu icin bu satir
  // erken donusun ARKASINDA kalinca `setActivePage` hic cagrilmiyor ve
  // sayfaya bagli TUM zamanlayicilar sessizce hic calismiyordu
  // (tablo bos, websocket baglanmiyor).
  setActivePage(ad);
  menuIsaretle(ad);
  if (getState("sayfa") === ad) { _mount.get(ad)?.(); return; }
  iptalEtHepsini();
  // Ayrildigimiz sayfanin canli akisini birak.
  const eski = getState("sayfa");
  if (eski && eski !== ad) {
    try { _unmount.get(eski)?.(); } catch (e) { console.error("[shell]", e); }
  }
  for (const e of document.querySelectorAll("[data-sayfa]")) {
    const benim = e.dataset.sayfa === ad;
    e.classList.toggle("aktif", benim);
    if (e.hasAttribute("hidden") || benim) e.hidden = !benim;
  }
  setState({ sayfa: ad });
  closeDrawer();
  // Adres cubugunda sayfa: yenileyince ayni sayfada kalinir ve
  // dogrudan baglanti verilebilir. (Eski sistemde yoktu.)
  const hedef = "#" + ad + (ad === "islem" && getState("seciliSembol")
                            ? "/" + getState("seciliSembol") : "");
  if (location.hash !== hedef) history.replaceState(null, "", hedef);
  const kurucu = _mount.get(ad);
  if (kurucu) kurucu();
}

// Yan menuyu acar.  (eski: menuAc)
export function openDrawer() {
  const m = document.getElementById("menu");
  const p = document.getElementById("perde");
  if (!m) return;
  m.classList.add("acik");
  p?.classList.add("acik");
  _menuKapat = pushModalLayer("menu", closeDrawer);
}

// Yan menuyu kapatir.  (eski: menuKapat)
export function closeDrawer() {
  document.getElementById("menu")?.classList.remove("acik");
  document.getElementById("perde")?.classList.remove("acik");
  if (_menuKapat) { _menuKapat(); _menuKapat = null; }
}

// Saati yazar (1 saniyede bir).  (eski: saatCiz)
export function renderClock() {
  const e = document.getElementById("zaman");
  if (e) e.textContent = formatClock();
}

// Elle yenileme -- TUM zamanlayicilari sifirlayip birer tur attirir.
//
// 23.09.2026, Ismail: "yenile ye bastigimda ekranda loading donsun ya".
// Dugme, isler GERCEKTEN bitene kadar doner (`refreshNow` artik soz
// donduruyor); sahte bir sure kullanilmaz. En az 400 ms gorunur kalir,
// aksi halde hizli donen turlarda goz bunu fark etmiyor.  (eski: elleYenile)
export async function manualRefresh() {
  const d = document.getElementById("btnYenile");
  d?.classList.add("donuyor");
  d?.setAttribute("aria-busy", "true");
  const bas = Date.now();
  try {
    await refreshNow();
  } finally {
    const kalan = 400 - (Date.now() - bas);
    if (kalan > 0) await new Promise((z) => setTimeout(z, kalan));
    d?.classList.remove("donuyor");
    d?.removeAttribute("aria-busy");
  }
}

// Sayfayi tamamen yeniler (YENILE dugmesi). Donen simge, tarayici yeni
// sayfayi yukleyene kadar gorunur.
export function reloadPage() {
  const d = document.getElementById("btnYenile");
  d?.classList.add("donuyor");
  d?.setAttribute("aria-busy", "true");
  location.reload();
}

// Verinin ne kadar taze oldugunu alt durum satirina yazar.
export function renderDataAge(tsMs) {
  const e = document.getElementById("dTarih");
  if (!e) return;
  if (!tsMs) { e.textContent = "—"; return; }
  const sn = Math.max(0, Math.round((Date.now() - tsMs) / 1000));
  e.textContent = sn < 90 ? `${sn} sn once` : `${Math.round(sn / 60)} dk once`;
  e.className = sn > 420 ? "eksi" : "";
}

// Calisma modu rozetini (DRY RUN / CANLI) cizer.
export function renderModeBadge(ayar) {
  const d = document.getElementById("modRozet");
  const y = document.getElementById("modYazi");
  const canli = !!ayar?.canli;
  if (y) y.textContent = canli ? "CANLI" : "DRY RUN";
  // Ayarlardaki gecis dugmesi hangi yone gidecegini yazar.
  const b = document.getElementById("btnCanli");
  if (b) b.textContent = canli ? "DRY RUN MODUNA DON" : "CANLI MODA GEC";

  // BOT rozeti (ust bardaki "B") -- PANELDEN BAGIMSIZ.
  //
  // 23.09.2026, Ismail: "sayfanin en ustunde dryrun yaziyor ya yanina
  // sadece icinde B harfi olan bi kutucuk koy; bot dry run da iken gri
  // solgun, bot canliya gectiginde yesil gozuksun".
  // Ihtiyac buradan dogdu: ust bardaki rozet YALNIZCA panelin modunu
  // gosteriyordu; panel canliya alininca kullanici botun da canliya
  // gectigini sandi. Olculdu: `bot_canli` degismiyor -- iki mod gercekten
  // bagimsiz; eksik olan GORUNURLUKTU.
  const br = document.getElementById("botRozet");
  if (br) {
    const botCanli = !!ayar?.bot_canli;
    br.classList.toggle("canli", botCanli);
    br.classList.toggle("dry", !botCanli);
    br.title = botCanli
      ? "BOT CANLI — gercek para ile emir gonderir (panelden bagimsiz)"
      : "BOT KAGIT — dry run (panelden bagimsiz)";
  }
  // Ayni rozet islem panelinde ve ayarlar sayfasinda da var.
  for (const id of ["trMod", "ayModYazi"]) {
    const x = document.getElementById(id);
    if (!x) continue;
    x.textContent = canli ? "CANLI" : (id === "trMod" ? "DRY" : "DRY RUN");
    x.classList.toggle("canli", canli);
    x.classList.toggle("dry", !canli);
  }
  if (d) {
    d.classList.toggle("canli", canli);
    d.classList.toggle("dry", !canli);
    d.setAttribute("aria-pressed", String(canli));
  }
}

// Canli/kagit modunu degistirir -- HER IKI YONDE de onay ister.
//
// 23.09.2026, Ismail: "canli moda ayarlardan gecilebilir sadece, canliya
// gecerken de emin misiniz cikarken de emin misiniz diye soracak".
// Onceden: ust bardaki rozet TIKLANABILIR bir dugmeydi ve canlidan cikis
// hic onay sormadan aninda oluyordu. Artik cagri yalnizca AYARLAR
// sayfasindaki dugmeden gelir (bkz. mountAppShell) ve iki yon de onayli.
async function modDegistir() {
  const ayar = getState("ayar") || {};
  if (ayar.canli) {
    const onay = await askConfirm("DRY RUN MODUNA DON",
      "Gercek para emirleri duracak; AL / SAT / ALSAT bundan sonra KAGIT "
      + "uzerinde calisacak. Acik gercek pozisyonlar kapanMAZ, oldugu gibi kalir.",
      { onayMetni: "DRY RUN'A DON" });
    if (!onay) return;
    const c = await apiPost("/yerel/ayar", { canli: false });
    if (c) { setState({ ayar: c.ayar }); renderModeBadge(c.ayar); showToast("DRY RUN moduna donuldu", "ok"); }
    return;
  }
  if (!ayar.anahtar_var) {
    showToast("Once Binance API anahtarini kaydet (Ayarlar)", "hata");
    return;
  }
  const onay = await askConfirm("CANLI MODA GEC",
    `Bu moddan sonra AL / SAT / ALSAT butonlari GERCEK PARA ile Binance'e `
    + `emir gonderir. Islem tutari: ${ayar.tutar} USDT`, { onayMetni: "CANLI MODA GEC" });
  if (!onay) return;
  const c = await apiPost("/yerel/ayar", { canli: true });
  if (c?.ayar?.canli) { setState({ ayar: c.ayar }); renderModeBadge(c.ayar); showToast("CANLI MOD ACIK", "uyari", 6000); }
  else showToast(c?.hata || "canli moda gecilemedi", "hata");
}

// Menudeki etkin ogeyi isaretler.
function menuIsaretle(sayfa) {
  for (const d of document.querySelectorAll("#menu .menu-oge")) {
    d.classList.toggle("aktif", d.dataset.git === sayfa);
  }
  const ds = document.getElementById("dSayfa");
  if (!ds) return;
  const ad = (document.querySelector(`#menu .menu-oge[data-git="${sayfa}"]`)
              ?.textContent || sayfa).trim().toUpperCase();
  // Kac zamanlayicinin dondugu durum satirinda gorunur. Eski sistemde bu
  // gorunurluk yoktu; tum sayfalar gezildikten sonra 12 dongu ayni anda
  // doniyor ve tarayici kilitleniyordu, ama disaridan anlasilmiyordu.
  const yazDonen = () => {
    const n = listPolls().filter((i) => i.aktif).length;
    ds.textContent = `${ad} · ${n} is`;
  };
  yazDonen();
  setTimeout(yazDonen, 400);
}

// Kabugu kurar: menu, kenar tuslari, kisayollar, saat.
export function mountAppShell() {
  document.getElementById("btnMenu")?.addEventListener("click", openDrawer);
  setupSideHandle();
  document.getElementById("perde")?.addEventListener("click", closeDrawer);
  // 26.09.2026, Ismail: "YENILE sayfayi yenileyecekti". Eskiden yalniz veri
  // zamanlayicilarini bir tur attiriyordu (manualRefresh) -- sayfa, JS/CSS
  // guncellemeleri gelmiyordu. Artik SAYFANIN TAMAMINI yeniler; acik sayfa
  // (#islem/SEMBOL gibi) adres cubugunda kaldigi icin ayni yere doner.
  document.getElementById("btnYenile")?.addEventListener("click", reloadPage);

  // TAM EKRAN (YATAY). Eski sistemde bu dugme yalnizca fullscreen aciyordu;
  // eger daha once DIKEY mod secilmisse (tercih localStorage'da kaliyor)
  // tam ekranda da dikey duzen kaliyordu -- kullanici "tam ekran yatay
  // modda solda 4, ortada 5m, sagda butonlar olacakti" dedi. Artik yatay
  // tam ekran AYNI ZAMANDA duzeni yataya alir.
  document.getElementById("tamekran")?.addEventListener("click", async () => {
    const { isFullscreen, toggleFullscreen } = await import("./fullscreen.js");
    if (!isFullscreen()) applyPortraitMode(false);     // 3 sutunlu yatay duzen
    await toggleFullscreen("landscape");
  });
  {
    const d = document.getElementById("tamekran");
    const guncelle = async () => {
      const { isFullscreen } = await import("./fullscreen.js");
      d?.setAttribute("aria-pressed", String(isFullscreen()));
    };
    document.addEventListener("fullscreenchange", guncelle);
    document.addEventListener("webkitfullscreenchange", guncelle);
  }

  for (const d of document.querySelectorAll("[data-git]")) {
    d.addEventListener("click", () => navigateToPage(d.dataset.git));
  }

  // Dugme yazisi SECILI temayi gosterir. Eskiden index.html'de "SIYAH"
  // sabit yaziyordu; tema degisince de guncellenmiyordu. Uc tema secilebilir
  // oldugundan (SIYAH / ACIK / HUD) buton artik her degisimde kendini yazar.
  const temaDugmesiniYaz = () => {
    const d = document.getElementById("btnTema");
    if (d) d.textContent = TEMA_KISA[getTercih("tema")] || "SIYAH";
  };
  temaDugmesiniYaz();
  document.getElementById("btnTema")?.addEventListener("click", () => {
    const s = TEMALAR.indexOf(getTercih("tema"));
    applyTheme(TEMALAR[(s + 1) % TEMALAR.length]);
    temaDugmesiniYaz();
  });
  // Dugme yazisi SECILI yazi tipini gosterir. Eskiden index.html'de
  // "INTER" sabit yaziyordu ve yazi tipi degisse de guncellenmiyordu.
  const yaziDugmesiniYaz = () => {
    const d = document.getElementById("btnYazi");
    if (d) d.textContent = YAZI_KISA[getTercih("yazitipi")] || "DIJITAL";
  };
  yaziDugmesiniYaz();
  document.getElementById("btnYazi")?.addEventListener("click", () => {
    const s = YAZITIPLERI.indexOf(getTercih("yazitipi"));
    const y = YAZITIPLERI[(s + 1) % YAZITIPLERI.length];
    applyFont(y);
    yaziDugmesiniYaz();
    showToast("yazi tipi: " + y, "bilgi", 1500);
  });
  // 03.10.2026: TV MODU dugmesi -- yalniz bu moddayken yazilar en az 14px.
  const tvDugme = document.getElementById("btnTvMod");
  if (tvDugme) {
    tvDugme.setAttribute("aria-pressed", String(document.documentElement.dataset.cihaz === "tv"));
    tvDugme.addEventListener("click", () => {
      const acik = setTvMode(document.documentElement.dataset.cihaz !== "tv");
      tvDugme.setAttribute("aria-pressed", String(acik));
      window.dispatchEvent(new Event("resize"));     // grafikler yeni yazi boyuyla yeniden olcsun
    });
  }
  // Mod degisimi YALNIZCA ayarlar sayfasindaki dugmeden yapilir.
  // Ust bardaki `#modRozet` bir dugme DEGIL, sadece gostergedir
  // (dry run'da gri, canli modda yesil) -- yanlislikla tiklanip gercek
  // para moduna gecilmesin.
  document.getElementById("btnCanli")?.addEventListener("click", modDegistir);

  // Dikey mod: acarken portre, kapatirken yataya doner.
  document.getElementById("btnDikey")?.addEventListener("click", async () => {
    const acik = getTercih("gorunum") !== "dikey";
    applyPortraitMode(acik);
    if (acik) await enterFullscreen("portrait");
    else await exitFullscreen();
  });

  // "sadece yukselenler" filtresi -- tabloya tercih uzerinden bildirilir.
  const by = document.getElementById("btnYuzde");
  by?.addEventListener("click", () => {
    const yeni = !getTercih("sadeceYukselen");
    setTercih("sadeceYukselen", yeni);
    by.setAttribute("aria-pressed", String(yeni));
    by.classList.toggle("acik", yeni);
  });
  if (by) {
    by.setAttribute("aria-pressed", String(!!getTercih("sadeceYukselen")));
    by.classList.toggle("acik", !!getTercih("sadeceYukselen"));
  }

  registerShortcut("f", () => document.getElementById("tamekran")?.click());
  registerShortcut("r", manualRefresh);
  for (const [i, s] of SAYFALAR.entries()) {
    if (i < 9) registerShortcut(String(i + 1), () => navigateToPage(s));
  }

  renderClock();
  setInterval(renderClock, 1000);
  window.addEventListener("hashchange", () =>
    navigateToPage(location.hash.replace("#", "") || "trade"));
}

// Baglanti rozetini cizer.  (eski: baglantiDurumu)
export function renderConnectionBadge(durum, ek) {
  const n = document.getElementById("wsNokta");
  const y = document.getElementById("wsDurum");
  if (n) n.className = "nokta " + (durum === "canli" ? "yesil" : durum === "koptu" ? "kirmizi" : "sari");
  // 26.09.2026: bagliyken "ms:—" (ilk mesaj gelene kadar), sonra ms:55.
  if (y && durum !== "canli") { y.textContent = durum; y.className = "msYok"; }
  if (y && durum === "canli" && !y.className.startsWith("ms")) { y.textContent = "ms:—"; y.className = "msOrta"; }
  setState({ baglanti: durum });
}

// WebSocket gecikmesini 5M basliginda gosterir: "ms:55".
// 26.09.2026, Ismail: "oyun oynarken fps geliyor ya, ayni onun gibi,
// baglandim mi baglanmadim mi anlamiyorum". Veri 5 sn gelmezse "ms:--" kirmizi.
let _msZaman = null;
export function renderLatency(ms) {
  const y = document.getElementById("wsDurum");
  if (!y) return;
  y.textContent = `ms:${ms}`;
  y.className = ms < 150 ? "msIyi" : ms < 500 ? "msOrta" : "msKotu";
  clearTimeout(_msZaman);
  _msZaman = setTimeout(() => { y.textContent = "ms:--"; y.className = "msKotu"; }, 5000);
}

// Sol kenar tutamagi: 3 dugmeyi acar/kapatir.
// Dugmelerden birine basilinca ya da disari dokununca kapanir.
export function setupSideHandle() {
  const kutu = document.getElementById("solkenar");
  const t = document.getElementById("kenarTutamak");
  if (!kutu || !t) return;
  const ayarla = (acik) => {
    kutu.classList.toggle("acik", acik);
    kutu.classList.toggle("kapali", !acik);
    t.setAttribute("aria-expanded", String(acik));
  };
  t.addEventListener("click", (e) => { e.stopPropagation(); ayarla(!kutu.classList.contains("acik")); });
  kutu.querySelectorAll(".kenar-dugme").forEach((b) =>
    b.addEventListener("click", () => setTimeout(() => ayarla(false), 150)));
  document.addEventListener("click", (e) => {
    if (kutu.classList.contains("acik") && !kutu.contains(e.target)) ayarla(false);
  });
}

// Kaynagin (alternative.me) KENDI siniflari -> CSS sinifi + Turkce ad.
// Esik uydurulmaz: renk, kaynagin verdigi siniftan gelir.
const KA_SINIF = {
  "Extreme Fear": ["asiriKorku", "Aşırı Korku"],
  "Fear": ["korku", "Korku"],
  "Neutral": ["notr", "Nötr"],
  "Greed": ["acgozluluk", "Açgözlülük"],
  "Extreme Greed": ["asiriAcgozluluk", "Aşırı Açgözlülük"],
};

// Kripto Korku & Acgozluluk rozetini cizer; veri yoksa "KA —" (uydurma deger yok).
export function renderFearGreedBadge(endeks) {
  const r = document.getElementById("fgRozet");
  if (!r) return;
  r.classList.remove("yok", ...Object.values(KA_SINIF).map((x) => x[0]));
  if (!endeks || !Number.isFinite(endeks.deger)) {
    r.classList.add("yok");
    r.textContent = "KA —";
    r.title = "Korku & Açgözlülük alınamadı";
    return;
  }
  const [sinif, ad] = KA_SINIF[endeks.sinif] || ["yok", endeks.sinif || "?"];
  r.classList.add(sinif);
  r.textContent = `KA ${endeks.deger}`;
  const tarih = new Date(endeks.ts).toLocaleDateString("tr-TR");
  r.title = `Kripto Korku & Açgözlülük: ${endeks.deger}/100 — ${ad} (${tarih}, alternative.me, günde bir güncellenir)`;
}
