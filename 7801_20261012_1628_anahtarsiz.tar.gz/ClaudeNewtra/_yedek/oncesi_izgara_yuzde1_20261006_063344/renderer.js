// chart/renderer.js -- SVG mum grafigi.
//
// ESKI SISTEM (F12): her karede `k.innerHTML = mumCizGenel(...)` ile TUM
// grafik yeniden yaziliyor, sonra etiketler / limit cizgisi / bilgi katmani
// ELLE geri konuyordu (4407-4424). Yapinin en kirilgan yaniydi.
//
// Burada katmanlar AYRI `<g>` ogeleri: mum katmani guncellenirken ustteki
// katmanlar (limit cizgisi, etiketler, iz noktalari) yerinde kalir.
import * as G from "./indicators.js";
import { formatPrice } from "../format.js";
import { getCandleWidth, getPriceLock, getScrollX, SAG_EKSEN_PX } from "./zoom.js";

const NS = "http://www.w3.org/2000/svg";
// `sag` degeri zoom.js ile ORTAK -- kaydirma tavani ayni olcuyu kullanir.
const KENAR = { ust: 6, alt: 16, sag: SAG_EKSEN_PX };

// Mum govdesinin mum adimina orani.
//
// 23.09.2026, Ismail: "mumlar cok kalin ya bi miktar incelt". Onceden 0.68
// idi; govdeler bitisik gorunuyor ve arkadaki %1 izgarasini yutuyordu.
// 0.52 ile mumlar arasinda gorunur bosluk kalir, izgara okunur.
const GOVDE_ORANI = 0.52;

// CIZIM SAYACLARI -- "takiliyor" sikayeti olculebilir olsun diye.
//
// `tam`   : tum SVG bastan kuruldu (izgara + mumlar + cizgiler)
// `hafif` : yalnizca son mumun ogeleri oynatildi (tik yolu)
// `tasma` : hafif yol denendi ama fiyat olcegin disina tasti -> tam cizim
// Konsoldan `__cn.cizim()` ile okunur.
export const DRAW_COUNTS = { tam: 0, hafif: 0, tasma: 0 };

// Her kutu icin son cizim olcegi -- limit cizgisi ve dokunma bunu okur.
const _olcek = new Map();
// Bir kutunun son cizim olcegi (mum adimi, fiyat araligi).
export const getChartScale = (kutuId) => _olcek.get(kutuId) || null;

function el(ad, ozellik = {}) {
  const e = document.createElementNS(NS, ad);
  for (const [k, v] of Object.entries(ozellik)) {
    if (v !== null && v !== undefined) e.setAttribute(k, String(v));
  }
  return e;
}

function katman(svg, sinif) {
  let g = svg.querySelector(`g.${sinif}`);
  if (!g) { g = el("g", { class: sinif }); svg.appendChild(g); }
  return g;
}

function svgHazirla(kap) {
  let svg = kap.querySelector("svg.mumSvg");
  if (!svg) {
    kap.innerHTML = "";
    svg = el("svg", { class: "mumSvg", width: "100%", height: "100%",
                      preserveAspectRatio: "none" });
    // 28.09.2026: "kZaman" (saatlik arka plan bantlari) EN ALTTA -- mumlarin
    // ALTINDA kalsin. "kZamanUst" (4H ust serit) EN USTTE -- mum fitilleri
    // onu ortmesin.
    for (const s of ["kZaman", "kGrid", "kHacim", "kMum", "kCizgi", "kAlt",
                     "kIz", "kSinyal", "kIlerleme", "kUst", "kZamanUst", "kImlec"]) {
      svg.appendChild(el("g", { class: s }));
    }
    kap.appendChild(svg);
  }
  return svg;
}

function cizgiYolu(dizi, x, yOl) {
  let d = "", basladi = false;
  for (let i = 0; i < dizi.length; i++) {
    const v = dizi[i];
    if (v == null || !Number.isFinite(v)) { basladi = false; continue; }
    d += `${basladi ? "L" : "M"}${x(i).toFixed(2)},${yOl(v).toFixed(2)}`;
    basladi = true;
  }
  return d;
}

// Fiyat ekseni etiketi -- arayuzun geri kalaniyla AYNI bicimleyici.
//
// 23.09.2026, Ismail: "fiyatta ki kusurat cok fazla". Eksen kendi sabit
// ondalik kurallarini kullaniyordu (0.41745 gibi); artik `formatPrice`
// ile anlamli basamaga gore yazilir ve sondaki sifirlar dusulur.
function eksenEtiketi(v) {
  // Eksen yalnizca OLCEK referansi; 4 anlamli basamak yeter (0.051692
  // yerine 0.05169). Fiyatin kendisi baslikta tam yaziliyor.
  return formatPrice(v, 4);
}

// YUZDE IZGARASI: her yatay kare fiyatin %1'i.
//
// 16.09.2026, Ismail: "her kare yuzde 1 gosterecek sekilde olacak, sanki
// bazen yanlis gosteriyor". Yuzde CARPIMSALDIR; sabit adimla (ortalama *
// 0.01) yalnizca grafigin ORTASINDA %1 tutuyor, asagida %1'den BUYUK,
// yukarida KUCUK cikiyordu. Olculmustu (ZEC 1000-1400):
//   altta 1008->1020 = %1.19 | ortada 1200->1212 = %1.00 | ustte 1380->1392 = %0.87
// Dogrusu: her cizgi bir oncekinin 1.01 KATI.
//
// 23.09.2026 EK: adim her zaman %1 kalirsa genis araliklarda (1D mini
// grafikte %30'luk menzil) cizgiler 2px'e siksip zemini boyuyor. Adim
// %1'in KATLARINDAN secilir; en az 6px aralik kalan ilk kat kullanilir --
// yani dar grafikte gercek %1, genisinde %2/%5/%10.
function izgaraCiz(grid, { az, en, y, W, anaYuk, sagKenar }) {
  if (!(az > 0) || !(en > az)) return [];
  const ADIMLAR = [1, 2, 5, 10, 25];
  let K = 0, py0 = 0, py1 = 0;
  for (const adim of ADIMLAR) {
    const k = 1 + adim / 100;
    // Iki komsu cizginin piksel araligi (en dar yer: grafigin USTU).
    const aralik = Math.abs(y(en) - y(en / k));
    if (aralik >= 6) { K = k; break; }
  }
  if (!K) return [];
  const cizgiler = [];
  const bas = Math.pow(K, Math.floor(Math.log(az) / Math.log(K)));
  for (let v = bas; v <= en * K; v *= K) {
    if (v < az) continue;
    const py = y(v);
    if (py < 0 || py > anaYuk + KENAR.ust) continue;
    cizgiler.push(py);
    grid.appendChild(el("line", { x1: 0, y1: py.toFixed(2), x2: W - sagKenar,
                                  y2: py.toFixed(2), class: "gridCizgi yuzdeCizgi" }));
  }
  // Dikey cizgiler: KARE gorunum icin yatay cizgilerin GERCEK piksel
  // araligini kullan (carpimsal oldugu icin sabit degil -- ortalamasi).
  if (cizgiler.length > 1) {
    const adimPx = Math.abs(cizgiler[0] - cizgiler.at(-1)) / (cizgiler.length - 1);
    if (adimPx > 6) {
      for (let px = 0; px <= W - sagKenar; px += adimPx) {
        grid.appendChild(el("line", { x1: px.toFixed(2), y1: KENAR.ust,
          x2: px.toFixed(2), y2: (KENAR.ust + anaYuk).toFixed(2),
          class: "gridCizgi yuzdeCizgiDikey" }));
      }
    }
  }
  return cizgiler;
}

// Ana cizim. `secenek.gosterge` -> {ha, ema, bb, vwap, hacim, rsi, obv, atr}
// `secenek.eksen === false` -> sagdaki fiyat sutunu ciziLMEZ (mini kutular).  (eski: mumCizGenel)
// Mum grafigini cizer; katmanlari ayri ayri gunceller.
export function renderCandleChart(kutuId, mumlar, secenek = {}) {
  const kap = document.getElementById(kutuId);
  if (!kap) return null;
  if (!mumlar?.length) {
    kap.innerHTML = `<div class="yok">${secenek.bosMetin || "VERI YOK"}</div>`;
    _olcek.delete(kutuId);
    return null;
  }
  const G_ = secenek.gosterge || {};
  const W = kap.clientWidth || 600;
  const H = kap.clientHeight || 200;
  // Mini kutularda sagdaki fiyat sutunu 52px yer kapliyordu; 150px'lik bir
  // kartta bu alanin ucte biri demek ve mumlar goze gorunmez hale geliyordu
  // (Ismail: "mumun yanindaki fiyati kaldir, kucuk oldugundan mumlar
  // gozukmuyor"). Eksen yoksa yalnizca 2px nefes payi birakilir.
  const sagKenar = secenek.eksen === false ? 2 : KENAR.sag;
  const altPanel = (G_.rsi ? 1 : 0) + (G_.obv ? 1 : 0) + (G_.atr ? 1 : 0);
  const altYuk = altPanel ? Math.min(0.42, 0.16 * altPanel) * H : 0;
  const anaYuk = H - altYuk - KENAR.ust - KENAR.alt;

  const veri = G_.ha ? G.heikinAshi(mumlar) : mumlar;
  const gen = secenek.sabitGenislik ? (W - sagKenar) / mumlar.length : getCandleWidth();
  const kaydir = secenek.sabitGenislik ? 0 : getScrollX();
  const x = (i) => i * gen - kaydir + gen / 2;

  // gorunen aralik
  let ilk = Math.max(0, Math.floor(kaydir / gen) - 1);
  let son = Math.min(veri.length, Math.ceil((kaydir + W - sagKenar) / gen) + 1);
  if (son <= ilk) { ilk = 0; son = veri.length; }
  const gorunen = veri.slice(ilk, son);

  const kilit = secenek.sabitGenislik ? null : getPriceLock();
  let en = kilit ? kilit.en : -Infinity, az = kilit ? kilit.az : Infinity;
  if (!kilit) {
    for (const m of gorunen) { if (m.y > en) en = m.y; if (m.d < az) az = m.d; }
    if (secenek.ekFiyat) for (const f of secenek.ekFiyat) {
      if (f == null) continue;
      if (f > en) en = f; if (f < az) az = f;
    }
    const pay = (en - az) * 0.06 || en * 0.002 || 1;
    en += pay; az -= pay;
  }
  const ara = Math.max(1e-12, en - az);
  const y = (v) => KENAR.ust + (en - v) / ara * anaYuk;

  const svg = svgHazirla(kap);
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  DRAW_COUNTS.tam++;

  // --- %1 izgarasi + fiyat ekseni ---
  const grid = katman(svg, "kGrid");
  grid.replaceChildren();
  izgaraCiz(grid, { az, en, y, W, anaYuk, sagKenar });
  if (secenek.eksen !== false) {
    // FIYAT ETIKETLERI grafigin SAG KENARINA BINDIRILIR; ayri bir sutun
    // ayrilmaz (bkz. zoom.SAG_EKSEN_PX). Okunabilirlik icin her etiketin
    // arkasina ince bir zemin konur -- mumlarin uzerinde kaybolmasin.
    for (let i = 0; i <= 4; i++) {
      const v = az + ara * (i / 4);
      const yy = y(v);
      const yazi = eksenEtiketi(v);
      // Zemin: yazinin yaklasik eni (tek genislikli rakam ~4.6px @8px).
      const en_ = yazi.length * 4.6 + 6;
      grid.appendChild(el("rect", { x: W - en_ - 2, y: yy - 6,
                                    width: en_, height: 11, class: "eksenZemin" }));
      const t = el("text", { x: W - 5, y: yy + 3, "text-anchor": "end",
                             class: "eksenYazi" });
      t.textContent = yazi;
      grid.appendChild(t);
    }
  }

  // --- hacim ---
  const hac = katman(svg, "kHacim");
  hac.replaceChildren();
  // 29.09.2026, Ismail: "volume barda her borsaninki farkli renk olsun"
  // (CHCM). G_.hacimCokBorsa acikken VE veri (secenek.cokBorsaHacim,
  // ts->{bybit,okx,mexc,gate}) varsa her mum ayni barin icinde 5 borsa
  // dilimine BOLUNUR (yigilmis/stacked) -- toplam yukseklik AYNI normalize
  // mantigiyla (gorunen pencerede max toplama gore, %18 tavan). Veri
  // yoksa/kapaliysa ESKI tek-renk/yon davranisi DEGISMEDEN kalir.
  if (G_.hacim && G_.hacimCokBorsa && secenek.cokBorsaHacim) {
    const renkler = secenek.renkHacim || {};
    const BORSA_SIRA = ["binance", "bybit", "okx", "mexc", "gate"];
    const toplam = (m) => {
      const cb = secenek.cokBorsaHacim[m.t] || {};
      return (m.h || 0) + (cb.bybit || 0) + (cb.okx || 0) + (cb.mexc || 0) + (cb.gate || 0);
    };
    const hEn = Math.max(...gorunen.map(toplam), 1);
    for (let i = 0; i < gorunen.length; i++) {
      const m = gorunen[i], xi = x(ilk + i);
      const cb = secenek.cokBorsaHacim[m.t] || {};
      const genislik = Math.max(0.6, gen * GOVDE_ORANI);
      let taban = KENAR.ust + anaYuk;
      for (const ad of BORSA_SIRA) {
        const deger = ad === "binance" ? (m.h || 0) : (cb[ad] || 0);
        if (!deger) continue;
        const yuk = (deger / hEn) * (anaYuk * 0.18);
        taban -= yuk;
        hac.appendChild(el("rect", {
          x: xi - genislik / 2, y: taban, width: genislik, height: yuk,
          style: renkler[ad] ? `fill:${renkler[ad]}` : null }));
      }
    }
  } else if (G_.hacim) {
    const hEn = Math.max(...gorunen.map((m) => m.h), 1);
    for (let i = 0; i < gorunen.length; i++) {
      const m = gorunen[i], xi = x(ilk + i);
      const yuk = (m.h / hEn) * (anaYuk * 0.18);
      hac.appendChild(el("rect", {
        x: xi - gen * GOVDE_ORANI / 2, y: KENAR.ust + anaYuk - yuk,
        width: Math.max(0.6, gen * GOVDE_ORANI), height: yuk,
        class: m.k >= m.a ? "hacimArti" : "hacimEksi" }));
    }
  }

  // --- mumlar ---
  const mum = katman(svg, "kMum");
  mum.replaceChildren();
  const ince = gen < 2.2;
  const sonSira = veri.length - 1;
  for (let i = 0; i < gorunen.length; i++) {
    const m = gorunen[i], xi = x(ilk + i);
    const yukseliyor = m.k >= m.a;
    // SON MUM (henuz kapanmamis olan) ICI BOS cizilir.
    // Ismail, 23.09.2026: "son mumun icini bos yap" -- boylece hangi mumun
    // hala olustugu bir bakista ayirt edilir.
    const acikMum = (ilk + i) === sonSira;
    const sinif = (yukseliyor ? "mumArti" : "mumEksi") + (acikMum ? " mumAcik" : "");
    mum.appendChild(el("line", { x1: xi, y1: y(m.y), x2: xi, y2: y(m.d), class: sinif + " fitil" }));
    if (!ince) {
      const ya = y(Math.max(m.a, m.k)), yb = y(Math.min(m.a, m.k));
      mum.appendChild(el("rect", { x: xi - gen * GOVDE_ORANI / 2, y: ya,
        width: Math.max(0.6, gen * GOVDE_ORANI), height: Math.max(0.8, yb - ya), class: sinif }));
    }
  }

  // --- cizgiler (EMA / BB / VWAP) ---
  const ciz = katman(svg, "kCizgi");
  ciz.replaceChildren();
  const kapanis = veri.map((m) => m.k);
  if (G_.ema) {
    const donem = secenek.emaDonem || [7, 20, 48, 99];
    donem.forEach((n, idx) => {
      ciz.appendChild(el("path", { d: cizgiYolu(G.ema(kapanis, n), x, y),
                                   class: `emaCizgi ema${idx}`, fill: "none" }));
    });
  }
  if (G_.bb) {
    const b = G.bollinger(kapanis, 20, 2);
    for (const [ad, dz] of [["bbUst", b.ust], ["bbOrta", b.orta], ["bbAlt", b.alt]]) {
      ciz.appendChild(el("path", { d: cizgiYolu(dz, x, y), class: `bbCizgi ${ad}`, fill: "none" }));
    }
  }
  if (G_.vwap) {
    ciz.appendChild(el("path", { d: cizgiYolu(G.vwap(veri), x, y), class: "vwapCizgi", fill: "none" }));
  }

  // --- alt paneller ---
  const alt = katman(svg, "kAlt");
  alt.replaceChildren();
  if (altPanel) {
    const panelYuk = altYuk / altPanel;
    let ust = KENAR.ust + anaYuk + 4;
    const panelCiz = (dizi, sinif, sabitAralik) => {
      const gec = dizi.slice(ilk, son).filter((v) => v != null && Number.isFinite(v));
      if (!gec.length) { ust += panelYuk; return; }
      const pEn = sabitAralik ? sabitAralik[1] : Math.max(...gec);
      const pAz = sabitAralik ? sabitAralik[0] : Math.min(...gec);
      const pAra = Math.max(1e-12, pEn - pAz);
      const py = (v) => ust + (pEn - v) / pAra * (panelYuk - 6);
      alt.appendChild(el("line", { x1: 0, y1: ust, x2: W - sagKenar, y2: ust, class: "gridCizgi" }));
      alt.appendChild(el("path", { d: cizgiYolu(dizi, x, py), class: sinif, fill: "none" }));
      ust += panelYuk;
    };
    if (G_.rsi) panelCiz(G.rsi(kapanis), "rsiCizgi", [0, 100]);
    if (G_.obv) panelCiz(G.obv(veri), "obvCizgi");
    if (G_.atr) panelCiz(G.atr(veri), "atrCizgi");
  }

  _olcek.set(kutuId, { W, H, gen, kaydir, ilk, son, en, az, ara, anaYuk,
                       ustKenar: KENAR.ust, sagKenar,
                       xOf: x, yOf: y, toplam: veri.length, mumlar: veri });
  return _olcek.get(kutuId);
}

// Islem noktalarini (giris/cikis) ayri katmana cizer -- mum katmani
// guncellenirken bunlar YERINDE KALIR.
// Giris/cikis islem noktalarini ayri katmana cizer.
export function renderTradeMarkers(kutuId, izler) {
  const kap = document.getElementById(kutuId);
  const svg = kap?.querySelector("svg.mumSvg");
  const o = getChartScale(kutuId);
  if (!svg || !o) return;
  const g = katman(svg, "kIz");
  g.replaceChildren();
  for (const iz of izler || []) {
    const i = o.mumlar.findIndex((m) => m.t >= iz.ts);
    if (i < 0) continue;
    const xx = o.xOf(i), yy = o.yOf(iz.fiyat);
    if (xx < -20 || xx > o.W) continue;
    g.appendChild(el("circle", { cx: xx, cy: yy, r: 3.2,
      class: `izNokta ${iz.tur === "cikis" ? "izCikis" : "izGiris"}`,
      style: iz.renk ? `stroke:${iz.renk};fill:${iz.renk}` : null }));
  }
}

// 27.09.2026, Ismail: "stratejinin secttigini mavi ucgen ile isaretle,
// gecmis mum uzerinde stratejinin nerede girecegini gorelim". Ayri katman
// (`kSinyal`) -- mum/iz katmanlariyla CAKISMAZ, STRATEJI dugmesiyle
// bagimsiz gosterilip gizlenir. `/yerel/gecmis-sinyal`'in `noktalar`
// listesini (ts, fiyat) alir.
// `renk`: Ayarlar sayfasindaki `renk_strateji_sinyal` -- verilmezse
// CSS varsayilani (#3399CC) kullanilir.
// `kapsayan`: 04.10.2026, Ismail: "strateji aktifken soldaki 1d 4h 1h ve 5m'de nerelere
// denk geliyor ise gostersin". Mini grafikte (buyuk zaman dilimi) 5m sinyali, onu
// ICINE ALAN mumun (t <= ts olan SON mum) ustune konur; ayni mumdaki sinyaller tek cizgi.
export function renderStrategyMarkers(kutuId, noktalar, renk, { kapsayan = false } = {}) {
  const kap = document.getElementById(kutuId);
  const svg = kap?.querySelector("svg.mumSvg");
  const o = getChartScale(kutuId);
  if (!svg || !o) return;
  const g = katman(svg, "kSinyal");
  g.replaceChildren();
  // 02.10.2026, Ismail: "strategy rengini giris noktasina nokta koy ve noktanin
  // oldugu yerde dikey turkuaz cizgi ciz". Ucgen yerine: sinyal mumunun
  // kapanisinda strateji renginde NOKTA + grafik boyunca DIKEY cizgi.
  const ust = o.ustKenar, alt = o.ustKenar + o.anaYuk;
  const cizilen = new Set();
  for (const n of noktalar || []) {
    let i;
    if (kapsayan) {
      i = -1;
      for (let j = o.mumlar.length - 1; j >= 0; j--) { if (o.mumlar[j].t <= n.ts) { i = j; break; } }
      if (i < 0 || cizilen.has(i)) continue;
      cizilen.add(i);
    } else {
      i = o.mumlar.findIndex((m) => m.t >= n.ts);
    }
    if (i < 0) continue;
    const xx = o.xOf(i), yy = o.yOf(n.fiyat);
    if (xx < -20 || xx > o.W) continue;
    g.appendChild(el("line", { x1: xx.toFixed(2), y1: ust, x2: xx.toFixed(2), y2: alt,
      // 02.10.2026: cizgi rengi = girisin sonucu (once +%2 yesil, once -%2 kirmizi)
      class: "sinyalDikey" + (n.sonuc === "hedef" ? " sdHedef" : n.sonuc === "stop" ? " sdStop" : "") }));
    g.appendChild(el("circle", { cx: xx.toFixed(2), cy: yy.toFixed(2), r: 3.6, class: "sinyalNokta",
      style: renk ? `fill:${renk}` : null }));
  }
}

// 27.09.2026, Ismail: "botun ve stratejinin GERCEKTEN girdigi coinlerde
// giris noktasindan saga dogru yatay uzasin, %1.2yi gectigi noktaya kadar".
// Sadece GERCEK girisler (bot + cuzdan) icin -- hipotez ucgeni degil.
// Hedefe 10 mum icinde ulasilmazsa cizgi 10. mumda biter, daha ileri
// UZAMAZ (kullanicinin acik talebi).
const ILERLEME_HEDEF_YUZDE = 1.2;
const ILERLEME_MAKS_MUM = 10;
export function renderEntryProgressLines(kutuId, girisler) {
  const kap = document.getElementById(kutuId);
  const svg = kap?.querySelector("svg.mumSvg");
  const o = getChartScale(kutuId);
  if (!svg || !o) return;
  const g = katman(svg, "kIlerleme");
  g.replaceChildren();
  for (const giris of girisler || []) {
    const i0 = o.mumlar.findIndex((m) => m.t >= giris.ts);
    if (i0 < 0) continue;
    const hedef = giris.fiyat * (1 + ILERLEME_HEDEF_YUZDE / 100);
    const son = Math.min(o.mumlar.length - 1, i0 + ILERLEME_MAKS_MUM);
    let i1 = son;
    for (let j = i0; j <= son; j++) {
      if (o.mumlar[j].y >= hedef) { i1 = j; break; }
    }
    const x0 = o.xOf(i0), x1 = o.xOf(i1), yy = o.yOf(giris.fiyat);
    if (x1 < -20 || x0 > o.W) continue;
    g.appendChild(el("line", { x1: x0, y1: yy, x2: x1, y2: yy,
      class: "ilerlemeCizgisi", style: giris.renk ? `stroke:${giris.renk}` : null }));
  }
}

// 28.09.2026, Ismail: "TM" dugmesi -- 5m grafikte GERCEK saat/4-saat
// sinirlarina gore arka plan bantlari. Saatlik bant: o saatin KENDI
// yonune (o saatteki ILK ACILIS vs SON KAPANIS) gore yesil/kirmizi.
// 4H serit: grafigin EN USTUNDE, yuksekligin %5'i, 48 mumluk gercek
// 4-saatlik dilimlere gore renklenen kareler.
// Ismail: "oturmuyor, algilanmiyor" -- ayni renkte ART ARDA iki donem
// yan yana gelince sinir GORUNMUYORDU. Cozum: KOMSU donemler HEP FARKLI
// gorunurlukte -- gercek saat/4-saat KOVA NUMARASININ tek/cift olusuna
// gore GORUNURLUK (fill-opacity) iki deger arasinda degisir (renk DEGIL,
// saydamlik degisir) -- boylece iki yesil saat yan yana bile olsa sinir
// HER ZAMAN sezilir. Saatlik bant %2/%5, 4H ust serit %7/%11 (CSS'te
// zbAlt/zbYuksek, zuAlt/zuYuksek -- deger denemeyle bulundu: %10 sabit ->
// sinir yok, %5/%10 -> 1h iyi 4h belirsiz, %3/%6 -> 4h yine belirsiz,
// son karar: 1h ve 4h AYRI cift, 4h daha yuksek taban).
// KURAL (Ismail: "kapanmamis mumlar icin hesap yapmaya calismasin, acilan
// mum da 1-2 mum beklesin, hatasiz olsun"):
//   - Dizinin SON elemani HER ZAMAN canli/kapanmamis sayilir, hesaba
//     KATILMAZ (mumlar.length-1 haric tutulur).
//   - Yeni baslayan (en guncel) saat/4-saat dilimi en az 2 KAPANMIS mum
//     icermiyorsa o dilim HIC CIZILMEZ (henuz cok taze).
const SAAT_MS = 3600000, DORT_SAAT_MS = SAAT_MS * 4;

// Mumlari (son/canli mum HARIC) GERCEK saat sinirina oturan gruplara
// ayirir. Her grup: {ilk, son, yon, kova} -- ilk/son = mumlar dizisindeki
// INDEKS araligi (ikisi de dahil), yon = "yesil" | "kirmizi", kova =
// GERCEK zaman kovasi NUMARASI (komsu donem alternatifligi bundan gelir,
// ekrana gore DEGIL -- kaydirinca/yakinlastirinca ayni saat hep ayni
// gorunurlukte kalsin diye).
function periyotGruplariniBul(mumlar, periyotMs) {
  const n = mumlar.length;
  const kapaliSon = n - 2;             // son eleman (n-1) canli/kapanmamis
  if (kapaliSon < 0) return [];
  const gruplar = [];
  let baslangic = 0;
  let mevcutKova = Math.floor(mumlar[0].t / periyotMs);
  for (let i = 1; i <= kapaliSon; i++) {
    const kova = Math.floor(mumlar[i].t / periyotMs);
    if (kova !== mevcutKova) {
      gruplar.push([baslangic, i - 1, mevcutKova]);
      baslangic = i;
      mevcutKova = kova;
    }
  }
  gruplar.push([baslangic, kapaliSon, mevcutKova]);
  const sonGrup = gruplar[gruplar.length - 1];
  if (sonGrup[1] - sonGrup[0] + 1 < 2) gruplar.pop();   // en yeni dilim cok taze
  return gruplar.map(([ilk, son, kova]) => ({
    ilk, son, kova,
    yon: mumlar[son].k >= mumlar[ilk].a ? "yesil" : "kirmizi",
  }));
}

export function renderTimeBands(kutuId, mumlar) {
  const kap = document.getElementById(kutuId);
  const svg = kap?.querySelector("svg.mumSvg");
  const o = getChartScale(kutuId);
  const saatlik = svg ? katman(svg, "kZaman") : null;
  const ustSerit = svg ? katman(svg, "kZamanUst") : null;
  if (saatlik) saatlik.replaceChildren();
  if (ustSerit) ustSerit.replaceChildren();
  if (!svg || !o || !mumlar?.length) return;

  const ustY = o.ustKenar, altY = o.ustKenar + o.anaYuk;
  const seritYuk = o.anaYuk * 0.05;

  for (const g of periyotGruplariniBul(mumlar, SAAT_MS)) {
    const x0 = o.xOf(g.ilk) - o.gen / 2, x1 = o.xOf(g.son) + o.gen / 2;
    if (x1 < 0 || x0 > o.W) continue;
    saatlik.appendChild(el("rect", {
      x: x0.toFixed(1), y: ustY.toFixed(1),
      width: Math.max(0, x1 - x0).toFixed(1), height: (altY - ustY).toFixed(1),
      class: `zamanBant ${g.yon === "yesil" ? "zbArti" : "zbEksi"} ${g.kova % 2 === 0 ? "zbAlt" : "zbYuksek"}`,
    }));
  }
  for (const g of periyotGruplariniBul(mumlar, DORT_SAAT_MS)) {
    const x0 = o.xOf(g.ilk) - o.gen / 2, x1 = o.xOf(g.son) + o.gen / 2;
    if (x1 < 0 || x0 > o.W) continue;
    ustSerit.appendChild(el("rect", {
      x: x0.toFixed(1), y: ustY.toFixed(1),
      width: Math.max(0, x1 - x0).toFixed(1), height: seritYuk.toFixed(1),
      class: `zamanUst ${g.yon === "yesil" ? "zuArti" : "zuEksi"} ${g.kova % 2 === 0 ? "zuAlt" : "zuYuksek"}`,
    }));
  }
}

// Yatay fiyat cizgisi (limit / stop / hedef) -- ust katman.
export function renderPriceLine(kutuId, fiyat, sinif = "limitCizgi", etiket) {
  const kap = document.getElementById(kutuId);
  const svg = kap?.querySelector("svg.mumSvg");
  const o = getChartScale(kutuId);
  if (!svg || !o) return;
  const g = katman(svg, "kUst");
  g.querySelectorAll(`.${sinif}`).forEach((x) => x.remove());
  if (fiyat == null) return;
  const yy = o.yOf(fiyat);
  g.appendChild(el("line", { x1: 0, y1: yy, x2: o.W - o.sagKenar, y2: yy, class: sinif }));
  if (etiket) {
    // Etiket cizginin ORTASINDA durur (Ismail: "switch i acinca yatay fiyat
    // cizgisi cikiyor ya fiyat ortada dursun"). Eskiden sol kenarda (x=4)
    // duruyordu ve mumlarin arasinda kayboluyordu.
    const t = el("text", { x: (o.W - o.sagKenar) / 2, y: yy - 4,
                           "text-anchor": "middle", class: sinif + " etiket" });
    t.textContent = etiket;
    g.appendChild(t);
  }
}

// SON MUMU tek basina gunceller -- TUM grafigi yeniden cizmeden.
//
// 23.09.2026, Ismail: "niye takiliyor ya, eski sistemde takilmiyordu".
// Her websocket tikinde `renderCandleChart` cagriliyordu; o da izgarayi,
// mumlari, gosterge cizgilerini ve alt panelleri BASTAN kuruyor
// (~350 SVG dugumu). Saniyede 20 tik gelince saniyede 60'a kadar tam
// yeniden cizim oluyor: JS ucuz ama tarayici her karede tum SVG icin
// stil+yerlesim+boyama yapmak zorunda kaliyordu.
//
// Tik geldiginde DEGISEN TEK SEY son mumun kapanisi (ve tepe/dibi).
// Bu fonksiyon yalnizca o mumun iki ogesini oynatir.
//
// Fiyat mevcut olcegin DISINA tasarsa `false` doner; cagiran taraf o
// zaman tam cizim yapar (olcek degismistir).
export function updateLastCandle(kutuId, mum) {
  const o = _olcek.get(kutuId);
  const kap = document.getElementById(kutuId);
  const svg = kap?.querySelector("svg.mumSvg");
  if (!o || !svg || !mum) return false;
  // 02.10.2026: canli (son) mum EKRANDA DEGILSE (grafik geriye kaydirilmis)
  // kMum'un son ogesi ESKI bir mumdur -- onu canli fiyatla BOZMA.
  if (o.son < o.toplam) return true;
  // Mum dizisi son cizimden sonra degistiyse (yeni mum) hafif yol gecersiz.
  if (mum.t !== o.mumlar.at(-1)?.t) return false;
  // Olcegin disina tasti -> tam cizim gerek.
  if (mum.y > o.en || mum.d < o.az) { DRAW_COUNTS.tasma++; return false; }
  const g = svg.querySelector("g.kMum");
  if (!g || g.childElementCount < 2) return false;

  // Son mumun ogeleri katmanin SONUNDA: once fitil, sonra (varsa) govde.
  const cocuk = g.children;
  const sonGovde = cocuk[cocuk.length - 1];
  const sonFitil = cocuk[cocuk.length - 2];
  const govdeMi = sonGovde.tagName === "rect";
  const fitil = govdeMi ? sonFitil : cocuk[cocuk.length - 1];
  if (!fitil || fitil.tagName !== "line") return false;

  const yukseliyor = mum.k >= mum.a;
  const sinif = (yukseliyor ? "mumArti" : "mumEksi") + " mumAcik";
  fitil.setAttribute("y1", o.yOf(mum.y));
  fitil.setAttribute("y2", o.yOf(mum.d));
  fitil.setAttribute("class", sinif + " fitil");
  if (govdeMi) {
    const ya = o.yOf(Math.max(mum.a, mum.k)), yb = o.yOf(Math.min(mum.a, mum.k));
    sonGovde.setAttribute("y", ya);
    sonGovde.setAttribute("height", Math.max(0.8, yb - ya));
    sonGovde.setAttribute("class", sinif);
  }
  DRAW_COUNTS.hafif++;
  return true;
}

// DOKUNMA IMLECI: parmagin/farenin bastigi mumun TAM ORTASINDAN gecen
// dikey cizgi.
//
// 23.09.2026, Ismail: "dokundugum yerde dikine tam mumun ortasina denk
// gelecek sekilde YALNIZCA DOKUNUNCA cikacak dikey cizgi olmali".
// Bu yuzden cizgi serbest x'e degil, mum merkezine (`xOf(i)`) oturur ve
// `indeks === null` gelince katman bosaltilir (parmak kalkinca kaybolur).
// Basili tutulan mumun ortasindan gecen dikey imleci cizer.
export function renderCrosshair(kutuId, indeks) {
  const kap = document.getElementById(kutuId);
  const svg = kap?.querySelector("svg.mumSvg");
  const o = getChartScale(kutuId);
  if (!svg || !o) return;
  const g = katman(svg, "kImlec");
  g.replaceChildren();
  if (indeks == null) return;
  const i = Math.max(0, Math.min(o.toplam - 1, Math.round(indeks)));
  const xx = o.xOf(i);
  if (xx < 0 || xx > o.W - o.sagKenar) return;
  g.appendChild(el("line", { x1: xx.toFixed(2), y1: 0,
                             x2: xx.toFixed(2), y2: o.H, class: "imlecCizgi" }));
}

// Mini kutu: sabit genislik, gosterge yok, fiyat ekseni yok.  (eski: trKutuCiz)
export function renderMiniChart(kutuId, mumlar, secenek = {}) {
  // 27.09.2026, Ismail: "HA tusu sol taraftakileri degistirmiyordu" --
  // burada `gosterge:{}` HER ZAMAN ZORLANIYORDU, cagiranin gonderdigi
  // gosterge (ornegin HA) sessizce siliniyordu. Artik cagiranin
  // gonderdigi KULLANILIR, hicbir sey gonderilmezse bos kalir.
  return renderCandleChart(kutuId, mumlar,
    { ...secenek, sabitGenislik: true, gosterge: secenek.gosterge || {}, eksen: false });
}
