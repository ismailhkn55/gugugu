// trade.js -- ana coin tablosu.
//
// Eski `ciz()` (2636) ~95 global degiskenden besleniyordu ve kolon adlari
// sunucunun alan adlarindan FARKLI ikinci bir adlandirma katmani
// kullaniyordu (`deg24` -> `d24`, `hacim_x` -> `hacimX`). Burada sunucunun
// alan adlari DOGRUDAN kullaniliyor -- bir ad, bir anlam.
//
// DOM yapisi ve CSS sinif adlari DEGISMEDI: gercek bir <table>, basliklar
// <th>, hucreler <td class="k-sira|k-sembol|... arti|eksi|notr|bar|guclu">.
import { apiGet } from "../api.js";
import { coinName, formatPrice } from "../format.js";
import { getActivePage, registerPoll, sharePollResult } from "../poll.js";
import { getState, getTercih, setState, selectRows } from "../store.js";
import { createSocketManager } from "../live/socketManager.js";
import { renderConnectionBadge, renderDataAge } from "../ui/shell.js";
import { renderTrailCell } from "../ui/marketDetail.js";

// Kolon tanimlari -- `alan` adlari SUNUCUNUNKILERLE AYNI.
export const KOLONLAR = [
  { alan: "rank", baslik: "#", g: 34, tip: "sira", k: "k-sira" },
  { alan: "sembol", baslik: "SEMBOL", g: 64, tip: "metin", k: "k-sembol" },
  { alan: "fiyat", baslik: "FIYAT", g: 92, tip: "fiyat", k: "k-fiyat" },
  { alan: "_canli", baslik: "CANLI%", g: 56, tip: "canli", k: "k-wspct" },
  { alan: "hiz", baslik: "HIZ", g: 48, tip: "pct", olcek: 5, k: "k-hiz" },
  { alan: "sira_izi", baslik: "IZ", g: 112, tip: "iz", k: "iz k-iz" },
  { alan: "deg24", baslik: "24s", g: 54, tip: "pct", olcek: 40 },
  { alan: "gun_pct", baslik: "GUN%", g: 52, tip: "pct", olcek: 25 },
  { alan: "deg5m", baslik: "5dk", g: 44, tip: "pct", olcek: 1.5 },
  { alan: "deg10m", baslik: "10dk", g: 46, tip: "pct", olcek: 2 },
  { alan: "deg15m", baslik: "15dk", g: 46, tip: "pct", olcek: 2.5 },
  { alan: "deg30m", baslik: "30dk", g: 46, tip: "pct", olcek: 4 },
  { alan: "deg1h", baslik: "1s", g: 48, tip: "pct", olcek: 6 },
  { alan: "deg2h", baslik: "2s", g: 48, tip: "pct", olcek: 8 },
  { alan: "deg4h", baslik: "4s", g: 48, tip: "pct", olcek: 10 },
  { alan: "deg8h", baslik: "8s", g: 48, tip: "pct", olcek: 14 },
  // 26.09.2026, Ismail: FARK = yesil degisim toplami - |kirmizi degisim
  // toplami| (her mum ONCEKI kapanisina gore olculur, 128 mum). Renk degerin
  // isaretinden gelir: negatifse kirmizilar baskin.
  // KARE = son 128 mumun fiyat araligi % (1% = 1 izgara karesi); nötr renk.
  // YUKSELIS = son kapanan mumun en yuksek degeri / pencere en dusuk degeri - 1
  // (pencere dibinden tepeye yukselis %); KARE'yi asmaz, hep pozitif.
  { alan: "fark128", baslik: "FARK", g: 76, tip: "pct", olcek: 40 },
  { alan: "kare128", baslik: "KARE", g: 56, tip: "kare" },
  { alan: "yukselis128", baslik: "YUKSELIS", g: 64, tip: "pct", olcek: 100 },
  { alan: "rsi", baslik: "RSI", g: 44, tip: "rsi" },
  { alan: "rsi_egim", baslik: "EGIM", g: 48, tip: "sayi1" },
  { alan: "atr_pct", baslik: "ATR%", g: 48, tip: "sayi2" },
  { alan: "hacim", baslik: "HACIM", g: 64, tip: "hacim" },
  { alan: "hacim_x", baslik: "xH", g: 46, tip: "sayi2" },
  { alan: "obv_kesim", baslik: "OBV", g: 64, tip: "obv" },
  { alan: "cci", baslik: "CCI", g: 52, tip: "cci" },
  { alan: "kdj_j", baslik: "KDJ-J", g: 52, tip: "kdj" },
  { alan: "ha_ardisik_yesil", baslik: "HA", g: 40, tip: "tam" },
  { alan: "rank_hiz", baslik: "sHIZ", g: 44, tip: "sira2" },
  { alan: "rank_atr", baslik: "sATR", g: 44, tip: "sira2" },
  { alan: "yesile_donus_mum", baslik: "YSL", g: 40, tip: "tam" },
];

const bicim = {
  sira: (v) => (v == null ? "·" : v),
  sira2: (v) => (v == null ? "·" : v),
  metin: (v) => (v == null ? "·" : v),
  tam: (v) => (v == null ? "·" : Math.round(v)),
  sayi1: (v) => (v == null ? "·" : (+v).toFixed(1)),
  sayi2: (v) => (v == null ? "·" : (+v).toFixed(2)),
  rsi: (v) => (v == null ? "·" : (+v).toFixed(0)),
  cci: (v) => (v == null ? "·" : (+v).toFixed(0)),
  kdj: (v) => (v == null ? "·" : (+v).toFixed(0)),
  pct: (v) => (v == null ? "·" : (v > 0 ? "+" : "") + (+v).toFixed(Math.abs(v) >= 100 ? 0 : 1)),
  kare: (v) => (v == null ? "·" : Math.round(+v)),
  hacim: (v) => {
    if (v == null) return "·";
    const f = +v;
    if (f >= 1e9) return (f / 1e9).toFixed(1) + "B";
    if (f >= 1e6) return (f / 1e6).toFixed(1) + "M";
    if (f >= 1e3) return (f / 1e3).toFixed(0) + "K";
    return f.toFixed(0);
  },
};

// --- tablo durumu (bu modulun kendi ici, global DEGIL) ---
let _siralama = "rank";
let _artan = true;
let _filtre = "";
let _soket = null;
let _wsIlk = new Map();     // sembol -> websocket'te ILK gorulen fiyat
let _wsSon = new Map();     // sembol -> son fiyat
let _kuruldu = false;
let _bekleyen = new Map();  // sembol -> onceki fiyat (kare basina toplu yazim)
let _kareBekliyor = false;

// Websocket'e gore yuzde degisim.
function wsYuzde(sembol) {
  const ilk = _wsIlk.get(sembol);
  const son = _wsSon.get(sembol);
  return ilk && son ? (son / ilk - 1) * 100 : null;
}

// Tek hucre.
function hucre(k, s) {
  const v = k.alan === "_canli" ? null : s[k.alan];
  let sinif = "", ic = (bicim[k.tip] || ((x) => x))(v);

  if (k.alan === "sembol") ic = coinName(v);      // USDT yazilmaz

  if (k.tip === "fiyat") {
    const f = _wsSon.get(s.sembol);
    ic = `<span class="fiyatDeger">${formatPrice(f ?? v)}</span>`;
  } else if (k.tip === "canli") {
    const yz = wsYuzde(s.sembol);
    sinif = yz == null ? "notr" : yz > 0 ? "arti" : yz < 0 ? "eksi" : "notr";
    ic = yz == null ? "·" : (yz > 0 ? "+" : "") + yz.toFixed(2) + "%";
  } else if (k.tip === "pct") {
    sinif = v > 0 ? "arti" : v < 0 ? "eksi" : "notr";
    if (v != null && Math.abs(v) >= (k.olcek || 10) * 0.6) sinif += " guclu";
    const oran = v == null ? 0 : Math.min(100, Math.abs(v) / (k.olcek || 10) * 100);
    ic = `<span style="width:${oran}%;background:currentColor"></span>` + ic;
    sinif += " bar";
  } else if (k.tip === "kare") {
    // KARE: son 128 mumun fiyat araligi % (1% = 1 izgara karesi).
    // Buyuk aralik ne iyi ne kotu -> notr renk.
    sinif = "notr";
  } else if (k.tip === "rsi") {
    sinif = v >= 70 ? "rsi-asiri" : v <= 30 ? "rsi-dip" : "notr";
  } else if (k.tip === "cci") {
    sinif = v > 100 ? "arti" : v < -100 ? "eksi" : "notr";
  } else if (k.tip === "kdj") {
    sinif = v > 80 ? "rsi-asiri" : v < 20 ? "rsi-dip" : "notr";
  } else if (k.tip === "sayi1" || k.tip === "tam") {
    sinif = v > 0 ? "arti" : v < 0 ? "eksi" : "notr";
  } else if (k.tip === "sira2") {
    sinif = "notr";
  } else if (k.tip === "iz") {
    ic = renderTrailCell(v);
  } else if (k.tip === "obv") {
    if (v == null) { sinif = "notr"; ic = "·"; }
    else {
      const yon = v > 0, bar = Math.abs(v) - 1, aci = s.obv_aci;
      sinif = (yon ? "arti" : "eksi") + (Math.abs(v) <= 3 ? " guclu" : "");
      ic = `<span title="${yon ? "OBV sinyalin ustunde" : "OBV sinyalin altinda"}, ${bar} bar once kesti">` +
           `${yon ? "▲" : "▼"}${bar}b<small style="opacity:.55;margin-left:3px">` +
           `${aci == null ? "" : (aci >= 0 ? "+" : "") + (+aci).toFixed(0) + "°"}</small></span>`;
    }
  }
  return `<td class="${k.k || ""} ${sinif}" style="width:${k.g}px;min-width:${k.g}px">${ic}</td>`;
}

// Ana tablonun baslik hucreleri (HTML). ORTAK: SECILENLER de bunu kullanir.
// 26.09.2026, Ismail: "secilenler ekraninda anasayfada gozuktugu gibi
// degerlerin TAMAMI gozukecek; burayi bozup duruyorsun". Seçilenler artik
// ayri bir 9 kolonluk kopya DEGIL -- ayni KOLONLAR + ayni hucre().
// `siraNo`: en basa 1'den sayan NO kolonu ekler; rank kolonunun basligi
// "ANA #" olur (SECILENLER: 26.09.2026, Ismail "onune bir sira no koy").
export function buildTableHead({ siraNo = false } = {}) {
  const no = siraNo
    ? `<th class="k-sira" title="bu listedeki sira" style="width:34px;min-width:34px">NO</th>` : "";
  return no + KOLONLAR.map((k) =>
    `<th data-a="${k.alan}" class="${k.k || ""}" title="${k.alan}"
        style="width:${k.g}px;min-width:${k.g}px">${siraNo && k.alan === "rank" ? "ANA #" : k.baslik}</th>`).join("");
}

// Ana tablonun satirlari (HTML), verilen SIRAYLA. ORTAK: SECILENLER de kullanir.
export function buildTableRows(liste, { siraNo = false } = {}) {
  return liste.map((s, i) =>
    `<tr data-sembol="${s.sembol}" data-zirve="${s.rank <= 3 ? 1 : 0}">` +
    (siraNo ? `<td class="k-sira" style="width:34px;min-width:34px">${i + 1}</td>` : "") +
    KOLONLAR.map((k) => hucre(k, s)).join("") + "</tr>").join("");
}

// Tablo basligini cizer.
function basliklariCiz() {
  const b = document.getElementById("basliklar");
  if (!b) return;
  b.innerHTML = buildTableHead();
  b.addEventListener("click", (e) => {
    const th = e.target.closest("th");
    if (!th) return;
    const a = th.dataset.a;
    if (a === _siralama) _artan = !_artan;
    else { _siralama = a; _artan = a === "rank" || a === "sembol"; }
    renderSymbolTable();
  });
}

function siralananListe() {
  let liste = selectRows().slice();
  if (_filtre) liste = liste.filter((s) => s.sembol.toLowerCase().includes(_filtre));
  if (getTercih("sadeceYukselen")) liste = liste.filter((s) => s.deg24 > 0);
  return sortRows(liste, _siralama, _artan);
}

// Satirlari bir kolona gore siralar (yerinde). ORTAK: SECILENLER de kullanir.
export function sortRows(liste, anahtar, _artan) {
  liste.sort((x, y) => {
    let a, b;
    if (anahtar === "_canli") {
      a = wsYuzde(x.sembol); b = wsYuzde(y.sembol);
      if (a == null && b == null) return 0;
      if (a == null) return 1;
      if (b == null) return -1;
      return _artan ? a - b : b - a;
    }
    if (anahtar === "sira_izi") {
      a = x.sira_izi?.at(-1) ?? 9999; b = y.sira_izi?.at(-1) ?? 9999;
    } else { a = x[anahtar]; b = y[anahtar]; }
    if (typeof a === "string") return _artan ? a.localeCompare(b) : b.localeCompare(a);
    a = a ?? -1e12; b = b ?? -1e12;
    return _artan ? a - b : b - a;
  });
  return liste;
}

// Tabloyu cizer.  (eski: ciz)
export function renderSymbolTable() {
  const govde = document.getElementById("govde");
  if (!govde) return;
  const liste = siralananListe();
  govde.innerHTML = buildTableRows(liste);

  const adet = document.getElementById("adet");
  if (adet) adet.textContent = liste.length;
  for (const th of document.getElementById("basliklar")?.children || []) {
    th.classList.toggle("aktif", th.dataset.a === _siralama);
    th.classList.toggle("artan", _artan);
  }
  const kb = KOLONLAR.find((k) => k.alan === _siralama);
  const dSira = document.getElementById("dSira");
  if (dSira && kb) dSira.textContent = kb.baslik + (_artan ? " ↑" : " ↓");
  alignStickyHeader();
  return liste;
}

// Sabit kolonlarin `left` degerlerini GERCEK genisliklerle hizalar.
//
// 16.09.2026, Ismail: "sola dogru suruklerken NO SEMBOL FIYAT CANLI ve HIZ
// sabit kalsin". CSS'teki sabit `left` degerleri kolon genisliklerinin tam
// beklenen degerde olduguna guveniyordu; gercekte SEMBOL 64 yerine 81px
// cikiyor ve zincir kayiyordu. Cozum: gercek genislikleri OLC, kumulatif yaz.
//
// 23.09.2026 KILITLENME DUZELTMESI (Ismail: "kilitleniyor").
// Onceki surum her satirin her hucresinde ONCE yazip SONRA okuyordu
// (`style.left = ...` ardindan `getBoundingClientRect()`), yani 213 satir x
// 5 hucre = 1065 kez ZORUNLU YERLESIM HESABI tetikliyordu. CDP ornekleyici
// profili olctu: `getBoundingClientRect` 35 saniyenin 10.7 saniyesini
// yiyordu (%30 CPU) ve kareler 2.7 saniyeye kadar donuyordu.
// Kolon genislikleri TUM satirlarda ayni oldugu icin bir kez olcmek yeter:
// once 5 olcum, sonra saf yazma. 1065 yerleşim -> 5.  (eski: stickyHizala)
// Sabit kolonlarin yatay konumunu gercek genisliklerle hizalar.
// `govdeId` / `baslikId`: ayni hizalama SECILENLER tablosunda da kullanilir.
// `sabit`: soldan kac kolon sabit (anasayfa 5; SECILENLER NO ile 6).
export function alignStickyHeader(govdeId = "govde", baslikId = "basliklar", sabit = 5) {
  const tr = document.querySelector(`#${govdeId} tr`);
  if (!tr) return;
  // ONCE OKU -- arada hic yazma olmasin ki yerlesim bir kez hesaplansin.
  const sol = [];
  let x = 0;
  for (let i = 0; i < sabit; i++) {
    const td = tr.children[i];
    if (!td) break;
    sol.push(x);
    x += td.getBoundingClientRect().width;
  }
  // SONRA YAZ -- bu dongude tek bir olcum yok.
  const basliklar = document.getElementById(baslikId);
  for (let i = 0; i < sol.length; i++) {
    const th = basliklar?.children[i];
    if (th) th.style.left = sol[i] + "px";
  }
  for (const satir of document.querySelectorAll(`#${govdeId} tr`)) {
    for (let i = 0; i < sol.length; i++) {
      const td = satir.children[i];
      if (!td) break;
      td.style.left = sol[i] + "px";
    }
  }
}

// Coine tiklandiginda islem ekranini acar.  (eski: coinAc)
export function openSymbol(sembol) {
  setState({ seciliSembol: sembol });
  const d = document.getElementById("dSecili");
  if (d) d.textContent = sembol;
  import("../ui/shell.js").then((m) => m.navigateToPage("islem"));
}

// Websocket'ten gelen fiyati KAYDEDER; DOM yazimini bir sonraki kareye
// erteler.
//
// 23.09.2026: aggTrade saniyede ~20 mesaj getiriyor ve her mesaj icin
// `document.querySelector` + hucre guncellemesi yapiliyordu. Profil bunu
// %5.7 CPU olarak gosterdi; 30 sembolde daha da artiyor. Ekranda saniyede
// 60'tan fazla guncelleme zaten gorunmez -- kare basina TEK yazim yeter.
// Websocket fiyatini kaydeder ve tablolara yazar. ORTAK: SECILENLER'in
// kendi soketi de bunu cagirir (CANLI% ve FIYAT orada da canli olsun).
export function recordLivePrice(sembol, fiyat, onceki) { canliYaz(sembol, fiyat, onceki); }

function canliYaz(sembol, fiyat, onceki) {
  if (!_wsIlk.has(sembol)) _wsIlk.set(sembol, fiyat);
  _wsSon.set(sembol, fiyat);
  _bekleyen.set(sembol, onceki);
  if (_kareBekliyor) return;
  _kareBekliyor = true;
  requestAnimationFrame(() => {
    _kareBekliyor = false;
    const kuyruk = [..._bekleyen];
    _bekleyen.clear();
    for (const [s, o] of kuyruk) hucreyeYaz(s, _wsSon.get(s), o);
  });
}

// Tek satirin fiyat ve CANLI% hucrelerini gunceller.
function hucreyeYaz(sembol, fiyat, onceki) {
  // Anasayfa (#govde) VE secilenler (#secGovde) tablosu -- ayni hucre kodu.
  for (const tr of document.querySelectorAll(
    `#govde tr[data-sembol="${sembol}"], #secGovde tr[data-sembol="${sembol}"]`)) {
    satiraYaz(tr, sembol, fiyat, onceki);
  }
}

function satiraYaz(tr, sembol, fiyat, onceki) {
  const f = tr.querySelector(".k-fiyat .fiyatDeger");
  if (f) {
    f.textContent = formatPrice(fiyat);
    if (onceki !== undefined && onceki !== fiyat) {
      f.classList.remove("yukari", "asagi");
      void f.offsetWidth;
      f.classList.add(fiyat > onceki ? "yukari" : "asagi");
    }
  }
  const c = tr.querySelector(".k-wspct");
  const yz = wsYuzde(sembol);
  if (c && yz != null) {
    c.textContent = (yz > 0 ? "+" : "") + yz.toFixed(2) + "%";
    c.className = "k-wspct " + (yz > 0 ? "arti" : yz < 0 ? "eksi" : "notr");
  }
}

// Sayfadan cikilinca canli akis aboneligi birakilir.
export function unmountTradePage() {
  _soket?.subscribeSymbols([]);
}

// Tabloyu tazeler (zamanlayici cagirir).  (eski: veriYenile)
export async function refreshSymbolTable() {
  const d = await apiGet("/yerel/ozet?n=400");
  if (!d) return null;
  setState({ satirlar: d.satir || [] });
  renderDataAge(d.ts);
  return d;
}

// Kac coine canli akis aboneligi acilacak.
//
// 23.09.2026, Ismail: "anasayfada 30 degil 10 tanesi websocket olsun bari,
// biraz hizlanir belki". Her abonelik saniyede birkac aggTrade mesaji
// demek; 30 sembolde gelen tik sayisi (ve her tik icin yapilan hucre
// guncellemesi) uc katina cikiyordu. Tablonun ust siralari zaten en cok
// bakilan yer.
const CANLI_SEMBOL_SAYISI = 10;

// Ilk N coine canli akis aboneligi.
function akisaAbone() {
  const liste = siralananListe().slice(0, CANLI_SEMBOL_SAYISI).map((x) => x.sembol);
  _soket?.subscribeSymbols(liste);
  rozetiTazele(liste.length);
}

// Rozete soketin O ANKI durumunu yazar.
//
// `onDurum` yalnizca DEGISIM aninda tetiklenir. Sayfaya geri donuldugunde
// soket zaten acik oldugu icin hicbir olay olmuyor ve rozet, baska bir
// sayfanin biraktigi eski yaziyla ("kapali") kaliyordu. Gezinti olcumu
// bunu acikca gosterdi: veri akarken (5000+ tick) rozet "kapali"ydi.
function rozetiTazele(adet) {
  if (!_soket || getActivePage() !== "trade") return;
  renderConnectionBadge(_soket.getConnectionState(), adet);
}

// Sayfayi kurar. Tekrar girildiginde canli akisa YENIDEN abone olur --
// `unmountTradePage` cikista aboneligi biraktigi icin bu sart (aksi halde
// anasayfaya donunce CANLI% kolonu sessizce olu kalir).
// Anasayfayi kurar; tekrar girildiginde canli akisa yeniden abone olur.
export function mountTradePage() {
  if (_kuruldu) { akisaAbone(); return; }
  _kuruldu = true;
  basliklariCiz();

  // NOT: eskiden burada `scroll` -> alignStickyHeader baglanmisti. Sabit
  // kolonlarin `left` degerleri kaydirmayla DEGISMEZ (position:sticky zaten
  // halleder); her kaydirma olayinda yeniden olcmek kilitlenmenin ikinci
  // kaynagiydi. Hizalama artik yalnizca cizimden ve pencere boyutundan sonra.
  window.addEventListener("resize", () => alignStickyHeader());  // olay nesnesi govdeId olarak gecmesin (tam ekranda hata veriyordu)
  document.getElementById("govde")?.addEventListener("click", (e) => {
    const s = e.target.closest("tr")?.dataset.sembol;
    if (s) openSymbol(s);
  });
  document.getElementById("ara")?.addEventListener("input", (e) => {
    _filtre = e.target.value.trim().toLowerCase();
    renderSymbolTable();
  });

  registerPoll("ozet", 10, refreshSymbolTable, { sayfa: "trade" });
  sharePollResult("ozet", () => { renderSymbolTable(); akisaAbone(); });

// Baglanti rozeti YALNIZCA aktif sayfanin soketinden yazilir.
//
// 23.09.2026 OLCUM: anasayfa ve islem sayfasi AYRI soket yoneticileri
// kullaniyor ama ikisi de ayni `#wsDurum` ogesine yaziyordu. Islem
// sayfasindan cikilinca onun soketi "kapali" bildirip anasayfanin
// "canli (30)" yazisini EZIYORDU -- gezinti testinde veri akmaya devam
// ederken (5648 tick) rozet "kapali" gorunuyordu. Kullanicinin
// "websocket surekli baglanmiyor" izleniminin kaynagi buydu.
  _soket = createSocketManager({
    onFiyat: canliYaz,
    onDurum: (d, ek) => { if (getActivePage() === "trade") renderConnectionBadge(d, ek); },
  });
}
