"""rank.sqlite okuyucusu -- SALT OKUNUR.

`hermes-rank` servisi (`toplayici.py`) yazar, bu uygulama yalnizca okur.
WAL kipinde `mode=ro` URI ile acilir, boylece yazici calisirken okuma bloke
olmaz.

Sutun listesi ELLE YAZILMAZ: `market.indicators.build_select_clause()`
uretir. Eski `veri.py` icindeki 50 sutunluk elle yazilmis `KOLON` dizesi ve
`toplayici.py`'deki elle sayilmis `"?"*51` bu yuzden vardi -- ikisi
ayrisabiliyordu ve `ema7` tam olarak boyle kayboldu.
"""
from __future__ import annotations

import os
import sqlite3
import threading
import time

from app.config.paths import get_rank_db_path
from app.core.applog import get_logger
from app.market.indicators import build_select_clause
from app.market.exclusions import load_excluded_symbols

_log = get_logger(__name__)
_onbellek: dict = {"ts": 0.0, "imza": None, "veri": None}
_onbellek_kilit = threading.Lock()

SNAPSHOT_CACHE_SN = 20
TRAIL_ROUNDS = 20            # gosterimde 20 tur
TRAIL_DIRECTION_ROUNDS = 5   # yon hesabi bilerek son 5 turda kalir


# rank.sqlite'i SALT OKUNUR acar. (eski: _ac)
def open_rank_db_readonly(path: str | None = None) -> sqlite3.Connection:
    yol = path or get_rank_db_path()
    if not os.path.exists(yol):
        raise FileNotFoundError(f"rank veritabani yok: {yol} "
                                "(hermes-rank servisi calisiyor mu?)")
    c = sqlite3.connect(f"file:{yol}?mode=ro", uri=True, timeout=15)
    c.row_factory = sqlite3.Row
    return c


# Veritabanindaki gercek sutunlar -- kayit defteriyle karsilastirmak icin.
def list_db_columns(conn: sqlite3.Connection | None = None) -> set[str]:
    kapat = conn is None
    c = conn or open_rank_db_readonly()
    try:
        return {r[1] for r in c.execute("PRAGMA table_info(anlik)")}
    finally:
        if kapat:
            c.close()


# Kayit defteri ile veritabani semasini karsilastirir.
# Acilista cagrilir: ayrisma varsa SESSIZ KALMAZ.
def verify_schema_contract() -> dict:
    from app.market.indicators import COLUMN_REGISTRY
    dbde = list_db_columns()
    defterde = {c.name for c in COLUMN_REGISTRY if not c.derived}
    eksik = sorted(defterde - dbde)      # defterde var, DB'de yok -> sorgu coker
    fazla = sorted(dbde - defterde - {"ts"})   # DB'de var, defterde yok -> kullanilmiyor
    if eksik:
        _log.error("SEMA AYRISMASI: kayit defterinde olup veritabaninda OLMAYAN "
                   "sutunlar: %s", ", ".join(eksik))
    if fazla:
        _log.warning("veritabaninda olup kayit defterinde olmayan sutunlar: %s",
                     ", ".join(fazla))
    return {"eksik": eksik, "fazla": fazla, "db_sutun": len(dbde),
            "defter_sutun": len(defterde), "uyumlu": not eksik}


# Son turun satirlari + sira izi. Haric tutulanlar elenir. (eski: ozet)
def fetch_latest_snapshot(limit: int = 400, *, cache_sn: int = SNAPSHOT_CACHE_SN) -> dict:
    haric = load_excluded_symbols()
    imza = (limit, haric)
    with _onbellek_kilit:
        if (_onbellek["veri"] is not None and _onbellek["imza"] == imza
                and time.time() - _onbellek["ts"] < cache_sn):
            return _onbellek["veri"]

    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {"ts": None, "turlar": [], "satir": [], "rejim": None}

        turlar = [r[0] for r in c.execute(
            "SELECT DISTINCT ts FROM anlik WHERE ts<=? ORDER BY ts DESC LIMIT ?",
            (son, TRAIL_ROUNDS)).fetchall()][::-1]

        # Haric tutulanlari Python'da eliyoruz; LIMIT'i asmamak icin fazladan cekip kirpiyoruz.
        ham = [dict(r) for r in c.execute(
            f"SELECT {build_select_clause()} FROM anlik "
            f"WHERE ts=? AND rank IS NOT NULL ORDER BY rank LIMIT ?",
            (son, limit + len(haric) + 20)).fetchall()]
        satir = [s for s in ham if s["sembol"] not in haric][:limit]

        if turlar and satir:
            attach_rank_trail(c, satir, turlar)
        attach_market_fields(satir)

        rejim = None
        try:
            r = c.execute("SELECT * FROM rejim WHERE ts=?", (son,)).fetchone()
            rejim = dict(r) if r else None
        except sqlite3.Error:
            pass

    d = {"ts": son, "turlar": turlar, "satir": satir, "rejim": rejim}
    with _onbellek_kilit:
        _onbellek.update(ts=time.time(), imza=imza, veri=d)
    return d


# Verilen sembollerin son tur satirlari -- HARIC LISTESI UYGULANMAZ.
#
# Elde tuttugumuz bir coin haric listesinde olabilir (ornegin sonradan
# elendi); cuzdan ve defter ekranlari onun gostergelerini yine de
# gostermeli. `fetch_latest_snapshot` haric tutulanlari eledigi icin ayri
# bir sorgu gerekiyor.
def fetch_rows_for_symbols(symbols) -> dict[str, dict]:
    istenen = sorted({str(x).strip().upper() for x in (symbols or []) if str(x).strip()})
    if not istenen:
        return {}
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        isaret = ",".join("?" * len(istenen))
        satir = [dict(r) for r in c.execute(
            f"SELECT {build_select_clause()} FROM anlik "
            f"WHERE ts=? AND sembol IN ({isaret})", (son, *istenen)).fetchall()]
        turlar = [r[0] for r in c.execute(
            "SELECT DISTINCT ts FROM anlik WHERE ts<=? ORDER BY ts DESC LIMIT ?",
            (son, TRAIL_ROUNDS)).fetchall()][::-1]
        if turlar and satir:
            attach_rank_trail(c, satir, turlar)
        # Piyasa kosullari tek sembolle KURULAMAZ; o anki tum evrenden
        # hesaplanip satira yazilir ki giris/cikis kaydi hangi piyasa
        # kosulunda acildigini da saklasin. (emir kaydindaki market snapshot)
        if satir:
            try:
                tum = [dict(r) for r in c.execute(
                    f"SELECT {build_select_clause()} FROM anlik WHERE ts=?",
                    (son,)).fetchall()]
                attach_market_fields(tum)
                pazar = {t["sembol"]: (t.get("genislik"), t.get("total3_5m"))
                         for t in tum}
                for r in satir:
                    g, t = pazar.get(r["sembol"], (None, None))
                    r["genislik"], r["total3_5m"] = g, t
            except sqlite3.Error:
                pass
    return {x["sembol"]: x for x in satir}


# Tek sembolun O ANKI piyasa goruntusu -- emir kaydina gomulur.
#
# 23.09.2026, Ismail: "giris detaylari cikis detaylari hepsi olmali ki
# ilerde bize strategy yazarken lazim olabilir". Defterde bugune kadar
# yalnizca fiyat/zaman vardi; hangi kosullarda girildigi KAYITLI DEGILDI,
# dolayisiyla gecmis islemlerden kural cikarmak imkansizdi. Bundan sonra
# her giriste ve cikista o anin tum gosterge degerleri saklanir.
# Rank veritabani okunamazsa emir yolu CALISMAYA DEVAM EDER (None doner).
def capture_market_snapshot(symbol: str) -> dict | None:
    try:
        return fetch_rows_for_symbols([symbol]).get(str(symbol).strip().upper())
    except Exception as e:                      # noqa: BLE001 - emir yolu bozulmamali
        _log.warning("piyasa goruntusu alinamadi (%s): %s", symbol, e)
        return None


# Satirlara son turlardaki rank izini ve yonunu ekler.
def attach_rank_trail(conn: sqlite3.Connection, rows: list[dict], rounds: list[int]) -> None:
    isaret = ",".join("?" * len(rounds))
    iz: dict[str, dict[int, int]] = {}
    for r in conn.execute(
            f"SELECT sembol, ts, rank FROM anlik WHERE ts IN ({isaret}) "
            f"AND rank IS NOT NULL", rounds).fetchall():
        iz.setdefault(r["sembol"], {})[r["ts"]] = r["rank"]
    for s in rows:
        d = iz.get(s["sembol"], {})
        dizi = [d[t] for t in rounds if t in d]
        s["sira_izi"] = dizi
        s["iz_yon"] = compute_trail_direction(dizi)


# Satirlara PIYASA KOSULU ekler: `genislik` ve `total3_5m`.
#
# 25.09.2026, Ismail (TP085 deneyi): "heatmap'in en az %25'i yesil olmali ve
# TOTAL3 bir onceki 5 dk'da yukseliyor olmali". Bu ikisi TEK SEMBOLLE
# kurulamaz -- tum evrenin snapshot'i gerekir, o yuzden `iz_yon` gibi
# "calisma aninda turetilmis" bir alan ve GERIYE-TESTTE SINANAMAZ
# (bkz. strategy/backtest.py UNTESTABLE_FIELDS).
#
# Tanimlar app/market/indicators.py'deki sutun kaydindaki ile BIREBIR:
#   genislik   = deg24>0 olan coinlerin payi (%)     (heatmap yesil %)
#   total3_5m  = hacim-agirlikli ort deg5m (%)       (TOTAL3 son 5m yonu)
#               (app/market/total3: deg24-agirlikli versiyonunun hizli kardesi;
#                "son 5 dakikada yukseliyor mu" sorusu icin deg5m gerekir)
def attach_market_fields(rows: list[dict]) -> None:
    if not rows:
        return
    olcu = [r for r in rows if r.get("deg24") is not None]
    genislik = (100.0 * sum(1 for r in olcu if (r.get("deg24") or 0) > 0) / len(olcu)
                if olcu else None)
    hacimli = [r for r in rows
               if r.get("deg5m") is not None and (r.get("hacim") or 0) > 0]
    toplam_h = sum(float(r["hacim"]) for r in hacimli)
    total3_5m = (sum(float(r["deg5m"]) * float(r["hacim"]) for r in hacimli) / toplam_h
                 if toplam_h else None)
    for r in rows:
        r["genislik"] = genislik
        r["total3_5m"] = total3_5m


# Iz yonu: POZITIF = siralamada tirmaniyor (rank kuculuyor).
# Yeterli tur yoksa None doner -- "olculmedi" ile "kipirdamadi" AYRIDIR.
# (Eski `veri.py` ikisine de 0 donuyordu; "UYDURMA VERI YOK" ilkesine aykiriydi.)
def compute_trail_direction(trail: list[int]) -> float | None:
    son = trail[-TRAIL_DIRECTION_ROUNDS:]
    if len(son) < 2:
        return None
    return float(son[0] - son[-1])


# N dakika onceki rank'lar: {sembol: eski_rank}.  (eski: rank_gecmisi)
def fetch_rank_history(minutes: int = 15) -> dict[str, int]:
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        hedef = son - minutes * 60_000
        eski = c.execute("SELECT max(ts) FROM anlik WHERE ts <= ?", (hedef,)).fetchone()[0]
        if not eski:
            return {}
        return {r["sembol"]: r["rank"] for r in c.execute(
            "SELECT sembol, rank FROM anlik WHERE ts=? AND rank IS NOT NULL",
            (eski,)).fetchall()}


# YAPAY ZEKA MIMO (24.09.2026): N dakika onceki CCI degerleri {sembol: cci} (heatmap filtresi).
def fetch_cci_history(minutes: int = 5) -> dict[str, float]:
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        hedef = son - minutes * 60_000
        eski = c.execute(
            "SELECT max(ts) FROM anlik WHERE ts <= ?", (hedef,)
        ).fetchone()[0]
        if not eski:
            return {}
        out: dict[str, float] = {}
        for r in c.execute(
            "SELECT sembol, cci FROM anlik WHERE ts=? AND cci IS NOT NULL",
            (eski,),
        ):
            try:
                out[r["sembol"]] = float(r["cci"])
            except (TypeError, ValueError):
                pass
        return out


# Son turdaki tum fiyatlar: {sembol: fiyat}.  (eski: son_fiyatlar -- hic cagrilmiyordu)
def fetch_snapshot_prices() -> dict[str, float]:
    with open_rank_db_readonly() as c:
        son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
        if not son:
            return {}
        return {r[0]: r[1] for r in c.execute(
            "SELECT sembol, fiyat FROM anlik WHERE ts=?", (son,)).fetchall()}
