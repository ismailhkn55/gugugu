// islem.js -- TRADE paneli: 1 canli + 4 mini grafik, emir butonlari.
import { apiGet, apiPost } from "../api.js";
import { askConfirm } from "../ui/confirm.js";
import { showToast, showToastDetail } from "../ui/toast.js";
import { coinName, formatPrice, formatSigned, formatUsdt, buttonLabel } from "../format.js";
import { getActivePage, registerPoll, refreshNow, sharePollResult } from "../poll.js";
import { subscribeState, getState, getTercih, setTercih, setState } from "../store.js";
import { createSocketManager } from "../live/socketManager.js";
import { klineCevir, rsi as rsiSeri, obv as obvSeri, ema as emaSeri,
         cciSon, bollinger as bollingerSeri, vwap as vwapSeri,
         atr as atrSeri, heikinAshi } from "../chart/indicators.js";
import { getChartScale, renderCandleChart, renderCrosshair, renderMiniChart,
         renderEntryProgressLines, renderPriceLine, renderStrategyMarkers,
         renderTimeBands, renderTradeMarkers, updateLastCandle } from "../chart/renderer.js";
import { attachChartGestures } from "../chart/gestures.js";
import { drawTvChart, isTvChartAvailable, isTvChartMounted, mountTvChart, setTvLimitDragHandler,
         setTvStopDragHandler,
         showAllTvCandles, showRecentTvCandles, unmountTvChart, updateTvLastCandle, resetTvPriceSquares,
         zoomTvChart } from "../chart/tvChart.js";
import { applyZoom, clearPriceLock, fitAllCandles, fitRecentCandles, getCandleWidth,
         getScrollX, maxScrollX, resetCandleWidth, scrollToEnd, setScrollX } from "../chart/zoom.js";
import { attachLimitHandle, followPrice, getLimitPrice, isLimitOpen, setLimitPrice,
         refreshLimitSlider, renderLimitLine, resetLimit,
         setLimitCapPercent } from "../chart/limitline.js";
import { openMethodPicker, baglaYontemKapat } from "../ui/methodPicker.js";
import { renderConnectionBadge, renderLatency } from "../ui/shell.js";

const MINI = [
  { kutu: "grafGun", bilgi: "grafGunBilgi", etiket: "gunTfEt", tf: "gun" },
  { kutu: "grafUst", bilgi: "grafUstBilgi", etiket: "ustTfEt", tf: "ust" },
  { kutu: "grafAlt", bilgi: "grafAltBilgi", etiket: "altTfEt", tf: "alt" },
  { kutu: "grafDort", bilgi: "grafDortBilgi", etiket: "dortTfEt", tf: "dort" },
];
const ANA = "grafCanli";
const ANA_MUM = 2016;      // 7 gun (5m)
const MUM_MS = 300_000;    // ana grafik mum suresi (5 dk)
const COKLU_HACIM_MUM = 288;   // 24 saat (5m) -- CHCM ilk yukleme (Ismail: "gereksiz veri cekmemeye calis")

let _kuruldu = false;
let _sembol = null;
let _mumlar = [];
let _soket = null;
let _sonFiyat = null;
let _cizimBekliyor = false;
// 27.09.2026, Ismail: "cok karisiyor" -- BOT'un GERCEKTEN girdigi ile
// CUZDAN/el ile (AL/AL TAKIP/ALSAT) girdigim AYRI RENKTE olsun, boylece
// karsilastirma yapilabilsin. Ayirici alan `el_kaynak` (varsa -> el/cuzdan,
// yoksa -> BOT) -- `_live` (canli/kagit) ayrimindan BAGIMSIZ.
let _izler = { bot: [], cuzdan: [] };
// CHCM (coklu borsa hacim): ts(ms) -> {bybit,okx,mexc,gate}. Sadece
// gosterge acikken VE o coin icin cekilir -- 163 coinin hepsi icin
// surekli cekmek gereksiz (plan: "sadece o an acik coin icin").
let _cokBorsaHacim = {};
// STRATEJI dugmesi -- gecmis mumlarda stratejinin GERCEKTE NEREDE
// GIRECEGINI (hipotez, gercek islem degil) mavi ucgenle gosterir.
// `_izler` (yukarida) GERCEK islemleri gosterir, bu ONDAN AYRI:
// `/yerel/gecmis-sinyal` replay'i.
let _sinyalNoktalari = [];
let _imlec = null;   // basili tutulan mumun sirasi (dikey imlec)
let _canliBarYukseklik = 0;   // son uygulanan bar yuksekligi
const _miniMumlar = new Map();   // kutuId -> o kutuda cizili mumlar

// --- gosterge tercihleri (KULLANICI tercihidir; yenileme donguleri ezmez) ---
function gosterge() {
  return getTercih("gosterge") || {};
}

// 03.10.2026, Ismail: "trade ekranindaki paneli TradingView chart ile degistir".
// Varsayilan TV grafigi; TV dugmesi kapatilirsa (ya da kutuphane yuklenemezse)
// eski SVG cizici.
let _tvSigdir = false;
function tvAcik() {
  return getTercih("tvGrafik") !== false && isTvChartAvailable();
}

// TV grafigini ciz: mumlar + gostergeler + strateji/islem isaretleri + fiyat cizgileri.
function tvCiz(poz) {
  if (!mountTvChart(ANA)) return false;
  const t = getTercih();
  const ayar = getState("ayar") || {};
  const cizgiler = [];
  if (poz) {
    // STP dugmesi aciksa STOP cizgisi suruklenebilir (bkz. stopSurukleBagla)
    cizgiler.push({ fiyat: poz.stop_guncel ?? poz.stop, ad: "STOP", renk: "#FF3366",
                    suruklenebilir: !!getTercih("stpAcik") });
    if (poz.kar_al) cizgiler.push({ fiyat: poz.kar_al, ad: "HEDEF", renk: "#33CC99" });
    cizgiler.push({ fiyat: poz.dolan_fiyat || poz.fiyat, ad: "GIRIS", renk: "#FFCC00" });
  }
  if (isLimitOpen() && getLimitPrice() != null) {
    cizgiler.push({ fiyat: getLimitPrice(), ad: "LIMIT", renk: "#3399CC" });
  }
  drawTvChart(_mumlar, {
    gosterge: gosterge(),
    sinyaller: t.izStrateji ? _sinyalNoktalari : [],
    sinyalRenk: ayar.renk_strateji_sinyal,
    izler: t.izCuzdan ? [..._izler.bot, ..._izler.cuzdan] : [],
    fiyatCizgileri: cizgiler,
  });
  if (_tvSigdir) { _tvSigdir = false; showRecentTvCandles(120, _mumlar.length); resetTvPriceSquares(); }
  return true;
}

// 03.10.2026, Ismail: "STP adinda dugme; acikken stop kaydirma acik olsun, kaydirinca
// emin misin desin, evet dediğimde o noktaya ayarlasin, her coin icin ayri; dokunmaz
// isem ayarlardaki gecerli". Birakilinca onay -> POST /yerel/emir/stop (o coinin
// acik pozisyonuna yazilir). Vazgecilirse cizgi eski yerine doner.
// LIMIT cizgisi TV grafiginde suruklenir (anahtar aciksa); birakilan fiyat ALSAT limiti
// olur, sagdaki kaydirici da oraya gelir. Onay YOK (emir degil, fiyat secimi).
function limitSurukleBagla() {
  setTvLimitDragHandler((yeni) => {
    const v = setLimitPrice(yeni, { elle: true });     // tavana kirpilmis deger
    const k = document.getElementById("limitKaydirici");
    if (k && v != null) k.value = v;
    alsatEtiketleri();
    cizIste();
  });
}

function stopSurukleBagla() {
  setTvStopDragHandler(async (yeni, eski) => {
    const poz = acikPozisyon();
    if (!poz) { cizIste(); return; }
    const giris = +(poz.dolan_fiyat || poz.fiyat);
    const yuzde = ((yeni / giris - 1) * 100).toFixed(2);
    const onay = await askConfirm("STOP DEGISTIR",
      `${coinName(poz.sembol)} -- stop ${formatPrice(eski)} -> ${formatPrice(yeni)} (girise gore ${yuzde}%). Emin misin?`
      + (poz._live ? "  GERCEK PARA pozisyonu." : ""),
      { onayMetni: "EVET, AYARLA", iptalMetni: "VAZGEC" });
    if (!onay) { cizIste(); return; }
    const c = await apiPost("/yerel/emir/stop", { canli: !!poz._live, id: poz.id, fiyat: yeni });
    if (c?.ok) {
      poz.stop_guncel = c.stop_elle; poz.stop_elle = c.stop_elle;
      showToast(`STOP ${formatPrice(c.stop_elle)} (${c.yuzde}%) -- ${coinName(poz.sembol)}`, "ok");
    }
    cizIste();
    izleriYukle();
  });
}

// Haric listesinde coin "ADA" ya da "ADAUSDT" diye yazilmis olabilir (sunucu ikisini
// de kabul ediyor: exclusions.expand_symbol_forms) -- iki bicim de taninir.
function engelBicimleri(s) {
  return [s, s.replace(/(USDT|USDC|FDUSD)$/, "")];
}
// ENGELLE dugmesi secili coinin durumunu gosterir (haric listesi).
function engelDurumuYaz() {
  const b = document.getElementById("btnTrHaric");
  if (!b) return;
  const liste = getState("haric") || [];
  const engelli = !!_sembol && engelBicimleri(_sembol).some((x) => liste.includes(x));
  b.classList.toggle("ekli", engelli);
  b.textContent = engelli ? "🚫 ENGELLI" : "🚫 ENGELLE";
  b.title = engelli ? "ENGELLI: bu coin HARIC listesinde -- basinca engel KALKAR"
                    : "ENGELLE: bu coini anasayfadaki HARIC TUTULANLAR listesine ekle";
}
async function engelListesiniYukle() {
  const d = await apiGet("/yerel/haric", { sessiz: true });
  if (d?.haric) setState({ haric: d.haric });
  engelDurumuYaz();
}

// requestAnimationFrame ile cizimi kareye sabitler.
function cizIste() {
  if (_cizimBekliyor) return;
  _cizimBekliyor = true;
  requestAnimationFrame(() => { _cizimBekliyor = false; anaCiz(); });
}

// TIK YOLU: tum grafigi degil, yalnizca degiseni gunceller.
//
// Tam cizim (`cizIste`) zoom/pan/yeni veri/gosterge degisiminde gerekir.
// Websocket tikinda ise yalnizca son mum, limit cizgisi ve canli bar
// degisir -- bunlar tek tek guncellenir. Olcek disina tasilirsa tam
// cizime dusulur.
let _hafifBekliyor = false;
let _yeniMumAcildi = false;
function hafifCiz() {
  if (_hafifBekliyor) return;
  _hafifBekliyor = true;
  requestAnimationFrame(() => {
    _hafifBekliyor = false;
    if (!_mumlar.length) return;
    // 02.10.2026 (Ismail: "mum asagi yukari saliniyor"): HA acikken grafik HA
    // mumlariyla cizili; son mum HAM mumla guncelleniyordu -> tam cizim ile tik
    // arasinda iki sekil/renk arasinda gidip geliyordu. Ayni seri kullanilir.
    const sonMum = gosterge().ha ? heikinAshi(_mumlar).at(-1) : _mumlar.at(-1);
    if (tvAcik() && isTvChartMounted()) {
      updateTvLastCandle(sonMum, _mumlar.at(-1));
      canliBarCiz();
      return;
    }
    if (!updateLastCandle(ANA, sonMum)) { anaCiz(); return; }
    renderLimitLine(ANA);
    canliBarCiz();
  });
}

function anaCiz() {
  if (!_mumlar.length) return;
  const poz = acikPozisyon();
  if (tvAcik() && tvCiz(poz)) {
    canliBarCiz();
    miniGostergeYaz();
    return;
  }
  if (isTvChartMounted()) unmountTvChart();     // TV kapatildi -> eski SVG grafik
  const ekFiyat = [];
  if (isLimitOpen() && getLimitPrice() != null) ekFiyat.push(getLimitPrice());
  if (poz) { ekFiyat.push(poz.stop_guncel ?? poz.stop); if (poz.kar_al) ekFiyat.push(poz.kar_al); }

  // `eksen: false` -- 5M ana grafikte sagdaki fiyat etiketleri HIC
  // cizilmez. Ismail, 23.09.2026: "5m ana grafikte sagda fiyat
  // gozukmesin, tamamen kaldir, goruntuyu bozuyor". Once ayrilan sutun
  // kaldirilip etiketler bindirilmisti (7.19); bu da yeterli gelmedi.
  // Fiyat zaten baslikta buyuk puntoyla ve yandaki canli barda var.
  // 29.09.2026: CHCM -- borsa renkleri Ayarlar'dan (renk_hacim_*), veri
  // _cokBorsaHacim'de (coin degisince/gosterge acilinca cokBorsaHacimYukle
  // doldurur).
  const _ayarRenk = getState("ayar") || {};
  renderCandleChart(ANA, _mumlar, { gosterge: gosterge(), ekFiyat, eksen: false,
                                    bosMetin: "COIN SECILMEDI",
                                    cokBorsaHacim: _cokBorsaHacim,
                                    renkHacim: {
                                      binance: _ayarRenk.renk_hacim_binance,
                                      bybit: _ayarRenk.renk_hacim_bybit,
                                      okx: _ayarRenk.renk_hacim_okx,
                                      mexc: _ayarRenk.renk_hacim_mexc,
                                      gate: _ayarRenk.renk_hacim_gate,
                                    } });
  // TM dugmesi -- gercek saat/4-saat bantlari. HA donusumunden ETKILENMEZ,
  // ham `_mumlar` (gercek 5m zaman damgalariyla) uzerinden hesaplanir.
  renderTimeBands(ANA, gosterge().tm ? _mumlar : []);
  // Ust katmanlar -- mum katmani guncellenince YERINDE kalirlar.
  if (poz) {
    renderPriceLine(ANA, poz.stop_guncel ?? poz.stop, "stopCizgi", "STOP");
    if (poz.kar_al) renderPriceLine(ANA, poz.kar_al, "hedefCizgi", "HEDEF");
    renderPriceLine(ANA, poz.dolan_fiyat || poz.fiyat, "limitCizgi", "GIRIS");
  }
  renderLimitLine(ANA);
  izleriCiz();
  imleciCiz();
  canliBarCiz();
  miniGostergeYaz();
}

// 28.09.2026, Ismail: "5m mumlarinin altina bi tablo yap ... obv'nin
// anasayfada gozukme sekli ile kucuk bi ok ile yukari asagi goster, total
// +1 mi +3 mu yazsin ... rsi yaz ustte ne oldugu altta degeri" -- 6
// hucrelik seritte OBV + RSI. Ham `_mumlar`den (HA DONUSUMSUZ, gercek
// kapanislarla) hesaplanir -- gosterge butonlarindaki OBV/RSI cizgileriyle
// AYNI seriyi kullanir (chart/indicators.js), backend'e sormaz.
// 28.09.2026, Ismail: "tabloyu 8 li yap ve degerler gelmiyor kontrol et
// bos kalan bi yer olmasin degerlerin geldigine de emin ol" -- 8 hucrenin
// HEPSI ham `_mumlar`den (HA donusumsuz, grafik cizgileriyle AYNI seri)
// hesaplanir; yer tutucu YOK, backend'e sormaz.
function miniGostergeYaz() {
  const kutu = document.getElementById("miniGosterge");
  if (!kutu || !_mumlar.length) return;
  // Ismail: "renkli olmasin degerler renkli olsun sadece" -- kutu/kenarlik
  // HEP notr, sinif SADECE <b> (deger) uzerinde.
  const yaz = (ad, metin, sinif) => {
    const h = kutu.querySelector(`[data-mg="${ad}"]`);
    const b = h?.querySelector("b");
    if (!b) return;
    b.textContent = metin;
    b.classList.toggle("arti", sinif === "arti");
    b.classList.toggle("eksi", sinif === "eksi");
  };

  const kapanislar = _mumlar.map((m) => m.k);
  const fiyat = _sonFiyat ?? kapanislar.at(-1);

  // RSI(14) -- 70/30 esikleri anasayfayla (pages/trade.js) AYNI.
  const r = rsiSeri(kapanislar, 14).at(-1);
  yaz("rsi", r == null ? "·" : r.toFixed(0),
      r == null ? null : r >= 70 ? "arti" : r <= 30 ? "eksi" : null);

  // CCI(20) -- +100/-100 esikleri anasayfayla AYNI.
  const c = cciSon(_mumlar, 20);
  yaz("cci", c == null ? "·" : c.toFixed(0),
      c == null ? null : c > 100 ? "arti" : c < -100 ? "eksi" : null);

  // OBV sinyali (EMA20) ustunde/altinde KAC BARDIR -- backend `obv_kesim`
  // ile ayni tanim (isaretli: + ustunde, - altinde), burada ham mumlardan.
  const o = obvSeri(_mumlar);
  const os = emaSeri(o, 20);
  let kesim = null, n = o.length;
  if (n && os[n - 1] != null) {
    const yon = o[n - 1] >= os[n - 1];
    let sayac = 0;
    for (let i = n - 1; i >= 0 && os[i] != null; i--) {
      if ((o[i] >= os[i]) !== yon) break;
      sayac++;
    }
    kesim = yon ? sayac : -sayac;
  }
  let obvMetin = "·", obvSinif = null;
  if (kesim > 0) { obvMetin = "▲+" + kesim; obvSinif = "arti"; }
  else if (kesim < 0) { obvMetin = "▼" + kesim; obvSinif = "eksi"; }
  yaz("obv", obvMetin, obvSinif);

  // EMA(20) -- fiyatin EMA'dan farki, %.
  const emaDeger = emaSeri(kapanislar, 20).at(-1);
  const emaFark = emaDeger ? (fiyat / emaDeger - 1) * 100 : null;
  yaz("ema", emaFark == null ? "·" : formatSigned(emaFark, 1),
      emaFark == null ? null : emaFark > 0 ? "arti" : emaFark < 0 ? "eksi" : null);

  // Bollinger(20,2) -- %B: bantlar icindeki konum (0=alt, 100=ust).
  const bb = bollingerSeri(kapanislar, 20, 2);
  const bUst = bb.ust.at(-1), bAlt = bb.alt.at(-1);
  const yuzdeB = (bUst != null && bAlt != null && bUst > bAlt)
    ? (fiyat - bAlt) / (bUst - bAlt) * 100 : null;
  yaz("bb", yuzdeB == null ? "·" : yuzdeB.toFixed(0),
      yuzdeB == null ? null : yuzdeB >= 80 ? "arti" : yuzdeB <= 20 ? "eksi" : null);

  // VWAP -- fiyatin VWAP'tan farki, %. Grafikteki VWAP cizgisiyle AYNI
  // seri (ham `_mumlar`, HA donusumsuz).
  const vwapDeger = vwapSeri(_mumlar).at(-1);
  const vwapFark = vwapDeger ? (fiyat / vwapDeger - 1) * 100 : null;
  yaz("vwap", vwapFark == null ? "·" : formatSigned(vwapFark, 1),
      vwapFark == null ? null : vwapFark > 0 ? "arti" : vwapFark < 0 ? "eksi" : null);

  // ATR(14) -- fiyatin yuzdesi olarak oynaklik. Yonu yok -> HEP NOTR.
  const atrDeger = atrSeri(_mumlar, 14).at(-1);
  const atrYuzde = atrDeger != null && fiyat ? atrDeger / fiyat * 100 : null;
  yaz("atr", atrYuzde == null ? "·" : atrYuzde.toFixed(2) + "%", null);

  // HCM: son mumun hacmi / ONDAN ONCEKI 20 mumun ortalama hacmi.
  const sonHacim = _mumlar.at(-1)?.h;
  const oncekiler = _mumlar.slice(-21, -1);
  const ortHacim = oncekiler.length
    ? oncekiler.reduce((a, m) => a + m.h, 0) / oncekiler.length : null;
  const oran = (sonHacim != null && ortHacim) ? sonHacim / ortHacim : null;
  yaz("hcm", oran == null ? "·" : oran.toFixed(1) + "x",
      oran == null ? null : oran >= 1.5 ? "arti" : oran <= 0.5 ? "eksi" : null);
}

// CUZDAN dugmesi: BOT (turuncu) + CUZDAN (sari) GERCEK giris/cikis
// noktalari, ayrica gercek girislerden saga uzanan %1.2 ilerleme cizgisi.
// STRATEJI dugmesi: gecmis kagit islemler DEGIL, stratejinin bu mum
// dizisinde NEREDE GIRECEGI (hipotez replay, mavi ucgen) -- birbirini
// BOZMAZ, ikisi ayni anda acik kalabilir.
function izleriCiz() {
  for (const m of MINI) if (_miniMumlar.get(m.kutu)) miniSinyalCiz(m);
  if (tvAcik()) { cizIste(); return; }     // TV grafiginde isaretler tam cizimle gelir
  const t = getTercih();
  const ayar = getState("ayar") || {};
  if (t.izCuzdan) {
    renderTradeMarkers(ANA, [..._izler.bot, ..._izler.cuzdan]);
    renderEntryProgressLines(ANA, [
      ..._izler.bot.filter((n) => n.tur === "giris"),
      ..._izler.cuzdan.filter((n) => n.tur === "giris"),
    ]);
  } else {
    renderTradeMarkers(ANA, []);
    renderEntryProgressLines(ANA, []);
  }
  renderStrategyMarkers(ANA, t.izStrateji ? _sinyalNoktalari : [],
    ayar.renk_strateji_sinyal);
}

// Aktif stratejinin gecmis mumlarda nerede tetiklendigini ceker
// (`/yerel/gecmis-sinyal`) -- STRATEJI dugmesi bunu mavi ucgenle gosterir.
// Gercek islem DEGIL, "burada girerdi" hipotezi.
async function sinyalleriYukle() {
  const istenen = _sembol;
  const d = await apiGet(
    `/yerel/gecmis-sinyal?sembol=${istenen}&interval=5m&limit=${ANA_MUM}&bar=${ANA_MUM}`,
    { sessiz: true });
  if (!d || istenen !== _sembol) return;   // eskimis yanit korumasi
  _sinyalNoktalari = d.noktalar || [];
  if (d.sinanamayan_kural?.length) {
    log_once_sinyal_uyari(d.sinanamayan_kural);
  }
  izleriCiz();
}
let _sinyalUyariGosterildi = "";
function log_once_sinyal_uyari(sinanamayan) {
  const anahtar = _sembol + "|" + sinanamayan.join(",");
  if (_sinyalUyariGosterildi === anahtar) return;
  _sinyalUyariGosterildi = anahtar;
  console.warn("gecmis-sinyal EKSIK -- sinanamayan kurallar:", sinanamayan);
}

// 5M grafigin yanindaki dar dikey kutu: SON MUMU buyutup gosterir.
//
// 23.09.2026, Ismail: "5m grafigin yaninda 5m'nin son mumunu gosteriyordu
// anlik, o da calismiyor". Ilk yazimda bu kutuyu bir CSS degiskenine
// (`--oran`) indirgemistim; `.canliBar` ise icine SVG bekliyor, dolayisiyla
// kutu BOS kaliyordu. Burada eski davranis geri getirildi.
//
// Pencere: mumun kendi araligi ORTALANIR. Taban %1 DEGIL %0.4 -- boylece
// kucuk oynamalarda bile arkada birkac yuzde cizgisi gorunur ve hareket
// buyutulmus olur. Mum buyudukce pencere de buyur, tasma olmaz.
function canliBarCiz() {
  const kutu = document.getElementById("canliBar");
  if (!kutu || !_mumlar.length) return;
  // Bar, 5M grafik kartiyla AYNI BOYDA olsun (Ismail'in istegi): grafik
  // kendi min-height'i yuzunden satirdan kisa kalabiliyor.
  // Yukseklik OLCUMU her karede yapilmaz: `getBoundingClientRect`
  // zorunlu yerlesim hesabi tetikler ve tik basina cagrilinca
  // `alignStickyHeader` vakasindaki (bkz. 7.8) ayni maliyeti dogurur.
  // Olcum yalnizca grafigin boyu DEGISTIGINDE tazelenir.
  const graf = document.getElementById(ANA);
  if (graf) {
    const gh = graf.clientHeight;          // yerlesim tetiklemez (onbellekli)
    if (gh > 10 && gh !== _canliBarYukseklik) {
      _canliBarYukseklik = gh;
      kutu.style.height = gh + "px";
    }
  }
  const m = _mumlar.at(-1);
  const ac = m?.a, yk = m?.y, ds = m?.d, kp = m?.k;
  if (!(ac > 0)) return;

  const H = kutu.clientHeight || 120;
  const W = kutu.clientWidth || 14;
  if (H < 10) return;

  const orta = (yk + ds) / 2;
  const menzil = Math.max(yk - ds, orta * 0.004);
  const pay = menzil * 0.25;                    // ustte/altta nefes payi
  const en = orta + menzil / 2 + pay;
  const az = orta - menzil / 2 - pay;
  const ara = Math.max(en - az, 1e-12);
  const y = (v) => H - ((v - az) / ara) * H;

  // Arka plan yuzde cizgileri (Ismail: "arkadaki yatay cizgiler gozukmuyor,
  // biraz belirgin yap"). Olculdu: pencere ~%1.37 oldugu icin %1'lik adimda
  // bara SADECE 1 cizgi dusuyordu. Cozum: pencereye gore adim sec, her TAM
  // %1 cizgisini daha koyu ciz. Referans mumun ACILISI -- %0 cizgisi hep
  // acilistan gecer, "acilisa gore nerede" dogrudan okunur.
  let g = "";
  if (az > 0) {
    const pencereYuzde = (ara / orta) * 100;
    const adim = pencereYuzde <= 0.6 ? 0.1
               : pencereYuzde <= 1.5 ? 0.25
               : pencereYuzde <= 4 ? 0.5 : 1.0;
    const K = 1 + adim / 100;
    const n0 = Math.ceil(Math.log(az / ac) / Math.log(K));
    for (let i = n0; ; i++) {
      const v = ac * Math.pow(K, i);
      if (v > en) break;
      const py = y(v);
      if (py < 0 || py > H) continue;
      const yuzde = i * adim;
      const sifir = yuzde === 0;
      const tamBir = !sifir && Math.abs(yuzde % 1) < 1e-6;
      const kal = sifir ? 1 : tamBir ? 0.9 : 0.5;
      const op = sifir ? 0.9 : tamBir ? 0.8 : 0.45;
      const renk = sifir ? "var(--metin-sonuk)" : "var(--izgara-cizgi)";
      g += `<line x1="0" y1="${py.toFixed(1)}" x2="${W}" y2="${py.toFixed(1)}" ` +
           `stroke="${renk}" stroke-width="${kal}" opacity="${op}"` +
           (sifir ? ' stroke-dasharray="2 2"' : "") + "/>";
    }
  }

  const renk = kp >= ac ? "var(--arti)" : "var(--eksi)";
  const ust = y(Math.max(ac, kp)), alt = y(Math.min(ac, kp));
  const gov = Math.max(1.5, alt - ust);
  // Govde barin TAMAMINI kaplamasin ki arkadaki cizgiler gorunsun
  // (14px'te 0.62 orani cizgileri yutuyordu).
  const gw = Math.max(4, W * 0.46);
  const limit = isLimitOpen() ? getLimitPrice() : null;

  kutu.innerHTML =
    `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">` + g +
    `<line x1="${W / 2}" y1="${y(yk).toFixed(1)}" x2="${W / 2}" y2="${y(ds).toFixed(1)}" ` +
      `stroke="${renk}" stroke-width="1" opacity=".8"/>` +
    `<rect x="${((W - gw) / 2).toFixed(1)}" y="${ust.toFixed(1)}" ` +
      `width="${gw.toFixed(1)}" height="${gov.toFixed(1)}" fill="${renk}"/>` +
    // Limit cizgisi bu barda da gorunsun (Ismail: "fiyatin cizgisi araya
    // koydugumuz websocket mumu uzerinde de gozuksun").
    (limit != null && limit >= az && limit <= en
      ? `<line x1="0" y1="${y(limit).toFixed(1)}" x2="${W}" y2="${y(limit).toFixed(1)}" ` +
        `stroke="var(--neon)" stroke-width="1" stroke-dasharray="3 2"/>` : "") +
    "</svg>";
  kutu.title = `son 5M mum · ${formatPrice(ds)} … ${formatPrice(yk)}`;
}

function acikPozisyon() {
  const e = getState("emirler") || {};
  return [...(e.takip || []), ...(e.acik || [])].find((p) => p.sembol === _sembol) || null;
}

// ALSAT buton etiketlerini ayardaki hedeflerle yazar.
function alsatEtiketleri() {
  const a = getState("ayar") || {};
  for (const n of [1, 2, 3]) {
    const e = document.getElementById(`alsat${n}Etiket`);
    if (e) e.textContent = String(a[`alsat_hedef_${n}`] ?? "—");
  }
  const et = document.getElementById("grafCanli5mEt");
  if (et) et.textContent = `5M · CANLI (${_mumlar.length} mum)`;
}

// Imlecin uzerinde durdugu mumun dizideki sirasini bulur.
function mumIndeksi(kap, olcek, istemciX) {
  const r = kap.getBoundingClientRect();
  return Math.round((istemciX - r.left + olcek.kaydir - olcek.gen / 2) / olcek.gen);
}

// Fare/dokunma ile secilen mumun bilgisini yazar ve DIKEY IMLECI surer.
//
// 23.09.2026, Ismail: "dokundugum yerde dikine tam mumun ortasina denk
// gelecek sekilde YALNIZCA DOKUNUNCA cikacak dikey cizgi olmali".
// Bu yuzden cizgi `pointerdown` ile acilir, `pointerup`/`pointercancel`/
// `pointerleave` ile kapanir; serbest gezinmede (basili degilken) cikmaz.
// Konum serbest x'e degil MUM MERKEZINE oturur (bkz. renderCrosshair).
function mumBilgisiKur() {
  const kap = document.getElementById(ANA);
  const bilgi = document.getElementById("grafCanliBilgi");
  if (!kap || !bilgi || kap.dataset.bilgiBagli === "1") return;
  kap.dataset.bilgiBagli = "1";

  const bilgiYaz = (i) => {
    const m = _mumlar[Math.max(0, Math.min(_mumlar.length - 1, i))];
    if (!m) return;
    const d = (m.k / m.a - 1) * 100;
    bilgi.innerHTML = `<span>A ${formatPrice(m.a)}</span><span>Y ${formatPrice(m.y)}</span>` +
      `<span>D ${formatPrice(m.d)}</span><span>K ${formatPrice(m.k)}</span>` +
      `<span class="${d > 0 ? "arti" : "eksi"}">${formatSigned(d, 2)}</span>`;
  };

  const konumdan = (e) => {
    const o = getChartScale(ANA);
    if (!o || !_mumlar.length) return null;
    return mumIndeksi(kap, o, e.clientX);
  };

  kap.addEventListener("pointerdown", (e) => {
    const i = konumdan(e);
    if (i == null) return;
    _imlec = i;
    bilgiYaz(i);
    imleciCiz();
  });
  kap.addEventListener("pointermove", (e) => {
    const i = konumdan(e);
    if (i == null) return;
    bilgiYaz(i);                       // bilgi serbest gezinmede de yazilir
    if (_imlec == null) return;        // cizgi ise YALNIZCA basiliyken
    _imlec = i;
    imleciCiz();
  });
  const birak = () => {
    if (_imlec == null) return;
    _imlec = null;
    imleciCiz();
  };
  kap.addEventListener("pointerup", birak);
  kap.addEventListener("pointercancel", birak);
  kap.addEventListener("pointerleave", () => { bilgi.textContent = ""; birak(); });
}

// Dikey imleci cizer/siler.
function imleciCiz() {
  renderCrosshair(ANA, _imlec);
}

// 24 saatlik ve gunluk yuzdeyi ANLIK fiyattan hesaplar.
const GUNLUK_MUM = 288;          // 288 x 5dk = 24 saat
const MUM128 = 128;              // 128 x 5dk = 10 saat 40 dakika
const MUM129 = 129;              // 128 DEGISIM icin bir onceki kapanis dahil

// 26.09.2026, Ismail: "son 128 mumin kirmizilari ve yesilleri ayri ayri
// toplansin" + FARK. Pencere toplayici.ince_olc ile AYNI: OLUSMAKTA olan
// son mum sayilmaz (kapanmadan rengi degisebilir). FARK icin HER MUMUN
// degisimi onceki kapanisa gore olculur -> 128 degisim icin 129 kapanmis
// mum gerekir (yoksa NULL).
//   fark128 = yesil degisimlerinin toplami - |kirmizi degisimlerinin toplami|
//   negatifse kirmizilar baskin (kutu KIRMIZI olur).
function mum128() {
  if (!_mumlar.length) return null;
  let m = _mumlar;
  const son = m.at(-1);
  if (son && son.t + 5 * 60 * 1000 > Date.now()) m = m.slice(0, -1);
  if (m.length < MUM129) return null;
  const w = m.slice(-MUM128);
  let yesil = 0, kirmizi = 0, yesilTop = 0, kirmiziTop = 0;
  let oncekiKp = m[m.length - MUM129].k;
  for (const x of w) {
    const renk = x.k > x.a ? 1 : (x.k < x.a ? -1 : 0);
    if (renk > 0) yesil++;
    else if (renk < 0) kirmizi++;
    if (renk !== 0 && oncekiKp > 0) {
      const deg = (x.k / oncekiKp - 1) * 100;
      if (renk > 0) yesilTop += deg;
      else kirmiziTop += deg;
    }
    oncekiKp = x.k;
  }
  return {
    yesil, kirmizi, coinsay: yesil - kirmizi,
    fark128: yesilTop - Math.abs(kirmiziTop),
  };
}

function canliYuzdeler() {
  const satir = (getState("satirlar") || []).find((x) => x.sembol === _sembol);
  const m128 = mum128();
  const yedek128 = satir
    ? { yesil: satir.coingreen ?? null,
        kirmizi: satir.coingreen != null && satir.coinsay != null
          ? satir.coingreen - satir.coinsay : null,
        coinsay: satir.coinsay ?? null,
        fark128: satir.fark128 ?? null }
    : null;
  const a128 = m128 || yedek128;
  if (!_mumlar.length || _sonFiyat == null) {
    return { deg24: satir?.deg24 ?? null, gun: satir?.gun_pct ?? null,
             fark128: a128?.fark128 ?? null, yesil: a128?.yesil ?? null,
             kirmizi: a128?.kirmizi ?? null, coinsay: a128?.coinsay ?? null };
  }
  // 24 saat once: 288 mum geri (yoksa elimizdeki en eski mum).
  const i = Math.max(0, _mumlar.length - 1 - GUNLUK_MUM);
  const f24 = _mumlar[i]?.k;
  const deg24 = f24 > 0 ? (_sonFiyat / f24 - 1) * 100 : satir?.deg24 ?? null;

  // UTC gununun ilk mumunun ACILISI (toplayicinin `gun_pct` tanimi).
  const son = new Date(_mumlar.at(-1).t);
  const gunBasi = Date.UTC(son.getUTCFullYear(), son.getUTCMonth(), son.getUTCDate());
  const ilk = _mumlar.find((m) => m.t >= gunBasi);
  const gun = ilk?.a > 0 ? (_sonFiyat / ilk.a - 1) * 100 : satir?.gun_pct ?? null;
  return { deg24, gun,
           fark128: a128?.fark128 ?? null, yesil: a128?.yesil ?? null,
           kirmizi: a128?.kirmizi ?? null, coinsay: a128?.coinsay ?? null };
}

// --- baslik / fiyat / kar-zarar ---
function basligiYaz() {
  const ad = document.getElementById("trAd");
  if (ad) {
    ad.textContent = _sembol ? coinName(_sembol) : "—";
    ad.title = _sembol || "";
  }
  const f = document.getElementById("trFiyat");
  if (f) f.textContent = _sonFiyat == null ? "·" : formatPrice(_sonFiyat);

  // Yuzde kutucuklari: deger `<b>`ye yazilir, renk kutunun kendisine.
  //
  // 26.09.2026: `renk` verilirse kutunun RENGI o degerden alinir (varsayilan
  // degerin kendisi -- FARK kutusu boyle renklendirilir).
  const kutuYaz = (id, deger, renk = deger) => {
    const k = document.getElementById(id);
    if (!k) return;
    const b = k.querySelector("b");
    if (b) b.textContent = deger == null ? "·" : formatSigned(deger, 1);
    k.classList.toggle("arti", deger != null && renk > 0);
    k.classList.toggle("eksi", deger != null && renk < 0);
  };
  // 24 SAAT ve GUN yuzdesi CANLI hesaplanir.
  //
  // 23.09.2026, Ismail: "ustteki 24h yi ve gunu websockete baglasana,
  // zaten veri geliyor, hareket etmiyor duruyor".
  // Sebep: bu degerler `getState("satirlar")` icinden okunuyordu; o liste
  // ANASAYFANIN zamanlayicisiyla doluyor ve islem ekranindayken hic
  // yenilenmiyor -- dolayisiyla girdigin andaki degerde DONUYORDU.
  // Artik elimizdeki 5m mumlardan ve websocket fiyatindan hesaplaniyor:
  //   gun  : UTC gununun ILK 5m mumunun acilisina gore  (toplayici ile ayni tanim)
  //   24s  : 288 mum (=24 saat) geriye gore
  // Mum yoksa ozet satirindaki degere dusulur.
  const y = canliYuzdeler();
  kutuYaz("trDeg24", y.deg24);
  kutuYaz("trDegGun", y.gun);
  // 128 MUM: FARK = yesil degisim toplami - |kirmizi degisim toplami|.
  // Renk degerin ISARETINDEN gelir: negatifse kirmizilar baskin.
  kutuYaz("trDeg128", y.fark128);
  // Y/K: son 128 mumun yesil / kirmizi adedi.
  const mk = document.getElementById("trMum128");
  if (mk) {
    const b = mk.querySelector("b");
    if (b) b.textContent = y.yesil == null ? "·" : `${y.yesil}/${y.kirmizi}`;
    mk.classList.toggle("arti", y.yesil != null && y.coinsay > 0);
    mk.classList.toggle("eksi", y.yesil != null && !(y.coinsay > 0));
  }

  // ELDE POZISYON VARSA sag kosede kar/zarar.
  // 23.09.2026, Ismail: "eger coinden elimizde var ise sag kosesinde
  // yuzdesel degisim gozukuyor degil mi kontrol et". Kontrol edildi:
  // calisiyor, ama `display` ile gizleniyordu; artik `hidden` niteligi
  // kullaniliyor (CSS `[hidden]` ile tutarli) ve kutu bicimine alindi.
  const kz = document.getElementById("trKZ");
  const poz = acikPozisyon();
  if (kz) {
    const varMi = !!(poz && _sonFiyat != null);
    kz.hidden = !varMi;
    if (varMi) {
      const giris = +(poz.dolan_fiyat || poz.fiyat);
      const k = (_sonFiyat / giris - 1) * 100;
      const b = kz.querySelector("b");
      if (b) b.textContent = formatSigned(k);
      kz.classList.toggle("arti", k > 0);
      kz.classList.toggle("eksi", k < 0);
      kz.title = `${buttonLabel(poz.el_kaynak || poz.kaynak)} · giris ${formatPrice(giris)}`;
    }
  }
}

// --- veri yukleme ---
// `sigdir`: gorunumu son 120 muma oturtur. YALNIZCA coin degisiminde
// true verilir.
//
// 23.09.2026 OLCUM: bu fonksiyon 30 saniyelik yenileme dongusunden de
// cagriliyor ve her seferinde `fitRecentCandles` calistiriyordu -- yani
// kullanici "TUMU" ile 2016 mumu ekrana sigdirdiktan 30 saniye sonra
// gorunum KENDILIGINDEN varsayilan zoom'a donuyordu. Olcumde mum katmani
// 1673 dugumden 230'a geri dustu. Yakinlastirma artik yalnizca coin
// degisince sifirlanir; yenileme kullanicinin gorunumune dokunmaz.
// 29.09.2026, Ismail: "trade ekranindaki hacim barinda her borsaninki
// farkli renk olsun" (CHCM) -- SADECE gosterge acikken VE o an ekrandaki
// coin icin cekilir (163 coinin hepsi icin surekli cekmek gereksiz).
// anaMumlariYukle ile AYNI "eskimis yanit korumasi" deseni.
async function cokBorsaHacimYukle() {
  if (!_sembol || !gosterge().hacimCokBorsa) return;
  const istenen = _sembol;
  const ham = await apiGet(
    "/yerel/hacim-coklu?symbol=" + istenen + "&interval=5m&limit=" + COKLU_HACIM_MUM,
    { sessiz: true });
  if (istenen !== _sembol) return;
  _cokBorsaHacim = ham || {};
  cizIste();
}

async function anaMumlariYukle({ sigdir = false } = {}) {
  if (!_sembol) return;
  const istenen = _sembol;
  const ham = await apiGet(
    `/yerel/mum?symbol=${istenen}&interval=5m&limit=${ANA_MUM}`, { sessiz: true });
  if (!ham?.length) return;
  // ESKIMIS YANIT KORUMASI.
  //
  // 23.09.2026, Ismail: "aniden son mum devasa, digerleri nokta gibi
  // oluyor". OLCULDU (gezinti testi): coin degistikten hemen sonra dikey
  // aralik 0.0245..0.3729'a ciktu -- yani 15 KATLIK bir aralik; en uzun
  // govde 633 piksel, digerleri noktaya indi. 30 saniyelik yenilemeden
  // sonra kendiliginden duzeliyordu, bu yuzden "aniden" gorunuyordu.
  //
  // SEBEP: 30 saniyelik `islemMum` dongusu ESKI coin icin bir istek
  // yolda iken kullanici baska bir coine geciyor. Yanit sonradan donup
  // `_mumlar`'i ESKI coinin mumlariyla dolduruyor; uzerine websocket'ten
  // YENI coinin fiyati binince son mumun tepe/dibi devasa aciliyor ve
  // olcek tum grafigi eziyordu.
  //
  // (Eski sistemde bunun icin bir kontrol vardi -- yeniden yazarken
  //  dusmus; `sunucu.py` yorumu: "canliMumlar o an YENI coine ait
  //  olabilir - sembol eslesmezse".)
  if (istenen !== _sembol) return;
  _mumlar = klineCevir(ham);
  _sonFiyat = _mumlar.at(-1)?.k ?? null;
  const kap = document.getElementById(ANA);
  if (sigdir) { fitRecentCandles(120, kap?.clientWidth || 800, _mumlar.length); _tvSigdir = true; }
  setLimitCapPercent((getState("ayar") || {}).limit_ust_yuzde ?? 0.4);
  refreshLimitSlider(ANA, "limitKaydirici", _sonFiyat);
  basligiYaz();
  alsatEtiketleri();
  cizIste();
  cokBorsaHacimYukle();   // CHCM acikken coin degisince yeni coin icin ceker
}

// 27.09.2026, Ismail: "HA tusuna basinca soldaki 5m/1h/4h/1d de Heikin
// Ashi'ye donecekti, olmuyor" -- iki sebebi vardi: (1) `renderMiniChart`
// cagrisi `gosterge` HIC gondermiyordu, (2) renderer.js'deki
// `renderMiniChart` gonderileni yoksayip HER ZAMAN `gosterge:{}` zorluyordu
// (ayri duzeltme). Burada SADECE `ha` aktarilir -- RSI/OBV/ATR gibi
// alt-panel acan gostergeler kucuk kutuya sigmadigi icin BILEREK disarida.
function miniTekCiz(m, mumlar) {
  renderMiniChart(m.kutu, mumlar,
    { bosMetin: "COIN SECILMEDI", gosterge: { ha: gosterge().ha } });
  miniSinyalCiz(m);
}
// STRATEJI acikken sinyaller soldaki 5M/1H/4H/1D mini grafiklerde de (o sinyali
// iceren mumun ustunde nokta + dikey cizgi) gorunur.
function miniSinyalCiz(m) {
  const t = getTercih();
  renderStrategyMarkers(m.kutu, t.izStrateji ? _sinyalNoktalari : [],
    (getState("ayar") || {}).renk_strateji_sinyal, { kapsayan: true });
}

// HA dugmesine basilinca TUM mini grafikleri, yeniden veri CEKMEDEN,
// onbellekten (`_miniMumlar`) aninda yeniden cizer.
function miniCiz() {
  for (const m of MINI) {
    const mumlar = _miniMumlar.get(m.kutu);
    if (mumlar) miniTekCiz(m, mumlar);
  }
}

async function miniYukle() {
  if (!_sembol) return;
  const istenen = _sembol;          // eskimis yanit korumasi (bkz. anaMumlariYukle)
  const a = getState("ayar") || {};
  for (const m of MINI) {
    if (istenen !== _sembol) return;
    const tf = a[m.tf + "_tf"] || "1h";
    const adet = a[m.tf + "_mum"] || 20;
    const et = document.getElementById(m.etiket);
    // 26.09.2026, Ismail: "5M 1H 4H 1D yazsa yetmiyor mu" -- mum adedi yazilmaz.
    if (et) et.textContent = tf.toUpperCase();
    const ham = await apiGet(
      `/yerel/mum?symbol=${istenen}&interval=${tf}&limit=${adet}`, { sessiz: true });
    if (!ham?.length || istenen !== _sembol) continue;
    const mumlar = klineCevir(ham);
    _miniMumlar.set(m.kutu, mumlar);
    miniTekCiz(m, mumlar);
    miniOzetYaz(m);
  }
}

// Mini kutunun bilgi satirina TUM serinin degisimini yazar (varsayilan).
function miniOzetYaz(m) {
  const mumlar = _miniMumlar.get(m.kutu);
  const b = document.getElementById(m.bilgi);
  if (!b || !mumlar?.length) return;
  const ilk = mumlar[0].a, son = mumlar.at(-1).k;
  const d = (son / ilk - 1) * 100;
  // 26.09.2026, Ismail: "solda 5M, sagda ORAN" -- yalniz yuzde; fiyat ipucunda.
  b.textContent = formatSigned(d, 1);
  b.title = `son fiyat ${formatPrice(son)} · ${mumlar.length} mum`;
  b.className = "mumBilgi " + (d > 0 ? "mbArti" : "mbEksi");
}

// Mini kutuda TIKLANAN mumun kendi degisimini yazar.
//
// 23.09.2026, Ismail: "soldaki 20 mum gosteren 4 grafik var ya orda bi
// tane muma tikladigimda o mumun degisim yuzdesini gormek istiyorum".
// Kutular sabit genislikte cizildigi icin (kaydirma yok) mum sirasi
// dogrudan yatay konumdan bulunur; olcek `getChartScale` ile okunur --
// cizimle AYNI kaynak, ikinci bir hesap yok.
function miniMumSec(m, olayX) {
  const mumlar = _miniMumlar.get(m.kutu);
  const kap = document.getElementById(m.kutu);
  const o = getChartScale(m.kutu);
  const b = document.getElementById(m.bilgi);
  if (!mumlar?.length || !kap || !o || !b) return;
  const r = kap.getBoundingClientRect();
  const i = Math.max(0, Math.min(mumlar.length - 1,
                                 Math.floor((olayX - r.left) / o.gen)));
  const mum = mumlar[i];
  const d = (mum.k / mum.a - 1) * 100;
  const govde = (mum.y - mum.d) > 0 ? ((mum.k - mum.a) / (mum.y - mum.d)) * 100 : 0;
  // 26.09.2026: bilgi artik baslik satirinin SAGINDA -- sigsin diye kisa
  // bicim (fiyat + yuzde); mum sirasi ipucunda.
  b.textContent = formatSigned(d, 2);
  b.className = "mumBilgi secili " + (d > 0 ? "mbArti" : "mbEksi");
  b.title = `mum #${i + 1} · kapanis ${formatPrice(mum.k)} · acilis ${formatPrice(mum.a)} · yuksek ${formatPrice(mum.y)} · `
          + `dusuk ${formatPrice(mum.d)} · kapanis ${formatPrice(mum.k)} · `
          + `govde/menzil %${govde.toFixed(0)}`;
}

// Mini kutulara tiklama baglanir (bir kez).
function miniTiklamaKur() {
  for (const m of MINI) {
    const kap = document.getElementById(m.kutu);
    if (!kap || kap.dataset.tikBagli === "1") continue;
    kap.dataset.tikBagli = "1";
    kap.addEventListener("click", (e) => miniMumSec(m, e.clientX));
    // Kutudan cikinca genel ozete geri don.
    kap.addEventListener("pointerleave", () => miniOzetYaz(m));
  }
}

async function izleriYukle() {
  const istenen = _sembol;
  const d = await apiGet("/yerel/emirler", { sessiz: true });
  if (!d || istenen !== _sembol) return;   // eskimis yanit korumasi
  setState({ emirler: d });
  const hepsi = [...(d.kapali || []), ...(d.takip || []), ...(d.acik || [])];
  const benim = hepsi.filter((e) => e.sembol === _sembol);
  // Ayirici: `el_kaynak` VARSA cuzdan/el (AL/AL TAKIP/ALSAT), YOKSA BOT --
  // canli/kagit (`_live`) ayrimindan BAGIMSIZ (Ismail: "botun girdigini
  // farkli renkte, cuzdanla girdigimi de ayri renkte gormeliyim").
  const ayar = getState("ayar") || {};
  const nokta = (e, tur, renk) => ({
    ts: tur === "giris" ? e.ts : (e.kapanis?.ts || e.ts),
    fiyat: tur === "giris" ? +(e.dolan_fiyat || e.fiyat) : +(e.kapanis?.fiyat || 0),
    tur, renk });
  _izler.bot = benim.filter((e) => !e.el_kaynak)
    .flatMap((e) => {
      const r = ayar.renk_bot_giris || "#FF9900";
      return [nokta(e, "giris", r), ...(e.kapanis ? [nokta(e, "cikis", r)] : [])];
    });
  _izler.cuzdan = benim.filter((e) => !!e.el_kaynak)
    .flatMap((e) => {
      const r = ayar.renk_cuzdan_giris || "#FFCC00";
      return [nokta(e, "giris", r), ...(e.kapanis ? [nokta(e, "cikis", r)] : [])];
    });
  basligiYaz();
  cizIste();
}

// --- emir gonderme ---
// Emirde kullanilmayan, cuzdanda birakilan pay (USDT).
//
// 23.09.2026, Ismail: "islem tutari cuzdanimizda bulunan usdt nin 1 dolar
// altini bolmesi lazim" -- yani hesap bakiyesinin TAMAMI degil, 1 USDT
// pay birakilarak kalan bolunur. Komisyon ve fiyat kaymasi icin tampon.
const REZERV_USDT = 1;

// Emir tutari: (serbest USDT - rezerv) x secilen yuzde.
//
// ONCEKI DAVRANIS: sabit `ayar.tutar` (30 USDT) yuzdeyle carpiliyordu --
// cuzdanda 5 USDT olsa bile 30 USDT'lik emir deneniyor, borsa reddediyordu.
// Artik taban GERCEK bakiyedir; canli modda Binance'deki serbest USDT,
// kagit modda kagit cuzdanin serbest bakiyesi.
// Emir tutarinin tabani: GERCEK Binance cuzdanindaki serbest USDT.
//
// 23.09.2026, Ismail: "28.95 usdt var ama ustteki islem miktari 29 dolar
// diyor". Sebep: dry run modunda KAGIT cuzdanin serbest bakiyesi
// (30 USDT) taban aliniyordu; 30 - 1 = 29 cikiyordu. Oysa ekranda
// kullanicinin gordugu rakam GERCEK bakiyesi (28.95).
//
// Cuzdan sayfasi zaten her iki modda da gercek parayi gosteriyor
// (bkz. 7.9); emir tutari da ayni rakamdan turetilmeli ki ekranda
// gorulen ile hesaplanan ayni olsun. Gercek bakiye okunamazsa (anahtar
// yok / Binance'e ulasilamadi) kagit cuzdana dusulur.
//
// NOT: kagit modda sunucu tarafindaki bakiye kontrolu yine KAGIT
// cuzdana bakar (`get_free_quote_balance(live=False)`); gercek bakiye
// kagit ana paradan buyukse emir oradan reddedilebilir ve sebebi acikca
// bildirilir.
function serbestBakiye() {
  const c = getState("cuzdan");
  if (!c) return null;                       // bakiye HENUZ bilinmiyor
  const v = c.gercek?.serbest ?? c.kagit?.serbest;
  return v == null ? null : +v;
}

function tutarHesapla() {
  const serbest = serbestBakiye();
  if (serbest == null) return null;          // bilinmiyorsa emir ACILMAZ
  const yuzde = +(document.getElementById("trYuzde")?.value || 100);
  return Math.max(0, serbest - REZERV_USDT) * (yuzde / 100);
}

function tutariYaz() {
  const e = document.getElementById("trTutar");
  const serbest = serbestBakiye();
  const tutar = tutarHesapla();
  if (e) {
    e.textContent = tutar == null ? "bakiye bekleniyor" : formatUsdt(tutar) + " USDT";
    e.title = serbest == null ? "cuzdan bakiyesi henuz alinmadi"
      : `serbest ${formatUsdt(serbest)} - ${REZERV_USDT} rezerv = `
        + `${formatUsdt(Math.max(0, serbest - REZERV_USDT))} USDT bolunuyor`;
  }
  const y = +(document.getElementById("trYuzde")?.value || 20);
  for (const s of document.querySelectorAll("#trYuzdeEt [data-y]")) {
    s.classList.toggle("se", +s.dataset.y === y);
  }
  butonlariTazele();
}

// Emir butonlarinin acik/kapali durumunu belirler.
//
// 23.09.2026 HATA (Ismail: "ayarlardan canliyi aktif ettim ama butonlar
// kapali geldi"): yedi butonun hepsi `index.html`'de `disabled` yaziliydi
// ve JS'te onlari ACAN TEK BIR SATIR YOKTU. Yani butonlar yalnizca canli
// modda degil, DRY RUN'da da hicbir zaman calismiyordu; yedi tiklama
// dinleyicisi de oluydu. Kural artik tek yerde ve olculebilir.
function butonlariTazele() {
  const ayar = getState("ayar") || {};
  const tutar = tutarHesapla();
  const poz = acikPozisyon();
  const coinVar = !!_sembol;
  const tutarVar = tutar != null && tutar > 0;
  // Canli modda gercek emir icin API anahtari SART.
  const alinabilir = coinVar && tutarVar && (!ayar.canli || ayar.anahtar_var);

  const ac = (id, kosul) => {
    const d = document.getElementById(id);
    if (d) d.disabled = !kosul;
  };
  for (const id of ["btnAl", "btnAlTakip", "btnAlSat1", "btnAlSat2", "btnAlSat3"]) {
    ac(id, alinabilir);
  }
  ac("btnDryrunGiris", coinVar && tutarVar);   // her zaman kagit
  ac("btnSat", !!poz);                         // yalnizca acik pozisyon varken

  const not = document.getElementById("trButonNot");
  if (not) {
    not.textContent = !coinVar ? "once coin sec"
      : !tutarVar ? (serbestBakiye() == null ? "cuzdan bakiyesi bekleniyor"
                                             : "yetersiz bakiye")
      : (ayar.canli && !ayar.anahtar_var) ? "canli mod icin API anahtari gerekli"
      : "";
  }
}

// Son 12 adet 5 dk mumda (1 saat) %3+ yukselis varsa uyari metni doner, yoksa null. Emri ENGELLEMEZ.
export function warnIfChasingEntry(mumlar) {
  if (!mumlar || mumlar.length < 13) return null;
  const son = +mumlar.at(-1).k, once = +mumlar.at(-13).k;
  if (!(son > 0) || !(once > 0)) return null;
  // Esik journal_analysis.PUMP_ESIK ile ayni bicim (carpim) -- %3'u tam yakalar, kayan nokta kaymaz.
  if (!(son > once * 1.03)) return null;
  return `UYARI: son 1 saatte +${((son / once - 1) * 100).toFixed(2)}% yukselmis, pump sonrasi giriyorsun`;
}

async function emirGonder(kaynak) {
  if (!_sembol) return showToast("ONCE COIN SEC", "iptal");
  const a = getState("ayar") || {};
  const canli = !!a.canli;
  const onaySiz = document.getElementById("islemOnaySwitch")?.checked;
  const tutar = tutarHesapla();
  if (tutar == null || tutar <= 0) {
    return showToast("CUZDAN BAKIYESI ALINAMADI", "hata");
  }
  const limit = isLimitOpen() ? getLimitPrice() : null;
  const pump = warnIfChasingEntry(_mumlar);

  if (!onaySiz || canli) {
    const ok = await askConfirm(
      `${buttonLabel(kaynak)} — ${_sembol}`,
      `${canli ? "GERCEK PARA" : "KAGIT"} · tutar ${formatUsdt(tutar)} USDT` +
      (limit ? ` · limit ${formatPrice(limit)}` : " · piyasa") +
      (pump ? ` · ${pump}` : ""),
      { onayMetni: canli ? "GERCEK EMIR GONDER" : "KAGIT EMIR" });
    if (!ok) return;
  } else if (pump) {
    showToast(pump, "uyari", 6000);
  }
  const c = await apiPost("/yerel/emir",
    { sembol: _sembol, kaynak, tutar, canli, limit: limit || undefined });
  if (c?.ok) {
    showToastDetail(`${buttonLabel(kaynak)} GONDERILDI`,
      `${_sembol} · ${formatUsdt(c.emir.tutar)} USDT`, canli ? "alis" : "bilgi");
    refreshNow();
  }
}

// 04.10.2026, Ismail: "dryrun ile al butonu, dry run icin SABIT 30 dolar var sayarak
// alacak; dryrunla alda limit yok". Tutar gercek cuzdandan HESAPLANMAZ; kagit
// cuzdanin serbest bakiyesine bakilmaz (30 varmis gibi). Fiyat: anlik (LIMIT yok).
const DRYRUN_TUTAR = 30;
async function kagitGiris() {
  if (!_sembol) return showToast("ONCE COIN SEC", "iptal");
  const c = await apiPost("/yerel/dryrun_giris",
    { sembol: _sembol, kaynak: "al", tutar: DRYRUN_TUTAR, bakiye_kontrol: false });
  if (c?.ok) { showToast("KAGIT GIRIS ACILDI", "bilgi"); refreshNow(); }
}

async function pozisyonKapat() {
  const poz = acikPozisyon();
  if (!poz) return showToast("ACIK POZISYON YOK", "iptal");
  if (!await askConfirm("POZISYONU KAPAT",
    `${_sembol} piyasadan kapatilacak.`, { onayMetni: "KAPAT" })) return;
  const c = await apiPost("/yerel/emir/kapat",
    { id: poz.id, canli: poz._live ?? poz.canli });
  if (c?.ok) {
    const kar = c.emir?.kar_p;
    if (c.emir?.kapanis?.toz) {
      showToastDetail("POZISYON KAPANDI (toz)",
        `${_sembol} ${formatSigned(kar)} -- asgari tutar altinda, coin borsada kaldi`,
        "uyari", 7000);
    } else {
      showToastDetail("POZISYON KAPANDI",
        `${_sembol} ${formatSigned(kar)}`,
        kar > 0 ? "kar" : "zarar");
    }
    refreshNow();
  }
}

// --- kurulum ---
// Islem panelini kurar: grafikler, dugmeler ve canli akis.
export function mountTradePanel() {
  if (_kuruldu) {
    seciliSembolDegisti();
    return;
  }
  _kuruldu = true;
  baglaYontemKapat();

  // gosterge dugmeleri -- KULLANICI tercihi, dongu ezmez
  document.getElementById("gostergeDugmeler")?.addEventListener("click", (e) => {
    const g = e.target.closest("[data-g]")?.dataset.g;
    if (!g) return;
    const t = { ...gosterge() };
    t[g] = !t[g];
    setTercih("gosterge", t);
    e.target.closest("[data-g]").classList.toggle("acik", t[g]);
    cizIste();
    if (g === "ha") miniCiz();   // mini grafikler (5m/1h/4h/1d) de HA'ya donsun
    // CHCM: acilinca, o an ekrandaki coin icin HEMEN ceker (30 sn'lik
    // dongusunu beklemez) -- kapatinca veriyi tutmanin bir zarari yok,
    // ciz() zaten G_.hacimCokBorsa kapaliyken onu kullanmaz.
    if (g === "hacimCokBorsa" && t[g]) cokBorsaHacimYukle();
  });

  // iz dugmeleri -- F1: yenileme dongusu bunlari ASLA degistirmez
  const izBagla = (id, anahtar) => {
    const d = document.getElementById(id);
    if (!d) return;
    d.classList.toggle("acik", !!getTercih(anahtar));
    d.addEventListener("click", () => {
      const yeni = !getTercih(anahtar);
      setTercih(anahtar, yeni);
      d.classList.toggle("acik", yeni);
      izleriCiz();
    });
  };
  izBagla("btnIzCuzdan", "izCuzdan");
  izBagla("btnIzStrateji", "izStrateji");

  // zoom
  // 02.10.2026: "-"/"+" yalniz mum genisligini degistiriyordu; kaydirma PIKSEL
  // olarak eski degerde kaliyordu. 200M'den sonra "-" -> gorunum verinin
  // disina dusuyor, grafik BOS kaliyordu. Artik sag kenardaki mum yerinde
  // kalir ve kaydirma yeni sinira oturtulur.
  const zoomTusu = (carpan) => {
    if (tvAcik()) { zoomTvChart(carpan); return; }
    const W = document.getElementById(ANA)?.clientWidth || 800;
    const sagMum = (getScrollX() + W) / getCandleWidth();
    applyZoom(carpan);
    setScrollX(sagMum * getCandleWidth() - W, maxScrollX(_mumlar.length, W));
    cizIste();
  };
  document.getElementById("btnZoomAz")?.addEventListener("click", () => zoomTusu(1 / 1.25));
  document.getElementById("btnZoomCok")?.addEventListener("click", () => zoomTusu(1.25));
  document.getElementById("btnSon25")?.addEventListener("click", () => {
    if (tvAcik()) { showRecentTvCandles(50, _mumlar.length); return; }
    clearPriceLock();
    fitRecentCandles(50, document.getElementById(ANA)?.clientWidth || 800, _mumlar.length);
    cizIste();
  });
  document.getElementById("btnSon128")?.addEventListener("click", () => {
    if (tvAcik()) { showRecentTvCandles(128, _mumlar.length); return; }
    clearPriceLock();
    fitRecentCandles(128, document.getElementById(ANA)?.clientWidth || 800, _mumlar.length);
    cizIste();
  });
  document.getElementById("btnSon200")?.addEventListener("click", () => {
    if (tvAcik()) { showRecentTvCandles(200, _mumlar.length); return; }
    clearPriceLock();
    fitRecentCandles(200, document.getElementById(ANA)?.clientWidth || 800, _mumlar.length);
    cizIste();
  });
  document.getElementById("btnTumu")?.addEventListener("click", () => {
    if (tvAcik()) { showAllTvCandles(); return; }
    clearPriceLock();
    fitAllCandles(_mumlar.length, document.getElementById(ANA)?.clientWidth || 800);
    cizIste();
  });

  // TV grafiginde kaydirma/zoom grafigin KENDISINDE -- eski hareketler cizim tetiklemez.
  attachChartGestures(ANA, () => { if (!tvAcik()) cizIste(); });
  stopSurukleBagla();
  limitSurukleBagla();
  const stpDugme = document.getElementById("btnStp");
  if (stpDugme) {
    stpDugme.classList.toggle("acik", !!getTercih("stpAcik"));
    stpDugme.addEventListener("click", () => {
      const yeni = !getTercih("stpAcik");
      setTercih("stpAcik", yeni);
      stpDugme.classList.toggle("acik", yeni);
      showToast(yeni ? "STP acik: STOP cizgisini surukleyebilirsin" : "STP kapali", "bilgi", 1800);
      cizIste();
    });
  }
  const tvDugme = document.getElementById("btnTvGrafik");
  if (tvDugme) {
    tvDugme.classList.toggle("acik", tvAcik());
    tvDugme.addEventListener("click", () => {
      const yeni = getTercih("tvGrafik") === false;
      setTercih("tvGrafik", yeni);
      tvDugme.classList.toggle("acik", yeni && isTvChartAvailable());
      if (!yeni) unmountTvChart(); else _tvSigdir = true;
      const kap = document.getElementById(ANA);
      if (kap) kap.replaceChildren();
      if (!yeni) fitRecentCandles(120, kap?.clientWidth || 800, _mumlar.length);
      cizIste();
    });
  }
  mumBilgisiKur();
  miniTiklamaKur();
  attachLimitHandle(ANA, { switchId: "limitCizgiSwitch", kaydiriciId: "limitKaydirici",
    onChange: () => {
      // 27.09.2026, Ismail: "LIMIT switch acilinca sagdaki kaydirma
      // cubugu cikinca mumlarin 4-5 tanesi kayboluyor" -- kaydirici
      // (16px, .limitKaydirici) acilinca flex-sibling olarak yer kapliyor,
      // #grafCanli DARALIYOR. Kaydirma (scroll) konumu ESKI genis
      // genislige gore hesaplanmisti; konteyner daralinca EN SON (canli)
      // mumlar konteynerin disina tasip kayboluyordu. Anahtar her
      // degisiminde SONA yeniden kaydir -- canli mum HER ZAMAN gorunsun.
      const kap = document.getElementById(ANA);
      if (kap) scrollToEnd(_mumlar.length, kap.clientWidth);
      cizIste();
    } });

  // emir butonlari
  document.getElementById("btnAl")?.addEventListener("click", () => emirGonder("al"));
  document.getElementById("btnAlTakip")?.addEventListener("click", () => emirGonder("altakip"));
  document.getElementById("btnAlSat1")?.addEventListener("click", () => emirGonder("alsat1"));
  document.getElementById("btnAlSat2")?.addEventListener("click", () => emirGonder("alsat2"));
  document.getElementById("btnAlSat3")?.addEventListener("click", () => emirGonder("alsat3"));
  document.getElementById("btnDryrunGiris")?.addEventListener("click", kagitGiris);
  document.getElementById("btnSat")?.addEventListener("click", pozisyonKapat);
  document.getElementById("trMini")?.addEventListener("click", () => {
    const poz = acikPozisyon();
    if (poz) openMethodPicker(poz, () => refreshNow());
  });

  // 03.10.2026, Ismail: "engellenmis coinde farkli gozukmeli; engelle diyorum ama
  // hala engelle aktif, sanki engellenmemis gibi". Dugme artik AC/KAPA: engelli
  // coinde kirmizi "ENGELLI" yazar, basinca engel kalkar.
  document.getElementById("btnTrHaric")?.addEventListener("click", async () => {
    if (!_sembol) return;
    const s = _sembol;
    const d = await apiGet("/yerel/haric", { sessiz: true });
    let liste = [...(d?.haric || [])];
    const bicim = engelBicimleri(s);
    const engelli = bicim.some((x) => liste.includes(x));
    liste = engelli ? liste.filter((x) => !bicim.includes(x)) : [...liste, s];
    const c = await apiPost("/yerel/haric", { haric: liste });
    if (!c) return;
    setState({ haric: c.haric || liste });
    showToast(engelli ? `${coinName(s)} ENGELI KALDIRILDI` : `${coinName(s)} ENGELLENDI (haric listesi)`,
              engelli ? "ok" : "iptal");
    engelDurumuYaz();
  });

  // tutar kaydirici
  const ty = document.getElementById("trYuzde");
  ty?.addEventListener("input", tutariYaz);
  document.getElementById("trYuzdeEt")?.addEventListener("click", (e) => {
    const y = e.target.closest("[data-y]")?.dataset.y;
    if (y && ty) { ty.value = y; tutariYaz(); }
  });

  window.addEventListener("resize", () => cizIste());

  // Calisma modu ya da anahtar durumu degisince butonlar ANINDA tazelensin
  // (emirler dongusunu 10 saniye beklemeden).
  subscribeState("ayar", butonlariTazele);

  // `onDurum` BAGLANMAMISTI: ust bardaki nokta ve "#wsDurum" yazisi bu
  // geri cagirmadan besleniyor, dolayisiyla islem ekraninda soket calissa
  // bile yazi sonsuza kadar "baglanmadi" kaliyordu (Ismail: "websocket
  // surekli baglanmiyor degil mi"). Anasayfada bagliydi, burada degildi.
  _soket = createSocketManager({
    // Rozeti yalnizca BU sayfa acikken yaz (bkz. trade.js aciklamasi).
    onDurum: (d, ek) => { if (getActivePage() === "islem") renderConnectionBadge(d, ek); },
    onGecikme: (ms) => { if (getActivePage() === "islem") renderLatency(ms); },
    onFiyat: (s, f, _onceki, ts) => {
      if (s !== _sembol) return;
      _sonFiyat = f;
      // Acik mumun kapanisi ANLIK fiyattir; tepe/dip de onunla genisler --
      // yoksa yandaki canli bar mumun gercek araligini gostermez.
      // Mum dizisi YALNIZCA bu sembole aitse guncellenir. `_mumlar`
      // her coin degisiminde bosaltilir; burada ayrica fiyatin mumun
      // makul araliginda oldugu dogrulanir -- yanlis coinin fiyati
      // son mumu devasa acmasin.
      if (_mumlar.length) {
        const son = _mumlar.at(-1);
        const makul = son.a > 0 && f > son.a * 0.5 && f < son.a * 2;
        if (makul && ts && ts >= son.t + MUM_MS) {
          // 02.10.2026: YENI 5 dk donemi basladi -> yeni mum ac. Eskiden tikler
          // KAPANMIS mumu uzatiyor (kapanis/tepe/dip bozuluyor), 30 sn'lik
          // yenilemede gercek mumlar gelince geri zipliyordu.
          _mumlar.push({ t: son.t + Math.floor((ts - son.t) / MUM_MS) * MUM_MS,
                         a: f, y: f, d: f, k: f, h: 0 });
          _yeniMumAcildi = true;
        } else if (makul) {
          son.k = f;
          if (f > son.y) son.y = f;
          if (f < son.d) son.d = f;
        }
      }
      // Cizgi, kullanici ona dokunmadigi surece son mumu TAKIP eder.
      // Tavan (limit_ust_yuzde) her tikte ayardan okunur -- ayar degisince
      // sayfa yenilenmeden gecerli olur.
      setLimitCapPercent((getState("ayar") || {}).limit_ust_yuzde ?? 0.4);
      followPrice(f, "limitKaydirici");
      basligiYaz();
      if (_yeniMumAcildi) { _yeniMumAcildi = false; cizIste(); } else hafifCiz();
    },
  });

  // Emir tutari GERCEK bakiyeden hesaplandigi icin bu sayfada da cuzdan
  // cekilir. Sayfaya bagli (`sayfa: "islem"`): baska sayfalardayken
  // Binance hesap sorgusu ATILMAZ.
  registerPoll("islemBakiye", 20, () => apiGet("/yerel/bakiye", { sessiz: true }),
               { sayfa: "islem" });
  sharePollResult("islemBakiye", (d) => { setState({ cuzdan: d }); tutariYaz(); });

  registerPoll("islemEmirler", 10, () => apiGet("/yerel/emirler", { sessiz: true }), { sayfa: "islem" });
  sharePollResult("islemEmirler", (d) => {
    setState({ emirler: d });
    butonlariTazele();           // SAT butonu acik pozisyona bagli
    if (_sembol) izleriYukle();
  });
  // Yenileme zoom'a DOKUNMAZ (sigdir verilmiyor).
  // 05.10.2026, Ismail: "stratejiden 1h heikinashileri kaldirdim ama soldaki panelde hala
  // gozukuyor". Sinyaller yalniz coin degisince yukleniyordu; strateji degisince ESKI
  // kurallarin sinyalleri kaliyordu. STRATEJI acikken 60 sn'de bir yenilenir.
  registerPoll("islemSinyal", 60, async () => {
    if (_sembol && getTercih().izStrateji) await sinyalleriYukle();
    return true;
  }, { sayfa: "islem" });
  registerPoll("islemMum", 30, async () => { await anaMumlariYukle(); return true; },
               { sayfa: "islem" });

  seciliSembolDegisti();
}

// Sayfadan cikilinca websocket aboneligi birakilir -- arka planda
// gereksiz akis tutulmasin.
// Sayfadan cikilinca websocket aboneligini birakir.
// 03.10.2026, Ismail: "trade ekranina gecince kesilmesin". Trade ekraninin soketi
// sayfadan cikinca KAPATILMAZ: secili coine abone kalir (tek akis, maliyeti cok
// dusuk), geri donuldugunde fiyat kesintisiz akar.
export function unmountTradePanel() {
  /* bilerek bos: abonelik korunur */
}

// Secili coin degisince tum paneli tazeler.
export async function seciliSembolDegisti() {
  let s = getState("seciliSembol");
  if (!s) {
    // Coin secilmeden girildiyse tablodaki ilk coini goster --
    // bos ekran yerine calisir bir panel.
    //
    // 23.09.2026: `satirlar` yalnizca ANASAYFANIN zamanlayicisi doldurur.
    // Dogrudan `#islem` adresiyle acildiginda (ya da o sayfadayken
    // yenilendiginde) o zamanlayici hic calismamis oluyor, liste bos
    // kaliyor ve panel TAMAMEN olu aciliyordu -- 4 mini grafik de, 5M de
    // "COIN SECILMEDI", websocket "baglanmadi". Olculdu: profil %99.8 bos.
    // Cozum: liste bossa ozet ucunu panelin kendisi bir kez ceker.
    s = (getState("satirlar") || [])[0]?.sembol;
    if (!s) {
      const d = await apiGet("/yerel/ozet?n=400", { sessiz: true });
      if (d?.satir?.length) {
        setState({ satirlar: d.satir });
        s = d.satir[0].sembol;
      }
    }
    if (!s) return;
    setState({ seciliSembol: s });
  }
  if (s === _sembol) { cizIste(); return; }
  _sembol = s;
  _mumlar = [];
  _sonFiyat = null;
  _imlec = null;
  _cokBorsaHacim = {};   // ESKI coinin CHCM verisi YENI coine bindirilmesin
  // Coin degisir degismez tuvali BOSALT. `anaCiz` mum dizisi bosken erken
  // donuyor, dolayisiyla eski SVG ekranda kaliyordu: baslik yeni coini
  // yazarken grafik hala ESKI coinin mumlarini gosteriyordu (olcum:
  // baslik SENTUSDT iken aralik baska bir coine aitti). Artik yeni veri
  // gelene kadar "YUKLENIYOR" gorunur -- yanlis coin hic gosterilmez.
  renderCandleChart(ANA, [], { bosMetin: "YUKLENIYOR" });
  for (const m of MINI) {
    _miniMumlar.delete(m.kutu);
    renderMiniChart(m.kutu, [], { bosMetin: "YUKLENIYOR" });
  }
  resetCandleWidth();
  setScrollX(0);
  clearPriceLock();
  resetLimit();          // yeni coin: cizgi yeniden TAKIP moduna doner
  basligiYaz();
  engelDurumuYaz();
  engelListesiniYukle();   // liste baska sayfada degismis olabilir
  tutariYaz();
  alsatEtiketleri();
  _soket?.subscribeSymbols([s]);
  // Soket zaten acik olabilir; rozet DEGISIM olayi beklemeden tazelensin
  // (bkz. trade.js/rozetiTazele aciklamasi).
  if (_soket && getActivePage() === "islem") {
    renderConnectionBadge(_soket.getConnectionState(), 1);
  }
  await anaMumlariYukle({ sigdir: true });   // coin degisti: gorunumu sifirla
  await Promise.all([miniYukle(), izleriYukle(), sinyalleriYukle()]);
}
