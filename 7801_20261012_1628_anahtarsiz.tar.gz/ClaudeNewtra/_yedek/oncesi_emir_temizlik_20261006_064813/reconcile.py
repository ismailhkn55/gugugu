"""Borsa ile defteri uzlastirir.

Defter "acik" diyor ama Binance'de o coin yoksa pozisyon elle satilmis
demektir; tersi de olabilir (borsada var, defterde yok). Bu modul ikisini
hizalar.

Eski `pozisyon_uzlastir` 19.09.2026'da duzeltilmisti (kilit icinde cift
kontrol) -- o dogru desen KORUNDU. Degisen: `live` artik zorunlu, ag
cagrilari kilit DISINDA yapiliyor ve gunluk `jsonstore` uzerinden yaziliyor.
"""
from __future__ import annotations

from typing import Any, Mapping

from app.config.paths import get_reconcile_log_path
from app.core.applog import get_logger
from app.core.jsonstore import read_json_file, write_json_file
from app.core.locking import ledger_lock
from app.core.timeutil import now_ms
from app.exchange.binance_rest import fetch_account_balances
from app.market.exclusions import load_position_exclusions
from app.trading.ledger import list_open_orders, load_ledger, save_ledger

_log = get_logger(__name__)
LOG_TAVAN = 200
TOZ_ESIGI_USDT = 1.0        # bu tutarin altindaki bakiye "toz" sayilir


# Uzlastirma gunlugune kayit ekler (son LOG_TAVAN kayit tutulur).
def log_reconciliation(record: Mapping[str, Any]) -> None:
    yol = get_reconcile_log_path()
    d = read_json_file(yol, {"kayitlar": []}) or {"kayitlar": []}
    d.setdefault("kayitlar", []).insert(0, {"ts": now_ms(), **dict(record)})
    d["kayitlar"] = d["kayitlar"][:LOG_TAVAN]
    write_json_file(yol, d)


# Borsadaki varlik miktarlari: {SEMBOL: miktar}. Haric tutulanlar elenir.
def fetch_exchange_holdings() -> dict[str, float]:
    haric = {x.upper() for x in load_position_exclusions()}
    hesap = fetch_account_balances()
    cikti: dict[str, float] = {}
    for b in hesap.get("balances", []):
        varlik = b["asset"].upper()
        if varlik in ("USDT",) or varlik in haric:
            continue
        toplam = float(b.get("free") or 0) + float(b.get("locked") or 0)
        if toplam > 0:
            cikti[varlik + "USDT"] = toplam
    return cikti


# Borsada olup defterde ACIK OLMAYAN varliklari takip listesine alir.
#
# 23.09.2026 Ismail: "cuzdan da olanlari takip edilenler listesine almasi
# lazim". DOKUMANTASYON 7.x: "Deftere hic yazilmamis gercek bir bakiye
# bulunursa ... normal AL butonu davranisiyla (kademeli stop) otomatik
# takibe alinir." BNB/USDT "pozisyon_haric" nedeniyle zaten
# "fetch_exchange_holdings" icinde elenir; toz esigi altindakiler de
# alinmaz. Yalnizca GERCEK (live) deftere yazar.
def adopt_untracked_holdings(live: bool, holdings: Mapping[str, float],
                             prices: Mapping[str, Any] | None = None) -> list[dict]:
    if not live:
        return []
    if not holdings:
        return []

    # Defterde zaten acik/takipte olan semboller: onlari ATLA.
    acik_semboller = {p.get("sembol") for p in list_open_orders(live)}
    adaylar = sorted(s for s in holdings if s and s not in acik_semboller)
    if not adaylar:
        return []

    # Fiyatlar: verilenler + eksikler icin toplu cekilir.
    from app.market.price_source import get_prices
    fiyat_ham: dict[str, Any] = dict(prices or {})
    # tuple (fiyat, kaynak) veya duz sayi kabul et
    def _p(x):
        if isinstance(x, (tuple, list)):
            return float(x[0]) if x and x[0] is not None else None
        try:
            return float(x) if x is not None else None
        except (TypeError, ValueError):
            return None

    hala = [s for s in adaylar if _p(fiyat_ham.get(s)) is None]
    if hala:
        for s, v in get_prices(hala).items():
            fiyat_ham.setdefault(s, v)

    # AL butonuyla AYNI cikis plani (kademeli stop) -- DOKUMANTASYON geregi.
    from app.config.settings import load_settings
    from app.core.timeutil import now_ms
    from app.exchange.symbol_rules import (get_symbol_filters,
                                           round_price_to_tick,
                                           round_quantity_to_step)
    from app.market.rank_repository import capture_market_snapshot
    from app.trading.exit_rules import apply_plan_to_order, build_manual_plan
    from app.trading.ledger import append_order

    ayar = load_settings()
    plan = build_manual_plan(ayar)
    eklenen: list[dict] = []

    for s in adaylar:
        miktar_raw = float(holdings.get(s) or 0)
        if miktar_raw <= 0:
            continue
        giris = _p(fiyat_ham.get(s))
        if not giris or giris <= 0:
            _log.warning("takibe alinamadi (fiyat yok): %s", s)
            continue
        deger = miktar_raw * giris
        if deger < TOZ_ESIGI_USDT:
            continue    # toz: kucuk bakiye takip listesine girmez

        try:
            kurallar = get_symbol_filters(s)
            tick = float(kurallar.get("tick") or 0)
            step = float(kurallar.get("step") or 0)
            giris_y = round_price_to_tick(giris, tick) if tick else giris
            miktar = round_quantity_to_step(miktar_raw, step) if step else miktar_raw
            if miktar <= 0:
                continue
        except Exception as e:
            _log.warning("takibe alinamadi (sembol kurallari %s): %s", s, e)
            continue

        kayit: dict[str, Any] = {
            "sembol": s, "taraf": "BUY", "dugme": "UZLASTIRMA",
            "fiyat": giris_y, "miktar": miktar,
            "tutar": round(miktar * giris_y, 6),
            "ts": now_ms(), "durum": "DOLDU", "borsa_id": None,
            "borsa_durum": "ADOPTED",
            "dolan_miktar": miktar, "dolan_fiyat": giris_y,
            "dolum_ts": now_ms(), "kapanis": None, "kar": None,
            "takip": True, "hiz": None,
            "el_kaynak": "al",     # kademeli stop plani (plan_for_source "al")
            # YAPAY ZEKA MIMO (24.09.2026): UI rozeti -- el_kaynak "al"
            # kalmali (plan davranisi), etiket yontem_label'dan okunur.
            "yontem_label": "uzlastirma",
            "giris_piyasa": None,
        }
        try:
            kayit["giris_piyasa"] = capture_market_snapshot(s)
        except Exception as e:
            # YAPAY ZEKA MIMO (24.09.2026): giris_piyasa None sessiz kalmasin.
            # Derin inceleme: PROM icin snapshot None kalmisti, log yoktu.
            _log.warning("takibe alindi ama giris_piyasa alinamadi (%s): %s", s, e)
        if kayit.get("giris_piyasa") is None:
            _log.warning("takibe alindi ama giris_piyasa bos (%s) -- "
                         "rank sqlite erisilemedi mi?", s)
        apply_plan_to_order(kayit, plan, entry_price=giris_y, atr_pct=None,
                            round_price=(lambda p: round_price_to_tick(p, tick))
                            if tick else None)
        kayan = append_order(kayit, live)
        tutar_usdt = round(miktar * giris_y, 4)
        kayit_log = {"sembol": s, "miktar": miktar, "giris": giris_y,
                     "tutar_usdt": tutar_usdt, "id": kayan.get("id"),
                     "aciklama": "Binance'te bulundu, deftede kaydi yoktu -- otomatik takibe alindi"}
        log_reconciliation({"tur": "takibe_alindi", "live": live, **kayit_log})
        _log.info("takibe alindi: %s x %.6f @ %.8f (id=%s)",
                  s, miktar, giris_y, kayan.get("id"))
        eklenen.append(kayit_log)
    return eklenen


# Defterde acik ama borsada OLMAYAN pozisyonlari bulur (elle satilmis).
#
# 23.09.2026 VERI BOZULMASI DUZELTMESI:
# Bu fonksiyon `list_open_orders` dondugu HER kaydi pozisyon sayiyordu --
# HENUZ DOLMAMIS limit emirleri dahil. Dolmamis bir alis emrinin karsiligi
# borsada henuz yoktur (`dolan_miktar = 0`), dolayisiyla "borsada yok"
# denip ELLE_SATILDI olarak kapatiliyordu.
#
# Gercekte yasandi: 5.59 USDT'lik bir LIMIT alis emri borsada ACIK
# beklerken, 60 saniye sonraki uzlastirma turu onu defterden kapatti ve
# UYDURMA bir kar/zarar yazdi (`kar_brut_p: 0.434`, `kar_p: -0.066`).
# Emir Binance'te durmaya devam etti; para kilitli kaldi ve defterde hic
# izi kalmadigi icin panel onu ARTIK TAKIP EDEMEZ hale geldi.
#
# Bekleyen emir POZISYON DEGILDIR: yalnizca dolumu olan kayitlar
# uzlastirmaya girer. Bekleyen emirlerin takibi `sync_with_exchange`'in
# isidir (borsa durumunu okur, dolunca `durum`u gunceller).
def detect_manual_sells(live: bool, holdings: Mapping[str, float],
                        prices: Mapping[str, Any] | None = None) -> list[dict]:
    eksik = []
    for poz in list_open_orders(live):
        # Dolumu olmayan (bekleyen) emirler atlanir.
        if float(poz.get("dolan_miktar") or 0) <= 0:
            continue
        if str(poz.get("durum") or "").upper() not in ("DOLDU", "KISMI"):
            continue
        s = poz["sembol"]
        elde = float(holdings.get(s) or 0)
        # Beklenen miktar GERCEK DOLUMDUR; nominal `miktar` degil
        # (kismi dolumda nominal miktar yanlis kiyas verir).
        beklenen = float(poz.get("dolan_miktar") or 0)
        if elde >= beklenen * 0.5:          # yarisi bile duruyorsa hala acik say
            continue
        fiyat = None
        if prices:
            f = prices.get(s)
            fiyat = f[0] if isinstance(f, tuple) else f
        deger = (elde * float(fiyat)) if (fiyat and elde) else 0.0
        eksik.append({"id": poz["id"], "sembol": s, "beklenen": beklenen,
                      "elde": elde, "toz": deger < TOZ_ESIGI_USDT})
    return eksik


# Elle satilmislari kilit icinde, CIFT KONTROLLE kapatir.
# 19.09.2026'daki dogru desen: kilit alindiktan SONRA defter yeniden okunur
# ve pozisyon hala acik mi diye bakilir.
def reconcile_positions(live: bool, *, prices: Mapping[str, Any] | None = None,
                        commission_pct: float = 0.0,
                        holdings: Mapping[str, float] | None = None) -> dict:
    # YAPAY ZEKA MIMO (24.09.2026): `holdings` opsiyonel -- cagiran bir kez
    # cekip gonderebilir (derin inceleme: cift fetch_exchange_holdings).
    if not isinstance(live, bool):
        raise TypeError("reconcile_positions: `live` acikca True/False verilmeli")
    try:
        elde = dict(holdings) if holdings is not None else fetch_exchange_holdings()
    except Exception as e:
        _log.warning("uzlastirma: borsa bakiyesi alinamadi: %s", e)
        return {"kapatilan": 0, "hata": str(e)}

    adaylar = detect_manual_sells(live, elde, prices)
    kapatilan = []
    for aday in adaylar:
        fiyat = None
        if prices:
            f = prices.get(aday["sembol"])
            fiyat = f[0] if isinstance(f, tuple) else f
        with ledger_lock():
            d = load_ledger(live)
            for i, e in enumerate(d["emirler"]):
                if int(e.get("id", -1)) != int(aday["id"]):
                    continue
                if e.get("kapanis"):       # CIFT KONTROL: arada kapanmis olabilir
                    break
                giris = float(e.get("dolan_fiyat") or e["fiyat"])
                kapanis_fiyat = float(fiyat) if fiyat else giris
                brut = (kapanis_fiyat / giris - 1) * 100 if giris else 0.0
                net = brut - float(commission_pct or 0)
                e["kapanis"] = {"fiyat": kapanis_fiyat, "sebep": "ELLE_SATILDI",
                                "ts": now_ms()}
                e["durum"] = "KAPANDI"
                e["kar_brut_p"] = round(brut, 3)
                e["kar_p"] = round(net, 3)
                d["emirler"][i] = e
                save_ledger(d, live)
                kapatilan.append({"id": e["id"], "sembol": e["sembol"],
                                  "kar_p": e["kar_p"]})
                break
    if kapatilan:
        log_reconciliation({"tur": "elle_satis", "live": live, "kayitlar": kapatilan})
        _log.info("uzlastirma: %d pozisyon ELLE_SATILDI olarak kapatildi", len(kapatilan))

    # Borsada olup defterde olmayanlari takibe AL (BNB/USDT + toz haric).
    try:
        takip_eklenen = adopt_untracked_holdings(live, elde, prices)
    except Exception as e:
        _log.warning("takibe alma basarisiz: %s", e)
        takip_eklenen = []

    return {"kapatilan": len(kapatilan), "ayrinti": kapatilan,
            "borsada_varlik": len(elde),
            "takip_eklenen": len(takip_eklenen),
            "takip_ayrinti": takip_eklenen}


# Borsa ile defteri esitler: once emir durumlari, sonra uzlastirma.
# (eski: borsa_senkron)
def sync_with_exchange(live: bool, *, prices=None, commission_pct: float = 0.0,
                       timeout_minutes: float = 6.0) -> dict:
    from app.trading.order_service import refresh_order_statuses
    durum = refresh_order_statuses(live, timeout_minutes=timeout_minutes)
    uzlastirma = reconcile_positions(live, prices=prices,
                                     commission_pct=commission_pct) if live else {
        "kapatilan": 0, "ayrinti": [], "not": "kagit modda uzlastirma yapilmaz"}
    return {"emir_durum": durum, "uzlastirma": uzlastirma}
