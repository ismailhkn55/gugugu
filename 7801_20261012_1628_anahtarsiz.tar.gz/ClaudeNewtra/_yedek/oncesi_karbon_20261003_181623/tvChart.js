// chart/tvChart.js -- TRADE ana grafigi: TradingView Lightweight Charts 4.2.0.
//
// 03.10.2026, Ismail: "trade ekranindaki paneli TradingView'in chart'i ile
// degistirelim artik". Kutuphane yerel dosyadan yuklenir
// (js/vendor/lightweight-charts-4.2.0.js, index.html <script>), internete
// bagli DEGIL. Eski SVG cizici (renderer.js) SILINMEDI: TV dugmesi kapatilinca
// ona donulur.
//
// Gosterilenler: mum (HA dugmesi dahil), hacim, EMA 7/20/48/99, BB 20/2,
// VWAP, strateji noktasi + sonuca gore DIKEY cizgi (yesil = once +%2,
// kirmizi = once -%2, turkuaz = belli degil), gercek islem izleri (ok),
// STOP / HEDEF / GIRIS / LIMIT fiyat cizgileri.
// Saat: grafik ekseni TR saati (UTC+3) -- LWC UTC gosterir, zaman 3 saat kaydirilir.
import { ema, bollinger, vwap, heikinAshi } from "./indicators.js";

const TR_SN = 3 * 3600;
const EMA_DONEM = [7, 20, 48, 99];
const EMA_RENK = ["#FFCC00", "#33CCCC", "#9999FF", "#FF9933"];
let _grafik = null;
let _kap = null;
let _ser = null;
let _fiyatCizgileri = [];
let _izgara = [];          // %1 yatay cizgileri (createPriceLine)
let _izgaraAnahtar = "";
let _sonUzunluk = 0;

const zaman = (ms) => Math.floor(ms / 1000) + TR_SN;
const css = (ad, yedek) =>
  getComputedStyle(document.documentElement).getPropertyValue(ad).trim() || yedek;

// Kutuphane yuklu mu (yerel <script> yuklenemediyse eski grafige donulur).
export function isTvChartAvailable() {
  return typeof window.LightweightCharts?.createChart === "function";
}

// Grafigi kutunun icine kurar (bir kez). Kutudaki SVG cizimi temizlenir.
export function mountTvChart(kutuId) {
  const kap = document.getElementById(kutuId);
  if (!kap || !isTvChartAvailable()) return false;
  if (_grafik && _kap === kap && kap.contains(_grafik._tvKutu)) return true;
  unmountTvChart();
  kap.replaceChildren();
  const ic = document.createElement("div");
  ic.className = "tvGrafik";
  kap.appendChild(ic);
  const L = window.LightweightCharts;
  const metin = css("--metin-sonuk", "#5d7d8a");
  const izgara = css("--izgara-sik", "#0b2028");
  _grafik = L.createChart(ic, {
    autoSize: true,
    layout: { background: { type: "solid", color: "transparent" }, textColor: metin,
              fontFamily: "Share Tech Mono, DejaVu Sans Mono, monospace", fontSize: 11 },
    // 03.10.2026, Ismail: "yatay cizgiler yuzde 1 olacak, KESINLIKLE" -- kutuphanenin
    // kendi yatay izgarasi (yuvarlak fiyat adimlari) KAPALI; yerine %1 cizgileri.
    grid: { vertLines: { color: izgara }, horzLines: { visible: false } },
    rightPriceScale: { borderColor: izgara, scaleMargins: { top: 0.06, bottom: 0.22 } },
    timeScale: { borderColor: izgara, timeVisible: true, secondsVisible: false,
                 rightOffset: 3, barSpacing: 6 },
    crosshair: { mode: L.CrosshairMode.Normal },
    localization: { priceFormatter: (p) => fiyatYaz(p) },
  });
  _grafik._tvKutu = ic;
  const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
  _ser = {
    // dikey sinyal cizgileri: tam boy histogram, kendi gorunmez olceginde (en altta cizilir)
    dikey: _grafik.addHistogramSeries({ priceScaleId: "dikey", priceLineVisible: false,
                                        lastValueVisible: false, base: 0 }),
    hacim: _grafik.addHistogramSeries({ priceScaleId: "hacim", priceFormat: { type: "volume" },
                                        priceLineVisible: false, lastValueVisible: false }),
    mum: _grafik.addCandlestickSeries({ upColor: arti, downColor: eksi, borderUpColor: arti,
                                        borderDownColor: eksi, wickUpColor: arti, wickDownColor: eksi }),
    ema: EMA_RENK.map((r) => _grafik.addLineSeries({ color: r, lineWidth: 1, priceLineVisible: false,
                                                     lastValueVisible: false, crosshairMarkerVisible: false })),
    bb: ["#6699CC", "#6699CC", "#6699CC"].map((r, i) => _grafik.addLineSeries({
      color: r, lineWidth: 1, lineStyle: i === 1 ? 2 : 0, priceLineVisible: false,
      lastValueVisible: false, crosshairMarkerVisible: false })),
    vwap: _grafik.addLineSeries({ color: "#CC99FF", lineWidth: 1, priceLineVisible: false,
                                  lastValueVisible: false, crosshairMarkerVisible: false }),
  };
  _grafik.priceScale("dikey").applyOptions({ visible: false, scaleMargins: { top: 0, bottom: 0 } });
  _grafik.priceScale("hacim").applyOptions({ visible: false, scaleMargins: { top: 0.82, bottom: 0 } });
  _kap = kap;
  _sonUzunluk = 0;
  return true;
}

// Grafigi kaldirir (eski SVG grafige donus).
export function unmountTvChart() {
  if (_grafik) {
    try { _grafik.remove(); } catch { /* zaten kaldirilmis */ }
  }
  _grafik = null; _ser = null; _fiyatCizgileri = []; _kap = null; _sonUzunluk = 0;
  _izgara = []; _izgaraAnahtar = "";
}

export const isTvChartMounted = () => !!_grafik;

function fiyatYaz(p) {
  if (p == null || !isFinite(p)) return "";
  const a = Math.abs(p);
  return p.toFixed(a >= 100 ? 2 : a >= 1 ? 4 : a >= 0.01 ? 5 : 8);
}

const cizgiVerisi = (mumlar, dizi) => {
  const v = [];
  for (let i = 0; i < mumlar.length; i++) {
    if (dizi[i] != null && isFinite(dizi[i])) v.push({ time: zaman(mumlar[i].t), value: dizi[i] });
  }
  return v;
};

// Tam cizim. `o`: {gosterge, sinyaller, sinyalRenk, izler, fiyatCizgileri:[{fiyat, ad, renk}]}
export function drawTvChart(mumlar, o = {}) {
  if (!_grafik || !mumlar?.length) return;
  const g = o.gosterge || {};
  const veri = g.ha ? heikinAshi(mumlar) : mumlar;
  const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
  const ilkCizim = _sonUzunluk === 0;
  _ser.mum.setData(veri.map((m) => ({ time: zaman(m.t), open: m.a, high: m.y, low: m.d, close: m.k })));
  _ser.hacim.setData(!g.hacim ? [] : mumlar.map((m, i) => ({
    time: zaman(m.t), value: m.h || 0,
    color: (veri[i].k >= veri[i].a ? arti : eksi) + "66" })));
  const kapanis = mumlar.map((m) => m.k);
  _ser.ema.forEach((s, i) => s.setData(g.ema ? cizgiVerisi(mumlar, ema(kapanis, EMA_DONEM[i])) : []));
  const b = g.bb ? bollinger(kapanis, 20, 2) : null;
  [["ust"], ["orta"], ["alt"]].forEach(([ad], i) => _ser.bb[i].setData(b ? cizgiVerisi(mumlar, b[ad]) : []));
  _ser.vwap.setData(g.vwap ? cizgiVerisi(mumlar, vwap(mumlar)) : []);

  // --- strateji noktalari + dikey cizgi, gercek islem izleri ---
  const bulBar = (ts) => {      // ts'ye denk gelen (>=) ilk mumun zamani
    for (const m of mumlar) if (m.t >= ts) return zaman(m.t);
    return null;
  };
  const isaret = [];
  const dikey = [];
  for (const n of o.sinyaller || []) {
    const t = bulBar(n.ts);
    if (t == null) continue;
    const renk = n.sonuc === "hedef" ? "#33CC33" : n.sonuc === "stop" ? "#FF3333" : "#00CCCC";
    dikey.push({ time: t, value: 1, color: renk + "AA" });
    isaret.push({ time: t, position: "inBar", shape: "circle", color: o.sinyalRenk || "#29FF42", size: 0.6 });
  }
  for (const iz of o.izler || []) {
    const t = bulBar(iz.ts);
    if (t == null) continue;
    const giris = iz.tur !== "cikis";
    isaret.push({ time: t, position: giris ? "belowBar" : "aboveBar", shape: giris ? "arrowUp" : "arrowDown",
                  color: iz.renk || (giris ? "#FF9900" : "#FFCC00"), size: 1 });
  }
  const tekil = new Map();
  for (const d of dikey) tekil.set(d.time, d);
  _ser.dikey.setData([...tekil.values()].sort((a, b) => a.time - b.time));
  _ser.mum.setMarkers(isaret.sort((a, b) => a.time - b.time));

  // --- fiyat cizgileri (STOP / HEDEF / GIRIS / LIMIT) ---
  for (const c of _fiyatCizgileri) _ser.mum.removePriceLine(c);
  _fiyatCizgileri = (o.fiyatCizgileri || []).filter((c) => c.fiyat != null && isFinite(c.fiyat))
    .map((c) => _ser.mum.createPriceLine({ price: +c.fiyat, color: c.renk, lineWidth: 1,
                                           lineStyle: 2, axisLabelVisible: true, title: c.ad }));
  yuzdeIzgarasiCiz(veri);
  if (ilkCizim) showRecentTvCandles(120, mumlar.length);
  _sonUzunluk = mumlar.length;
}

// %1 IZGARASI: her yatay cizgi bir oncekinin TAM 1.01 kati (carpimsal -- eski
// grafikteki gibi; sabit adim grafigin altinda %1'den buyuk, ustunde kucuk olurdu).
// Seviyeler 1.01^k -- coin ve zoom degisse de AYNI fiyatlarda. Adim HIC buyumez.
// Yuklenen mumlarin tum araligi kapsanir; gorunmeyenler zaten cizilmez.
function yuzdeIzgarasiCiz(veri) {
  let az = Infinity, en = -Infinity;
  for (const m of veri) { if (m.d < az) az = m.d; if (m.y > en) en = m.y; }
  if (!(az > 0) || !(en > az)) return;
  const K = 1.01;
  const k0 = Math.floor(Math.log(az / K) / Math.log(K)), k1 = Math.ceil(Math.log(en * K) / Math.log(K));
  const anahtar = `${k0}:${k1}`;
  if (anahtar === _izgaraAnahtar && _izgara.length) return;
  for (const c of _izgara) _ser.mum.removePriceLine(c);
  const renk = css("--izgara-cizgi", "#1d4352");
  _izgara = [];
  for (let k = k0; k <= k1 && _izgara.length < 400; k++) {
    _izgara.push(_ser.mum.createPriceLine({ price: Math.pow(K, k), color: renk, lineWidth: 1,
                                            lineStyle: 0, axisLabelVisible: false, title: "" }));
  }
  _izgaraAnahtar = anahtar;
}

// Websocket tiki: yalniz son mumu gunceller (yeni mum da olabilir).
export function updateTvLastCandle(mum, hamMum) {
  if (!_grafik || !mum) return;
  _ser.mum.update({ time: zaman(mum.t), open: mum.a, high: mum.y, low: mum.d, close: mum.k });
  if (hamMum) {
    const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
    _ser.hacim.update({ time: zaman(hamMum.t), value: hamMum.h || 0,
                        color: (mum.k >= mum.a ? arti : eksi) + "66" });
  }
}

// Son `n` mumu ekrana sigdirir (50M / 128M / 200M dugmeleri).
export function showRecentTvCandles(n, toplam) {
  if (!_grafik || !toplam) return;
  _grafik.timeScale().setVisibleLogicalRange({ from: Math.max(0, toplam - n), to: toplam + 2 });
}

// Tum mumlari sigdirir (TUMU).
export function showAllTvCandles() {
  _grafik?.timeScale().fitContent();
}

// "+" / "-": sag kenar sabit, gorunen mum sayisi carpanla degisir.
export function zoomTvChart(carpan) {
  if (!_grafik) return;
  const ts = _grafik.timeScale();
  const r = ts.getVisibleLogicalRange();
  if (!r) return;
  const genislik = (r.to - r.from) / carpan;
  ts.setVisibleLogicalRange({ from: r.to - genislik, to: r.to });
}
