// giris.js -- uygulamanin giris noktasi.
//
// Eski `index.html` 6.646 satirdi: CSS, HTML ve 130 fonksiyonluk JS tek
// dosyadaydi. Burada yalnizca baglama var.
import { apiGet } from "./api.js";
import { DRAW_COUNTS } from "./chart/renderer.js";
import { baglaKlavye } from "./keys.js";
import { getActivePage, listPolls, registerPoll, sharePollResult,
         startPolling } from "./poll.js";
import { setState, tercihleriYukle } from "./store.js";
import { mountAppShell, navigateToPage, registerPage, renderFearGreedBadge,
         renderModeBadge } from "./ui/shell.js";
import { temalariUygula } from "./ui/theme.js";
import { showToast } from "./ui/toast.js";

import { mountTradePage, unmountTradePage } from "./pages/trade.js";
import { mountPicksPage, unmountPicksPage } from "./pages/picks.js";
import { mountWinnersPage } from "./pages/winners.js";
import { mountWalletPage, unmountWalletPage } from "./pages/wallet.js";
import { mountNotesPage } from "./pages/notes.js";
import { mountHeatmapPage } from "./pages/heatmap.js";
import { mountBotPage } from "./pages/botPage.js";
import { mountSettingsPage } from "./pages/settingsPage.js";
import { mountStrategiesPage } from "./pages/strategies.js";
import { mountTradePanel, unmountTradePanel } from "./pages/islem.js";
import { mountJournalPage } from "./pages/journal.js";
import { mountBacktestPage } from "./pages/backtest.js";

// Sayfa kuruculari -- her biri KENDI zamanlayicisini kaydeder ve
// yalnizca o sayfaya ilk girildiginde kurulur.
function sayfalariKaydet() {
  registerPage("trade", mountTradePage, unmountTradePage);
  registerPage("secilenler", mountPicksPage, unmountPicksPage);
  registerPage("kazananlar", mountWinnersPage);
  registerPage("cuzdan", mountWalletPage, unmountWalletPage);
  registerPage("notlar", mountNotesPage);
  registerPage("heatmap", mountHeatmapPage);
  registerPage("bot", mountBotPage);
  registerPage("ayarlar", mountSettingsPage);
  registerPage("stratejiler", mountStrategiesPage);
  registerPage("islem", mountTradePanel, unmountTradePanel);
  registerPage("gunluk", mountJournalPage);
  registerPage("geriyetest", mountBacktestPage);
}

// Ayarlar TEK yerden cekilir; mod rozeti ve diger sayfalar buradan beslenir.
function ayarlariKur() {
  registerPoll("ayar", 15, () => apiGet("/yerel/ayar", { sessiz: true }));
  sharePollResult("ayar", (d) => {
    if (!d?.ayar) return;
    setState({ ayar: { ...d.ayar, anahtar_var: d.anahtar_var }, sema: d.sema || [] });
    renderModeBadge({ ...d.ayar, anahtar_var: d.anahtar_var });
    // Hicbir modulun okumadigi ayar varsa kullaniciya bir kez bildir.
    if (d.olu_ayarlar?.length && !window.__oluBildirildi) {
      window.__oluBildirildi = true;
      console.warn("[ayar] kullanilmayan anahtarlar:", d.olu_ayarlar.join(", "));
    }
    if (d.uyari && !window.__uyariBildirildi) {
      window.__uyariBildirildi = true;
      showToast(d.uyari, "uyari", 8000);
    }
  });
}

// Korku & Acgozluluk rozeti. YALNIZ 7801'in kendi ucu okunur (sunucu
// onbellekli); 30 dk'da bir yeter -- kaynak gunde bir guncellenir.
function korkuEndeksiKur() {
  registerPoll("korku", 1800, () => apiGet("/yerel/korku-acgozluluk", { sessiz: true }));
  sharePollResult("korku", (d) => renderFearGreedBadge(d?.endeks));
}

async function basla() {
  tercihleriYukle();
  temalariUygula();
  baglaKlavye();
  mountAppShell();
  sayfalariKaydet();
  ayarlariKur();
  korkuEndeksiKur();

  // SIRA ONEMLI: once zamanlayicilar acilir, sonra sayfa bildirilir.
  // `navigateToPage` aktif sayfayi `poll.js`'e soyler; sayfaya bagli
  // isler ancak ondan sonra donmeye baslar.
  startPolling();
  const bas = location.hash.replace("#", "");
  navigateToPage(bas || "trade");

  // Hata ayiklama kancasi: konsoldan `__cn.isler()` ile hangi
  // zamanlayicinin dondugu gorulebilir. Kilitlenme sikayetinden sonra
  // eklendi -- "hangi is calisiyor" sorusu olculebilir olmali.
  // DONMA KAYDEDICI: 250 ms'den uzun kareleri kaydeder.
  //
  // "Kilitleniyor" sikayeti olculebilir olmali: donma olunca konsolda
  // `__cn.donma()` son 30 uzun kareyi (sure + o anki sayfa) dokuyor.
  // Maliyeti bir rAF sayaci -- olculdu, gorunur yuku yok.
  const _donmalar = [];
  let _sonKare = performance.now();
  (function kareSayaci() {
    const t = performance.now(), d = t - _sonKare;
    _sonKare = t;
    if (d > 250) {
      _donmalar.push({ ms: Math.round(d), sayfa: getActivePage(),
                       saat: new Date().toTimeString().slice(0, 8) });
      if (_donmalar.length > 30) _donmalar.shift();
    }
    requestAnimationFrame(kareSayaci);
  })();

  window.__cn = {
    isler: listPolls,
    sayfa: getActivePage,
    durum: () => ({ sayfa: getActivePage(), isler: listPolls().filter((i) => i.aktif) }),
    donma: () => _donmalar.slice(),
    // Cizim sayaclari: tam cizim vs hafif guncelleme orani.
    // "Takiliyor" sikayetinde `tam` sayisinin yuksek olmasi, grafigin
    // her tikte bastan kuruldugunu gosterir.
    cizim: () => ({ ...DRAW_COUNTS }),
  };

  // 26.09.2026: "tv is not defined" hatasi ekranda cikiyordu ama `tv`
  // bizim kodumuzda HIC yok -- tarayicidaki bir EKLENTININ sayfaya
  // enjekte ettigi betikten geliyordu. Yalniz KENDI dosyalarimizdan gelen
  // hatalar gosterilir; digerleri konsola uyari olarak duser. Gosterilen
  // hatada dosya:satir da yazar, kaynagi hemen bulunur.
  // Son 20 hata `__cn.hatalar()` ile okunur.
  const _hatalar = [];
  window.__cn.hatalar = () => _hatalar.slice();
  window.addEventListener("error", (e) => {
    const dosya = e.filename || "";
    // Yalniz /js/ altindaki DOSYALARIMIZ "bizim" sayilir. Sayfa adresinin
    // kendisinden (ornek "...7801/#islem/X", satir 3) gelen hata bizim olamaz:
    // index.html'de satir ici betik YOK -- bu, disaridan enjekte edilen koddur
    // (tarayici eklentisi ya da Chrome koprusu). 26.09.2026 "tv is not defined".
    const bizim = dosya.startsWith(location.origin + "/js/");
    _hatalar.push({ zaman: new Date().toLocaleTimeString(), mesaj: e.message, dosya, satir: e.lineno, bizim });
    if (_hatalar.length > 20) _hatalar.shift();
    if (!bizim) { console.warn("dis kaynakli hata (eklenti?):", e.message, dosya); return; }
    const kisa = dosya.slice(location.origin.length).replace(/^\//, "");
    showToast(`hata: ${translateError(e.message)} (${kisa}:${e.lineno})`, "hata");
  });
  window.addEventListener("unhandledrejection", (e) => {
    const yigin = String(e.reason?.stack || "");
    _hatalar.push({ zaman: new Date().toLocaleTimeString(), mesaj: String(e.reason?.message || e.reason), yigin });
    if (_hatalar.length > 20) _hatalar.shift();
    // Yigin bizim dosyamizi gostermiyorsa (eklenti) ekrana cikarma.
    if (yigin && !yigin.includes(location.origin)) { console.warn("dis kaynakli hata:", e.reason); return; }
    showToast(`hata: ${translateError(e.reason?.message || e.reason)}`, "hata");
  });
}

// Tarayicinin INGILIZCE hata mesajini Turkceye cevirir.
// 26.09.2026, Ismail: "hata undefined diyene kadar turkce yazsana".
// Taninmayan mesaj oldugu gibi kalir (bilgi kaybolmasin).
export function translateError(mesaj) {
  const m = String(mesaj ?? "").replace(/^Uncaught\s+/, "").replace(/^(ReferenceError|TypeError|SyntaxError|RangeError|Error):\s*/, "");
  const K = [
    [/^(\S+) is not defined$/, (a) => `'${a}' diye bir sey tanimli degil`],
    [/^Cannot read propert(?:y|ies) of (undefined|null) \(reading '(.+)'\)$/, (b, a) => `bos (${b === "null" ? "null" : "tanimsiz"}) bir degerin '${a}' alani okunamadi`],
    [/^Cannot set propert(?:y|ies) of (undefined|null) \(setting '(.+)'\)$/, (b, a) => `bos bir degere '${a}' alani yazilamadi`],
    [/^(.+) is not a function$/, (a) => `'${a}' bir fonksiyon degil`],
    [/^(.+) is not iterable$/, (a) => `'${a}' uzerinde dongu kurulamaz`],
    [/^Cannot access '(.+)' before initialization$/, (a) => `'${a}' tanimlanmadan once kullanildi`],
    [/^Assignment to constant variable\.?$/, () => "sabit bir degiskene yeniden deger atandi"],
    [/^Failed to fetch$/, () => "sunucuya ulasilamadi"],
    [/^NetworkError.*$/, () => "ag hatasi: sunucuya ulasilamadi"],
    [/^Unexpected token (.+)$/, (a) => `beklenmeyen karakter: ${a}`],
    [/^Unexpected end of JSON input$/, () => "sunucudan gelen veri yarim (JSON bitmedi)"],
    [/^Maximum call stack size exceeded$/, () => "sonsuz dongu: cagri yigini doldu"],
    [/^The user aborted a request\.?$/, () => "istek iptal edildi"],
    [/^Script error\.?$/, () => "dis kaynakli betik hatasi (ayrinti gizli)"],
  ];
  for (const [re, f] of K) { const r = m.match(re); if (r) return f(...r.slice(1)); }
  return m;
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", basla);
} else {
  basla();
}
