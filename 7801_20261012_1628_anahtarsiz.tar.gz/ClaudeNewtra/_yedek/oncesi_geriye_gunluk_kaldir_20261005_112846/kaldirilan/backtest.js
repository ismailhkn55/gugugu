// backtest.js -- GERIYE TEST: stratejinin son 2 gundeki K/Z simulasyonu.
//
// Hesap sunucuda (app/strategy/backtest.simulate_strategy_trades -- canli
// botun AYNI yolu: giris kurali, hiz sirasi, maks pozisyon, decide_exit,
// komisyon). Mumlar sunucu onbelleginden gelir; tarayici Binance'e GITMEZ.
// `renderBacktestSummary` strateji duzenleyicisindeki ANINDA K/Z paneliyle ORTAK.
import { apiGet, apiPost } from "../api.js";
import { getState, setState } from "../store.js";
import { getActivePage } from "../poll.js";
import { coinName, formatPrice, formatSigned, formatUsdt } from "../format.js";
import { drawEquityCurve } from "../ui/equityCurve.js";

let _kuruldu = false;
let _sira = 0;
let _tekrar = null;
let _son = null;

const kacis = (s) => String(s ?? "").replace(/[<>&"]/g, (c) =>
  ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;" })[c]);
const isaret = (v) => (v > 0 ? "arti" : v < 0 ? "eksi" : "");
const tarihSaat = (ms) => {
  if (!ms) return "-";
  const d = new Date(+ms);
  const iki = (x) => String(x).padStart(2, "0");
  return `${iki(d.getDate())}.${iki(d.getMonth() + 1)} ${iki(d.getHours())}:${iki(d.getMinutes())}`;
};
const sr = (ad, deger, sinif = "", baslik = "") =>
  `<div class="sr"${baslik ? ` title="${kacis(baslik)}"` : ""}><span>${ad}</span><b class="${sinif}">${deger}</b></div>`;

// Geriye-test ozetini (K/Z, isabet, PF, dusus, egri, uyarilar) verilen kaba cizer.
export function renderBacktestSummary(kap, d, { kompakt = false } = {}) {
  if (!kap) return;
  if (!d) { kap.innerHTML = `<div class="kucuk eksi">geriye-test calismadi (sunucu yaniti yok)</div>`; return; }
  const hazirlik = d.hazirlaniyor
    ? `<div class="btHazirlik">veri hazirlaniyor: ${d.hazir}/${d.toplam} coin (ilk seferde ~30 sn, sonra aninda)</div>` : "";
  if (!d.profil) { kap.innerHTML = hazirlik || `<div class="kucuk">sonuc yok</div>`; return; }
  const p = d.profil;
  const uyarilar = [];
  if (!d.tam_sinanabilir) {
    uyarilar.push(`<div class="btEksik">EKSIK: ${(d.sinanamayan_kural || []).map(kacis).join(" · ")}
      -- bu kurallar gecmiste kurulamaz, sonuca KATILMADI; canlida daha az giris olur.</div>`);
  }
  if (d.dogrulama?.length) {
    uyarilar.push(`<div class="btEksik">KURAL HATASI: ${d.dogrulama.map(kacis).join(" · ")}</div>`);
  }
  const islem = p.islem || 0;
  const ust = `
    <div class="pnlUst">
      <div class="pnlBuyuk ${isaret(p.toplam_kar)}">${islem ? `${formatUsdt(p.toplam_kar, 2)} USDT` : "0 islem"}</div>
      <div class="pnlKucuk">
        <div title="toplam K/Z / (tutar x maks pozisyon) -- yuzdeler TOPLANMAZ">sermaye <b class="${isaret(d.sermaye_getiri_p)}">${d.sermaye_getiri_p == null ? "-" : formatSigned(d.sermaye_getiri_p)}</b></div>
        <div title="ayni coinlerde ayni donemde sadece alip tutsaydin (ortalama)">al-tut <b class="${isaret(d.al_tut_ort_p)}">${d.al_tut_ort_p == null ? "-" : formatSigned(d.al_tut_ort_p)}</b></div>
      </div>
    </div>`;
  const satirlar = [
    sr("islem", `${islem}${islem ? `  (${p.kazanan} + / ${p.kaybeden} -)` : ""}`),
    sr("isabet", islem ? `${p.isabet.toFixed(1)}%` : "-"),
    sr("kar faktoru", p.kar_faktoru ?? "-", (p.kar_faktoru ?? 1) < 1 ? "eksi" : "arti",
       "toplam kazanc / toplam kayip -- 1'in altinda kaybettirir"),
    sr("islem basi ort. net", d.ort_net_p == null ? "-" : formatSigned(d.ort_net_p), isaret(d.ort_net_p),
       `komisyon %${d.komisyon_p} dusulmus`),
    sr("maks. dusus", islem ? `${formatUsdt(p.maks_dusus, 2)} USDT` : "-", "eksi"),
    sr("sinyal / atlanan", `${d.sinyal} / ${d.atlanan_sinyal}`, "",
       "atlanan: maks pozisyon dolu, coin zaten acik ya da bekleme suresi"),
    sr("acik kalan", (d.acik || []).length),
  ];
  const alt = `<div class="btAlt">${d.toplam} coin · son ${Math.round((d.donem?.bar || 0) / 288)} gun · tutar ${d.tutar} · maks ${d.maks_pozisyon}
    · ${d.sure_ms} ms${d.bayat ? ` · ${d.bayat} coin 1 bar eski` : ""}</div>`;
  const not = `<div class="btNot">Evren: bugunun en likit ${d.toplam} coini. Gecmise bugunun listesiyle bakilir, sonuc iyimser olabilir; AL-TUT ile kiyasla.
    Bar ici sira temkinli: once dusuk (stop), sonra yuksek (hedef).</div>`;
  kap.innerHTML = `${hazirlik}${uyarilar.join("")}${ust}
    <div class="pnlEgri btEgri"></div>
    <div class="satirlar">${(kompakt ? satirlar.slice(0, 5) : satirlar).join("")}</div>${alt}${kompakt ? "" : not}`;
  drawEquityCurve(kap.querySelector(".btEgri"), p.egri, { yukseklik: kompakt ? 58 : 120 });
}

function tablo(basliklar, satirlar, sinif = "gnTablo") {
  const bas = basliklar.map(([ad, sag]) => `<th${sag ? ' class="sag"' : ""}>${ad}</th>`).join("");
  return `<table class="${sinif}"><thead><tr>${bas}</tr></thead><tbody>${satirlar.join("")}</tbody></table>`;
}

// Islem listesini sabit sutunlu tabloya cizer; satira tiklayinca o coinin grafigi acilir.
export function renderBacktestTrades(d) {
  const kap = document.getElementById("btIslemler");
  if (!kap) return;
  const liste = (d?.islemler || []).slice().reverse();
  if (!liste.length) { kap.innerHTML = `<div class="bos">islem yok</div>`; return; }
  const satir = liste.map((t) => `<tr class="btSatir" data-sembol="${kacis(t.sembol)}">
      <td>${kacis(coinName(t.sembol))}</td>
      <td>${tarihSaat(t.giris_ts)}</td><td class="sag">${formatPrice(t.giris_fiyat)}</td>
      <td>${tarihSaat(t.cikis_ts)}</td><td class="sag">${formatPrice(t.cikis_fiyat)}</td>
      <td>${kacis(t.sebep)}</td>
      <td class="sag ${isaret(t.kar_p)}">${formatSigned(t.kar_p)}</td>
      <td class="sag ${isaret(t.kar)}">${formatUsdt(t.kar, 2)}</td></tr>`);
  kap.innerHTML = (d.islem_toplam > liste.length
    ? `<div class="kucuk">son ${liste.length} / ${d.islem_toplam} islem</div>` : "")
    + tablo([["COIN", false], ["GIRIS", false], ["FIYAT", true], ["CIKIS", false],
             ["FIYAT", true], ["SEBEP", false], ["NET %", true], ["K/Z USDT", true]], satir);
}

// Bir coinin kapanis cizgisi + o coindeki giris (yesil) / cikis (renk = sonuc) isaretleri.
export async function drawTradeMarkers(sembol) {
  const kap = document.getElementById("btGrafik");
  const bas = document.getElementById("btGrafikBaslik");
  if (!kap || !_son) return;
  if (bas) bas.textContent = coinName(sembol);
  const r = await apiGet(`/yerel/geriye-test/seri?sembol=${encodeURIComponent(sembol)}`, { sessiz: true });
  const seri = r?.seri || [];
  if (seri.length < 2) { kap.innerHTML = `<div class="yok">GRAFIK YOK</div>`; return; }
  // Kabin GERCEK piksel olculeriyle cizilir: "preserveAspectRatio=none" ile
  // daireler elipse donusuyordu (ilk ekran goruntusunde yakalandi).
  const W = Math.max(300, Math.round(kap.clientWidth || 600));
  const H = Math.max(120, Math.round(kap.clientHeight || 160));
  const t0 = seri[0][0], t1 = seri.at(-1)[0];
  const fy = seri.map((x) => x[1]);
  const en = Math.max(...fy), az = Math.min(...fy), a = Math.max(1e-12, en - az);
  const X = (t) => ((t - t0) / Math.max(1, t1 - t0) * W).toFixed(1);
  const Y = (f) => (H - 8 - (f - az) / a * (H - 16)).toFixed(1);
  const cizgi = seri.map(([t, f]) => `${X(t)},${Y(f)}`).join(" ");
  const isaretler = (_son.islemler || []).filter((t) => t.sembol === sembol).map((t) =>
    `<circle cx="${X(t.giris_ts)}" cy="${Y(t.giris_fiyat)}" r="3.5" class="btGiris"><title>GIRIS ${formatPrice(t.giris_fiyat)}</title></circle>
     <circle cx="${X(t.cikis_ts)}" cy="${Y(t.cikis_fiyat)}" r="3.5" class="${t.kar >= 0 ? "btCikisArti" : "btCikisEksi"}"><title>CIKIS ${formatPrice(t.cikis_fiyat)} ${kacis(t.sebep)} ${formatSigned(t.kar_p)}</title></circle>`).join("");
  kap.innerHTML = `<svg viewBox="0 0 ${W} ${H}">
    <polyline points="${cizgi}" fill="none" stroke="currentColor" stroke-width="1.2" opacity=".7"/>${isaretler}</svg>`;
}

async function calistir() {
  if (getActivePage() !== "geriyetest") return;
  clearTimeout(_tekrar);
  const sira = ++_sira;
  const genis = !!document.getElementById("btGenis")?.checked;
  const taslak = getState("btTaslak");
  const govde = taslak ? { strateji: taslak, genis } : { genis };
  const ozet = document.getElementById("btOzet");
  ozet?.classList.add("btBekliyor");
  const d = await apiPost("/yerel/geriye-test", govde, { sessiz: true });
  if (sira !== _sira) return;
  ozet?.classList.remove("btBekliyor");
  _son = d;
  const ad = document.getElementById("btStrateji");
  if (ad) ad.textContent = `${d?.strateji || "-"}${taslak ? " (KAYDEDILMEMIS TASLAK)" : ""}`;
  renderBacktestSummary(ozet, d);
  renderBacktestTrades(d);
  const sebep = document.getElementById("btSebep");
  if (sebep) {
    const g = d?.profil?.sebep || [];
    sebep.innerHTML = g.length ? tablo([["SEBEP", false], ["ISLEM", true], ["ISABET", true], ["K/Z USDT", true], ["ORT %", true]],
      g.map((r) => `<tr><td>${kacis(r.ad)}</td><td class="sag">${r.islem}</td><td class="sag">${r.isabet.toFixed(1)}%</td>
        <td class="sag ${isaret(r.kar)}">${formatUsdt(r.kar, 2)}</td><td class="sag ${isaret(r.ort_kar_p)}">${formatSigned(r.ort_kar_p)}</td></tr>`))
      : `<div class="bos">-</div>`;
  }
  const ilk = d?.islemler?.at(-1)?.sembol;
  if (ilk) drawTradeMarkers(ilk);
  if (d?.hazirlaniyor) _tekrar = setTimeout(calistir, 3000);
}

// GERIYE TEST sayfasini kurar; acilista ve CALISTIR'da tek istek (periyodik yoklama YOK).
export function mountBacktestPage() {
  if (!_kuruldu) {
    _kuruldu = true;
    document.getElementById("btnBtCalistir")?.addEventListener("click", calistir);
    document.getElementById("btGenis")?.addEventListener("change", calistir);
    document.getElementById("btnBtAktif")?.addEventListener("click", () => {
      setState({ btTaslak: null });
      calistir();
    });
    document.getElementById("btIslemler")?.addEventListener("click", (e) => {
      const s = e.target.closest(".btSatir")?.dataset.sembol;
      if (s) drawTradeMarkers(s);
    });
  }
  calistir();
}
