// journal.js -- ISLEM GUNLUGU: defterden profil + 4 davranis teshisi.
//
// Veri YALNIZ 7801'in kendi ucundan gelir (/yerel/gunluk-analiz); dis API yok.
// Hesap sunucuda (app/reporting/journal_analysis.py); burada yalniz cizim.
import { apiGet } from "../api.js";
import { registerPoll, refreshNow, sharePollResult } from "../poll.js";
import { formatSigned, formatUsdt, formatDuration } from "../format.js";
import { drawEquityCurve } from "../ui/equityCurve.js";

let _kuruldu = false;

const kacis = (s) => String(s ?? "").replace(/[<>&"]/g, (c) =>
  ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;" })[c]);

// Siddet -> TAM sinif adi (css_denetim dinamik ad yakalayamaz, acik yazilir).
const SIDDET_SINIF = { yuksek: "siddetYuksek", orta: "siddetOrta", dusuk: "siddetDusuk" };
const SIDDET_AD = { yuksek: "YUKSEK", orta: "ORTA", dusuk: "DUSUK" };
const DAVRANIS_AD = {
  kaybedeni_tutma: ["KAYBEDENI UZUN TUTMA", "kaybedenler kazananlardan kac kat uzun tutuluyor (>=1.2 orta, >=1.5 yuksek)"],
  pump_kovalama: ["PUMP KOVALAMA", "ayni coinde, 3 alis oncesinden %3+ yuksekten alma orani (>=%40 orta, >=%60 yuksek)"],
  asiri_islem: ["ASIRI ISLEM", "yogun gunlerin islem basi K/Z'si sakin gunlerden ne kadar kotu"],
  capalanma: ["CAPALANMA", "sik islem gorulen coinlerin kaci dar fiyat bandinda (CV<%5)"],
};

const isaret = (v) => (v > 0 ? "arti" : v < 0 ? "eksi" : "");
const sr = (ad, deger, sinif = "", baslik = "") =>
  `<div class="sr"${baslik ? ` title="${kacis(baslik)}"` : ""}><span>${ad}</span><b class="${sinif}">${deger}</b></div>`;

function tabloCiz(basliklar, satirlar) {
  const bas = basliklar.map(([ad, sag]) => `<th${sag ? ' class="sag"' : ""}>${ad}</th>`).join("");
  return `<table class="gnTablo"><thead><tr>${bas}</tr></thead><tbody>${satirlar.join("")}</tbody></table>`;
}

function grupSatiri(r) {
  return `<tr><td>${kacis(r.ad)}</td><td class="sag">${r.islem}</td>`
    + `<td class="sag">${r.isabet.toFixed(1)}%</td>`
    + `<td class="sag ${isaret(r.kar)}">${formatUsdt(r.kar, 2)}</td>`
    + `<td class="sag ${isaret(r.ort_kar_p)}">${formatSigned(r.ort_kar_p)}</td></tr>`;
}

// Gunluk raporunu (profil + egri + davranis + kirilimlar) cizer.
export function renderJournalReport(d) {
  const kap = document.getElementById("gunlukIcerik");
  if (!kap) return;
  const p = d?.profil;
  if (!p || !p.islem) {
    kap.innerHTML = `<div class="bos">bu secimde kapanmis islem yok</div>`;
    return;
  }
  const tarih = (ms) => new Date(ms).toLocaleDateString("tr-TR");
  const ozet = [
    sr("donem", `${tarih(p.ilk_ts)} - ${tarih(p.son_ts)}`),
    sr("islem", `${p.islem}  (${p.kazanan} + / ${p.kaybeden} -${p.notr ? ` / ${p.notr} 0` : ""})`),
    sr("isabet", `${p.isabet.toFixed(2)}%`),
    sr("toplam K/Z", `${formatUsdt(p.toplam_kar, 2)} USDT`, isaret(p.toplam_kar)),
    sr("kazanc / kayip orani", p.kazanc_kayip_orani ?? "—", "",
       "ortalama kazanc USDT / ortalama kayip USDT -- 1'in altindaysa kayiplar kazanclardan buyuk"),
    sr("kar faktoru", p.kar_faktoru ?? "—", (p.kar_faktoru ?? 1) < 1 ? "eksi" : "arti",
       "toplam kazanc / toplam kayip -- 1'in altinda sistem para kaybediyor"),
    sr("ort. kazanc / kayip", `${formatSigned(p.ort_kazanc_p)} / ${formatSigned(p.ort_kayip_p)}`),
    sr("maks. dusus", `${formatUsdt(p.maks_dusus, 2)} USDT`, "eksi"),
    sr("medyan sure", formatDuration(p.medyan_sure_dk * 60000)),
    sr("haftalik islem", p.haftalik_islem),
  ];
  const notlar = [];
  if (d.toz_dislanan) notlar.push(`${d.toz_dislanan} toz islem (< 1 USDT, eski test artigi) dislandi`);
  if (p.turetilen) notlar.push(`${p.turetilen} islemin USDT K/Z'si defterde yoktu; yuzdeden turetildi`);

  const davranis = Object.entries(DAVRANIS_AD).map(([anahtar, [ad, aciklama]]) => {
    const x = d.davranis?.[anahtar] || {};
    const s = x.siddet || "dusuk";
    return `<tr title="${kacis(aciklama)}"><td>${ad}</td>`
      + `<td class="${SIDDET_SINIF[s] || ""}">${SIDDET_AD[s] || s}</td>`
      + `<td class="gnKanit">${kacis(x.kanit)}</td></tr>`;
  });

  const sembol = p.sembol || [];
  const enKotu = sembol.slice(0, 8);
  const enIyi = sembol.slice(-8).reverse();
  const grupBas = [["", false], ["ISLEM", true], ["ISABET", true], ["K/Z USDT", true], ["ORT %", true]];

  kap.innerHTML = `
    <div class="kartlar">
      <div class="kart"><h3>OZET</h3><div class="satirlar">${ozet.join("")}</div>
        ${notlar.length ? `<div class="gnNot">${notlar.map(kacis).join("<br>")}</div>` : ""}</div>
      <div class="kart"><h3>SERMAYE EGRISI <small>(kapanis sirasiyla birikimli USDT)</small></h3>
        <div class="pnlEgri gnEgri" id="gnEgri"></div></div>
      <div class="kart genis"><h3>DAVRANIS TESHISI</h3>
        ${tabloCiz([["", false], ["SIDDET", false], ["KANIT", false]], davranis)}</div>
      <div class="kart genis"><h3>CIKIS SEBEBINE GORE</h3>
        ${tabloCiz([["SEBEP", false], ...grupBas.slice(1)], (p.sebep || []).map(grupSatiri))}</div>
      <div class="kart"><h3>EN COK KAYBETTIREN COINLER</h3>
        ${tabloCiz([["COIN", false], ...grupBas.slice(1)], enKotu.map(grupSatiri))}</div>
      <div class="kart"><h3>EN COK KAZANDIRAN COINLER</h3>
        ${tabloCiz([["COIN", false], ...grupBas.slice(1)], enIyi.map(grupSatiri))}</div>
    </div>`;
  drawEquityCurve(document.getElementById("gnEgri"), p.egri, { yukseklik: 120 });
}

function istekYolu() {
  const kaynak = document.getElementById("gnKaynak")?.value || "canli";
  const sadece = document.getElementById("gnSadece")?.value || "";
  const toz = document.getElementById("gnToz")?.checked ? 1 : 0;
  return `/yerel/gunluk-analiz?kaynak=${kaynak}&toz=${toz}${sadece ? `&sadece=${sadece}` : ""}`;
}

// ISLEM GUNLUGU sayfasini kurar; yalniz sayfa acikken 5 dk'da bir yeniler (yerel uc).
export function mountJournalPage() {
  if (_kuruldu) return;
  _kuruldu = true;
  for (const id of ["gnKaynak", "gnSadece", "gnToz"]) {
    document.getElementById(id)?.addEventListener("change", () => refreshNow("gunluk"));
  }
  registerPoll("gunluk", 300, () => apiGet(istekYolu(), { sessiz: true }), { sayfa: "gunluk" });
  sharePollResult("gunluk", renderJournalReport);
}
