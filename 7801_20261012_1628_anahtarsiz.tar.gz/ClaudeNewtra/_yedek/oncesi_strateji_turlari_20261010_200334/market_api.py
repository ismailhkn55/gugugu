"""Piyasa verisi uclari: ozet, kazananlar, aday, mum, geriye-test, tickler, haric."""
from __future__ import annotations

from app.config.settings import load_settings
from app.market import candles as CN, exclusions as EX, rank_repository as RR, ticks as TK
from app.market.indicators import COLOR_SOURCE
from app.strategy.entry import select_candidates
from app.strategy.backtest import list_higher_tf_needs, replay_strategy_signals
from app.strategy.registry import get_active_strategy
from app.strategy.rule_engine import derive_color_field
from app.web.router import query_int, query_live


# GET /yerel/heatmap
# YAPAY ZEKA MIMO (24.09.2026): kendi endeks + heatmap + akis sistemi.
# KAC-Index (TOTAL3) mantigi: BTC/ETH disi altcoin evrenine gore gucu olcer.
# Harici API yok — rank.sqlite + Binance ticker/24hr MINI yeterli.
# Her 5 dakikada bir, 5 dakikalik pencerenin bitimine 40 saniye kala
# cagrilmasi BEKLENIR (frontend zamanlar); endpoint anlik hesaplar.
# YAPAY ZEKA MIMO (24.09.2026): tavan yok (~210), deg24 sirali, BTC/ETH karo, cci_5dk/cci_artis.
def handle_heatmap(req):
    import time as _time
    from app.config.paths import get_heatmap_state_path
    from app.config.settings import load_settings
    from app.core.jsonstore import read_json_file, write_json_file
    from app.exchange.binance_rest import public_request

    ayar = load_settings()
    # Tavan yok: anasayfadaki tum rank satirlari (+ istege bagli BTC/ETH).
    _ = query_int  # n parametresi bilgi amaclidir; filtre/sirala frontend'de

    # YAPAY ZEKA MIMO (24.09.2026): siralama + BTC/ETH tercihi ayarlardan
    sira = str(ayar.get("heatmap_siralama") or "deg24")
    btc_eth_var = bool(ayar.get("heatmap_btc_eth", True))
    if sira not in ("deg24", "deg5m", "deg1h", "hacim"):
        sira = "deg24"

    snap = RR.fetch_latest_snapshot(limit=400)
    satir = snap.get("satir") or []

    # --- Binance tum USDT/USDC 24s ozeti + BTC/ETH karo kaynaklari ---
    usdt_h = usdc_h = btc_h = eth_h = 0.0
    btc_deg = eth_deg = None
    btc_px = eth_px = None
    try:
        tickers = public_request("/api/v3/ticker/24hr", type="MINI")
    except Exception:
        tickers = []
    tick_map = {}
    for t in tickers if isinstance(tickers, list) else []:
        s = str(t.get("symbol") or "")
        tick_map[s] = t
        try:
            qv = float(t.get("quoteVolume") or 0)
        except (TypeError, ValueError):
            qv = 0.0
        if s.endswith("USDT"):
            usdt_h += qv
            if s == "BTCUSDT":
                btc_h = qv
                try:
                    op, lp = float(t["openPrice"]), float(t["lastPrice"])
                    btc_deg = (lp / op - 1) * 100 if op else None
                    btc_px = lp
                except Exception:
                    pass
            elif s == "ETHUSDT":
                eth_h = qv
                try:
                    op, lp = float(t["openPrice"]), float(t["lastPrice"])
                    eth_deg = (lp / op - 1) * 100 if op else None
                    eth_px = lp
                except Exception:
                    pass
        elif s.endswith("USDC"):
            usdc_h += qv

    # --- YAPAY ZEKA MIMO (24.09.2026): CCI 5 dk onceki (rank tarihinden) ---
    try:
        cci_eski = RR.fetch_cci_history(5)
    except Exception:
        cci_eski = {}

    # --- heatmap karolari: anasayfa evreni (+ BTC/ETH karo) ---
    aday = [s for s in satir if s.get("hacim") is not None]
    karolar = []
    for s in aday:
        t = dict(s)
        cci_now = t.get("cci")
        cci_prev = cci_eski.get(t.get("sembol"))
        t["cci_5dk"] = cci_prev
        if cci_now is not None and cci_prev is not None:
            t["cci_artis"] = bool(float(cci_now) > float(cci_prev))
        else:
            t["cci_artis"] = None
        karolar.append(t)

    if btc_eth_var:
        for sembol, deg, px in (
            ("BTCUSDT", btc_deg, btc_px),
            ("ETHUSDT", eth_deg, eth_px),
        ):
            t = tick_map.get(sembol) or {}
            try:
                hacim = float(t.get("quoteVolume") or 0)
            except (TypeError, ValueError):
                hacim = 0.0
            karolar.append({
                "sembol": sembol,
                "fiyat": px,
                "deg24": deg,
                "deg5m": None,
                "deg1h": None,
                "hacim": hacim,
                "rank": None,
                "rsi": None,
                "cci": None,
                "cci_5dk": None,
                "cci_artis": None,
                "endeks": None,
                "endeks_guclu": False,
                "btc_eth_karo": True,
            })

    anahtar = "hacim" if sira == "hacim" else sira
    karolar.sort(key=lambda x: -(x.get(anahtar) if x.get(anahtar) is not None else -1e18))

    # --- TOTAL3 proxy: hacim-agirlikli altcoin ort 24s degisimi ---
    # (rank evreni zaten BTC/ETH disi; KAC-Index'in TOTAL3 karsiligi)
    olculu = [s for s in satir
              if s.get("deg24") is not None and (s.get("hacim") or 0) > 0]
    toplam_h = sum(s["hacim"] or 0 for s in olculu) or 1.0
    if olculu:
        total3 = sum((s.get("deg24") or 0) * (s["hacim"] or 0)
                     for s in olculu) / toplam_h
        yesil = sum(1 for s in olculu if (s.get("deg24") or 0) > 0)
        genislik = 100.0 * yesil / len(olculu)
        ort_deg = sum(s.get("deg24") or 0 for s in olculu) / len(olculu)
    else:
        total3 = genislik = ort_deg = 0.0

    # KAC benzeri goreli endeks: coin deg24 - TOTAL3 proxy
    # YAPAY ZEKA MIMO (24.09.2026): BTC/ETH karolarinda total3 karsiligi anlamsiz -- endeks None
    for t in karolar:
        if t.get("btc_eth_karo"):
            t["endeks"] = None
            t["endeks_guclu"] = False
            continue
        d = t.get("deg24")
        t["endeks"] = None if d is None else round(d - total3, 3)
        t["endeks_guclu"] = bool(t["endeks"] is not None and t["endeks"] > 0)

    # BTC hacim payi (Binance-native "dominance" proxy)
    btc_dom = (100.0 * btc_h / usdt_h) if usdt_h else None
    eth_dom = (100.0 * eth_h / usdt_h) if usdt_h else None

    # --- onceki snapshot ile Δ ---
    prev = read_json_file(get_heatmap_state_path(), {}) or {}
    usdt_d = usdc_d = genislik_d = None
    if isinstance(prev, dict) and prev.get("usdt_hacim"):
        uh = float(prev["usdt_hacim"] or 0)
        if uh:
            usdt_d = 100.0 * (usdt_h - uh) / uh
    if isinstance(prev, dict) and prev.get("usdc_hacim"):
        uc = float(prev["usdc_hacim"] or 0)
        if uc:
            usdc_d = 100.0 * (usdc_h - uc) / uc
    if isinstance(prev, dict) and prev.get("genislik") is not None:
        genislik_d = genislik - float(prev["genislik"])

    # --- akis rozeti: USDT hacmi + genislik ---
    # USDT hacmi azalirken genislik yuksekse -> coinlere gecis
    usdt_az = usdt_d is not None and usdt_d < -1.0
    usdt_ar = usdt_d is not None and usdt_d > 1.0
    gen_y = genislik >= 55
    gen_d = genislik <= 45
    if usdt_az and gen_y:
        akis = {"yon": "coin", "sinif": "arti",
                "metin": "Para coinlere akiyor (USDT↓ + genislik↑)"}
    elif usdt_ar and gen_d:
        akis = {"yon": "usdt", "sinif": "eksi",
                "metin": "USDSt'e park / risk-off (USDT↑ + genislik↓)"}
    elif usdt_az and gen_d:
        akis = {"yon": "kuruma", "sinif": "notr",
                "metin": "Hacim kuruyor (USDT↓ + genislik↓)"}
    elif usdt_ar and gen_y:
        akis = {"yon": "karisik", "sinif": "uyari",
                "metin": "Karisik (USDT↑ + genislik↑)"}
    else:
        akis = {"yon": "notr", "sinif": "notr", "metin": "Notr"}

    ts = int(_time.time() * 1000)
    gecmis = (prev.get("gecmis") if isinstance(prev, dict) else None) or []
    if not isinstance(gecmis, list):
        gecmis = []
    gecmis = (gecmis + [{
        "ts": ts, "usdt_hacim": usdt_h, "usdc_hacim": usdc_h,
        "genislik": genislik, "total3": total3,
    }])[-40:]

    write_json_file(get_heatmap_state_path(), {
        "ts": ts, "usdt_hacim": usdt_h, "usdc_hacim": usdc_h,
        "genislik": genislik, "total3": total3, "gecmis": gecmis,
    })

    # Sonraki frontend hedefi: 5 dk pencere bitimine 40 sn kala
    now_s = _time.time()
    period = 300.0
    hedef_offset = period - 40.0          # 260. saniye
    gecen = now_s % period
    bekleme = hedef_offset - gecen
    if bekleme < 0:
        bekleme += period
    sonraki_hedef = int((now_s + bekleme) * 1000)

    return 200, {
        "ts": snap.get("ts"),
        "alma_ts": ts,
        "sonraki_hedef": sonraki_hedef,
        "indexler": {
            "usdt_hacim": usdt_h, "usdt_d": usdt_d,
            "usdc_hacim": usdc_h, "usdc_d": usdc_d,
            "total3": total3, "genislik": genislik,
            "genislik_d": genislik_d, "ort_deg": ort_deg,
            "btc_dom": btc_dom, "eth_dom": eth_dom,
            "btc_hacim": btc_h, "eth_hacim": eth_h,
            "btc_deg": btc_deg, "eth_deg": eth_deg,
            "coin_sayisi": len(olculu),
        },
        "akis": akis,
        "karolar": karolar,
        "gecmis": gecmis,
        "siralama": sira,
        "btc_eth": btc_eth_var,
        "kaynak": "binance+rank (YAPAY ZEKA MIMO)",
    }


# GET /yerel/ozet -- coin tablosu (+ turetilmis renk alanlari).
def handle_snapshot(req):
    d = RR.fetch_latest_snapshot(limit=query_int(req["params"], "n", 400))
    for s in d["satir"]:
        for renk, kaynak in COLOR_SOURCE.items():
            s[renk] = derive_color_field(s.get(kaynak))
    return 200, d


# GET /yerel/kazananlar -- siralamada tirmananlar.
def handle_winners(req):
    p = req["params"]
    basamak = query_int(p, "basamak", 20)
    dakika = query_int(p, "dakika", 15)
    eski = RR.fetch_rank_history(dakika)
    d = RR.fetch_latest_snapshot(limit=400)
    satir = []
    for s in d["satir"]:
        onceki = eski.get(s["sembol"])
        if onceki is None or s.get("rank") is None:
            continue
        fark = onceki - s["rank"]
        if fark >= basamak:
            satir.append({**s, "eski_rank": onceki, "tirmanis": fark})
    satir.sort(key=lambda x: -x["tirmanis"])
    return 200, {"ts": d["ts"], "basamak": basamak, "dakika": dakika,
                 "aday_sayisi": len(satir), "satir": satir[:query_int(p, "n", 12)]}


# GET /yerel/aday -- aktif stratejinin adaylari.
def handle_candidates(req):
    a = load_settings()
    live = query_live(req["params"], bool(a.get("bot_canli")))
    st = get_active_strategy(live=live)
    d = RR.fetch_latest_snapshot(limit=400)
    sonuc = select_candidates(d["satir"], st, limit=query_int(req["params"], "n", 20))
    return 200, {"ts": d["ts"], "strateji": st.get("ad"), **sonuc}


# GET /yerel/mum -- Binance mum verisi.
def handle_candles(req):
    p = req["params"]
    sembol = p.get("symbol") or p.get("sembol")
    if not sembol:
        return 400, {"hata": "symbol gerekli"}
    toplam = query_int(p, "limit", 500)
    aralik = p.get("interval") or "5m"
    if toplam > 1000:
        return 200, CN.fetch_candle_range(sembol, aralik, total=toplam)
    return 200, CN.fetch_candle_page(sembol, aralik, limit=toplam,
                                     end_time=query_int(p, "endTime", 0) or None)


# GET /yerel/hacim-coklu -- coklu borsa (CHCM) hacim verisi.
# 29.09.2026, Ismail: "trade ekranindaki hacim barinda her borsaninki
# farkli renk olsun" -- Binance disindaki 4 borsanin (Bybit/OKX/MEXC/
# Gate.io) AYNI sembol/interval hacmini ceker. SADECE Binance'in temiz
# (delist/stabil/statik-haric elenmis) listesindeki coinler icin denenir
# -- gereksiz "coin yok" istegi/hatasi olusmasin.
def handle_multi_exchange_volume(req):
    p = req["params"]
    sembol = p.get("symbol") or p.get("sembol")
    if not sembol:
        return 400, {"hata": "symbol gerekli"}
    s = sembol.upper().replace("/", "")
    taban = s[:-4] if s.endswith(("USDT", "USDC")) else s
    if taban not in EX.load_clean_base_coins():
        return 200, {}
    aralik = p.get("interval") or "5m"
    hacim = CN.fetch_multi_exchange_volume(s, aralik, limit=query_int(p, "limit", 288))
    return 200, {str(ts): borsalar for ts, borsalar in hacim.items()}


# GET /yerel/gecmis-sinyal -- strateji gecmiste nerede tetiklenmis.
def handle_history_signals(req):
    p = req["params"]
    sembol = p.get("sembol") or p.get("symbol")
    if not sembol:
        return 400, {"hata": "sembol gerekli"}
    a = load_settings()
    live = query_live(p, bool(a.get("bot_canli")))
    st = get_active_strategy(live=live)
    mumlar = CN.fetch_candle_page(sembol, p.get("interval") or "5m",
                                  limit=query_int(p, "limit", 576))
    # 02.10.2026: strateji 4h/1h/1d HA kullaniyorsa o dilimin mumlari da
    # verilir (yalniz gereken dilim; 5 dk onbellekli -- surekli sorgu yok).
    ust = {alan: fetch_higher_tf_candles(sembol, aralik)
           for alan, aralik in list_higher_tf_needs(st).items()}
    return 200, replay_strategy_signals(mumlar, st, warmup=query_int(p, "warmup", 60),
                                        max_bars=query_int(p, "bar", 500), higher_tf=ust)


# Ust zaman dilimi mumlari, sembol+aralik basina 5 dk bellek onbellegi.
# Grafik her acilista/yenilemede bu ucu cagirir; Binance'e her seferinde gidilmez.
_UST_ONBELLEK: dict[tuple[str, str], tuple[float, list]] = {}


def fetch_higher_tf_candles(symbol: str, interval: str) -> list[list]:
    import time
    anahtar = (symbol.upper(), interval)
    kayit = _UST_ONBELLEK.get(anahtar)
    if kayit and time.time() - kayit[0] < 300:
        return kayit[1]
    mumlar = CN.fetch_candle_page(symbol, interval, limit=120)
    _UST_ONBELLEK[anahtar] = (time.time(), mumlar)
    return mumlar


# GET /yerel/tickler -- bir sembolun tick arsivi.
def handle_tick_archive(req):
    # Hem `sembol` hem `symbol` kabul edilir: `/yerel/mum` `symbol`
    # kullaniyordu, burasi yalnizca `sembol` -- ayni panelde iki farkli
    # ad, cagiranin hata almasina yol aciyordu (23.09.2026 uc taramasinda
    # yakalandi).
    p = req["params"]
    sembol = p.get("sembol") or p.get("symbol")
    if not sembol:
        return 400, {"hata": "sembol gerekli"}
    t = TK.read_tick_archive(sembol, limit=query_int(p, "n", 500))
    return 200, {"sembol": sembol.upper(), "adet": len(t), "tickler": t}


# GET /yerel/haric
def handle_exclusions_read(req):
    from app.core.jsonstore import read_json_file
    from app.config.paths import get_panel_config_path
    return 200, {"haric": (read_json_file(get_panel_config_path(), {}) or {}).get("haric", [])}


# POST /yerel/haric
def handle_exclusions_write(req):
    return 200, {"haric": EX.save_excluded_symbols(req["body"].get("haric") or [])}


# GET /yerel/pozisyon-haric
def handle_position_exclusions_read(req):
    return 200, {"haric": EX.load_position_exclusions()}


# POST /yerel/pozisyon-haric
def handle_position_exclusions_write(req):
    return 200, {"haric": EX.save_position_exclusions(req["body"].get("haric") or [])}


# GET /yerel/korku-acgozluluk
# Kaynak gunde bir guncellenir; fear_greed modulu onbellekten verir, disari
# gunde ~1 istek cikar. Tarayici yalniz bu ucu okur (alternative.me'yi degil).
def handle_fear_greed(req):
    from app.market.fear_greed import count_fear_greed_requests, fetch_fear_greed_index
    return 200, {"endeks": fetch_fear_greed_index(),
                 "dis_istek": count_fear_greed_requests()}
