// botPage.js -- BOT: durum, kagit cuzdan, calisan isler.
import { apiGet, apiPost } from "../api.js";
import { askConfirm } from "../ui/confirm.js";
import { showToast } from "../ui/toast.js";
import { formatUsdt } from "../format.js";
import { registerPoll, refreshNow, sharePollResult } from "../poll.js";
import { getState, setState } from "../store.js";
import { renderClosedTrades, renderPositionTable } from "../ui/positionTable.js";
import { openSymbol } from "./trade.js";

let _kuruldu = false;

// Calisan isleri gosterir.
//
// Eski sistemde bu GORUNURLUK HIC YOKTU: `takipci()` tanimliydi ama
// baslatilmiyordu ve bu AYLARCA fark edilmedi. Artik hangi isin kac tur
// attigi ve son hatasi ekranda.
function isleriCiz(isler) {
  const e = document.getElementById("botSatir");
  if (!e) return;
  const liste = isler || [];
  if (!liste.length) { e.innerHTML = `<div class="bos">is yok</div>`; return; }
  // 23.09.2026, Ismail: "bot turu filan bunlar hizali olsun, yazilar esit
  // degil de bole solgun bi tablo icinde olsunlar gorüntüyü bozmadan".
  // Onceden satir ici rozetlerdi: her isin adi farkli uzunlukta oldugu
  // icin sayilar hicbir yerde alt alta gelmiyordu. Artik sabit sutunlu,
  // sonuk cerceveli bir tablo.
  e.innerHTML = `<table class="isTablo"><tbody>${
    liste.map((j) => `<tr title="${j.aciklama || ""}">
      <td class="is-durum"><span class="isNokta ${j.calisiyor ? "acik" : "kapali"}"></span></td>
      <td class="is-ad">${j.ad}</td>
      <td class="is-sayi">${j.aralik_sn ? j.aralik_sn + "sn" : "·"}</td>
      <td class="is-sayi">${j.tur ?? 0} tur</td>
      <td class="is-sayi ${j.hata ? "eksi" : ""}">${j.hata ? j.hata + " hata" : "—"}</td>
      <td class="is-sayi">${j.son_tur_sn_once == null ? "·" : j.son_tur_sn_once + "sn once"}</td>
    </tr>`).join("")}</tbody></table>`;
}

// Bot ac/kapat ve mod dugmelerini cizer.  (eski: botKontrolCiz)
export function renderBotControls(d) {
  const yaz = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  // Buyuk yazi: yalnizca mod degil, CALISIYOR MU bilgisini de tasir.
  yaz("botMod", (d.bot_canli ? "CANLI" : "KAGIT")
      + (d.bot_acik ? " · CALISIYOR" : " · DURDU"));
  // 26.09.2026, Ismail: anahtar durumu bot sayfasinda degil AYARLAR'da
  // gorunur (#ayAnahtarDurum).
  yaz("botTakip", String(d.acik_pozisyon ?? 0));
  // HATA (23.09.2026): kod `aktif` sinifi yaziyordu ama CSS `.modBtn.se`
  // bekliyordu -- yani secili mod HICBIR ZAMAN isaretlenmiyordu
  // (Ismail: "calisma modu dry run ise dryrun aktif oldugu belli olsun,
  // hangisinde oldugu belli degil"). Sinif adi CSS ile eslendi ve
  // secili dugmeye ayrica metin isareti konuyor.
  const bd = document.getElementById("btnBotDry");
  const bc = document.getElementById("btnBotCanli");
  const canli = !!d.bot_canli;
  bd?.classList.toggle("se", !canli);
  bc?.classList.toggle("se", canli);
  bd?.setAttribute("aria-pressed", String(!canli));
  bc?.setAttribute("aria-pressed", String(canli));
  const bdE = document.getElementById("botDryEt");
  const bcE = document.getElementById("botCanliEt");
  if (bdE) bdE.textContent = canli ? "kagit para" : "● AKTIF";
  if (bcE) bcE.textContent = canli ? "● AKTIF" : "gercek para";
  const ws = d.websocket || {};
  const wsE = document.getElementById("wsDurum");
  if (wsE && ws.durum) wsE.textContent = `${ws.durum}${ws.bayat ? " (BAYAT)" : ""}`;
  isleriCiz(d.isler);
}

// Kagit cuzdan ozetini cizer.
//
// 24.09.2026, Ismail: "acik tradeler botun parasinda oynama yapmiyor ...
// bot cuzdani da hareket etmeli". Sunucu artik acik pozisyonlari ANLIK
// fiyattan degerlendiriyor (`acik_kar`); bu deger satira yaziliyor ki
// toplamdaki oynamanin NEREDEN geldigi gorunsun.
export function renderPaperWallet(c) {
  const yaz = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  yaz("bcToplam", formatUsdt(c.toplam));
  yaz("bcSerbest", formatUsdt(c.serbest));
  yaz("bcKilitli", formatUsdt(c.kilitli));
  const i = c.istatistik || {};
  const acik = c.acik_kar;
  // formatSigned "%" ekler; burada USDT degeri isteniyor -- elle yaziliyor.
  yaz("bcSatir", `${i.islem || 0} islem · isabet ${i.isabet ?? "—"}% · ort ${i.ortalama ?? "—"}%`
      + (acik == null ? "" : ` · acik K/Z ${acik > 0 ? "+" : ""}${(+acik).toFixed(3)} USDT`));
}

// BOTUN kapanmis islemlerini listeler.
//
// 23.09.2026: artik iki defterden de okunur (bot canli calisiyorsa
// kayitlari canli defterdedir) ve cuzdandakiyle AYNI zengin kartla cizilir
// -- giris/cikis detaylari ve, varsa, o anin gosterge degerleri.
export function renderPaperHistory(kapali) {
  const s = document.getElementById("bcGecSayi");
  // bot'unkiler + kagitta elle acilanlar (gercek paradaki elle islemler CUZDAN'da)
  const liste = (kapali || []).filter((e) => !e.el_kaynak || !(e._live ?? e.canli));
  if (s) s.textContent = String(liste.length);
  renderClosedTrades("bcGecmis", liste);
}

// Botun calisma modunu (kagit/canli) degistirir.  (eski: botModDegistir)
export async function setBotMode(canli) {
  const c = await apiPost("/yerel/bot", { bot_canli: canli });
  if (c?.ok) { showToast(`bot ${canli ? "CANLI" : "KAGIT"} moda alindi`, canli ? "uyari" : "ok"); refreshNow("bot"); }
  else showToast(c?.hata || "mod degistirilemedi", "hata");
}

// Bot durumunu sunucudan tazeler.  (eski: botYenile)
export async function refreshBotState() {
  // Gecmis ayrica cekilmiyor: `/yerel/emirler` zaten IKI defterin kapanmis
  // kayitlarini `_live` isaretiyle birlikte donuyor (bir istek eksildi).
  const [bot, cuzdan, emirler] = await Promise.all([
    apiGet("/yerel/bot", { sessiz: true }),
    apiGet("/yerel/bot-cuzdan", { sessiz: true }),
    apiGet("/yerel/emirler?n=60", { sessiz: true }),
  ]);
  return { bot, cuzdan, emirler };
}

// Botu acar/kapatir -- ACARKEN HANGI MODDA calisacagini soyleyip onay ister.
//
// 23.09.2026, Ismail: "emin misiniz dry run'da calisacak, ya da emin
// misiniz canli'da calisacak desin". Onceden onaysiz aciliyordu ve
// kullanici hangi modda basladigini goremiyordu -- gercek para modunda
// bu kabul edilemez.
export async function botuAcKapat() {
  const d = await apiGet("/yerel/bot", { sessiz: true });
  if (!d) return;
  if (d.bot_acik) {
    if (!await askConfirm("BOTU DURDUR",
      "Bot yeni pozisyon ACMAYI birakacak. ACIK pozisyonlar kapanMAZ; "
      + "stop/hedef takibi her zamanki gibi surer.",
      { onayMetni: "DURDUR" })) return;
  } else {
    const canli = !!d.bot_canli;
    if (!await askConfirm(
      canli ? "BOT CANLI MODDA CALISACAK" : "BOT DRY RUN'DA CALISACAK",
      canli
        ? `Emin misiniz? Bot GERCEK PARA ile Binance'e emir gonderecek. `
          + `Strateji: ${d.strateji || "—"}`
        : `Emin misiniz? Bot KAGIT cuzdanla calisacak, gercek emir `
          + `gondermeyecek. Strateji: ${d.strateji || "—"}`,
      { onayMetni: canli ? "CANLI BASLAT" : "DRY RUN BASLAT" })) return;
  }
  const c = await apiPost("/yerel/bot", { acik: !d.bot_acik });
  if (c) {
    showToast(`bot ${c.bot_acik ? "ACIK" : "KAPALI"}`, c.bot_acik ? "ok" : "iptal");
    refreshNow("bot");
  }
}

// BOT sayfasini kurar ve zamanlayicisini kaydeder.
export function mountBotPage() {
  if (_kuruldu) return;
  _kuruldu = true;
  // Ismail: "burada dryrun yada canli gecis yaparken emin misiniz diye
  // sorsun". Eskiden yalnizca CANLIYA gecis onay istiyordu; canlidan
  // cikis tek tiklamayla sessizce oluyordu.
  document.getElementById("btnBotDry")?.addEventListener("click", async () => {
    if (!getState("bot")?.bot_canli) return;          // zaten kagit modda
    if (await askConfirm("BOT KAGIT MODA ALINSIN MI",
      "Bot bundan sonra GERCEK emir GONDERMEYECEK; kagit cuzdanla calisacak. "
      + "Acik gercek pozisyonlar kapanMAZ, oldugu gibi kalir.",
      { onayMetni: "KAGIDA AL" })) setBotMode(false);
  });
  document.getElementById("btnBotCanli")?.addEventListener("click", async () => {
    if (getState("bot")?.bot_canli) return;           // zaten canli
    if (await askConfirm("BOT CANLI MODA ALINSIN MI",
      "Bot bundan sonra GERCEK PARA ile Binance'e emir gonderecek.",
      { onayMetni: "CANLIYA AL" })) setBotMode(true);
  });
  document.getElementById("btnBotAc")?.addEventListener("click", botuAcKapat);
  document.getElementById("btnCuzdanSifirla")?.addEventListener("click", async () => {
    if (!await askConfirm("KAGIT CUZDANI SIFIRLA",
      "KAGIT defter sifirlanacak ve yedegi alinacak. Gercek para defterine DOKUNULMAZ."))
      return;
    const c = await apiPost("/yerel/bot", { cuzdan_sifirla: 1 });
    if (c) { showToast(`kagit defter sifirlandi (${c.silinen} kayit, yedek alindi)`, "ok"); refreshNow(); }
  });
  document.getElementById("btnDryTemizle")?.addEventListener("click", async () => {
    if (!await askConfirm("KAGIT GECMISI TEMIZLE", "Kapanmis kagit islemler silinir.")) return;
    const c = await apiPost("/yerel/defter-temizle", { canli: false });
    if (c) { showToast(`${c.silinen} kayit silindi`, "ok"); refreshNow("bot"); }
  });

  // 24.09.2026, Ismail: "bot menusunde coinin adina tiklayinca trade
  // ekrani acilsin". BU DAVRANIS CUZDAN SAYFASINDA VARDI, bot sayfasinda
  // YOKTU -- oradaki kartlara tiklaninca hicbir sey olmuyordu. Ayni
  // `.pozSembol` baglamasi (pozisyon + acik emir + kapanmis gecmis)
  // burada da kuruluyor. YONTEM/KAPAT/IPTAL butonlari (`data-eylem`)
  // kendi islerine karismasin diye bilerek disari birakiliyor.
  const sembolTikla = (e) => {
    if (e.target.closest("[data-eylem]")) return;
    if (!e.target.closest(".pozSembol")) return;
    const sembol = e.target.closest("[data-sembol]")?.dataset.sembol;
    if (sembol) openSymbol(sembol);
  };
  for (const id of ["bcPoz", "bcAcikEmir", "bcGecmis"]) {
    document.getElementById(id)?.addEventListener("click", sembolTikla);
  }

  registerPoll("bot", 5, refreshBotState, { sayfa: "bot" });
  sharePollResult("bot", (d) => {
    if (d.bot) { setState({ bot: d.bot }); renderBotControls(d.bot); }
    if (d.cuzdan) renderPaperWallet(d.cuzdan);
    if (d.emirler) {
      const piyasa = d.emirler.piyasa || {};
      // Bot HANGI MODDA calisiyorsa calissin tuttugu coinler burada gorunur:
      // defter suzgeci YOK (`live: null`), yalnizca "botun actiklari" suzgeci
      // var. Her satirda mod etiketi (CANLI / KAGIT) yazili.
      renderPositionTable("bcPoz", d.emirler,
                          { live: null, tur: "takip", sadece: "botVeKagit", piyasa });
      renderPositionTable("bcAcikEmir", d.emirler,
                          { live: null, tur: "acik", sadece: "botVeKagit", piyasa });
      renderPaperHistory(d.emirler.kapali);
    }
  });
}
