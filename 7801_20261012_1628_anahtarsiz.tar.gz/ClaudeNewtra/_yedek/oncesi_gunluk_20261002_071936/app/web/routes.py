"""
42 ucun TEK tablosu.
YAPAY ZEKA MIMO (24.09.2026): sayac 39 -> 42 guncellendi
  (derin inceleme: 25 GET + 17 POST = 42; eski not 39 diyordu).
Eski `do_GET`+`do_POST` 945 satirlik if/elif zinciriydi.
"""
from __future__ import annotations

from app.web.handlers import (admin_api, market_api, notes_api, orders_api,
                              report_api, settings_api, strategy_api)
from app.web.router import register_route


# Tum uclari kaydeder. `main` acilista BIR KEZ cagirir.
def register_all_routes() -> int:
    u = [
        # --- piyasa ---
        ("GET", "/yerel/ozet", market_api.handle_snapshot, "coin tablosu"),
        ("GET", "/yerel/heatmap", market_api.handle_heatmap,
         "heatmap + endeks + akis (YAPAY ZEKA MIMO)"),
        ("GET", "/yerel/kazananlar", market_api.handle_winners, "siralamada tirmananlar"),
        ("GET", "/yerel/aday", market_api.handle_candidates, "strateji adaylari"),
        ("GET", "/yerel/mum", market_api.handle_candles, "mum verisi"),
        ("GET", "/yerel/hacim-coklu", market_api.handle_multi_exchange_volume, "coklu borsa hacim (CHCM)"),
        ("GET", "/yerel/korku-acgozluluk", market_api.handle_fear_greed,
         "kripto Korku & Acgozluluk (onbellekli, gunde ~1 dis istek)"),
        ("GET", "/yerel/gecmis-sinyal", market_api.handle_history_signals, "geriye-test"),
        ("GET", "/yerel/tickler", market_api.handle_tick_archive, "tick arsivi"),
        ("GET", "/yerel/haric", market_api.handle_exclusions_read, "haric coinler"),
        ("POST", "/yerel/haric", market_api.handle_exclusions_write, "haric listesi yaz"),
        ("GET", "/yerel/pozisyon-haric", market_api.handle_position_exclusions_read,
         "uzlastirmada sayilmayanlar"),
        ("POST", "/yerel/pozisyon-haric", market_api.handle_position_exclusions_write,
         "pozisyon haric yaz"),
        # --- emirler ---
        ("GET", "/yerel/emirler", orders_api.handle_order_list, "acik/takip/kapali emirler"),
        ("POST", "/yerel/emir", orders_api.handle_place_order, "AL/AL TAKIP/ALSAT"),
        ("POST", "/yerel/dryrun_giris", orders_api.handle_paper_entry, "kagit giris"),
        ("POST", "/yerel/emir/kapat", orders_api.handle_close_one, "pozisyon kapat"),
        ("POST", "/yerel/emir/hepsini-kapat", orders_api.handle_close_all, "hepsini kapat"),
        ("POST", "/yerel/emir/iptal", orders_api.handle_cancel_order, "emir iptal"),
        ("POST", "/yerel/yontem-degistir", orders_api.handle_change_method, "cikis yontemi"),
        ("POST", "/yerel/defter-temizle", orders_api.handle_purge_ledger, "kapanmislari sil"),
        # --- ayar ---
        ("GET", "/yerel/ayar", settings_api.handle_settings_read, "ayarlar + sema"),
        ("POST", "/yerel/ayar", settings_api.handle_settings_write, "ayar yaz"),
        ("POST", "/yerel/anahtar", settings_api.handle_credentials_write, "API anahtari"),
        # --- strateji ---
        ("GET", "/yerel/strateji", strategy_api.handle_strategy_list, "stratejiler"),
        ("POST", "/yerel/strateji", strategy_api.handle_strategy_command, "kaydet/sil/aktif"),
        # --- rapor ---
        ("GET", "/yerel/pnl", report_api.handle_pnl, "kar/zarar egrisi"),
        ("GET", "/yerel/bakiye", report_api.handle_balance, "cuzdan"),
        ("GET", "/yerel/bot-cuzdan", report_api.handle_paper_wallet, "kagit cuzdan"),
        ("GET", "/yerel/gercek-cuzdan", report_api.handle_live_wallet, "gercek cuzdan"),
        ("GET", "/yerel/gecmis", report_api.handle_trade_history, "kapanmis emirler"),
        ("GET", "/yerel/isabet", report_api.handle_accuracy, "sinyal isabeti"),
        # --- notlar ---
        ("GET", "/yerel/notlar", notes_api.handle_notes_read, "notlar"),
        ("POST", "/yerel/notlar", notes_api.handle_notes_write, "not yaz"),
        # --- yonetim ---
        ("GET", "/yerel/bot", admin_api.handle_bot_status, "bot ozeti + calisan isler"),
        ("POST", "/yerel/bot", admin_api.handle_bot_command, "bot komutu"),
        ("GET", "/yerel/durum", admin_api.handle_legacy_status, "sade durum"),
        ("GET", "/yerel/surum", admin_api.handle_app_version, "arayuz surumu"),
        ("GET", "/yerel/saglik", admin_api.handle_health, "YENI: neyin calistigi"),
        ("GET", "/yerel/uclar", admin_api.handle_route_list, "YENI: uc listesi"),
        ("POST", "/yerel/telegram", admin_api.handle_telegram_config, "telegram ayari"),
        ("POST", "/yerel/telegram-mesaj", admin_api.handle_telegram_send, "telegram mesaj"),
        ("POST", "/yerel/uzlastir-simdi", admin_api.handle_reconcile_now, "elle uzlastirma"),
        ("GET", "/yerel/uzlastirma-gunlugu", admin_api.handle_reconcile_log, "uzlastirma gunlugu"),
    ]
    for yontem, yol, isleyici, aciklama in u:
        register_route(yontem, yol, isleyici, aciklama)
    return len(u)
