# -*- coding: utf-8 -*-
"""Tum HTTP uclarini sirayla cagirir ve yanitlarini ozetler."""
import json, urllib.request
U = "http://127.0.0.1:7801"
UCLAR = [
    ("/yerel/ozet?n=20", "satir"), ("/yerel/kazananlar?n=5", "satir"),
    ("/yerel/aday?n=5", "aday"), ("/yerel/emirler", "takip"),
    ("/yerel/bakiye", "gercek"), ("/yerel/pnl?kaynak=canli&sadece=el", "seri"),
    ("/yerel/gecmis?kaynak=canli&n=3", "gecmis"), ("/yerel/bot", "isler"),
    ("/yerel/strateji", "stratejiler"), ("/yerel/ayar", "ayar"),
    ("/yerel/notlar", None), ("/yerel/haric", "haric"),
    ("/yerel/pozisyon-haric", "haric"), ("/yerel/uzlastirma-gunlugu", None),
    ("/yerel/heatmap", None), ("/yerel/korku-acgozluluk", "endeks"),
    ("/yerel/saglik", "isler"), ("/yerel/bot-cuzdan", None),
    ("/yerel/gercek-cuzdan", "para"), ("/yerel/uclar", None),
    ("/yerel/mum?symbol=BTCUSDT&interval=5m&limit=5", None),
    ("/yerel/tickler?symbol=BTCUSDT", None),
]
kotu = []
for yol, anahtar in UCLAR:
    try:
        r = urllib.request.urlopen(U + yol, timeout=25)
        d = json.loads(r.read())
        ek = ""
        if anahtar and isinstance(d, dict) and anahtar in d:
            v = d[anahtar]
            ek = "  %s=%s" % (anahtar, len(v) if hasattr(v, "__len__") else "var")
        print("  %-46s %s%s" % (yol, r.status, ek))
    except Exception as e:
        kotu.append((yol, str(e)[:60]))
        print("  %-46s HATA: %s" % (yol, str(e)[:60]))
print("  --> basarisiz uc:", len(kotu))
