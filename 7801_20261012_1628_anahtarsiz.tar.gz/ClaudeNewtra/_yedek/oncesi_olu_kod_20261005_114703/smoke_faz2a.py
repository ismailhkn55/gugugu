"""Kural motoru: (1) arayuz alanlari gercekten var mi, (2) ESKI MOTORLA
213 sembolde birebir ayni karar mi veriyor, (3) ema4 tuzagi yakalaniyor mu."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/DATA/AppData/Newtrade")
from app.core.applog import setup_logging
from app.market import rank_repository as RR, indicators as IND
from app.strategy import rule_engine as RE
import strateji as ESKI          # ESKI MOTOR
setup_logging()

print("=== 1) ARAYUZ ALANLARI GERCEKTEN VAR MI ===")
ui = """atr_pct cci deg10m deg15m deg1h deg20m deg24 deg2h deg30m deg35m deg40m deg45m
deg4h deg50m deg55m deg5m deg8h ema20 ema20_uzak ema4 ema48_uzak ema7 ema_dizilim
ema_kesim gun_pct ha_1d_ardisik_yesil ha_1h_ardisik_yesil ha_4h_ardisik_yesil
ha_ardisik_yesil ha_yesil_yukselis hacim hacim_x hiz iz_yon kdj_j obv_aci obv_kesim
rank rank_atr rank_hiz renk_10m renk_15m renk_1h renk_20m renk_2h renk_30m renk_35m
renk_40m renk_45m renk_4h renk_50m renk_55m renk_5m renk_8h renk_gun rsi wma48
yesile_donus_mum""".split()
yok = [a for a in ui if not IND.is_known_field(a)]
print(f"  arayuzde sunulan alan: {len(ui)}")
print(f"  KAYIT DEFTERINDE OLMAYAN: {yok or 'yok'}")
if yok:
    print("  -> bu alan(lar)i kullanan kural, eski motorda SESSIZCE sifir aday verirdi")
# renk alanlarinin eski motorla ayni adlandirmada oldugunu dogrula
print(f"  renk alani adlari eski motorla ayni mi: "
      f"{set(IND.COLOR_SOURCE) == set(ESKI.RENK_KAYNAK)}")

print("\n=== 2) ESKI MOTOR vs YENI MOTOR — 213 sembol ===")
st = ESKI.aktif(canli=False)
kurallar = st["kurallar"]
print(f"  strateji: {st['ad']}  ({len(kurallar)} kural)")
for k in kurallar:
    print("    -", RE.describe_rule(k))
d = RR.fetch_latest_snapshot(limit=400)
satirlar = d["satir"]
# eski motor renk alanlarini satirda bekliyor; ikisi de turetiyor
ayni = farkli = 0
ornek_fark = []
for s in satirlar:
    eski_sonuc = all(ESKI._kural_gecti(s, k) for k in kurallar)
    yeni = RE.evaluate_rule_set(s, kurallar, strict_fields=False)
    if eski_sonuc == yeni["gecti"]:
        ayni += 1
    else:
        farkli += 1
        if len(ornek_fark) < 3:
            ornek_fark.append((s["sembol"], eski_sonuc, yeni["gecti"], yeni))
print(f"  sembol: {len(satirlar)}   AYNI KARAR: {ayni}   FARKLI: {farkli}")
for sem, e, y, det in ornek_fark:
    print(f"    {sem}: eski={e} yeni={y}")
    for r in det["sonuclar"]:
        print("       ", RE.explain_rule_outcome(r))
gecen_eski = sum(1 for s in satirlar if all(ESKI._kural_gecti(s, k) for k in kurallar))
gecen_yeni = sum(1 for s in satirlar if RE.evaluate_rule_set(s, kurallar, strict_fields=False)["gecti"])
print(f"  kurallari gecen sembol — eski: {gecen_eski}  yeni: {gecen_yeni}")

print("\n=== 3) ema4 TUZAGI ===")
ornek = satirlar[0]
tuzak = {"alan": "ema4", "op": ">", "deger": 0}
print("  ESKI motor  :", ESKI._kural_gecti(ornek, tuzak), " <- sessiz False, hata yok")
r = RE.evaluate_rule(ornek, tuzak)
print("  YENI motor  :", r.outcome.value, "|", r.reason)

print("\n=== 4) NULL alan ile OLMAYAN alan AYRI MI ===")
for k in ({"alan": "ha_yesil_yukselis", "op": ">", "deger": 0},
          {"alan": "uydurma_alan", "op": ">", "deger": 0},
          {"alan": "cci", "op": "gecersizop", "deger": 0},
          {"alan": "cci", "op": ">"}):
    r = RE.evaluate_rule(ornek, k)
    print(f"  {RE.describe_rule(k):<34} {r.outcome.value:<9} {r.reason}")

print("\n=== 5) strict_fields: ALAN_YOK sessizce 'elendi' gorunmuyor ===")
kume = list(kurallar) + [tuzak]
gevsek = RE.evaluate_rule_set(ornek, kume, strict_fields=False)
siki = RE.evaluate_rule_set(ornek, kume, strict_fields=True)
print(f"  gevsek (eski davranis): gecti={gevsek['gecti']}")
print(f"  siki   (yeni varsayilan): gecti={siki['gecti']}  hata={siki['hata_gerekce']}")
