import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.core.applog import setup_logging, get_logger, log_once
from app.core.timeutil import now_ms, utc_day_start_ms, align_to_bucket_ms, format_duration
from app.core.jsonstore import read_json_file
from app.core.locking import ledger_lock, is_holding_lock, assert_no_network_in_lock
from app.core.errors import AppError, UnknownFieldError
from app.config import paths, settings, secrets

setup_logging()
print("=== paths ===")
print("  app_root  :", paths.get_app_root())
print("  ledger T  :", os.path.basename(paths.get_ledger_path(True)))
print("  ledger F  :", os.path.basename(paths.get_ledger_path(False)))
try:
    paths.get_ledger_path(None); print("  HATA: None kabul edildi!")
except TypeError as e:
    print("  live=None reddedildi:", e)

print("\n=== timeutil ===")
print("  now_ms          :", now_ms())
print("  utc gun acilisi :", utc_day_start_ms())
print("  5dk kilavuz     :", align_to_bucket_ms(now_ms()))
print("  format_duration :", format_duration(0), "|", format_duration(95_000),
      "|", format_duration(3_600_000 * 26))

print("\n=== locking ===")
print("  kilit disinda is_holding_lock:", is_holding_lock())
with ledger_lock():
    print("  kilit icinde is_holding_lock :", is_holding_lock())
    try:
        assert_no_network_in_lock("Binance DELETE")
        print("  HATA: kilit icinde ag cagrisina izin verildi!")
    except AppError as e:
        print("  kilit icinde ag cagrisi ENGELLENDI")
print("  cikista is_holding_lock      :", is_holding_lock())

print("\n=== settings (GERCEK ayar.json, salt okunur) ===")
a = settings.load_settings()
print("  anahtar sayisi :", len(a))
print("  canli          :", a["canli"])
print("  bot_cikis_esik :", a["bot_cikis_esik"])
print("  komisyon       :", a["komisyon_toplam"])
print("  YENI (eskiden koda gomuluydu):")
for k in ("dinamik_atr_carpan", "dinamik_mesafe_tavan", "alsat_kilit_orani"):
    print(f"    {k:24} = {a[k]}   ({settings.describe_setting(k).label})")
print("  OLU AYARLAR:", ", ".join(settings.list_orphan_settings(a)) or "yok")
uyari = settings.check_scalp_target_order(a)
print("  ALSAT sira kontrolu:", uyari or "sira dogru")
print("  cikis geometrisi:", len(settings.get_exit_geometry(a)), "anahtar")

print("\n=== secrets ===")
print("  anahtar var mi :", secrets.has_api_credentials())
k = secrets.load_api_credentials()
print("  alanlar        :", sorted(k) if k else None)
print("  (deger BASILMIYOR)")
k2 = secrets.load_api_credentials()
print("  ikinci okuma onbellekten mi:", k is k2)
