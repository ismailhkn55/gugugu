"""Fiyatin TEK cephesi.

Eski sistemde fiyat YEDI ayri yoldan geliyordu ve ayni turda karisiyorlardi:
bot giris kararini sqlite'tan (20 saniye eski), cikis kararini websocket'ten
(anlik), satis kaydini gercek dolumdan aliyordu. Hangi sayinin nereden
geldigi hicbir yerde yazmiyordu.

Burada sira acikca tanimli -- akis > REST > anlik goruntu -- ve her fiyat
KENDI KAYNAGINI tasir.
"""
from __future__ import annotations

from app.core.applog import get_logger, log_once
from app.exchange.binance_ws import STREAM
from app.exchange.symbol_rules import normalize_symbol

_log = get_logger(__name__)

SOURCE_STREAM = "akis"       # websocket, anlik
SOURCE_REST = "rest"         # Binance REST, agirlik maliyetli
SOURCE_SNAPSHOT = "anlik"    # rank.sqlite, en fazla 5 dk eski


# Tek fiyat: (fiyat, kaynak). Fiyat bulunamazsa (None, "yok").
def get_price(symbol: str, *, allow_rest: bool = True) -> tuple[float | None, str]:
    s = normalize_symbol(symbol)
    f = STREAM.get_last_price(s)
    if f is not None and not STREAM.is_stream_stale():
        return f, SOURCE_STREAM
    if allow_rest:
        from app.exchange.binance_rest import fetch_ticker_price
        try:
            return float(fetch_ticker_price(s)["price"]), SOURCE_REST
        except Exception as e:
            log_once(_log, "price-rest", f"REST fiyat alinamadi ({s}): {e}")
    from app.market.rank_repository import fetch_snapshot_prices
    try:
        f2 = fetch_snapshot_prices().get(s)
        if f2 is not None:
            return float(f2), SOURCE_SNAPSHOT
    except Exception:
        pass
    return None, "yok"


# Coklu fiyat: {sembol: (fiyat, kaynak)}.
# Akistan karsilanamayanlar icin TEK toplu REST cagrisi yapilir --
# eski `_fiyatlar` her sembol icin ayri ayri tum ticker listesini cekiyordu.
def get_prices(symbols, *, allow_rest: bool = True) -> dict[str, tuple[float | None, str]]:
    istenen = [normalize_symbol(s) for s in symbols if s]
    sonuc: dict[str, tuple[float | None, str]] = {}
    eksik: list[str] = []
    bayat = STREAM.is_stream_stale()
    for s in istenen:
        f = STREAM.get_last_price(s)
        if f is not None and not bayat:
            sonuc[s] = (f, SOURCE_STREAM)
        else:
            eksik.append(s)

    if eksik and allow_rest:
        from app.exchange.binance_rest import fetch_all_ticker_prices
        try:
            tablo = {x["symbol"]: float(x["price"]) for x in fetch_all_ticker_prices()}
            for s in list(eksik):
                if s in tablo:
                    sonuc[s] = (tablo[s], SOURCE_REST)
                    eksik.remove(s)
        except Exception as e:
            log_once(_log, "prices-rest", f"toplu REST fiyat alinamadi: {e}")

    if eksik:
        from app.market.rank_repository import fetch_snapshot_prices
        try:
            anlik = fetch_snapshot_prices()
            for s in list(eksik):
                if s in anlik:
                    sonuc[s] = (float(anlik[s]), SOURCE_SNAPSHOT)
                    eksik.remove(s)
        except Exception:
            pass
    for s in eksik:
        sonuc[s] = (None, "yok")
    return sonuc


# Bir kaynak kodunun okunur karsiligi (arayuzde gosterilir).
def describe_price_source(source: str) -> str:
    return {SOURCE_STREAM: "canli akis", SOURCE_REST: "borsa sorgusu",
            SOURCE_SNAPSHOT: "son tur (5 dk'ya kadar eski)",
            "yok": "fiyat bulunamadi"}.get(source, source)
