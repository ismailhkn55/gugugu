"""Gosterge SOZLESMESI ve hesaplari -- TEK KAYNAK.

NEDEN BOYLE: eski sistemde bir gosterge sutunu eklemek DORT ayri yere elle
dokunmayi gerektiriyordu:
    1. rank/toplayici.py  -> INSERT listesi (ve elle sayilmis `"?"*59`)
    2. rank/db.py         -> EK_KOLON goc listesi
    3. Newtrade/veri.py   -> KOLON dizesi
    4. Newtrade/sunucu.py -> geriye-test `satir` sozlugu
Biri unutulunca kural SESSIZCE hic ateslemiyordu:
  * `ema7` (22.09.2026) -- 2'ye eklenmemisti; sifirdan kurulumda toplayici
    her turda cokuyordu (23.09'da bulundu).
  * `ema4` -- toplayici hesapliyor ama INSERT'e koymuyor; sutun veritabaninda
    YOK, buna ragmen arayuzde secilebiliyor. Bu kurali kullanan strateji
    sonsuza kadar sifir aday veriyor. HALA ACIK.
  * `rsi` -- ayni sinif, sunucu.py:2258'deki yorumda itiraf ediliyor.

Burada sutunlar TEK yerde tanimli. Sema, INSERT, secim listesi, arayuz alan
listesi ve geriye-test hepsi bu defterden turetilir; ayrisamazlar.

`ALAN_YOK` durumu artik sessiz `False` degil -- kural motoru bunu hata sayar.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Sequence


@dataclass(frozen=True)
class ColumnSpec:
    """Tek bir gosterge sutununun tanimi."""
    name: str
    kind: type                  # float | int | str
    meaning: str                # ne oldugu (dokumantasyon buradan uretilir)
    producer: str               # onu hesaplayan fonksiyon / kaynak
    nullable: bool = True       # olculememisse NULL kalabilir mi
    derived: bool = False       # veritabaninda degil, calisma aninda turetilir


def _c(name, kind, meaning, producer, **kw) -> ColumnSpec:
    return ColumnSpec(name, kind, meaning, producer, **kw)


# ---------------------------------------------------------------------------
# SUTUN KAYIT DEFTERI -- rank.sqlite `anlik` tablosunun tam sozlesmesi.
# Sira, veri.py'nin KOLON dizesiyle ayni; degistirilirse iki taraf birlikte
# degisir cunku ikisi de buradan uretilir.
# ---------------------------------------------------------------------------
COLUMN_REGISTRY: tuple[ColumnSpec, ...] = (
    _c("sembol", str, "Islem cifti, ornegin PROMUSDT", "ticker/24hr", nullable=False),
    _c("fiyat", float, "Son fiyat (lastPrice)", "ticker/24hr", nullable=False),

    # --- yuzde degisimler ---
    _c("deg5m", float, "% son 5m mum. Mum <%20 dolduysa son KAPANMIS mumun degisimi", "ince_olc"),
    _c("deg1h", float, "% 12 bar geri", "geri(12)"),
    _c("deg2h", float, "% 24 bar geri", "geri(24)"),
    _c("deg4h", float, "% 48 bar geri", "geri(48)"),
    _c("deg8h", float, "% 96 bar geri", "geri(96)"),
    _c("deg24", float, "% 24 saat -- Binance KAYAN penceresi, 5m mumlardan degil", "ticker/24hr"),
    _c("gun_pct", float, "% UTC gun acilisina gore", "ince_olc"),

    # --- hacim ---
    _c("hacim", float, "24s quote hacmi (USDT)", "ticker/24hr"),
    _c("hacim_x", float, "5m hacim / son 288 mumun ortancasi, tam-mum karsiligina olceklenmis",
       "compute_volume_ratio"),
    _c("hacim_x_1h", float, "Ayni oran 1h icin -- YALNIZ en hareketli 150 cift, gerisi NULL",
       "hacim_kat"),
    _c("hacim_x_4h", float, "Ayni oran 4h icin -- ayni 150 sinirli", "hacim_kat"),
    # 02.10.2026, Ismail: "kendinden onceki 3 mumun hacminin ortalamasinin 3
    # kati ise 1. ya da 2. HA mumunda giris" -- hacim_x 288 mumun ORTANCASINA
    # bakiyor; bu alan yalniz ONCEKI 3 MUMA bakar (ani patlama).
    # 02.10.2026, Ismail: "4h kirmizida kalanlari ele" -- ekrandaki TM seridi
    # her 4h dilimi KENDI rengiyle (kapanis >= acilis) boyar. Bu alan ayni
    # tanimi KARAR ANINDA verir: fiyat icinde bulunulan 4h dilimin acilisinin
    # ustunde mi. (ha_4h_ardisik_yesil bir ONCEKI kapanmis HA mumuna bakar.)
    # 02.10.2026, Ismail: "yesilin tepesinden giriyor" -- ALGO'da dipten %7-8
    # yukseldikten sonraki girisler -%2 ile kapandi. Giris yukselisin neresinde?
    # 03.10.2026, Ismail: DENEME S7 girisi (7802'de %95 kazanan) -- yalniz KAPANMIS mumlar.
    _c("ha_kapali_yesil", int, "KAPANMIS 5m mumlarla HA ardisik yesil sayisi (son 60 mum)",
       "count_closed_ha_streak"),
    _c("dusus_3s", float, "Son 36 kapanmis mumda (3 saat) tepeden sonraki dibe dusus %",
       "compute_drawdown_from_peak"),
    _c("bbw_yuzdelik", float, "Onceki mumun Bollinger genisligi, son 200 mum icinde yuzdelik (0 = en dar)",
       "compute_bb_width_percentile"),
    _c("kirilim_tetik", int,
       "1 = SERT_DUSUS (3s'te >= %3 dusus, dipten donuyor) VEYA SIKISMA (BB en dar %20 + orta ustu) "
       "VEYA BTC_DONUS (BTC 1s <= -0.25, 15dk >= +0.34, coin 24s <= -4.5) -- gecmis taramada BTC_DONUS YOK",
       "ince_olc"),
    _c("dipten_24s", float,
       "Fiyat son 24 saatin (288 x 5m) en dusugunden % kac yukarida",
       "compute_rise_from_low"),
    _c("h4_anlik_yesil", int,
       "1 = icinde bulunulan 4h mum su an YESIL (fiyat >= 4h acilisi), 0 = kirmizi",
       "compute_open_period_green"),
    _c("hacim_3ort_x", float,
       "5m hacim / onceki 3 mumun ortalama hacmi, tam-mum karsiligina olceklenmis",
       "compute_prev3_volume_ratio"),

    # --- klasik gostergeler ---
    _c("atr_pct", float, "ATR(14)/fiyat*100, 5m, Wilder", "compute_atr_percent"),
    _c("rsi", float, "RSI(14), 5m, Wilder", "compute_rsi"),
    _c("rsi_egim", float, "RSI'in son 3 mumdaki degisimi", "compute_rsi"),
    _c("hiz", float, "Normalize momentum: deg1h / kendi tipik hareketi",
       "compute_normalized_momentum"),
    _c("obv", float, "On Balance Volume ham degeri (mutlak degeri anlamsiz)", "compute_obv"),
    _c("obv_sinyal", float, "OBV'nin EMA(20)'si -- olcumle secildi", "compute_obv_signal"),
    _c("obv_kesim", int, "Kac bardir sinyalin ustunde(+)/altinda(-); |1| = bu barda kesti",
       "compute_cross_age"),
    _c("obv_aci", float, "OBV egimi, derece. 45 = kendi tipik hizi", "compute_slope_angle"),
    _c("cci", float, "CCI(20), 5m, Lambert 0.015", "compute_cci"),
    # 27.09.2026, Ismail: "cci artis miktari" -- 7 mum onceki CCI'ye gore
    # MUTLAK puan farki (cci_simdi - cci_7_once). Yuzde DEGIL: CCI isaret
    # degistirebildigi icin (-30 -> -10 gibi) yuzde hesap payda sifira/
    # negatife yaklasinca anlamsizlasir. -30'dan -10'a gibi eksi kalan ama
    # YUKSELEN hareketi yakalamak icin. compute_cci ile ayni pencere (n=20),
    # 7 mum geriden kesilmis veriyle tekrar cagirilir.
    _c("cci_artis", float, "CCI'nin 7 mum onceye gore MUTLAK degisimi (puan)",
       "compute_cci"),
    _c("kdj_j", float, "KDJ(9,3,3) J = 3K-2D; 0-100 disina tasar", "compute_kdj_j"),
    _c("kdj_j_aci", float, "J'nin egimi, derece", "compute_slope_angle"),

    # --- siralamalar ---
    _c("rank", int, "deg24'e gore sira; 1 = en cok yukselen", "toplayici"),
    _c("rank_hacim", int, "Hacme gore sira", "toplayici"),
    _c("rank_hiz", int, "hiz'a gore sira (hiz NULL ise NULL)", "toplayici"),
    _c("rank_atr", int, "atr_pct'e gore sira; 1 = en oynak", "toplayici"),

    # --- ince zaman dilimleri (25m YOK -- bilerek) ---
    _c("deg10m", float, "% 2 bar geri", "ince_olc"),
    _c("deg15m", float, "% 3 bar geri", "ince_olc"),
    _c("deg20m", float, "% 4 bar geri", "ince_olc"),
    _c("deg30m", float, "% 6 bar geri", "ince_olc"),
    _c("deg35m", float, "% 7 bar geri", "ince_olc"),
    _c("deg40m", float, "% 8 bar geri", "ince_olc"),
    _c("deg45m", float, "% 9 bar geri", "ince_olc"),
    _c("deg50m", float, "% 10 bar geri", "ince_olc"),
    _c("deg55m", float, "% 11 bar geri", "ince_olc"),

    # --- mum rengi / Heikin Ashi ---
    _c("yesile_donus_mum", int,
       "Son 20 mumda KIRMIZI->YESIL donusu kac mum once (0 = bu mumda). "
       "Son mum yesil degilse NULL", "count_bars_since_green_flip"),
    _c("ha_ardisik_yesil", int, "5m Heikin Ashi'de ardisik yesil mum sayisi",
       "count_consecutive_green_ha"),
    _c("ha_yesil_yukselis", float,
       "Yesil HA serisinin ILK mumunun acilisindan beri % yukselis; seri yoksa NULL",
       "measure_green_ha_gain"),
    _c("ha_1d_ardisik_yesil", int, "1D HA ardisik yesil -- yalnizca KAPANMIS mumlar (repaint yok)",
       "count_consecutive_green_ha"),
    _c("ha_4h_ardisik_yesil", int, "4H HA ardisik yesil, kapanmis mumlar",
       "count_consecutive_green_ha"),
    _c("ha_1h_ardisik_yesil", int, "1H HA ardisik yesil, kapanmis mumlar",
       "count_consecutive_green_ha"),
    _c("ha_4h_yesil_yukselis", float,
       "4H Heikin Ashi -- yesil HA serisinin ILK mumunun acilisindan beri % "
       "yukselis, yalnizca KAPANMIS 4H mumlar (repaint yok); seri yoksa NULL",
       "measure_green_ha_gain"),

    # --- hareketli ortalamalar ---
    _c("ema_dizilim", int, "1 = ema4>ema7>ema20 (su an dizilim var)", "ince_olc"),
    _c("ema_kesim", int, "1 = dizilim BU barda yeni olustu (giris sinyali)", "ince_olc"),
    _c("ema20_uzak", float, "Fiyat EMA20'den yuzde kac uzakta", "compute_ema"),
    _c("ema48_uzak", float, "Fiyat EMA48'den yuzde kac uzakta (>=49 mum gerekir)", "compute_ema"),
    _c("ema20", float, "Ham EMA20 -- alan-alan kiyaslama icin", "compute_ema"),
    _c("wma48", float, "WMA(48); en yeni mum en agirlikli", "compute_wma"),
    _c("ema7", float, "Ham EMA7", "compute_ema"),

    # --- Bollinger orta cizgi (29.09.2026, Ismail: "fiyat boiler band orta
    # cizgisini yukari kesti" / "orta cizginin uzerinde") ---
    _c("bb_orta_uzak", float,
       "Fiyatin Bollinger ORTA cizgisinden (SMA20) yuzde kac uzakta -- >0 ise ustunde",
       "compute_sma"),
    _c("bb_orta_kesim", int,
       "1 = fiyat Bollinger ORTA cizgisini BU barda yukari kesti (giris sinyali)",
       "compute_sma"),
    # 29.09.2026, Ismail: "hacim yesil gelirse yada 2x uzeri VEYA boiler
    # bandi kesince giris" -- kural motoru yalniz VE destekliyor, iki AYRI
    # alani (hacim_x, bb_orta_kesim) OR ile birlestiremez. Bu alan OR'u
    # ONCEDEN hesaplar: strateji tarafinda tek basina yeterli olur.
    _c("hacim_bb_tetik", int,
       "1 = hacim_x >= 2 VEYA bb_orta_kesim == 1 (hacim patlamasi veya "
       "Bollinger orta kesisimi -- ikisinden biri yeterli)",
       "ince_olc"),

    # --- son 128 mum sayimi + FARK/KARE (26.09.2026, Ismail) ---
    # 128 DEGISIM icin 129 kapanmis mum gerekir (bir onceki kapanis).
    _c("deg128m", float,
       "% son 128 kapanmis 5m mum (kapanis/kapanis) -- kural alani",
       "ince_olc"),
    _c("coingreen", int,
       "Son 128 mumda kapanisi acilisindan yuksek olan (YESIL) mum adedi",
       "ince_olc"),
    _c("coinsay", int,
       "Son 128 mumda yesil - kirmizi farki; esit mumlar sayilmaz",
       "ince_olc"),
    _c("yesildeg", float,
       "Son 128 mumun YESIL olanlarinin degisim toplami (%) -- her mum "
       "onceki kapanisina gore olculur; anasayfada gosterilmez",
       "ince_olc"),
    _c("kirmizideg", float,
       "Son 128 mumun KIRMIZI olanlarinin degisim toplami (%) -- "
       "cogunlukla eksi deger; anasayfada gosterilmez",
       "ince_olc"),
    _c("fark128", float,
       "yesildeg - |kirmizideg|; negatifse kirmizilar baskin. "
       "Anasayfadaki FARK sutunu ve islem ekranindaki FARK kutusu",
       "ince_olc"),
    _c("kare128", float,
       "Son 128 mumun fiyat araligi % (enYuksek/enDusuk - 1); 1% = 1 izgara "
       "karesi. Anasayfadaki KARE sutunu", "ince_olc"),
    _c("yukselis128", float,
       "Son kapanan mumun en yuksek degeri / son 128 mumun en dusuk degeri - 1 "
       "(*100): pencere dibinden tepeye yukselis %. Anasayfadaki YUKSELIS "
       "sutunu", "ince_olc"),

    # --- calisma aninda turetilenler (veritabaninda YOK) ---
    _c("sira_izi", list, "Son 20 turdaki rank degerleri", "attach_rank_trail", derived=True),
    _c("iz_yon", float,
       "Son 5 turda rank degisimi; POZITIF = siralamada tirmaniyor "
       "(yon = ESKI_rank - YENI_rank)", "compute_trail_direction", derived=True),

    # --- PIYASA DURUMU: TUM EVRENDEN hesaplanir, tek sembolle kurulamaz
    # (geriye-testte `UNTESTABLE_FIELDS` icinde, bkz. strategy/backtest.py) ---
    _c("genislik", float,
       "Heatmap yesil yuzdesi: deg24>0 olan coinlerin payi (%) -- "
       "PIYASA KOSULU, her satira AYNI deger yazilir", "attach_market_fields", derived=True),
    _c("total3_5m", float,
       "Hacim-agirlikli altcoin ort deg5m (%) = TOTAL3 son 5 dakikadaki yonu; "
       "POZITIF ise TOTAL3 yukseliyor. PIYASA KOSULU, her satira AYNISI",
       "attach_market_fields", derived=True),
)

_INDEX: dict[str, ColumnSpec] = {c.name: c for c in COLUMN_REGISTRY}

# Yuzde alanlarindan TURETILEN renk alanlari (veritabaninda saklanmaz,
# boylece her zaman guncel yuzdeyle tutarli kalir).
# Adlar strateji.py:210 RENK_KAYNAK ve index.html:6008 ALANLAR_LISTE ile
# BIREBIR ayni olmak ZORUNDA -- ilk yazimimda "renk_deg5m" demistim,
# gercegi "renk_5m"; ayrica "renk_deg24" diye olmayan bir alan uydurmus,
# gercekte var olan "renk_gun"u atlamistim. Tam olarak onlemeye calistigim
# hata sinifi; capraz dogrulama yakaladi.
COLOR_SOURCE: dict[str, str] = {
    "renk_5m": "deg5m", "renk_10m": "deg10m", "renk_15m": "deg15m",
    "renk_20m": "deg20m", "renk_30m": "deg30m", "renk_35m": "deg35m",
    "renk_40m": "deg40m", "renk_45m": "deg45m", "renk_50m": "deg50m",
    "renk_55m": "deg55m", "renk_1h": "deg1h", "renk_2h": "deg2h",
    "renk_4h": "deg4h", "renk_8h": "deg8h", "renk_gun": "gun_pct",
}


# Veritabanindan SECILECEK sutun adlari (turetilmisler haric).
def list_column_names() -> tuple[str, ...]:
    return tuple(c.name for c in COLUMN_REGISTRY if not c.derived)


# SQL SELECT icin sutun listesi -- veri.py'nin elle yazilmis KOLON dizesinin yerine.
def build_select_clause() -> str:
    return ", ".join(list_column_names())


# Bir sutunun tanimi.
def get_column_meta(name: str) -> ColumnSpec | None:
    return _INDEX.get(name)


# Bu alan gercekten var mi? (renk_* turetilmisleri de kapsar)
# `ema4` gibi "hesaplaniyor ama saklanmiyor" alanlar burada YOK -> kural motoru
# onu sessizce elemek yerine ALAN_YOK diye bildirecek.
def is_known_field(name: str) -> bool:
    return name in _INDEX or name in COLOR_SOURCE


# Kural yazarken secilebilecek TUM alanlar -- arayuz listesi bundan uretilir.
def list_available_fields() -> tuple[str, ...]:
    return tuple(sorted(set(_INDEX) | set(COLOR_SOURCE)))


# 27.09.2026, Ismail: "seceneklerini az aciklayici yap" -- alan aciklamalari
# ARTIK BURADAN (tek kaynak) arayuze gider; JS'te ikinci bir metin
# TEKRAR YAZILMAZ (COLUMN_REGISTRY.meaning ile ekranda gorunen ayrismasin).
def field_meanings() -> dict[str, str]:
    return {c.name: c.meaning for c in COLUMN_REGISTRY}


# --------------------------------------------------------------- hesaplar

# Ortanca. Cift sayida elemanda ORTALAMA alir -- toplayici.py:200 ile ayni.
# (Ilk yazimimda ust ortanca kullanmistim; toplayiciyla ayrisiyordu.)
def median(values: Sequence[float]) -> float | None:
    y = sorted(v for v in values if v is not None)
    n = len(y)
    if not n:
        return None
    return y[n // 2] if n % 2 else (y[n // 2 - 1] + y[n // 2]) / 2.0



# Ustel hareketli ortalama serisi.
def compute_ema(values: Sequence[float], period: int) -> list[float]:
    if not values or period <= 0:
        return []
    k = 2.0 / (period + 1)
    out = [float(values[0])]
    for v in values[1:]:
        out.append(float(v) * k + out[-1] * (1 - k))
    return out


# Basit hareketli ortalama serisi (Bollinger ORTA cizgisi icin, 29.09.2026).
def compute_sma(values: Sequence[float], period: int) -> list[float | None]:
    if not values or period <= 0:
        return []
    out: list[float | None] = [None] * len(values)
    toplam = 0.0
    for i, v in enumerate(values):
        toplam += float(v)
        if i >= period:
            toplam -= float(values[i - period])
        if i >= period - 1:
            out[i] = toplam / period
    return out


# Agirlikli hareketli ortalama (en yeni mum en agirlikli).
def compute_wma(values: Sequence[float], period: int) -> float | None:
    if len(values) < period or period <= 0:
        return None
    dilim = [float(v) for v in values[-period:]]
    toplam_agirlik = period * (period + 1) / 2
    return sum(v * (i + 1) for i, v in enumerate(dilim)) / toplam_agirlik


# RSI(period), Wilder yumusatmasi. (deger, son 3 mumdaki egim) doner.
def compute_rsi(closes: Sequence[float], period: int = 14) -> tuple[float | None, float | None]:
    if len(closes) < period + 4:
        return None, None
    kazanc = kayip = 0.0
    for i in range(1, period + 1):
        d = float(closes[i]) - float(closes[i - 1])
        kazanc += max(d, 0.0)
        kayip += max(-d, 0.0)
    kazanc, kayip = kazanc / period, kayip / period
    seri = []
    for i in range(period + 1, len(closes)):
        d = float(closes[i]) - float(closes[i - 1])
        kazanc = (kazanc * (period - 1) + max(d, 0.0)) / period
        kayip = (kayip * (period - 1) + max(-d, 0.0)) / period
        rs = kazanc / kayip if kayip > 1e-12 else float("inf")
        seri.append(100.0 - 100.0 / (1.0 + rs))
    if not seri:
        return None, None
    egim = seri[-1] - seri[-4] if len(seri) >= 4 else None
    return seri[-1], egim


# ATR(period) / fiyat * 100, Wilder.
def compute_atr_percent(highs: Sequence[float], lows: Sequence[float],
                        closes: Sequence[float], period: int = 14) -> float | None:
    n = min(len(highs), len(lows), len(closes))
    if n < period + 1:
        return None
    tr = []
    for i in range(1, n):
        h, l, pc = float(highs[i]), float(lows[i]), float(closes[i - 1])
        tr.append(max(h - l, abs(h - pc), abs(l - pc)))
    atr = sum(tr[:period]) / period
    for v in tr[period:]:
        atr = (atr * (period - 1) + v) / period
    son = float(closes[-1])
    return (atr / son * 100.0) if son else None


# On Balance Volume serisi.
def compute_obv(closes: Sequence[float], volumes: Sequence[float]) -> list[float]:
    n = min(len(closes), len(volumes))
    if n < 2:
        return []
    out = [0.0]
    for i in range(1, n):
        d = float(closes[i]) - float(closes[i - 1])
        out.append(out[-1] + (float(volumes[i]) if d > 0 else
                              -float(volumes[i]) if d < 0 else 0.0))
    return out


# OBV'nin sinyal cizgisi (EMA 20 -- olcumle secilmisti, korunuyor).
def compute_obv_signal(obv: Sequence[float], period: int = 20) -> list[float]:
    return compute_ema(obv, period)


# Kac bardir seri sinyalin ustunde(+)/altinda(-). |1| = bu barda kesti.
def compute_cross_age(series: Sequence[float], signal: Sequence[float]) -> int | None:
    n = min(len(series), len(signal))
    if n < 2:
        return None
    ustunde = series[-1] >= signal[-1]
    say = 0
    for i in range(n - 1, -1, -1):
        if (series[i] >= signal[i]) != ustunde:
            break
        say += 1
    return say if ustunde else -say


# Serinin egimi, DERECE. 45 derece = serinin kendi tipik hizi.
#
# 26.09.2026: canli toplayicinin `gostergeler.aci` fonksiyonuyla BIREBIR.
# Onceki surum 5 barlik egim + yalniz son 5 adimin ortancasini kullaniyordu;
# ayni mumda BTC 48.6 / 31.2 derece, barlarin %83'unde >5 derece fark.
# Canli tanim: egim son `lookback`(3) bar, tipik hiz son `window`(100)
# degerin bar basi adimlarinin UST ortancasi (adim[len//2]); None atlanir.
def compute_slope_angle(series: Sequence[float | None], lookback: int = 3,
                        window: int = 100) -> float | None:
    v = [float(x) for x in series[-window:] if x is not None]
    if len(v) < lookback + 1:
        return None
    hiz = (v[-1] - v[-1 - lookback]) / lookback
    adim = sorted(abs(v[i] - v[i - 1]) for i in range(1, len(v)))
    tipik = adim[len(adim) // 2]
    if not tipik:
        return 0.0
    return math.degrees(math.atan(hiz / tipik))


# CCI(period), Lambert sabiti 0.015.
def compute_cci(highs: Sequence[float], lows: Sequence[float],
                closes: Sequence[float], period: int = 20) -> float | None:
    n = min(len(highs), len(lows), len(closes))
    if n < period:
        return None
    tp = [(float(highs[i]) + float(lows[i]) + float(closes[i])) / 3.0
          for i in range(n - period, n)]
    ort = sum(tp) / period
    sapma = sum(abs(v - ort) for v in tp) / period
    return (tp[-1] - ort) / (0.015 * sapma) if sapma > 1e-12 else 0.0


# KDJ(9,3,3) J degeri.
# `return_series=True`: J serisini dondurur (ilk period-1 deger None) --
# canli `gostergeler.kdj` ile ayni; `kdj_j_aci` icin gerekli.
def compute_kdj_j(highs: Sequence[float], lows: Sequence[float],
                  closes: Sequence[float], period: int = 9, *,
                  return_series: bool = False):
    n = min(len(highs), len(lows), len(closes))
    if n < period:
        return [] if return_series else None
    k = d = 50.0
    seri: list[float | None] = [None] * (period - 1)
    for i in range(period - 1, n):
        en_y = max(float(x) for x in highs[i - period + 1:i + 1])
        en_d = min(float(x) for x in lows[i - period + 1:i + 1])
        rsv = 50.0 if en_y - en_d < 1e-12 else (float(closes[i]) - en_d) / (en_y - en_d) * 100.0
        k = (2 * k + rsv) / 3
        d = (2 * d + k) / 3
        seri.append(3 * k - 2 * d)
    return seri if return_series else 3 * k - 2 * d


# Heikin Ashi serisi: [(acilis, yuksek, dusuk, kapanis), ...]
def build_heikin_ashi(ohlc: Sequence[Sequence[float]]) -> list[tuple[float, float, float, float]]:
    out: list[tuple[float, float, float, float]] = []
    for i, m in enumerate(ohlc):
        o, h, l, c = (float(m[0]), float(m[1]), float(m[2]), float(m[3]))
        hc = (o + h + l + c) / 4.0
        ho = (o + c) / 2.0 if i == 0 else (out[-1][0] + out[-1][3]) / 2.0
        out.append((ho, max(h, ho, hc), min(l, ho, hc), hc))
    return out


# Ardisik yesil Heikin Ashi mum sayisi.
# ONEMLI: HA YOL BAGIMLIDIR -- her mum bir oncekinden turer. Toplayici HA'yi
# yalnizca SON 30 HAM MUMDAN kuruyor (gostergeler.py:228 `bakilacak=30`);
# 500 mumdan kurulan HA farkli degerler verir. Ayni pencere kullanilmali.
# Veri yetersizse None -- "olculmedi" ile "sifir yesil" AYRIDIR.
def count_consecutive_green_ha(ohlc: Sequence[Sequence[float]],
                               lookback: int = 30) -> int | None:
    if not ohlc or len(ohlc) < 3:
        return None
    ha = build_heikin_ashi(list(ohlc[-lookback:]))
    say = 0
    for mum in reversed(ha):
        if mum[3] > mum[0]:
            say += 1
        else:
            break
    return say


# Yesil HA serisinin ILK mumunun acilisindan beri % yukselis; seri yoksa None.
# Ayni 30 mumluk pencere (gostergeler.py:245).
def measure_green_ha_gain(ohlc: Sequence[Sequence[float]],
                          lookback: int = 30) -> float | None:
    if not ohlc or len(ohlc) < 3:
        return None
    ha = build_heikin_ashi(list(ohlc[-lookback:]))
    n = 0
    for mum in reversed(ha):
        if mum[3] > mum[0]:
            n += 1
        else:
            break
    if n == 0:
        return None
    bas = ha[-n][0]
    if bas <= 0:
        return None
    # Toplayici 4 basamaga yuvarliyor (gostergeler.py:269); veritabanindaki
    # deger de yuvarlanmis oldugu icin ayni yuvarlama uygulanir, yoksa
    # kural motoru "ayni sayi" icin farkli sonuc verebilir.
    return round((ha[-1][3] / bas - 1) * 100.0, 4)


# Kirmizidan yesile donus kac mum once oldu (0 = bu mumda); son mum
# yesil degilse None -- "olculmedi" ile "sifir" karistirilmaz.
def count_bars_since_green_flip(ohlc: Sequence[Sequence[float]], lookback: int = 20) -> int | None:
    if not ohlc:
        return None
    if len(ohlc) < 2:
        return None
    # Toplayici HAM mum rengini `kapanis >= acilis` ile olcuyor (>= , > degil)
    # ve pencereyi `bakilacak + 1` mum aliyor (toplayici.py:246).
    dilim = list(ohlc[-(lookback + 1):])
    yesil = [float(m[3]) >= float(m[0]) for m in dilim]
    if not yesil[-1]:
        return None          # su an yesil degilse "donus" anlamsiz
    for i in range(len(yesil) - 1, 0, -1):
        if yesil[i] and not yesil[i - 1]:
            return (len(yesil) - 1) - i
    return None


# Hacmin kendi ortancasina orani; acik mum sure oranina gore olceklenir.
def compute_volume_ratio(volumes: Sequence[float], *,
                         elapsed_ratio: float = 1.0) -> float | None:
    """15.09.2026 duzeltmesi KORUNUYOR: acilmis ama kapanmamis mumun hacmi,
    tam dolmus mumlarin ortancasina boluniyordu; mum 20 saniyelikken payda
    kucuk kalip hacim_x ~0 cikiyor ve "hacim_x >= 2" kurali TUM evreni
    eliyordu (panel 0.00 derken gercek deger 7.70x idi). Cozum birim
    esitleme. Mum cok tazeyse (%20'den az dolmus) sahte 50x uretmemek icin
    son KAPANMIS mumun degeri kullanilir."""
    if len(volumes) < 2:
        return None
    hac = [float(v) for v in volumes]
    if elapsed_ratio < 0.2:
        kapali_ort = median(hac[:-2]) if len(hac) > 2 else None
        return (hac[-2] / kapali_ort) if kapali_ort else None
    ort = median(hac[:-1])
    if not ort:
        return None
    return (hac[-1] / min(elapsed_ratio, 1.0)) / ort


# KAPANMIS mumlarla HA ardisik yesil (deneme_sinyal / toplayici ile ayni: son 60 mum, ilk mum tohumu).
def count_closed_ha_streak(ohlc: Sequence[Sequence[float]], *, lookback: int = 60) -> int | None:
    if len(ohlc) < lookback:
        return None
    d = [tuple(map(float, x)) for x in ohlc[-lookback:]]
    hc = [(a + b + c + e) / 4 for a, b, c, e in d]
    ho = [(d[0][0] + d[0][3]) / 2]
    for i in range(1, len(hc)):
        ho.append((ho[-1] + hc[i - 1]) / 2)
    n = 0
    for i in range(len(hc) - 1, -1, -1):
        if hc[i] > ho[i]:
            n += 1
        else:
            break
    return n


# Son `n` mumda tepeden SONRAKI dibe dusus % (negatif). (yuksekler, dusukler)
def compute_drawdown_from_peak(highs: Sequence[float], lows: Sequence[float], *,
                               n: int = 36) -> tuple[float, float] | None:
    if len(highs) < n:
        return None
    h, l = [float(x) for x in highs[-n:]], [float(x) for x in lows[-n:]]
    ti = max(range(n), key=lambda j: (h[j], -j))
    dip = min(l[ti:])
    return (dip / h[ti] - 1) * 100, dip


# Onceki mumun Bollinger genisligi (4*sd/sma, sd ddof=0), son `window` mum icinde yuzdelik
# ve son SMA20. Veri yetmezse None.
def compute_bb_width_percentile(closes: Sequence[float], *, n: int = 20,
                                window: int = 200) -> tuple[float, float] | None:
    c = [float(x) for x in closes]
    if len(c) < window + n + 1:
        return None
    gen, sma = [], 0.0
    for i in range(len(c) - window - 1, len(c)):
        w = c[i - n + 1:i + 1]; sma = sum(w) / n
        sd = (sum((v - sma) ** 2 for v in w) / n) ** 0.5
        gen.append(4 * sd / sma)
    return sum(1 for v in gen[:-1] if v <= gen[-2]) / (len(gen) - 1) * 100, sma


# Son kapanis, son `n` mumun en dusugunden % kac yukarida. Az veri -> None.
def compute_rise_from_low(lows: Sequence[float], closes: Sequence[float], *,
                          n: int = 288) -> float | None:
    if len(lows) < n or not closes:
        return None
    dip = min(float(x) for x in lows[-n:])
    return (float(closes[-1]) / dip - 1) * 100.0 if dip else None


# Icinde bulunulan `period_ms` donemi su an yesil mi: son kapanis >= donemin
# ilk 5m mumunun acilisi. Donemin ilk mumu pencerede yoksa None (uydurma yok).
def compute_open_period_green(ts: Sequence[int], opens: Sequence[float],
                              closes: Sequence[float], *,
                              period_ms: int = 14_400_000) -> int | None:
    if not ts:
        return None
    bas = int(ts[-1]) // period_ms * period_ms
    for t, a in zip(ts, opens):
        if int(t) == bas:
            return 1 if float(closes[-1]) >= float(a) else 0
        if int(t) > bas:
            break
    return None


# Bu mumun hacmi / ONCEKI 3 mumun ortalama hacmi (02.10.2026, Ismail).
def compute_prev3_volume_ratio(volumes: Sequence[float], *,
                               elapsed_ratio: float = 1.0) -> float | None:
    """compute_volume_ratio ile ayni birim esitleme: acik mumun hacmi gecen
    sure oranina bolunup tam-mum karsiligina cevrilir. Mum %20'den az dolmussa
    son KAPANMIS mum, kendinden onceki 3 mumla kiyaslanir. Veri yetmiyorsa ya da
    onceki 3 mumun hacmi sifirsa None -- uydurma deger yok."""
    hac = [float(v) for v in volumes]
    if elapsed_ratio < 0.2:
        hac = hac[:-1]
        elapsed_ratio = 1.0
    if len(hac) < 4:
        return None
    ort = sum(hac[-4:-1]) / 3.0
    if not ort:
        return None
    return (hac[-1] / min(elapsed_ratio, 1.0)) / ort


# Degisimin kendi tipik hareketine orani -- "hiz".
def compute_normalized_momentum(closes: Sequence[float], *, lookback: int = 12,
                                change_pct: float | None = None) -> float | None:
    """Toplayici.py:402-406 ile BIREBIR ayni:
        deg12  = TUM seri boyunca 12-bar yuzde degisimleri
        tipik  = |deg12|'nin ortancasi, SON eleman haric
        hiz    = deg1h / tipik
    Ilk yazimimda yalnizca son 13 mumun 1-bar adimlarini kullanmistim; sonuc
    toplayiciyla %348 sapiyordu. Ayni pencere, ayni ortanca."""
    kap = [float(c) for c in closes]
    if len(kap) <= lookback + 1:
        return None
    deg12 = [(kap[i] / kap[i - lookback] - 1) * 100.0
             for i in range(lookback, len(kap)) if kap[i - lookback]]
    if len(deg12) < 2:
        return None
    tipik = median([abs(d) for d in deg12[:-1]])
    yuzde = change_pct if change_pct is not None else deg12[-1]
    if not tipik or yuzde is None:
        return None
    return yuzde / tipik
