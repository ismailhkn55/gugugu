"""Tick arsivi.

Eski `tickler/*.jsonl` dosyalarinda ayni `(ts, fiyat)` cifti defalarca
yaziliydi -- orneklenen dosyada %35 tekrar, toplam 217 MB. Websocket ayni
fiyati arka arkaya gonderdiginde her biri ayri satir olarak diske
yaziliyordu. Burada son yazilan cift hatirlanir, aynisi tekrar yazilmaz.
"""
from __future__ import annotations

import os

from app.config.paths import get_tick_dir
from app.core.applog import get_logger
from app.core.jsonstore import append_jsonl_record, read_jsonl_records

_log = get_logger(__name__)
_son_yazilan: dict[str, tuple[int, float]] = {}


def _yol(symbol: str) -> str:
    return os.path.join(get_tick_dir(), f"{symbol.upper()}.jsonl")


# Bu (ts, fiyat) cifti en son yazilanla ayni mi?
def is_duplicate_tick(symbol: str, ts: int, price: float) -> bool:
    return _son_yazilan.get(symbol.upper()) == (int(ts), float(price))


# Tek tick'i tampona/diske yazar; tekrar ise atlar. Yazilan sayisini doner.
def buffer_tick(symbol: str, ts: int, price: float) -> int:
    s = symbol.upper()
    if is_duplicate_tick(s, ts, price):
        return 0
    _son_yazilan[s] = (int(ts), float(price))
    append_jsonl_record(_yol(s), {"ts": int(ts), "fiyat": float(price)})
    return 1


# Websocket tamponundaki tick'leri diske yazar; (yazilan, atlanan) doner.
def flush_ticks_to_disk(batch: dict[str, list]) -> tuple[int, int]:
    yazilan = atlanan = 0
    for sembol, tickler in (batch or {}).items():
        for t in tickler:
            try:
                n = buffer_tick(sembol, t["ts"], t["fiyat"])
            except (KeyError, TypeError, ValueError):
                continue
            yazilan += n
            atlanan += (1 - n)
    if atlanan:
        _log.debug("tick yazimi: %d yazildi, %d tekrar atlandi", yazilan, atlanan)
    return yazilan, atlanan


# Bir sembolun tick gecmisini okur.
def read_tick_archive(symbol: str, *, limit: int | None = None) -> list[dict]:
    return list(read_jsonl_records(_yol(symbol), limit=limit))
