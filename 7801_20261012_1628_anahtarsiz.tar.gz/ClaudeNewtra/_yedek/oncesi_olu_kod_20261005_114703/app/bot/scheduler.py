"""Arka plan isleri -- TEK KAYIT DEFTERI.

ESKI SISTEMDEKI HATA: `takipci()` (websocket tabanli 1 saniyelik stop/hedef
takibi) tanimliydi ama `__main__` icinde HICBIR YERDE BASLATILMIYORDU.
Kodun kendi yorumu bunu itiraf ediyor (sunucu.py:3075):

    "KRITIK: takipci() tanimli oldugu halde HICBIR YERDE baslatilmiyordu --
     bu yuzden WS.IZLE hicbir zaman 'canli' olmuyordu ... Ismail'in
     'websocket uzerinden takip edilsin' talebi bu satir eksik oldugu icin
     hic gerceklesmemisti."

Bir is parcaciginin baslatilmasini unutmak SESSIZ bir hatadir: sistem
calisir gorunur, yalnizca o ozellik yoktur. Burada tum isler TEK listede
tanimlanir, `start_all_jobs()` hepsini baslatir ve HANGISININ CALISTIGINI
LOGLAR. `list_running_jobs()` her an disaridan sorulabilir.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable

from app.core.applog import get_logger, log_once
from app.core.timeutil import now_ms

_log = get_logger(__name__)


@dataclass
class Job:
    """Tek bir arka plan isi."""
    name: str
    interval_sn: float
    run: Callable[[], None]
    description: str = ""
    enabled: bool = True
    # calisma anindaki durum
    thread: threading.Thread | None = field(default=None, repr=False)
    last_run_ms: int = 0
    runs: int = 0
    errors: int = 0
    last_error: str | None = None


JOB_REGISTRY: dict[str, Job] = {}
_durdur = threading.Event()


# Is kaydi. Ayni ad iki kez kaydedilemez.
def register_job(name: str, interval_sn: float, run: Callable[[], None],
                 *, description: str = "", enabled: bool = True) -> Job:
    if name in JOB_REGISTRY:
        raise ValueError(f"is zaten kayitli: {name}")
    JOB_REGISTRY[name] = Job(name, interval_sn, run, description, enabled)
    return JOB_REGISTRY[name]


# Tek bir isin dongusu. Hata YUTULMAZ, sayilir ve loglanir.
def run_job_loop(job: Job) -> None:
    while not _durdur.is_set():
        bas = time.time()
        try:
            job.run()
            job.runs += 1
            job.last_run_ms = now_ms()
        except Exception as e:
            job.errors += 1
            job.last_error = f"{type(e).__name__}: {e}"
            log_once(_log, f"job-{job.name}", f"[{job.name}] hata: {e}")
        kalan = job.interval_sn - (time.time() - bas)
        if kalan > 0:
            _durdur.wait(kalan)


# Kayitli TUM isleri baslatir ve hangisinin calistigini loglar.
def start_all_jobs() -> list[str]:
    _durdur.clear()
    baslatilan = []
    for job in JOB_REGISTRY.values():
        if not job.enabled:
            _log.warning("[%s] KAPALI -- baslatilmadi (%s)", job.name, job.description)
            continue
        job.thread = threading.Thread(target=run_job_loop, args=(job,),
                                      daemon=True, name=f"job-{job.name}")
        job.thread.start()
        baslatilan.append(job.name)
        _log.info("[%s] basladi -- her %.0f sn (%s)",
                  job.name, job.interval_sn, job.description)
    _log.info("toplam %d/%d is calisiyor: %s",
              len(baslatilan), len(JOB_REGISTRY), ", ".join(baslatilan))
    eksik = [n for n, j in JOB_REGISTRY.items() if j.enabled and not (j.thread and j.thread.is_alive())]
    if eksik:
        _log.error("BASLATILAMAYAN IS(LER): %s", ", ".join(eksik))
    return baslatilan


# Su an calisan isler ve son tur bilgileri -- saglik ucu bunu doner.
def list_running_jobs() -> list[dict]:
    simdi = now_ms()
    return [{
        "ad": j.name, "aciklama": j.description, "acik": j.enabled,
        "calisiyor": bool(j.thread and j.thread.is_alive()),
        "aralik_sn": j.interval_sn, "tur": j.runs, "hata": j.errors,
        "son_hata": j.last_error,
        "son_tur_sn_once": round((simdi - j.last_run_ms) / 1000, 1) if j.last_run_ms else None,
    } for j in JOB_REGISTRY.values()]


# Tum isleri durdurur (kapanista).
def stop_all_jobs() -> None:
    _durdur.set()
