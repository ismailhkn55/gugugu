"""Ayar semasi -- her anahtarin tipi, varsayilani, etiketi ve ONU OKUYAN modul.

NEDEN SEMA: eski `ayar.json`'da alti anahtar hicbir kod tarafindan
okunmuyordu (`altakip_esik`, `altakip_mesafe`, `altakip_stop`,
`altakip_ema_periyot`, `al_trailing_baslangic`, `bot_tutar`). Kullanici
paneli acip bunlari degistiriyor, hicbir sey olmuyordu -- ustelik ucu POST
beyaz listesindeydi, yani kaydediliyor ama kullanilmiyordu.

Ayrica UC SAYI koda gomuluydu ve ekrandan gorulemiyordu: dinamik ATR carpani,
dinamik mesafe tavani ve ALSAT'in 0.78'lik kilit orani. Onlar da buraya alindi.

Arayuzdeki etiketler de bu semadan uretilir, boylece "ekranda yazan" ile
"gercekte kullanilan" bir daha ayrisamaz.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from app.config.paths import get_settings_path
from app.core.applog import get_logger
from app.core.jsonstore import read_json_file, write_json_file

_log = get_logger(__name__)


@dataclass(frozen=True)
class SettingSpec:
    """Tek bir ayarin tanimi."""
    key: str
    kind: type
    default: Any
    label: str                  # arayuzde gorunen metin
    reader: str                 # bu ayari OKUYAN modul ("-" ise hicbiri)
    minimum: float | None = None
    maximum: float | None = None
    editable: bool = True       # panelden degistirilebilir mi


def _s(key, kind, default, label, reader, **kw) -> SettingSpec:
    return SettingSpec(key, kind, default, label, reader, **kw)


# --------------------------------------------------------------------------
# SEMA. `reader` alani "bu ayari kim okuyor" sorusunun tek dogru cevabidir.
# --------------------------------------------------------------------------
SETTING_SCHEMA: tuple[SettingSpec, ...] = (
    # --- genel / mod ---
    _s("canli", bool, False, "Gercek para modu", "her katman"),
    # 23.09.2026: panel artik emir tutarini CUZDAN BAKIYESINDEN hesapliyor
    # ((serbest USDT - 1 rezerv) x secilen yuzde, bkz. islem.js/tutarHesapla).
    # Bu anahtar YEDEK olarak kaldi: stratejide `tutar` yoksa bot bunu
    # kullanir; ayrica tutar verilmeden gelen API istekleri icin varsayilan.
    # Etiketi gercegi yansitsin diye degistirildi -- "elle islem tutari"
    # yazarken panelde hicbir etkisi olmamasi, duzeltmeye calistigimiz
    # "olu ayar" sinifinin (B6) ta kendisi olurdu.
    _s("tutar", float, 30.0, "Yedek islem tutari (USDT) — strateji/API tutar vermezse",
       "trading.order_service", minimum=0),
    _s("kagit_bakiye", float, 30.0, "Kagit cuzdan ana parasi (USDT)", "trading.wallet", minimum=0),
    _s("komisyon_toplam", float, 0.5, "Gidis-donus komisyon (%)", "trading.wallet", minimum=0),
    _s("emir_asim_dk", int, 6, "Limit emir bu surede dolmazsa iptal (dk)",
       "trading.order_service", minimum=1),

    # --- emir defteri derinligi ---
    _s("al_sira", int, 1, "AL limit fiyati: kacinci alis kademesi", "trading.order_service", minimum=1),
    _s("sat_sira", int, 2, "SAT limit fiyati: kacinci satis kademesi", "trading.order_service", minimum=1),
    _s("alsat_sira", int, 1, "ALSAT limit kademesi", "trading.order_service", minimum=1),

    # --- BOT girisinde kullanilan baslangic degerleri ---
    _s("kar_al", float, 1.6, "Bot girisinde baslangic kar hedefi (%)", "trading.order_service"),
    _s("stop", float, 3.0, "Bot girisinde baslangic stop (%)", "trading.order_service"),

    # --- bot calismasi ---
    _s("bot_acik", bool, False, "Bot calisiyor mu", "bot.trade_loop"),
    _s("bot_canli", bool, False, "Bot gercek para ile mi", "bot.trade_loop"),
    _s("bot_bekleme_sn", int, 10, "Pozisyon kapandiktan sonra nefes payi (sn)",
       "bot.trade_loop", minimum=0),
    _s("coin_bekleme_dk", int, 1, "Ayni coin tekrar alinamaz suresi (dk)",
       "bot.trade_loop", minimum=0),
    _s("pozisyon_haric", list, ["BNB"], "Uzlastirmada pozisyon sayilmayan varliklar",
       "trading.reconcile"),

    # --- AL butonu cikis geometrisi ---
    _s("al_stop", float, 8.0, "AL: baslangic stop (%)", "trading.exit_rules"),
    _s("al_kilit2_esik", float, 1.2, "AL: 1. merdiven esigi (%)", "trading.exit_rules"),
    _s("al_kilit2_yuzde", float, 0.7, "AL: 1. merdiven kilidi (%)", "trading.exit_rules"),
    _s("al_kilit3_esik", float, 3.0, "AL: 2. merdiven esigi (%)", "trading.exit_rules"),
    _s("al_kilit3_yuzde", float, 2.0, "AL: 2. merdiven kilidi (%)", "trading.exit_rules"),
    _s("al_dinamik_esik", float, 7.0, "AL: dinamik takip bu kardan sonra (%)", "trading.exit_rules"),
    _s("al_trailing_mesafe", float, 2.0, "AL: takip mesafesi tabani (%)", "trading.exit_rules"),

    # --- BOT / AL TAKIP cikis geometrisi (ikisi AYNI plani kullanir) ---
    _s("bot_cikis_stop", float, 6.0, "BOT/AL TAKIP: baslangic stop (%)", "trading.exit_rules"),
    _s("bot_cikis_merdiven_esik", float, 2.0, "BOT/AL TAKIP: merdiven esigi (%)", "trading.exit_rules"),
    _s("bot_cikis_merdiven_kilit", float, 0.8, "BOT/AL TAKIP: merdiven kilidi (%)", "trading.exit_rules"),
    _s("bot_cikis_esik", float, 5.0, "BOT/AL TAKIP: dinamik takip esigi (%)", "trading.exit_rules"),
    _s("bot_cikis_mesafe", float, 1.4, "BOT/AL TAKIP: takip mesafesi tabani (%)", "trading.exit_rules"),
    _s("bot_cikis_ivme_acik", bool, True, "Ivme genislemesi acik mi", "trading.exit_rules"),
    _s("bot_cikis_ivme_carpan", float, 3.0, "Ivme: takip mesafesi carpani", "trading.exit_rules"),
    _s("bot_cikis_ivme_esik", float, 1.0, "Ivme: deg5m esigi (%)", "trading.exit_rules"),
    _s("bot_cikis_ivme_hacim", float, 3.0, "Ivme: hacim_x esigi", "trading.exit_rules"),

    # --- ALSAT butonlari ---
    _s("alsat_hedef_1", float, 0.8, "ALSAT 1: sabit hedef (%)", "trading.exit_rules"),
    _s("alsat_hedef_2", float, 1.2, "ALSAT 2: sabit hedef (%)", "trading.exit_rules"),
    _s("alsat_hedef_3", float, 1.8, "ALSAT 3: sabit hedef (%)", "trading.exit_rules"),
    _s("alsat_stop", float, 1.0, "ALSAT: baslangic stop (%)", "trading.exit_rules"),

    # --- 23.09.2026: eskiden KODA GOMULU olan, ekrandan gorulemeyen sayilar ---
    _s("dinamik_atr_carpan", float, 1.2, "Dinamik takip: ATR carpani",
       "trading.exit_rules"),
    _s("dinamik_mesafe_tavan", float, 4.0, "Dinamik takip: mesafe tavani (%)",
       "trading.exit_rules"),
    _s("dinamik_mesafe_taban_min", float, 0.6, "Dinamik takip: mesafe alt siniri (%)",
       "trading.exit_rules"),
    _s("alsat_kilit_orani", float, 0.78, "ALSAT: kilit = hedef x bu oran",
       "trading.exit_rules", minimum=0, maximum=1),

    # --- arayuz grafik tercihleri ---
    _s("ust_tf", str, "1h", "Ust grafik zaman dilimi", "web.static"),
    _s("ust_mum", int, 20, "Ust grafik mum sayisi", "web.static"),
    _s("alt_tf", str, "4h", "Alt grafik zaman dilimi", "web.static"),
    _s("alt_mum", int, 20, "Alt grafik mum sayisi", "web.static"),
    # 26.09.2026, Ismail: "switch acikken limit cizgimiz mumun %0.4'ten fazla
    # ustune cikmasin; ayarlara ekle, ne kadar yukari cikabilecegini yazayim".
    _s("limit_ust_yuzde", float, 0.4,
       "LIMIT cizgisi anlik fiyatin en fazla bu kadar USTUNE cikabilir (%)",
       "web.static", minimum=0),
    _s("gun_tf", str, "5m", "Gun grafigi zaman dilimi", "web.static"),
    _s("gun_mum", int, 20, "Gun grafigi mum sayisi", "web.static"),
    _s("dort_tf", str, "1d", "Dorduncu grafik zaman dilimi", "web.static"),
    _s("dort_mum", int, 20, "Dorduncu grafik mum sayisi", "web.static"),

    # --- telegram ---
    # YAPAY ZEKA MIMO (24.09.2026): gunluk arsiv ayari semaya eklendi.
    # Derin inceleme yuksek oncelik #3: append_daily_snapshot hic cagrilmıyor
    # ve bu anahtar semada olmadigi icin /yerel/isabet daima "arsiv bos" idi.
    _s("gunluk_arsiv_acik", bool, False, "Gunluk mum arsivini yaz (isabet olcumu icin)",
       "reporting.daily_archive"),
    # --- YAPAY ZEKA MIMO (24.09.2026): HEATMAP sayfasi ---
    _s("heatmap_cci_acik", bool, False, "HEATMAP: CCI (5dk onceki) filtresi varsayilan",
       "web.heatmap"),
    _s("heatmap_siralama", str, "deg24", "HEATMAP: siralama (deg24|deg5m|deg1h|hacim)",
       "web.heatmap"),
    _s("heatmap_btc_eth", bool, True, "HEATMAP: BTC/ETH karolarini goster", "web.heatmap"),
    _s("telegram_token", str, "", "Telegram bot token", "notify.telegram_client", editable=True),
    _s("telegram_chat", str, "", "Yetkili Telegram chat kimligi",
       "notify.telegram_commands", editable=True),

    # --- 27.09.2026, Ismail: ISLEM grafiginde BOT/CUZDAN/STRATEJI
    # isaretlerinin renkleri -- silmeden ac/kapa yerine dogrudan renk
    # degistirilebilsin. Guvenli web rengi (00/33/66/99/CC/FF bilesenli). ---
    _s("renk_bot_giris", str, "#FF9900",
       "Grafikte BOT'un gercekten girdigi noktalarin rengi", "web.static"),
    _s("renk_cuzdan_giris", str, "#FFCC00",
       "Grafikte cuzdan/el (AL/AL TAKIP/ALSAT) girisi noktalarin rengi", "web.static"),
    _s("renk_strateji_sinyal", str, "#3399CC",
       "Grafikte stratejinin GIRECEGI (hipotez) ucgenin rengi", "web.static"),

    # 29.09.2026, Ismail: CHCM (coklu borsa hacim) -- hacim barinda her
    # borsanin kendi rengi. Guvenli web rengi (00/33/66/99/CC/FF bilesenli),
    # mevcut renklerle (--arti/--eksi/renk_bot_giris/...) CAKISMAYAN 5 ton.
    _s("renk_hacim_binance", str, "#CC9900",
       "Coklu borsa hacim barinda Binance dilimi rengi", "web.static"),
    _s("renk_hacim_bybit", str, "#FF6600",
       "Coklu borsa hacim barinda Bybit dilimi rengi", "web.static"),
    _s("renk_hacim_okx", str, "#6699FF",
       "Coklu borsa hacim barinda OKX dilimi rengi", "web.static"),
    _s("renk_hacim_mexc", str, "#9933CC",
       "Coklu borsa hacim barinda MEXC dilimi rengi", "web.static"),
    _s("renk_hacim_gate", str, "#00CCCC",
       "Coklu borsa hacim barinda Gate.io dilimi rengi", "web.static"),
)

_INDEX: dict[str, SettingSpec] = {s.key: s for s in SETTING_SCHEMA}

# Eski ayar.json'da bulunan ama HICBIR kodun okumadigi anahtarlar.
# Silinmiyorlar (dosyada duruyorlar) ama acilista uyari veriliyor ve
# panelde "kullanilmiyor" diye isaretleniyorlar.
DEAD_SETTINGS: tuple[str, ...] = (
    "al_trailing_baslangic",     # kodda sifir eslesme
    "altakip_ema_periyot",       # 22.09'da EMA dokunus kurali kaldirildi, ayar kaldi
    "altakip_esik",              # AL TAKIP artik bot_cikis_* kullaniyor
    "altakip_mesafe",
    "altakip_stop",
    "bot_tutar",                 # bot tutari stratejiden geliyor
)


# Bilinen ayar anahtarlari.
def list_setting_keys() -> tuple[str, ...]:
    return tuple(_INDEX)


# Bir ayarin tanimi (tip, varsayilan, etiket, okuyan modul).
def describe_setting(key: str) -> SettingSpec | None:
    return _INDEX.get(key)


# Hicbir modulun okumadigi ayarlar -- acilista loglanir, panelde isaretlenir.
def list_orphan_settings(data: dict | None = None) -> list[str]:
    data = load_settings() if data is None else data
    return sorted(k for k in data if k in DEAD_SETTINGS or k not in _INDEX)


def _coerce(spec: SettingSpec, value: Any) -> Any:
    """Degeri semadaki tipe cevirir; ceviremezse varsayilana duser."""
    try:
        if spec.kind is bool:
            v = value if isinstance(value, bool) else str(value).lower() in ("1", "true", "evet")
        elif spec.kind is list:
            v = list(value) if isinstance(value, (list, tuple)) else spec.default
        elif spec.kind is str:
            v = str(value)
        else:
            v = spec.kind(value)
    except (TypeError, ValueError):
        _log.warning("ayar %s: %r semaya uymuyor, varsayilan kullanildi", spec.key, value)
        return spec.default
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if spec.minimum is not None and v < spec.minimum:
            v = spec.minimum
        if spec.maximum is not None and v > spec.maximum:
            v = spec.maximum
    return v


# ayar.json'u semaya gore okur; eksikleri varsayilanla doldurur,
# bilinmeyen anahtarlari OLDUGU GIBI korur (veri kaybi olmasin).
def load_settings() -> dict:
    ham = read_json_file(get_settings_path(), {})
    if not isinstance(ham, dict):
        ham = {}
    sonuc = dict(ham)
    for spec in SETTING_SCHEMA:
        sonuc[spec.key] = _coerce(spec, ham[spec.key]) if spec.key in ham else spec.default
    return sonuc


# Ayarlari atomik yazar. Yalnizca semadaki DEGISTIRILEBILIR anahtarlar
# guncellenir; bilinmeyen anahtar sessizce yazilmaz, reddedilir.
def save_settings(updates: dict) -> tuple[dict, list[str]]:
    mevcut = load_settings()
    reddedilen: list[str] = []
    for k, v in (updates or {}).items():
        spec = _INDEX.get(k)
        if spec is None or not spec.editable:
            reddedilen.append(k)
            continue
        mevcut[k] = _coerce(spec, v)
    # YAPAY ZEKA MIMO (24.09.2026): olu/semadisi anahtarlari dosyadan TEMIZLE.
    # Derin inceleme: list_orphan_settings 6 anahtar gosteriyordu ama save_settings
    # onlari silmiyordu -- her acilista "hicbir modulun okumadigi ayar" uyarisi.
    oluler = [k for k in list(mevcut) if k not in _INDEX or k in DEAD_SETTINGS]
    for k in oluler:
        mevcut.pop(k, None)
    if oluler:
        _log.info("olu ayarlar dosyadan temizlendi (YAPAY ZEKA MIMO): %s",
                  ", ".join(oluler))
    write_json_file(get_settings_path(), mevcut)
    if reddedilen:
        _log.warning("bilinmeyen/degistirilemez ayar reddedildi: %s", ", ".join(reddedilen))
    return mevcut, reddedilen


# Gercek para modu acik mi.
def is_live_trading_enabled(data: dict | None = None) -> bool:
    return bool((data if data is not None else load_settings()).get("canli"))


# Cikis geometrisini tek sozlukte toplar -- exit_rules'in tek girdisi.
def get_exit_geometry(data: dict | None = None) -> dict:
    a = data if data is not None else load_settings()
    return {k: a.get(k, _INDEX[k].default) for k in _INDEX
            if k.startswith(("al_", "alsat_", "bot_cikis_", "dinamik_"))}


# ALSAT hedefleri buton numarasina gore artan mi? Degilse UYARIR ama
# degeri DEGISTIRMEZ -- sessizce yeniden siralamak islem davranisini degistirir.
def check_scalp_target_order(data: dict | None = None) -> str | None:
    a = data if data is not None else load_settings()
    h = [a.get(f"alsat_hedef_{i}") for i in (1, 2, 3)]
    if all(isinstance(x, (int, float)) for x in h) and not (h[0] <= h[1] <= h[2]):
        return (f"ALSAT hedefleri artan sirada degil: 1={h[0]} 2={h[1]} 3={h[2]}. "
                "Buton numarasi ile hedef buyuklugu ortusmuyor.")
    return None
