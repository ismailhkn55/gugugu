"""Zaman yardimcilari. Tum zaman damgalari epoch MILISANIYE."""
import time

MS = 1000
DAKIKA_MS = 60 * MS
SAAT_MS = 60 * DAKIKA_MS
GUN_MS = 24 * SAAT_MS


# Simdiki zaman, epoch milisaniye.
def now_ms() -> int:
    return int(time.time() * MS)


# Verilen anin icinde bulundugu UTC gununun acilis zamani.
def utc_day_start_ms(ts_ms: int | None = None) -> int:
    ts_ms = now_ms() if ts_ms is None else ts_ms
    return ts_ms - (ts_ms % GUN_MS)


# Zamani sabit bir kilavuza oturtur (rank toplayicisi 5 dakikalik kilavuz kullanir).
def align_to_bucket_ms(ts_ms: int, bucket_ms: int = 5 * DAKIKA_MS) -> int:
    return ts_ms - (ts_ms % bucket_ms)


# Sureyi "2s 14dk" gibi okunur yazar.
def format_duration(ms: int) -> str:
    if ms < 0:
        return "-"
    sn = ms // MS
    if sn < 60:
        return f"{sn}sn"
    dk, sn = divmod(sn, 60)
    if dk < 60:
        return f"{dk}dk" if sn == 0 else f"{dk}dk {sn}sn"
    saat, dk = divmod(dk, 60)
    if saat < 24:
        return f"{saat}s" if dk == 0 else f"{saat}s {dk}dk"
    gun, saat = divmod(saat, 24)
    return f"{gun}g" if saat == 0 else f"{gun}g {saat}s"
