"""Islem ozeti ve gunun kari."""
from __future__ import annotations

import datetime

from app.trading.ledger import list_closed_orders
from app.trading.wallet import compute_ledger_stats


# Islem ozeti -- `wallet.compute_ledger_stats`'i disariya acan ince katman.
def summarize_trades(live: bool) -> dict:
    return compute_ledger_stats(live)


# Bugun (UTC) gerceklesmis kar yuzdesi toplami.   (eski: _gunun_kari)
def compute_today_profit(live: bool) -> float:
    bugun = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%d")
    toplam = 0.0
    for e in list_closed_orders(live):
        ts = (e.get("kapanis") or {}).get("ts")
        if not ts:
            continue
        g = datetime.datetime.fromtimestamp(ts / 1000, datetime.UTC).strftime("%Y-%m-%d")
        if g == bugun:
            toplam += float(e.get("kar_p") or 0)
    return round(toplam, 3)
