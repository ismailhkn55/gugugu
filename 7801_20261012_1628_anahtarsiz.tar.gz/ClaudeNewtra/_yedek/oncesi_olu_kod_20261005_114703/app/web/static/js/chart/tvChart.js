// chart/tvChart.js -- TRADE ana grafigi: TradingView Lightweight Charts 4.2.0.
//
// 03.10.2026, Ismail: "trade ekranindaki paneli TradingView'in chart'i ile
// degistirelim artik". Kutuphane yerel dosyadan yuklenir
// (js/vendor/lightweight-charts-4.2.0.js, index.html <script>), internete
// bagli DEGIL. Eski SVG cizici (renderer.js) SILINMEDI: TV dugmesi kapatilinca
// ona donulur.
//
// Gosterilenler: mum (HA dugmesi dahil), hacim, EMA 7/20/48/99, BB 20/2,
// VWAP, strateji noktasi + sonuca gore DIKEY cizgi (yesil = once +%2,
// kirmizi = once -%2, turkuaz = belli degil), gercek islem izleri (ok),
// STOP / HEDEF / GIRIS / LIMIT fiyat cizgileri.
// Saat: grafik ekseni BINANCE saati (UTC) -- 05.10.2026 (once TR +3 idi).
import { ema, bollinger, vwap, heikinAshi } from "./indicators.js";

// 05.10.2026, Ismail: "saatleri esitle" -- eksen BINANCE saati (UTC). Mumlar UTC'ye gore
// acilir; TR saati (+3) kullanilinca 4h TM serit sinirlari (UTC 00/04/08) eksende 03/07/11
// gorunuyor, gece 00:00'a denk gelmiyordu. Artik eksen = Binance = 00/04/08... sinirlari.
const TR_SN = 0;
const EMA_DONEM = [7, 20, 48, 99];
const EMA_RENK = ["#FFCC00", "#33CCCC", "#9999FF", "#FF9933"];
let _grafik = null;
let _kap = null;
let _ser = null;
let _fiyatCizgileri = [];
let _izgara = [];          // %1 yatay cizgileri (createPriceLine)
let _izgaraAnahtar = "";
let _sonUzunluk = 0;
let _sonZaman = 0;
let _hacimAcik = false;
let _dikeyler = [];        // [{time, renk}] -- strateji dikey cizgileri (ust katman)
let _dikeyKat = null;
// 04.10.2026, Ismail: "TradingView'de de TM butonunun gorselini yapamiyor muyuz" --
// 1 saatlik arka plan bantlari + 4 saatlik ust serit (eski SVG grafikteki gibi),
// grafigin USTUNDE ayri katman; x konumu zaman ekseninden.
let _zamanKat = null;
let _tmMumlar = [];        // TM aciksa ham 5m mumlar (HA donusumsuz), yoksa []
// 03.10.2026, Ismail: "aldiktan sonra stop'u her coin icin ekranda kaydirarak belirlemek istiyorum"
let _stopCizgi = null;     // STOP fiyat cizgisi (createPriceLine) -- surukleniyor
let _stopFiyat = null;
let _girisFiyat = null;
let _stopIslev = null;     // (yeniFiyat, eskiFiyat) => birakilinca cagrilir (islem.js)
let _surukle = null;       // {tur:"stop"|"limit", fiyat} -- surukleme suruyor
// 04.10.2026, Ismail: "limit cizgisi ignenin ucunda, asagi inmiyor" -- TV grafiginde LIMIT
// cizgisi de suruklenir (LIMIT anahtari aciksa). Birakinca islem.js limit fiyatini yazar.
let _limitCizgi = null;
let _limitFiyat = null;
let _limitIslev = null;    // HCM kapaliyken bos hacim serisine tik yazilmaz         // grafikteki son mumun zamani (ms) -- geriye giden veri korumasi

const zaman = (ms) => Math.floor(ms / 1000) + TR_SN;
const css = (ad, yedek) =>
  getComputedStyle(document.documentElement).getPropertyValue(ad).trim() || yedek;

// Kutuphane yuklu mu (yerel <script> yuklenemediyse eski grafige donulur).
export function isTvChartAvailable() {
  return typeof window.LightweightCharts?.createChart === "function";
}

// Grafigi kutunun icine kurar (bir kez). Kutudaki SVG cizimi temizlenir.
export function mountTvChart(kutuId) {
  const kap = document.getElementById(kutuId);
  if (!kap || !isTvChartAvailable()) return false;
  // tema ya da TV modu degisince renk/yazi boyu yeniden okunsun diye grafik yeniden kurulur
  const tema = (document.documentElement.dataset.tema || "") + "|" + (document.documentElement.dataset.cihaz || "");
  if (_grafik && _kap === kap && kap.contains(_grafik._tvKutu) && _grafik._tema === tema) return true;
  unmountTvChart();
  kap.replaceChildren();
  const ic = document.createElement("div");
  ic.className = "tvGrafik";
  kap.appendChild(ic);
  const L = window.LightweightCharts;
  const metin = css("--metin-sonuk", "#5d7d8a");
  const izgara = css("--izgara-sik", "#0b2028");
  _grafik = L.createChart(ic, {
    autoSize: true,
    layout: { background: { type: "solid", color: "transparent" }, textColor: metin,
              fontFamily: "Share Tech Mono, DejaVu Sans Mono, monospace",
              fontSize: document.documentElement.dataset.cihaz === "tv" ? 14 : 11 },
    // 03.10.2026, Ismail: "yatay cizgiler yuzde 1 olacak, KESINLIKLE" -- kutuphanenin
    // kendi yatay izgarasi (yuvarlak fiyat adimlari) KAPALI; yerine %1 cizgileri.
    grid: { vertLines: { color: izgara }, horzLines: { visible: false } },
    rightPriceScale: { borderColor: izgara, scaleMargins: { top: 0.06, bottom: 0.22 } },
    timeScale: { borderColor: izgara, timeVisible: true, secondsVisible: false,
                 rightOffset: 3, barSpacing: 6 },
    crosshair: { mode: L.CrosshairMode.Normal },
    localization: { priceFormatter: (p) => fiyatYaz(p) },
  });
  _grafik._tvKutu = ic;
  _grafik._tema = tema;
  const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
  _ser = {
    hacim: _grafik.addHistogramSeries({ priceScaleId: "hacim", priceFormat: { type: "volume" },
                                        priceLineVisible: false, lastValueVisible: false }),
    mum: _grafik.addCandlestickSeries({ upColor: arti, downColor: eksi, borderUpColor: arti,
                                        borderDownColor: eksi, wickUpColor: arti, wickDownColor: eksi }),
    ema: EMA_RENK.map((r) => _grafik.addLineSeries({ color: r, lineWidth: 1, priceLineVisible: false,
                                                     lastValueVisible: false, crosshairMarkerVisible: false })),
    bb: ["#6699CC", "#6699CC", "#6699CC"].map((r, i) => _grafik.addLineSeries({
      color: r, lineWidth: 1, lineStyle: i === 1 ? 2 : 0, priceLineVisible: false,
      lastValueVisible: false, crosshairMarkerVisible: false })),
    vwap: _grafik.addLineSeries({ color: "#CC99FF", lineWidth: 1, priceLineVisible: false,
                                  lastValueVisible: false, crosshairMarkerVisible: false }),
  };
  // 03.10.2026: dikey sinyal cizgileri ESKIDEN tam boy histogram serisiydi; canli mum
  // guncellemeleriyle birlikte kutuphane ara sira "Value is null" atip kareyi (saat
  // ekseni dahil) cizmiyordu (STRATEJI kapali -> 0 hata, dikey seri kapali -> 0 hata).
  // Artik grafigin USTUNDE ayri bir katman; x konumu zaman ekseninden okunur.
  _zamanKat = document.createElement("div");
  _zamanKat.className = "tvZamanKat";
  ic.appendChild(_zamanKat);
  _dikeyKat = document.createElement("div");
  _dikeyKat.className = "tvDikeyKat";
  ic.appendChild(_dikeyKat);
  _grafik.timeScale().subscribeVisibleLogicalRangeChange(ustKatmanlariKonumla);
  _grafik._gozlemci = new ResizeObserver(() => requestAnimationFrame(ustKatmanlariKonumla));
  _grafik._gozlemci.observe(ic);
  _grafik.priceScale("hacim").applyOptions({ visible: false, scaleMargins: { top: 0.82, bottom: 0 } });
  _kap = kap;
  _sonUzunluk = 0;
  stopSuruklemeKur(ic);
  return true;
}

// STOP cizgisini surukle-birak. Fare VE dokunma. Olaylar grafik kutusunda YAKALAMA
// asamasinda tutulur -- cizgi tutulunca grafik kaymaz (olay kutuphaneye inmez).
export function setTvStopDragHandler(fn) { _stopIslev = fn; }
export function setTvLimitDragHandler(fn) { _limitIslev = fn; }
// Fiyatin grafik kutusundaki y konumu (piksel) -- sinama/yardimci.
export function tvPriceToY(p) { return _ser ? _ser.mum.priceToCoordinate(+p) : null; }
// 04.10.2026, Ismail: "stop yazisinin yaninda degeri de yazsin" -> STOP fiyat (girise gore %).
function stopEtiketi(p) {
  return `STOP ${fiyatYaz(p)}` + (_girisFiyat ? ` (${((p / _girisFiyat - 1) * 100).toFixed(2)}%)` : "");
}
function stopSuruklemeKur(ic) {
  const yOf = (ev) => {
    const t = ev.touches ? ev.touches[0] || ev.changedTouches[0] : ev;
    return t.clientY - ic.getBoundingClientRect().top;
  };
  // y'ye en yakin suruklenebilir cizgi: "stop" | "limit" | null
  const yakin = (y) => {
    if (!_ser) return null;
    const pay = document.documentElement.dataset.cihaz === "tv" ? 14 : (ic.clientWidth < 600 ? 16 : 8);
    let en = null, enMesafe = pay + 1;
    for (const [tur, cz, f, fn] of [["stop", _stopCizgi, _stopFiyat, _stopIslev],
                                    ["limit", _limitCizgi, _limitFiyat, _limitIslev]]) {
      if (!fn || !cz || f == null) continue;
      const ly = _ser.mum.priceToCoordinate(f);
      if (ly != null && Math.abs(y - ly) < enMesafe) { en = tur; enMesafe = Math.abs(y - ly); }
    }
    return en;
  };
  const bas = (ev) => {
    const tur = yakin(yOf(ev));
    if (!tur) return;
    ev.stopPropagation(); ev.preventDefault();
    _surukle = { tur, fiyat: tur === "stop" ? _stopFiyat : _limitFiyat };
  };
  const hareket = (ev) => {
    if (!_surukle) {
      if (!ev.touches) ic.style.cursor = yakin(yOf(ev)) ? "ns-resize" : "";
      return;
    }
    ev.stopPropagation(); ev.preventDefault();
    const p = _ser?.mum.coordinateToPrice(yOf(ev));
    if (p == null || !(p > 0)) return;
    _surukle.fiyat = p;
    if (_surukle.tur === "stop") _stopCizgi?.applyOptions({ price: p, title: stopEtiketi(p) });
    else _limitCizgi?.applyOptions({ price: p, title: `LIMIT ${fiyatYaz(p)}` });
  };
  const bit = (ev) => {
    if (!_surukle) return;
    ev.stopPropagation();
    const s = _surukle; _surukle = null;
    if (s.tur === "limit") { _limitIslev?.(s.fiyat); return; }
    if (_stopFiyat && Math.abs(s.fiyat / _stopFiyat - 1) > 1e-6) _stopIslev?.(s.fiyat, _stopFiyat);
  };
  ic.addEventListener("mousedown", bas, true);
  ic.addEventListener("touchstart", bas, { capture: true, passive: false });
  ic.addEventListener("mousemove", hareket, true);
  ic.addEventListener("touchmove", hareket, { capture: true, passive: false });
  ic.addEventListener("mouseup", bit, true);
  ic.addEventListener("mouseleave", bit, true);
  ic.addEventListener("touchend", bit, true);
}

// Grafigi kaldirir (eski SVG grafige donus).
export function unmountTvChart() {
  if (_grafik) {
    try { _grafik._gozlemci?.disconnect(); _grafik.remove(); } catch { /* zaten kaldirilmis */ }
  }
  _grafik = null; _ser = null; _fiyatCizgileri = []; _kap = null; _sonUzunluk = 0;
  _izgara = []; _izgaraAnahtar = ""; _sonZaman = 0; _dikeyler = []; _dikeyKat = null;
  _stopCizgi = null; _stopFiyat = null; _surukle = null; _zamanKat = null; _tmMumlar = [];
  _limitCizgi = null; _limitFiyat = null;
}

export const isTvChartMounted = () => !!_grafik;

function fiyatYaz(p) {
  if (p == null || !isFinite(p)) return "";
  const a = Math.abs(p);
  return p.toFixed(a >= 100 ? 2 : a >= 1 ? 4 : a >= 0.01 ? 5 : 8);
}

const cizgiVerisi = (mumlar, dizi) => {
  const v = [];
  for (let i = 0; i < mumlar.length; i++) {
    if (dizi[i] != null && isFinite(dizi[i])) v.push({ time: zaman(mumlar[i].t), value: dizi[i] });
  }
  return v;
};

// Tam cizim. `o`: {gosterge, sinyaller, sinyalRenk, izler, fiyatCizgileri:[{fiyat, ad, renk}]}
export function drawTvChart(mumlar, o = {}) {
  if (!_grafik || !mumlar?.length) return;
  const g = o.gosterge || {};
  const veri = g.ha ? heikinAshi(mumlar) : mumlar;
  const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
  const ilkCizim = _sonUzunluk === 0;
  // 03.10.2026: mum kapanisinda websocket yeni mumu ekledikten SONRA 30 sn'lik
  // yenileme o mumu icermeyen liste getirirse seri GERIYE gidiyordu; kutuphane
  // ara sira "Value is null" (olmayan mumu renklendirme) atiyordu. Geriye gidiste
  // seriler once bosaltilir.
  if (mumlar.at(-1).t < _sonZaman) {
    _ser.mum.setMarkers([]);
    for (const x of [_ser.mum, _ser.hacim]) x.setData([]);
  }
  _ser.mum.setData(veri.map((m) => ({ time: zaman(m.t), open: m.a, high: m.y, low: m.d, close: m.k })));
  _hacimAcik = !!g.hacim;
  _ser.hacim.setData(!g.hacim ? [] : mumlar.map((m, i) => ({
    time: zaman(m.t), value: m.h || 0,
    color: (veri[i].k >= veri[i].a ? arti : eksi) + "66" })));
  const kapanis = mumlar.map((m) => m.k);
  _ser.ema.forEach((s, i) => s.setData(g.ema ? cizgiVerisi(mumlar, ema(kapanis, EMA_DONEM[i])) : []));
  const b = g.bb ? bollinger(kapanis, 20, 2) : null;
  [["ust"], ["orta"], ["alt"]].forEach(([ad], i) => _ser.bb[i].setData(b ? cizgiVerisi(mumlar, b[ad]) : []));
  _ser.vwap.setData(g.vwap ? cizgiVerisi(mumlar, vwap(mumlar)) : []);

  // --- strateji noktalari + dikey cizgi, gercek islem izleri ---
  const bulBar = (ts) => {      // ts'ye denk gelen (>=) ilk mumun zamani
    for (const m of mumlar) if (m.t >= ts) return zaman(m.t);
    return null;
  };
  const isaret = [];
  const dikey = [];
  for (const n of o.sinyaller || []) {
    const t = bulBar(n.ts);
    if (t == null) continue;
    const renk = n.sonuc === "hedef" ? "#33CC33" : n.sonuc === "stop" ? "#FF3333" : "#00CCCC";
    dikey.push({ time: t, renk });
    isaret.push({ time: t, position: "inBar", shape: "circle", color: o.sinyalRenk || "#29FF42", size: 0.6 });
  }
  for (const iz of o.izler || []) {
    const t = bulBar(iz.ts);
    if (t == null) continue;
    const giris = iz.tur !== "cikis";
    isaret.push({ time: t, position: giris ? "belowBar" : "aboveBar", shape: giris ? "arrowUp" : "arrowDown",
                  color: iz.renk || (giris ? "#FF9900" : "#FFCC00"), size: 1 });
  }
  const tekil = new Map();
  for (const d of dikey) tekil.set(d.time, d);
  _dikeyler = [...tekil.values()];
  _tmMumlar = g.tm ? mumlar : [];
  ustKatmanlariKonumla();
  _ser.mum.setMarkers(isaret.sort((a, b) => a.time - b.time));

  // --- fiyat cizgileri (STOP / HEDEF / GIRIS / LIMIT) ---
  // Surukleme surerken cizgiler yeniden KURULMAZ (30 sn yenilemesi elden almasin).
  if (!_surukle) {
    for (const c of _fiyatCizgileri) _ser.mum.removePriceLine(c);
    const liste = (o.fiyatCizgileri || []).filter((c) => c.fiyat != null && isFinite(c.fiyat));
    _girisFiyat = +(liste.find((c) => c.ad === "GIRIS")?.fiyat) || null;
    _stopCizgi = null; _stopFiyat = null; _limitCizgi = null; _limitFiyat = null;
    _fiyatCizgileri = liste.map((c) => {
      const stop = c.ad === "STOP" && c.suruklenebilir;
      if (c.ad === "LIMIT") {
        const lz = _ser.mum.createPriceLine({ price: +c.fiyat, color: c.renk, lineWidth: 2, lineStyle: 0,
                                              axisLabelVisible: true, title: `LIMIT ${fiyatYaz(+c.fiyat)}` });
        _limitCizgi = lz; _limitFiyat = +c.fiyat;
        return lz;
      }
      const cz = _ser.mum.createPriceLine({ price: +c.fiyat, color: c.renk, lineWidth: stop ? 2 : 1,
                                            lineStyle: stop ? 0 : 2, axisLabelVisible: true,
                                            title: c.ad === "STOP" ? stopEtiketi(+c.fiyat) : c.ad });
      if (stop) { _stopCizgi = cz; _stopFiyat = +c.fiyat; }
      return cz;
    });
  }
  yuzdeIzgarasiCiz(veri);
  if (ilkCizim) showRecentTvCandles(120, mumlar.length);
  _sonUzunluk = mumlar.length;
  _sonZaman = mumlar.at(-1).t;
}

// "#RRGGBB" -> "rgba(r,g,b,0.5)" (cizgi yari yariya soluk).
function yariSoluk(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex.trim());
  return m ? `rgba(${parseInt(m[1], 16)},${parseInt(m[2], 16)},${parseInt(m[3], 16)},0.5)` : hex;
}

// %1 IZGARASI: her yatay cizgi bir oncekinin TAM 1.01 kati (carpimsal -- eski
// grafikteki gibi; sabit adim grafigin altinda %1'den buyuk, ustunde kucuk olurdu).
// Seviyeler 1.01^k -- coin ve zoom degisse de AYNI fiyatlarda. Adim HIC buyumez.
// Yuklenen mumlarin tum araligi kapsanir; gorunmeyenler zaten cizilmez.
function yuzdeIzgarasiCiz(veri) {
  let az = Infinity, en = -Infinity;
  for (const m of veri) { if (m.d < az) az = m.d; if (m.y > en) en = m.y; }
  if (!(az > 0) || !(en > az)) return;
  const K = 1.01;
  const k0 = Math.floor(Math.log(az / K) / Math.log(K)), k1 = Math.ceil(Math.log(en * K) / Math.log(K));
  const anahtar = `${k0}:${k1}:${css("--izgara-cizgi", "")}`;
  if (anahtar === _izgaraAnahtar && _izgara.length) return;
  for (const c of _izgara) _ser.mum.removePriceLine(c);
  // 04.10.2026, Ismail: "trading view'de yatay cizgileri yuzde 50 soluklastir"
  const renk = yariSoluk(css("--izgara-cizgi", "#1d4352"));
  // TV modu: TV 1920x1080'i 4K'ya 2 kat buyutuyor; 1px cizgi yumusuyor, 2px net kalir.
  const kalin = document.documentElement.dataset.cihaz === "tv" ? 2 : 1;
  _izgara = [];
  for (let k = k0; k <= k1 && _izgara.length < 400; k++) {
    _izgara.push(_ser.mum.createPriceLine({ price: Math.pow(K, k), color: renk, lineWidth: kalin,
                                            lineStyle: 0, axisLabelVisible: false, title: "" }));
  }
  _izgaraAnahtar = anahtar;
}

function ustKatmanlariKonumla() { dikeyleriKonumla(); zamanBantlariniKonumla(); }

// TM: mumlari GERCEK saat sinirina oturan gruplara ayirir (son/canli mum haric,
// en yeni dilim tek mumluksa atlanir) -- renderer.periyotGruplariniBul ile AYNI kural.
function periyotGruplari(mumlar, periyotMs) {
  const kapaliSon = mumlar.length - 2;
  if (kapaliSon < 0) return [];
  const gruplar = [];
  let bas = 0, kova = Math.floor(mumlar[0].t / periyotMs);
  for (let i = 1; i <= kapaliSon; i++) {
    const k = Math.floor(mumlar[i].t / periyotMs);
    if (k !== kova) { gruplar.push([bas, i - 1, kova]); bas = i; kova = k; }
  }
  gruplar.push([bas, kapaliSon, kova]);
  const son = gruplar[gruplar.length - 1];
  if (son[1] - son[0] + 1 < 2) gruplar.pop();
  return gruplar.map(([ilk, sn, k]) => ({ ilk, son: sn, kova: k,
    yesil: mumlar[sn].k >= mumlar[ilk].a }));
}
function zamanBantlariniKonumla() {
  if (!_grafik || !_zamanKat) return;
  if (!_tmMumlar.length) { _zamanKat.replaceChildren(); return; }
  const ts = _grafik.timeScale();
  const yarim = Math.max(1, (ts.options().barSpacing || 6) / 2);
  const parca = document.createDocumentFragment();
  for (const [periyot, sinif] of [[3_600_000, "zb"], [14_400_000, "zu"]]) {
    for (const p of periyotGruplari(_tmMumlar, periyot)) {
      const x0 = ts.timeToCoordinate(zaman(_tmMumlar[p.ilk].t));
      const x1 = ts.timeToCoordinate(zaman(_tmMumlar[p.son].t));
      if (x0 == null && x1 == null) continue;
      const sol = Math.round((x0 ?? 0) - yarim), sag = Math.round((x1 ?? ts.width()) + yarim);
      const b = document.createElement("i");
      b.className = `${sinif} ${p.yesil ? "arti" : "eksi"} ${p.kova % 2 ? "yuksek" : "alt"}`;
      b.style.cssText = `left:${sol}px;width:${Math.max(1, sag - sol)}px`
        + (sinif === "zb" ? `;bottom:${ts.height()}px` : "");
      parca.appendChild(b);
    }
  }
  _zamanKat.replaceChildren(parca);
}

// Dikey strateji cizgilerini ust katmanda zaman eksenine gore yerlestirir
// (kaydirma/zoom/boyut degisiminde yeniden). Saat ekseninin ustunde biter.
function dikeyleriKonumla() {
  if (!_grafik || !_dikeyKat) return;
  const ts = _grafik.timeScale();
  const alt = ts.height();
  const parca = document.createDocumentFragment();
  for (const d of _dikeyler) {
    const x = ts.timeToCoordinate(d.time);
    if (x == null) continue;
    const c = document.createElement("i");
    c.style.cssText = `left:${Math.round(x)}px;bottom:${alt}px;background:${d.renk}`;
    parca.appendChild(c);
  }
  _dikeyKat.replaceChildren(parca);
}

// Websocket tiki: yalniz son mumu gunceller (yeni mum da olabilir).
export function updateTvLastCandle(mum, hamMum) {
  if (!_grafik || !mum || mum.t < _sonZaman) return;     // eski mum guncellenemez
  _sonZaman = mum.t;
  _ser.mum.update({ time: zaman(mum.t), open: mum.a, high: mum.y, low: mum.d, close: mum.k });
  if (hamMum && _hacimAcik) {
    const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
    _ser.hacim.update({ time: zaman(hamMum.t), value: hamMum.h || 0,
                        color: (mum.k >= mum.a ? arti : eksi) + "66" });
  }
}

// Son `n` mumu ekrana sigdirir (50M / 128M / 200M dugmeleri).
export function showRecentTvCandles(n, toplam) {
  if (!_grafik || !toplam) return;
  _grafik.timeScale().setVisibleLogicalRange({ from: Math.max(0, toplam - n), to: toplam + 2 });
}

// Tum mumlari sigdirir (TUMU).
export function showAllTvCandles() {
  _grafik?.timeScale().fitContent();
}

// "+" / "-": sag kenar sabit, gorunen mum sayisi carpanla degisir.
export function zoomTvChart(carpan) {
  if (!_grafik) return;
  const ts = _grafik.timeScale();
  const r = ts.getVisibleLogicalRange();
  if (!r) return;
  const genislik = (r.to - r.from) / carpan;
  ts.setVisibleLogicalRange({ from: r.to - genislik, to: r.to });
}
