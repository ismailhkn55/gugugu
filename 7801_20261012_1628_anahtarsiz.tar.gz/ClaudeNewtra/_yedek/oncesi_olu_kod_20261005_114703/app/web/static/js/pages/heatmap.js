// heatmap.js -- HEATMAP: anasayfa evreni + BTC/ETH, deg24, CCI filtresi.
//
// YAPAY ZEKA MIMO (24.09.2026):
//   * GUNLUK sayfasi kaldirildi, yerine HEATMAP.
//   * KAC-Index: endeks = deg24 - total3 (BTC/ETH disi altcoin evreni).
//   * ~210 anasayfa karosu + BTC/ETH; tavan yok; en buyuk % ustte.
//   * CCI ↑ 5dk filtresi (varsayilan KAPALI) + siralama chip'leri.
//   * Zamanlama: 5 dk penceresi bitimine 40 sn kala yenileme.
//   * Harici API yok: rank.sqlite + Binance ticker/24hr.
import { apiGet } from "../api.js";
import { coinName, formatSigned } from "../format.js";
import { getTercih, setTercih, getState } from "../store.js";
import { registerPoll, sharePollResult } from "../poll.js";
import { openSymbol } from "./trade.js";

let _kuruldu = false;
let _sonVeri = null;
const PERIYOT = 5 * 60 * 1000;
const OFSET = PERIYOT - 40 * 1000;
const SIRA = ["deg24", "deg5m", "deg1h", "hacim"];
let _sonAlma = 0;
let _hedefTs = 0;

// 5 dk penceresinin kacinci saniyesinde oldugumuz
export function pencereSaniye() {
  return Math.floor((Date.now() % PERIYOT) / 1000);
}

// Cagri hedef penceresinde mi (bitime ~40 sn kala)
export function hedefPenceresinde() {
  const s = pencereSaniye();
  const h = Math.floor(OFSET / 1000);
  return s >= h - 5 && s < h + 30;
}

// Sonraki 5 dk - 40 sn hedefinin epoch'u
export function sonrakiHedefTs() {
  const now = Date.now();
  const ms = now % PERIYOT;
  let bekle = OFSET - ms;
  if (bekle < 0) bekle += PERIYOT;
  return now + bekle;
}

// deg24 -> tema arti/eksi alpha'li renk
export function renkFor(deg, tavan = 8) {
  if (deg == null || Number.isNaN(+deg)) return "var(--panel)";
  const oran = Math.min(1, Math.abs(+deg) / tavan);
  const a = (0.18 + oran * 0.72).toFixed(3);
  const hex = +deg >= 0 ? "47,224,138" : "255,77,106";
  return `rgba(${hex},${a})`;
}

// CCI filtresi acik mi? (switch > tercih > ayar varsayilani; varsayilan kapali)
function hmCciAcikMi() {
  const el = document.getElementById("hmCciSwitch");
  if (el) return !!el.checked;
  const t = getTercih("heatmap_cci");
  if (t !== undefined && t !== null) return !!t;
  return !!getState("ayar")?.heatmap_cci_acik;
}

function hmSiraModu(d) {
  const v = getTercih("heatmap_sira");
  if (SIRA.includes(v)) return v;
  const a = d?.siralama || getState("ayar")?.heatmap_siralama;
  if (SIRA.includes(a)) return a;
  return "deg24";
}

// Index kartlari + akis + hedef sayaci.
function ustCiz(d) {
  const kapI = document.getElementById("hmIndex");
  const kapA = document.getElementById("hmAkis");
  const kapN = document.getElementById("hmSonraki");
  if (!kapI) return;

  _hedefTs = d?.sonraki_hedef || sonrakiHedefTs();
  if (kapN) {
    const kalan = Math.max(0, _hedefTs - Date.now());
    const sn = Math.ceil(kalan / 1000);
    kapN.textContent = ` · sonraki: ${Math.floor(sn / 60)}dk ${sn % 60}sn`;
  }

  const x = d?.indexler || {};
  const usdtM = (x.usdt_hacim || 0) / 1e6;
  const usdcM = (x.usdc_hacim || 0) / 1e6;
  const karts = [
    ["USDT HACIM", `$${usdtM.toFixed(0)}M`, x.usdt_d, "usdtD"],
    ["USDC HACIM", `$${usdcM.toFixed(0)}M`, x.usdc_d, "usdcD"],
    ["TOTAL3 (ALT)", formatSigned(x.total3, 2), null, "total3"],
    ["GENISLIK", `%${(x.genislik ?? 0).toFixed(0)}`, x.genislik_d, "genD"],
    ["BTC PAY", x.btc_dom != null ? `%${x.btc_dom.toFixed(1)}` : "—", x.btc_deg, "btc"],
    ["ETH PAY", x.eth_dom != null ? `%${x.eth_dom.toFixed(1)}` : "—", x.eth_deg, "eth"],
    ["ORT 24S", formatSigned(x.ort_deg, 2), null, "ort"],
    ["COIN", String(x.coin_sayisi ?? "—"), null, "n"],
  ];
  kapI.innerHTML = karts.map(([ad, deger, delta, id]) => {
    let alt = "";
    if (delta != null && id.endsWith("D")) {
      const s = +delta > 0 ? "arti" : +delta < 0 ? "eksi" : "notr";
      alt = `<span class="hmDelt ${s}">${formatSigned(delta, 1)}</span>`;
    } else if (id === "btc" && x.btc_deg != null) {
      const s = +x.btc_deg > 0 ? "arti" : "eksi";
      alt = `<span class="hmDelt ${s}">${formatSigned(x.btc_deg, 1)}</span>`;
    } else if (id === "eth" && x.eth_deg != null) {
      const s = +x.eth_deg > 0 ? "arti" : "eksi";
      alt = `<span class="hmDelt ${s}">${formatSigned(x.eth_deg, 1)}</span>`;
    }
    return `<div class="hmKart">
      <div class="hmAd">${ad}</div>
      <div class="hmDeger">${deger}</div>${alt}
    </div>`;
  }).join("");

  if (kapA) {
    const a = d?.akis || {};
    const s = a.sinif || "notr";
    kapA.className = `hmAkis ${s}`;
    kapA.innerHTML = `<span class="hmNokta"></span>
      <span class="hmAkisMetin">${a.metin || "—"}</span>
      <span class="hmAkisAlt">USDT↓ genislik↑ = coinlere akis · USDT↑ genislik↓ = park</span>`;
  }
}

// ---------------------------------------------------------------------
// TREEMAP (26.09.2026, Ismail): "yuzdesel yukselmesi en buyuk olan en buyuk
// kutucuk, sonra bir kucuk... dinamik; yazilar okunsun okunabildigi kadar.
// Asiri dusen en sondaki 9'u altina, arada 1 satir bosluk".
//   * Kutu ALANI degerle orantili (squarified treemap).
//   * Yazi puntosu kutuya gore olceklenir; en kucuk kutu okunamayacak hale
//     gelmeden durulur -> kac coin sigacagi EKRANA gore kendiliginden cikar.
//   * Yazi rengi zemine gore siyah/beyaz secilir (yesil ustunde okunmuyordu).
//   * "e+2.3" (anlasilmiyordu) -> yer varsa "ALT'A GORE +2.3%".
// ---------------------------------------------------------------------
const MIN_EN = 46;          // okunur kutunun en dar eni (px)
const MIN_BOY = 28;         // en kisa boyu (px)
const DUSEN_ADET = 9;
const BOSLUK_SATIR = 20;    // iki harita arasi "1 satir bosluk" (+ baslik)

// Kareye yakin dikdortgenlere boler (Bruls ve digerleri, squarified).
// items: [{v, t}] BUYUKTEN KUCUGE sirali. Doner: [{t, x, y, w, h}].
export function squarifyTiles(items, x, y, w, h) {
  const out = [];
  const toplam = items.reduce((a, b) => a + b.v, 0);
  if (!(toplam > 0) || w <= 0 || h <= 0) return out;
  const olcek = (w * h) / toplam;
  let kalan = items.map((q) => ({ t: q.t, a: q.v * olcek }));
  const enKotu = (satir, kisa) => {
    const top = satir.reduce((a, b) => a + b.a, 0);
    let mx = 0, mn = Infinity;
    for (const q of satir) { if (q.a > mx) mx = q.a; if (q.a < mn) mn = q.a; }
    return Math.max((kisa * kisa * mx) / (top * top), (top * top) / (kisa * kisa * mn));
  };
  while (kalan.length) {
    const kisa = Math.min(w, h);
    const satir = [kalan[0]];
    let i = 1;
    while (i < kalan.length && enKotu([...satir, kalan[i]], kisa) <= enKotu(satir, kisa)) {
      satir.push(kalan[i]); i++;
    }
    const top = satir.reduce((a, b) => a + b.a, 0);
    if (w >= h) {
      const sw = top / h; let cy = y;
      for (const q of satir) { const qh = q.a / sw; out.push({ t: q.t, x, y: cy, w: sw, h: qh }); cy += qh; }
      x += sw; w -= sw;
    } else {
      const sh = top / w; let cx = x;
      for (const q of satir) { const qw = q.a / sh; out.push({ t: q.t, x: cx, y, w: qw, h: sh }); cx += qw; }
      y += sh; h -= sh;
    }
    kalan = kalan.slice(i);
  }
  return out;
}

// En fazla kac oge sigar ki en kucuk kutu hala okunur olsun.
function okunurYerlesim(ogeler, w, h) {
  for (let n = ogeler.length; n >= 1; n--) {
    const yer = squarifyTiles(ogeler.slice(0, n), 0, 0, w, h);
    if (yer.every((r) => r.w >= MIN_EN && r.h >= MIN_BOY)) return yer;
  }
  return [];
}

// "#RRGGBB" / "rgb(...)" -> [r,g,b]
function rgbOku(c) {
  c = String(c).trim();
  if (c.startsWith("#")) {
    const h = c.length === 4 ? c.slice(1).split("").map((x) => x + x).join("") : c.slice(1);
    return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
  }
  const m = c.match(/\d+(\.\d+)?/g) || [0, 0, 0];
  return m.slice(0, 3).map(Number);
}
function parlaklik([r, g, b]) {
  const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}

// Kutu zemini (panel -> arti/eksi, siddete gore) + okunur yazi rengi.
function kutuRengi(oran, pozitif) {
  const cs = getComputedStyle(document.documentElement);
  const a = rgbOku(cs.getPropertyValue("--panel") || "#0a141a");
  const b = rgbOku(cs.getPropertyValue(pozitif ? "--arti" : "--eksi") || (pozitif ? "#33CC99" : "#FF3366"));
  const k = 0.25 + 0.75 * Math.min(1, Math.max(0, oran));
  const z = a.map((v, i) => Math.round(v + (b[i] - v) * k));
  const L = parlaklik(z);
  // siyah mi beyaz mi daha yuksek kontrast verir
  const yazi = (L + 0.05) / 0.05 > 1.05 / (L + 0.05) ? "#000000" : "#FFFFFF";
  return { zemin: `rgb(${z.join(",")})`, yazi };
}

// Tek kutunun HTML'i; punto kutuya gore.
function kutuHtml(r, deger, enBuyuk, pozitif, metinDeger) {
  const t = r.t, ad = coinName(t.sembol);
  const yuzde = metinDeger;
  const cciVar = t.cci_artis === true;
  // Share Tech Mono harf eni ~0.54em + harf araligi; 0.72 guvenli pay
  // (0.62 ile "GRAM..." "1000CA..." kesiliyordu -- olculdu).
  const harf = Math.max(ad.length + (cciVar ? 2 : 0), yuzde.length, 4);
  const punto = Math.max(9, Math.min(30, Math.floor(Math.min((r.w - 8) / (harf * 0.72), (r.h - 4) / 2.5))));
  const { zemin, yazi } = kutuRengi(Math.abs(deger) / (enBuyuk || 1), pozitif);
  const endeks = t.endeks;
  const altSatir = endeks != null && r.h >= punto * 3.4 && r.w >= 11 * punto * 0.5
    ? `<span class="hmTmAlt">ALT'A GORE ${formatSigned(endeks, 1)}</span>` : "";
  const cci = cciVar ? " ▲" : "";
  const yaziYok = r.w < MIN_EN || r.h < MIN_BOY;     // kutu var, yazi sigmiyor
  return `<button type="button" class="hmTm" data-sembol="${t.sembol}"
      style="left:${r.x.toFixed(1)}px;top:${r.y.toFixed(1)}px;width:${r.w.toFixed(1)}px;height:${r.h.toFixed(1)}px;background:${zemin};color:${yazi};font-size:${punto}px"
      title="${t.sembol} · 24s ${formatSigned(t.deg24, 2)} · ALT'a (TOTAL3) gore ${formatSigned(endeks, 2)} · CCI ${t.cci != null ? (+t.cci).toFixed(0) : "—"}">
    ${yaziYok ? "" : `<span class="hmTmAd">${ad}${cci}</span><span class="hmTmDeg">${yuzde}</span>${altSatir}`}</button>`;
}

// CCI filtresi + siralama ile treemap ciz.
export function karolariCiz() {
  const kapH = document.getElementById("hmHarita");
  const kapS = document.getElementById("hmFiltreSayi");
  if (!kapH || !_sonVeri) return;

  let liste = [...(_sonVeri.karolar || [])];
  const sira = hmSiraModu(_sonVeri);
  const cciOn = hmCciAcikMi();
  const toplam = liste.length;
  if (cciOn) liste = liste.filter((t) => t.btc_eth_karo || t.cci_artis === true);

  // Boyut olcutu: secili sira (24s / 5dk / 1h); "hacim" secilince boyut
  // hacim, renk 24s. Dusenler seridi her zaman 24s'e gore.
  const olcut = sira === "hacim" ? "hacim" : sira;
  // 02.10.2026 (Ismail, "heatmap kirmizi/yesil"): buyuk alan eskiden YALNIZ
  // yukselenleri gosteriyordu -- canlida 163 coinin 105'i duserken ekran yesil
  // goruyordu. Artik buyuk alan ISARETE GORE iki blok: yukselen (yesil) + dusen
  // (kirmizi); her blogun alani kendi toplam buyuklugune orantili, renk olcegi
  // ikisinde ORTAK. Asagidaki 9'luk dusen SERIDI (26.09 istegi) ozet olarak kalir.
  const isaretDeg = (t) => (sira === "hacim" ? +t.deg24 : +t[olcut]);
  const boyut = (t) => (sira === "hacim" ? +t.hacim : Math.abs(+t[olcut]));
  const gecerli = liste.filter((t) => Number.isFinite(isaretDeg(t)) && isaretDeg(t) !== 0
                                      && boyut(t) > 0);
  const yukselen = gecerli.filter((t) => isaretDeg(t) > 0)
    .map((t) => ({ t, v: boyut(t) })).sort((a, b) => b.v - a.v);
  const buyukDusen = gecerli.filter((t) => isaretDeg(t) < 0)
    .map((t) => ({ t, v: boyut(t) })).sort((a, b) => b.v - a.v);
  const dusen = liste.filter((t) => t.deg24 < 0)
    .sort((a, b) => a.deg24 - b.deg24).slice(0, DUSEN_ADET)
    .map((t) => ({ t, v: Math.abs(+t.deg24) }));
  // Dusen seridinde 9'u da gorunsun: cok kucuk dususler en buyugun %35'i
  // kadar yer alir (siralama ve renk yine gercek degerden).
  const dMax = Math.max(...dusen.map((q) => q.v), 0);
  for (const q of dusen) q.v = Math.max(q.v, dMax * 0.35);

  // Olculer: harita bir EKRAN boyu (sayfanin gorunen yuksekligi).
  const sayfa = kapH.closest(".sayfa");
  const W = Math.floor(kapH.clientWidth);
  // Gorunen alan: sayfanin alt kenari ile alttaki durum cubugunun ustu.
  const altbar = document.getElementById("altbar");
  const ust = sayfa ? sayfa.getBoundingClientRect().top : 0;
  const alt = altbar ? altbar.getBoundingClientRect().top : innerHeight;
  const ekranH = Math.max(220, Math.floor(alt - ust) - 12);
  const dikey = W < 520;
  const dusenH = dusen.length ? (dikey ? 2 * 56 : 60) : 0;
  const ustH = ekranH - dusenH - (dusen.length ? BOSLUK_SATIR : 0);

  const topY = yukselen.reduce((a, q) => a + q.v, 0);
  const topD = buyukDusen.reduce((a, q) => a + q.v, 0);
  const pay = topY + topD > 0 ? topY / (topY + topD) : 1;
  // 02.10.2026, Ismail: "ustteki HEPSINI gostermesi gerekiyor" -- buyuk alanda
  // artik HIC coin atilmaz (eskiden okunurYerlesim en kucukleri dusuruyordu).
  // Yaziya yer olmayan kutu yazisiz cizilir; adi/yuzdesi title'da.
  const ARA = yukselen.length && buyukDusen.length ? 3 : 0;   // iki blok arasi ince cizgi payi
  let ustYer, ustDusenYer;
  if (W >= ustH) {                                   // yatay ekran: yan yana
    const wY = Math.round((W - ARA) * pay);
    ustYer = squarifyTiles(yukselen, 0, 0, wY, ustH);
    ustDusenYer = squarifyTiles(buyukDusen, wY + ARA, 0, W - wY - ARA, ustH);
  } else {                                           // dikey ekran: ust ustte
    const hY = Math.round((ustH - ARA) * pay);
    ustYer = squarifyTiles(yukselen, 0, 0, W, hY);
    ustDusenYer = squarifyTiles(buyukDusen, 0, hY + ARA, W, ustH - hY - ARA);
  }
  const altYer = okunurYerlesim(dusen, W, dusenH);
  // ORTAK renk olcegi: ayni yuzde iki blokta da ayni koyulukta.
  const enB = Math.max(...gecerli.map((t) => Math.abs(isaretDeg(t))), 1);
  const enD = Math.max(...dusen.map((q) => q.v), 1);

  if (kapS) {
    kapS.textContent = `${yukselen.length} yukselen · ${buyukDusen.length} dusen / ${toplam}`
      + ` · haritada ${ustYer.length}+${ustDusenYer.length}`
      + (cciOn ? " · CCI↑" : "");
  }
  if (!ustYer.length && !ustDusenYer.length && !altYer.length) {
    kapH.style.height = "";
    kapH.innerHTML = `<div class="bos">karo yok (filtre)</div>`;
    return;
  }
  kapH.style.height = `${ustH + (altYer.length ? BOSLUK_SATIR + dusenH : 0)}px`;
  const metin = (t) => sira === "hacim" ? formatSigned(t.deg24, 1) : formatSigned(t[olcut], 1);
  let html = ustYer.map((r) => kutuHtml(r, isaretDeg(r.t), enB, true, metin(r.t))).join("")
    + ustDusenYer.map((r) => kutuHtml(r, isaretDeg(r.t), enB, false, metin(r.t))).join("");
  if (altYer.length) {
    html += `<div class="hmTmAyrac" style="top:${ustH}px;height:${BOSLUK_SATIR}px">EN COK DUSEN ${altYer.length}</div>`;
    html += altYer.map((r) => kutuHtml({ ...r, y: r.y + ustH + BOSLUK_SATIR },
      r.t.deg24, enD, false, formatSigned(r.t.deg24, 1))).join("");
  }
  kapH.innerHTML = html;
}

export function renderHeatmap(d) {
  _sonVeri = d;
  ustCiz(d);
  karolariCiz();
}

// Switch + chip durumunu bagla (mount'ta bir kez).
function hmKontrolDurumu() {
  const sw = document.getElementById("hmCciSwitch");
  if (sw) {
    const t = getTercih("heatmap_cci");
    if (t === undefined || t === null) {
      sw.checked = !!getState("ayar")?.heatmap_cci_acik;
    } else {
      sw.checked = !!t;
    }
    sw.addEventListener("change", () => {
      setTercih("heatmap_cci", sw.checked);
      karolariCiz();
    });
  }
  const kap = document.getElementById("hmSiraChips");
  if (kap) {
    const guncelle = () => {
      const s = hmSiraModu(_sonVeri);
      for (const b of kap.querySelectorAll("[data-sira]")) {
        b.classList.toggle("aktif", b.dataset.sira === s);
      }
    };
    kap.addEventListener("click", (e) => {
      const b = e.target.closest("[data-sira]");
      if (!b) return;
      setTercih("heatmap_sira", b.dataset.sira);
      guncelle();
      karolariCiz();
    });
    guncelle();
  }
}

// Sunucudan heatmap verisini ceker.
export async function refreshHeatmap(zorla = false) {
  if (!zorla && _sonAlma && !hedefPenceresinde()) {
    return null;
  }
  _sonAlma = Date.now();
  _hedefTs = sonrakiHedefTs();
  return apiGet("/yerel/heatmap?n=400");
}

// Hedefe hizali 5 dk zinciri (duvar saati).
function zamanlaPencere() {
  const bekle = Math.max(500, sonrakiHedefTs() - Date.now());
  setTimeout(async () => {
    const d = await refreshHeatmap(true);
    if (d) renderHeatmap(d);
    zamanlaPencere();
  }, bekle);
}

export function mountHeatmapPage() {
  if (_kuruldu) return;
  _kuruldu = true;
  document.getElementById("hmHarita")?.addEventListener("click", (e) => {
    const s = e.target.closest("[data-sembol]")?.dataset.sembol;
    if (s) openSymbol(s);
  });
  hmKontrolDurumu();
  registerPoll("heatmap", 300, () => refreshHeatmap(true), {
    sayfa: "heatmap",
    hemen: true,
  });
  sharePollResult("heatmap", renderHeatmap);
  // Treemap olcusu ekrana bagli: dondurunce / pencere degisince yeniden ciz.
  let _boyutZaman = null;
  window.addEventListener("resize", () => {
    clearTimeout(_boyutZaman);
    _boyutZaman = setTimeout(karolariCiz, 150);
  });
  zamanlaPencere();
}
