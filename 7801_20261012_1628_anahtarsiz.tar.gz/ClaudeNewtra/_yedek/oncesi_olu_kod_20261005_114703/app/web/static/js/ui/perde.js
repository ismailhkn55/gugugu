// perde.js -- iskelette HAZIR olan pencereleri acip kapatan ortak yardimci.
//
// Pencereler `.acik` sinifiyla acilir (CSS: 80-bildirim.css, 96-notlar.css,
// 97-kalan.css). Her acilan pencere modal yiginina eklenir, boylece Escape
// YALNIZCA en usttekini kapatir.
import { pushModalLayer } from "../keys.js";

const _acik = new Map();   // perdeId -> kapat fonksiyonu

// Pencereyi acar; kapatma fonksiyonu doner.
export function openPerde(perdeId, { onClose } = {}) {
  const p = document.getElementById(perdeId);
  if (!p) return () => {};
  closePerde(perdeId);
  p.classList.add("acik");
  p.setAttribute("aria-hidden", "false");

  const kapat = () => {
    p.classList.remove("acik");
    p.setAttribute("aria-hidden", "true");
    cikar();
    _acik.delete(perdeId);
    onClose?.();
  };
  const cikar = pushModalLayer(perdeId, kapat);
  _acik.set(perdeId, kapat);

  // Perdeye (kutunun disina) tiklayinca kapansin.
  const disTik = (e) => { if (e.target === p) kapat(); };
  p.addEventListener("click", disTik, { once: false });
  return kapat;
}

// Verilen perdeyi kapatir.
export function closePerde(perdeId) {
  const k = _acik.get(perdeId);
  if (k) k();
}

// Perde acik mi.
export function isPerdeOpen(perdeId) {
  return _acik.has(perdeId);
}
