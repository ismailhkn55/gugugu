// format.js -- bicimleme yardimcilari (saf fonksiyonlar).

// Fiyati anlamli basamaga gore, sondaki sifirlar olmadan yazar.
//
// 23.09.2026, Ismail: "coin deki fiyattaki asiri kusurat, o kadar kusurat
// olmamasi lazim". Onceki surum buyukluge gore SABIT ondalik sayisi
// kullaniyordu (`toFixed`); bu sondaki sifirlari ZORLA yaziyordu --
// 74.8600, 1.4670, 0.00001230. Binance'in tick adimi zaten ~5-6 anlamli
// basamak.
// Fiyati anlamli basamaga gore, sondaki sifirlar olmadan yazar.
export function formatPrice(v, anlamli = 6) {
  if (v === null || v === undefined || Number.isNaN(+v)) return "-";
  const f = +v;
  if (f === 0) return "0";
  const a = Math.abs(f);
  // Buyuk fiyatta iki ondalik yeter; kucukte ANLAMLI BASAMAK kullanilir.
  let s = a >= 1000 ? f.toFixed(2) : f.toPrecision(anlamli);
  // toPrecision cok kucuk sayilarda ussel gosterime kacar (1.23e-8).
  if (s.includes("e")) s = f.toFixed(12);
  // Sondaki anlamsiz sifirlari at: "74.8600" -> "74.86", "1.4670" -> "1.467".
  if (s.includes(".")) s = s.replace(/0+$/, "").replace(/\.$/, "");
  return s;
}

// Coin adi -- kotasyon birimi (USDT) YAZILMAZ.
//
// 23.09.2026, Ismail: "coin isimlerinde usdt yazmasina gerek yok".
// Panelde her sey USDT paritesi oldugu icin bu ek bilgi tasimiyordu,
// yalnizca yer kapliyordu. Tam sembol `title` ile erisilebilir kalir.
export function coinName(sembol) {
  return String(sembol || "").replace(/USDT$/i, "") || String(sembol || "");
}

// Yuzde biçimi, isaretli.
export function formatPercent(v, basamak = 2) {
  if (v === null || v === undefined || Number.isNaN(+v)) return "-";
  return (+v).toFixed(basamak) + "%";
}

// Isaretli yuzde (+/-).
export function formatSigned(v, basamak = 2) {
  if (v === null || v === undefined || Number.isNaN(+v)) return "-";
  const f = +v;
  return (f > 0 ? "+" : "") + f.toFixed(basamak) + "%";
}

// USDT tutari.  (eski: usdt)
export function formatUsdt(v, basamak = 2) {
  if (v === null || v === undefined || Number.isNaN(+v)) return "-";
  return (+v).toFixed(basamak);
}

// Saat (HH:MM:SS).  (eski: zmn)
export function formatClock(ms) {
  const d = ms ? new Date(+ms) : new Date();
  return d.toTimeString().slice(0, 8);
}

// Sure: "2s 14dk".  (eski: sureYaz)
export function formatDuration(ms) {
  if (!ms || ms < 0) return "-";
  const sn = Math.floor(ms / 1000);
  if (sn < 60) return `${sn}sn`;
  const dk = Math.floor(sn / 60);
  if (dk < 60) return `${dk}dk`;
  const s = Math.floor(dk / 60);
  if (s < 24) return `${s}s ${dk % 60}dk`;
  return `${Math.floor(s / 24)}g ${s % 24}s`;
}

// Tablo hucresi: sayi ise renk sinifiyla birlikte.  (eski: hucre)
export function formatCell(v, tip) {
  if (v === null || v === undefined) return { metin: "-", sinif: "" };
  if (tip === "pct") return { metin: formatSigned(v), sinif: +v > 0 ? "art" : +v < 0 ? "eks" : "" };
  if (tip === "fiyat") return { metin: formatPrice(v), sinif: "" };
  if (tip === "int") return { metin: String(Math.round(+v)), sinif: "" };
  if (typeof v === "number") return { metin: (+v).toFixed(2), sinif: "" };
  return { metin: String(v), sinif: "" };
}

// Alan adinin okunur karsiligi.
const ALAN_ADLARI = {
  deg5m: "5 dk %", deg1h: "1 saat %", deg2h: "2 saat %", deg4h: "4 saat %",
  deg8h: "8 saat %", deg24: "24 saat %", gun_pct: "gun %", hacim: "hacim",
  hacim_x: "hacim x", hacim_3ort_x: "hacim / onceki 3 ort", h4_anlik_yesil: "4h su an yesil (TM)", dipten_24s: "24s dibinden %", ha_kapali_yesil: "HA yesil (kapanmis)", dusus_3s: "3s dusus %", bbw_yuzdelik: "BB genislik yuzdelik", kirilim_tetik: "kirilim tetik", atr_pct: "ATR %", rsi: "RSI", hiz: "hiz", cci: "CCI",
  cci_artis: "CCI artis (7 mum once -> simdi, puan)",
  // 26.09.2026, Ismail: etiketler anasayfadaki sutun basliklariyla ayni
  // baslamali (sATR, sHIZ, HA, YSL) — boylece ayni isimle araninca bulunsun.
  kdj_j: "KDJ J", rank: "sira", rank_atr: "sATR (ATR sirasi)",
  rank_hiz: "sHIZ (hiz sirasi)",
  ema7: "EMA7", ema20: "EMA20", wma48: "WMA48", obv_kesim: "OBV kesim",
  obv_aci: "OBV acisi", ha_ardisik_yesil: "HA (ardisik yesil mum)",
  ha_yesil_yukselis: "HA yesil yukselis", yesile_donus_mum: "YSL (yesile donus mumu)",
  ema_dizilim: "EMA dizilim", ema_kesim: "EMA kesim", iz_yon: "iz yonu",
  genislik: "heatmap yesil %", total3_5m: "TOTAL3 5m %",
  deg128m: "128 mum %", coingreen: "yesil mum (128)",
  coinsay: "yesil-kirmizi (128)",
  yesildeg: "yesil degisim toplami (128)",
  kirmizideg: "kirmizi degisim toplami (128)",
  fark128: "FARK (128 mum)",
  kare128: "KARE (128 mum araligi %)",
  yukselis128: "YUKSELIS (128 mum dibinden %)",
  bb_orta_uzak: "BB orta uzaklik %", bb_orta_kesim: "BB orta kesim (yukari)",
  ha_4h_yesil_yukselis: "HA 4H yesil yukselis",
  hacim_bb_tetik: "Hacim/BB tetik (2x veya kesim)",
};

// 26.09.2026, Ismail: bu alanlar ekranda HER ZAMAN 1 ondalikla gosterilir.
const TEK_ONDALIK = new Set(["coinsay", "coingreen", "yesildeg", "kirmizideg",
                             "fark128", "kare128", "yukselis128"]);

// Kural degerini alanina gore bicimler. (eski: kuralDegeri)
export function formatRuleValue(ad, deger) {
  if (deger == null || deger === "") return "";
  if (TEK_ONDALIK.has(ad) && Number.isFinite(+deger)) return (+deger).toFixed(1);
  return String(deger);
}

// Kural alaninin Turkce ekran adini dondurur.  (eski: alanAdi)
export function fieldLabel(ad) {
  return ALAN_ADLARI[ad] || ad;
}

const OP_ADLARI = {
  ">=": "en az", "<=": "en fazla", ">": "buyuk", "<": "kucuk",
  "==": "esit", "!=": "farkli", yukari: "yukari", asagi: "asagi",
};

// Karsilastirma operatorunun Turkce adini dondurur.  (eski: opAdi)
export function operatorLabel(op) {
  return OP_ADLARI[op] || op;
}

// Buton adi (el_kaynak -> okunur).  (eski: butonAdi)
export function buttonLabel(kaynak) {
  // YAPAY ZEKA MIMO (24.09.2026): UZLASTIRMA etiketi eklendi.
  // Adopt edilen pozisyonlar el_kaynak="al" oldugu icin UI'da "AL"
  // gorunuyordu; gercek yontem (uzlastirma) ayirt edilemiyordu.
  return { al: "AL", altakip: "AL TAKIP", alsat1: "ALSAT 1",
           alsat2: "ALSAT 2", alsat3: "ALSAT 3",
           uzlastirma: "UZLASTIRMA" }[kaynak] || (kaynak || "BOT");
}
