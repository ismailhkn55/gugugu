// confirm.js -- onay penceresi.
//
// DUZELTME (23.09.2026): ilk yazimda kendi `.onayPerde` elemanimi
// olusturuyordum; iskelette ZATEN `#onayPerde` / `#onayKutu` /
// `#onayBaslik` / `#onayMetin` / `#onayEvet` / `#onayHayir` var ve
// 80-bildirim.css onlari bicimlendiriyor.
//
// Eski sistemde onay penceresinin Escape isleyicisi HIC YOKTU (menu, not ve
// yontem pencerelerinin vardi). Burada tum pencereler ayni yigini kullanir.
import { closePerde, openPerde } from "./perde.js";

// Onay ister; kullanici onaylarsa true doner.  (eski: onay)
export function askConfirm(baslik, metin, { onayMetni = "ONAYLA", iptalMetni = "VAZGEC" } = {}) {
  const evet = document.getElementById("onayEvet");
  const hayir = document.getElementById("onayHayir");
  const bas = document.getElementById("onayBaslik");
  const met = document.getElementById("onayMetin");
  if (!evet || !hayir) return Promise.resolve(window.confirm(`${baslik}\n\n${metin}`));

  if (bas) bas.textContent = baslik;
  if (met) met.textContent = metin;
  evet.textContent = onayMetni;
  hayir.textContent = iptalMetni;

  return new Promise((coz) => {
    let bitti = false;
    const bitir = (sonuc) => {
      if (bitti) return;
      bitti = true;
      evet.removeEventListener("click", onEvet);
      hayir.removeEventListener("click", onHayir);
      closePerde("onayPerde");
      coz(sonuc);
    };
    const onEvet = () => bitir(true);
    const onHayir = () => bitir(false);
    evet.addEventListener("click", onEvet);
    hayir.addEventListener("click", onHayir);
    openPerde("onayPerde", { onClose: () => bitir(false) });
    evet.focus();
  });
}

// Acik onay penceresini kapatir.  (eski: onayKapat)
export function closeConfirm() {
  closePerde("onayPerde");
}
