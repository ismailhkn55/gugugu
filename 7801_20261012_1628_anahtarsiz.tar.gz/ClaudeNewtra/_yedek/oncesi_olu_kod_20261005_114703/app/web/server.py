"""HTTP sunucusu.

IKI GURULTU KAYNAGI KAPATILDI:

1. `sunucu.log` icinde 750 traceback vardi ve HICBIRI uygulama mantigi
   degildi: 172 x ConnectionResetError + 47 x BrokenPipeError -- istemci
   sayfayi kapatinca cevap yazimi patliyordu. Bu gurultu gercek hatalari
   gorunmez kiliyordu. Artik tek noktada yutuluyor.

2. 348 x "Address already in use": servis yeniden baslarken eski soket
   hala bagliyken yeni surec baslamaya calisiyordu. Artik acilista port
   yoklanir ve kimin tuttugu soylenir.
"""
from __future__ import annotations

import json
import os
import socket
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from app.core.applog import get_logger
from app.web import static_guard as SG
from app.web.router import parse_query_params, read_json_body, resolve_route

_log = get_logger(__name__)

# Istemci bagliyi kopardiginda olusan, uygulama hatasi OLMAYAN istisnalar.
CLIENT_DISCONNECT = (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)


# Port bos mu; degilse kimin tuttugunu soyler.
def ensure_port_available(port: int, *, host: str = "0.0.0.0", wait_sn: float = 10.0) -> None:
    son = time.time() + wait_sn
    while time.time() < son:
        s = socket.socket()
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((host, port))
            return
        except OSError:
            time.sleep(0.5)
        finally:
            s.close()
    sahip = ""
    try:
        for p in os.listdir("/proc"):
            if not p.isdigit():
                continue
            try:
                with open(f"/proc/{p}/cmdline", "rb") as f:
                    sahip = f"PID {p}: {f.read().replace(b'0', b' ').decode(errors='replace')[:80]}"
            except OSError:
                continue
    except OSError:
        pass
    raise OSError(f"port {port} dolu ({wait_sn:.0f} sn beklendi). {sahip}")


class _Handler(BaseHTTPRequestHandler):
    server_version = "ClaudeNewtra"
    protocol_version = "HTTP/1.1"

    # Varsayilan log'u kapat: erisim satirlari applog'a gider.
    def log_message(self, *a) -> None:
        pass

    def _gonder(self, kod: int, govde: bytes, tur: str) -> None:
        try:
            self.send_response(kod)
            self.send_header("Content-Type", tur)
            self.send_header("Content-Length", str(len(govde)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(govde)
        except CLIENT_DISCONNECT:
            pass          # istemci sayfayi kapatti -- uygulama hatasi DEGIL

    def _json(self, kod: int, veri) -> None:
        self._gonder(kod, json.dumps(veri, ensure_ascii=False, default=str).encode(),
                     "application/json; charset=utf-8")

    def _islet(self, yontem: str) -> None:
        yol = self.path.split("?")[0]
        rota = resolve_route(yontem, yol)
        if rota is not None:
            istek = {
                "params": parse_query_params(self.path),
                "body": read_json_body(self._govde()) if yontem == "POST" else {},
                "path": yol, "client": self.client_address[0],
            }
            try:
                kod, veri = rota.handler(istek)
            except Exception as e:
                _log.exception("[%s %s] isleyici hatasi", yontem, yol)
                return self._json(500, {"hata": f"{type(e).__name__}: {e}"})
            return self._json(kod, veri)
        if yontem == "GET":
            return self._statik(yol)
        self._json(404, {"hata": "yok"})

    def _govde(self) -> bytes:
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return b""
        return self.rfile.read(n) if n > 0 else b""

    def _statik(self, yol: str) -> None:
        if yol in ("/", ""):
            yol = "/index.html"
        kok = getattr(self.server, "static_root", "")
        tam = SG.resolve_static_path(yol, kok)
        if not tam:
            # Beyaz listede degil: gizli/, *.json, *.py, .oncesi_* hepsi buraya duser.
            return self._json(403, {"hata": "yasak"})
        try:
            with open(tam, "rb") as f:
                govde = f.read()
        except OSError:
            return self._json(404, {"hata": "dosya yok"})
        self._gonder(200, govde, SG.guess_content_type(tam))

    def do_GET(self) -> None:
        self._islet("GET")

    # HEAD, GET ile ayni basliklari dondurur; govde yazilmaz (bkz. `_gonder`).
    # Eskiden tanimli degildi ve `curl -I` / bazi vekiller "501 Unsupported
    # method" aliyordu.
    def do_HEAD(self) -> None:
        self._islet("GET")

    def do_POST(self) -> None:
        self._islet("POST")

    def handle_one_request(self) -> None:
        try:
            super().handle_one_request()
        except CLIENT_DISCONNECT:
            self.close_connection = True


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    static_root = ""


# Sunucuyu kurar (port yoklamasi dahil).
def create_http_server(port: int, static_root: str, *, host: str = "0.0.0.0") -> _Server:
    ensure_port_available(port, host=host)
    s = _Server((host, port), _Handler)
    s.static_root = static_root
    _log.info("sunucu hazir: http://%s:%d  (statik kok: %s)", host, port, static_root)
    return s


# Dinlemeye baslar.
def run_http_server(server: _Server) -> None:
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _log.info("kapatiliyor...")
    finally:
        server.server_close()


# Istemci kopmasi mi? (disaridan da sorulabilsin diye acik.)
def suppress_client_disconnect(exc: BaseException) -> bool:
    return isinstance(exc, CLIENT_DISCONNECT)
