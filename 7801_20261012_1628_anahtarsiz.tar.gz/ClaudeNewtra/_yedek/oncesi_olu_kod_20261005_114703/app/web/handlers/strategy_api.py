"""Strateji uclari."""
from __future__ import annotations

from app.config.settings import load_settings
from app.core.errors import UnknownFieldError
from app.market.indicators import field_meanings, list_available_fields
from app.strategy import registry as REG
from app.strategy.backtest import summarize_backtest_gaps
from app.strategy.rule_engine import OPERATORS
from app.web.router import query_live


# GET /yerel/strateji
def handle_strategy_list(req):
    d = REG.list_strategies()
    for s in d["stratejiler"]:
        s["_dogrulama"] = REG.validate_strategy(s)
        s["_calisan_kurallar"] = REG.stamp_measurement_context(s)
        s["_geriye_test"] = summarize_backtest_gaps(s)
    return 200, {**d, "alanlar": list(list_available_fields()),
                 "operatorler": list(OPERATORS), "aciklamalar": field_meanings()}


# POST /yerel/strateji -- kaydet / sil / aktif yap.
def handle_strategy_command(req):
    g = req["body"] or {}
    a = load_settings()
    if g.get("sil"):
        return 200, {"ok": REG.delete_strategy(g["sil"])}
    # Satir switch'i: {anahtar: {"ad": "...", "acik": true/false}}
    anahtar = g.get("anahtar")
    if isinstance(anahtar, dict):
        ad = anahtar.get("ad")
        if not ad:
            return 400, {"hata": "anahtar.ad gerekli"}
        ok, mesaj = REG.toggle_strategy(ad, bool(anahtar.get("acik")))
        if not ok:
            return 409, {"ok": False, "hata": mesaj, "mesaj": mesaj, "ad": ad}
        return 200, {"ok": True, "mesaj": mesaj, "ad": ad}
    if g.get("aktif_yap"):
        live = bool(g["canli"]) if "canli" in g else bool(a.get("bot_canli"))
        ok = REG.set_active_strategy(g["aktif_yap"], live=live)
        hata = None if ok else (f"'{g['aktif_yap']}' kapali -- once AC"
                                if not ok else None)
        return (200 if ok else 404), {"ok": ok, "canli": live, "hata": hata}
    st = g.get("strateji")
    if not st:
        return 400, {"hata": "strateji gerekli"}
    try:
        return 200, {"ok": True, **REG.save_strategy(st)}
    except UnknownFieldError as e:
        return 400, {"hata": str(e), "sorunlar": REG.validate_strategy(st)}


# POST /yerel/geriye-test -- {strateji: TASLAK} | {ad: "..."} | {} (aktif), `genis`.
# HICBIR SEY KAYDETMEZ (registry'ye dokunmaz). Istek BEKLEMEZ: onbellek eksikse
# arka planda isitilir, yanit "hazirlaniyor" der; tarayici birkac sn sonra tekrar sorar.
def handle_backtest_run(req):
    from app.reporting.backtest_report import run_backtest
    g = req["body"] or {}
    st = g.get("strateji")
    if st is None and g.get("ad"):
        st = next((s for s in REG.list_strategies()["stratejiler"] if s.get("ad") == g["ad"]), None)
        if st is None:
            return 404, {"hata": f"'{g['ad']}' adinda strateji yok"}
    if st is None:
        st = REG.get_active_strategy(live=bool(load_settings().get("bot_canli")))
    kurallar = st.get("kurallar") if isinstance(st, dict) else None
    if (not isinstance(st, dict) or not isinstance(kurallar or [], list)
            or len(kurallar or []) > 60 or not all(isinstance(k, dict) for k in kurallar or [])):
        return 400, {"hata": "strateji bicimi gecersiz (kurallar listesi, en fazla 60)"}
    try:
        sonuc = run_backtest(dict(st), wide=bool(g.get("genis")))
    except (TypeError, ValueError) as e:
        return 400, {"hata": f"strateji degerleri gecersiz: {e}"}
    sonuc["dogrulama"] = REG.validate_strategy(st)
    return 200, sonuc


# GET /yerel/geriye-test/seri?sembol= -- onbellekteki kapanis serisi; DIS ISTEK YOK.
def handle_backtest_series(req):
    from app.reporting.backtest_report import get_cached_close_series
    s = str(req["params"].get("sembol") or "").upper()
    seri = get_cached_close_series(s)
    return (200, {"sembol": s, "seri": seri}) if seri else (404, {"hata": "onbellekte yok"})
