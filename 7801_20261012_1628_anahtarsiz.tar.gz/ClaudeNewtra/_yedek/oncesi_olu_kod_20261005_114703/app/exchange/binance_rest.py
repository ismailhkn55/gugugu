"""Binance REST -- borsayla konusan TEK yer.

ESKI `bcek` NELERI YAPMIYORDU (hepsi olculdu):
  * Yeniden deneme YOK. Tek `urlopen`, hata yukari firlardi ve cagiranlarin
    cogu `except Exception: pass` ile yutuyordu.
  * Hiz siniri yonetimi YOK. `X-MBX-USED-WEIGHT-1M` hic okunmuyor, 429/418
    ayirt edilmiyor, `Retry-After` bakilmiyordu. Websocket koptugunda
    `_fiyatlar` saniyede bir TUM ticker listesini cekiyor (agirlik 4/sn =
    240/dk); `account` ve `klines` ustune binince 1200/dk tavanina
    yaklasiyor, 418 IP ban riski doguyordu.
  * Saat senkronu YOK. `/api/v3/time` hic cagrilmiyordu; sistem saati
    kayarsa Binance -1021 doner ve TUM imzali istekler sessizce olur.
  * Hata govdesi okunmuyordu. Binance'in kendi kodu (-2010 yetersiz bakiye,
    -1013 filtre hatasi) hicbir zaman gorulmuyor, log'a yalnizca
    "HTTP Error 400: Bad Request" dusuyordu.
  * Anahtar HER cagrida diskten okunuyordu.
  * Idempotency YOK. `newClientOrderId` kullanilmadigi icin ag zaman
    asiminda emrin gidip gitmedigi bilinemiyordu.

KORUNAN IYI SEYLER: `/api/v3/` on eki disina cikilamaz (futures/margin
kazasi imkansiz), imza urlencode ciktisinin TAMAMI uzerinden ve `signature`
en sona ekleniyor, `None` parametreler eleniyor, POST /order icin side ve
type beyaz listesi var.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import random
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from app.config.secrets import load_api_credentials
from app.core.applog import get_logger, log_once
from app.core.errors import ExchangeError, OrderRejectedError, RateLimitError
from app.core.locking import assert_no_network_in_lock
from app.core.timeutil import now_ms

_log = get_logger(__name__)

BASE_URL = "https://api.binance.com"
ALLOWED_PREFIX = ("/api/v3/",)          # spot disina CIKILAMAZ
DEFAULT_TIMEOUT = 15
RECV_WINDOW_MS = 8000
MAX_ATTEMPTS = 4
# Binance'in GERCEK siniri hesaptan hesaba ve zamanla degisir; acilista
# exchangeInfo'dan okunur. 6000 bugunku spot degeri -- eski belgelerdeki
# 1200 rakamini sabit yazmistim ve saglik ucu "2534/1200" diye YANLIS
# alarm veriyordu (gercekte %42'ydi).
WEIGHT_LIMIT_1M = 6000
WEIGHT_SOFT_LIMIT = 4500

_durum = {"weight_1m": 0, "weight_ts": 0.0, "clock_skew_ms": 0, "clock_synced_at": 0.0}

# Hangi ucun kac kez cagrildigi. Hiz siniri asildiginda "nereden geliyor"
# sorusunu cevaplamak icin -- eski sistemde bu gorunurluk hic yoktu ve
# websocket koptugunda saniyede bir tum ticker listesi cekiliyordu.
REQUEST_COUNTS: dict[str, int] = {}


# Uc bazinda cagri sayilari (saglik ucu bunu doner).
def get_request_counts() -> dict[str, int]:
    return dict(sorted(REQUEST_COUNTS.items(), key=lambda x: -x[1]))


# Sayaclari sifirlar.
def reset_request_counts() -> None:
    REQUEST_COUNTS.clear()


# Yolu dogrular: yalnizca spot API. Futures/margin/sapi kazasi imkansiz.
def _assert_allowed_path(path: str) -> None:
    if not path.startswith(ALLOWED_PREFIX):
        raise ExchangeError(f"izin verilmeyen yol: {path!r} (yalnizca {ALLOWED_PREFIX})")


# urlencode edilmis sorgunun HMAC-SHA256 imzasini uretir.
def build_query_signature(query: str, secret: str) -> str:
    return hmac.new(secret.encode(), query.encode(), hashlib.sha256).hexdigest()


# Binance hata govdesindeki kodu ve mesaji okur (-2010, -1013, -1021 ...).
def read_error_payload(raw: bytes) -> tuple[int | None, str]:
    try:
        d = json.loads(raw.decode("utf-8", "replace"))
        return d.get("code"), str(d.get("msg", ""))
    except Exception:
        return None, raw.decode("utf-8", "replace")[:300]


# Cevap basliklarindaki kullanilan agirligi izler; tavana yaklasinca yavaslatir.
def track_request_weight(headers) -> int:
    try:
        w = int(headers.get("X-MBX-USED-WEIGHT-1M") or 0)
    except (TypeError, ValueError):
        return _durum["weight_1m"]
    _durum["weight_1m"] = w
    _durum["weight_ts"] = time.time()
    if w > WEIGHT_SOFT_LIMIT:
        log_once(_log, "weight",
                 f"Binance agirligi yuksek: {w}/{WEIGHT_LIMIT_1M} -- yavaslatiliyor")
        time.sleep(min(2.0, (w - WEIGHT_SOFT_LIMIT) / 500.0))
    return w


# Son olculen dakikalik agirlik (saglik ucu bunu raporlar).
def get_used_weight() -> int:
    return _durum["weight_1m"]


# Gercek hiz sinirlarini borsadan okur ve sabitleri guncellestirir.
def sync_rate_limits() -> dict:
    global WEIGHT_LIMIT_1M, WEIGHT_SOFT_LIMIT
    d = public_request("/api/v3/exchangeInfo", symbol="BTCUSDT")
    sinirlar = {}
    for x in d.get("rateLimits", []):
        sinirlar[x["rateLimitType"]] = {
            "limit": x["limit"], "aralik": f"{x['intervalNum']} {x['interval']}"}
        if x["rateLimitType"] == "REQUEST_WEIGHT" and x["interval"] == "MINUTE":
            WEIGHT_LIMIT_1M = int(x["limit"])
            WEIGHT_SOFT_LIMIT = int(WEIGHT_LIMIT_1M * 0.75)
    _log.info("hiz sinirlari: agirlik %d/dk (yumusak esik %d)",
              WEIGHT_LIMIT_1M, WEIGHT_SOFT_LIMIT)
    return sinirlar


# Borsa saatiyle yerel saat arasindaki farki olcer.
def sync_exchange_clock() -> int:
    d = public_request("/api/v3/time")
    fark = int(d["serverTime"]) - now_ms()
    _durum.update(clock_skew_ms=fark, clock_synced_at=time.time())
    if abs(fark) > 1000:
        _log.warning("sistem saati borsadan %d ms sapiyor -- imzali istekler "
                     "bu farkla duzeltiliyor", fark)
    else:
        _log.info("saat farki %d ms", fark)
    return fark


# Olculen saat farki; hic olculmediyse 0.
def get_clock_skew_ms() -> int:
    return _durum["clock_skew_ms"]


def _sleep_backoff(attempt: int, base: float = 0.5) -> None:
    """Ustel bekleme + jitter: art arda hatada API'yi bombalamamak icin."""
    time.sleep(min(8.0, base * (2 ** attempt)) * (0.7 + 0.6 * random.random()))


# Istegi gonderir; 429/418'de bekler, gecici hatada ustel bekleyip yeniden dener.
def send_with_retry(request: urllib.request.Request, *, timeout: int = DEFAULT_TIMEOUT,
                    retry: bool = True) -> dict | list:
    assert_no_network_in_lock(f"{request.get_method()} {request.selector if hasattr(request, 'selector') else ''}")
    son_hata: Exception | None = None
    for deneme in range(MAX_ATTEMPTS if retry else 1):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as c:
                track_request_weight(c.headers)
                return json.load(c)
        except urllib.error.HTTPError as e:
            ham = e.read()
            kod, mesaj = read_error_payload(ham)
            if e.code in (429, 418):
                bekle = float(e.headers.get("Retry-After") or 2 ** deneme)
                _log.warning("Binance hiz siniri (%s) -- %.1f sn bekleniyor", e.code, bekle)
                if not retry or deneme == MAX_ATTEMPTS - 1:
                    raise RateLimitError(f"hiz siniri: {mesaj}", retry_after=bekle,
                                         code=kod, http_status=e.code, payload=mesaj)
                time.sleep(bekle)
                son_hata = RateLimitError(mesaj, retry_after=bekle, code=kod, http_status=e.code)
                continue
            if kod == -1021:            # timestamp penceresi disinda
                _log.warning("Binance -1021 (zaman damgasi) -- saat yeniden olculuyor")
                try:
                    sync_exchange_clock()
                except Exception:
                    pass
                son_hata = ExchangeError(mesaj, code=kod, http_status=e.code, payload=mesaj)
                if retry and deneme < MAX_ATTEMPTS - 1:
                    continue
            if 400 <= e.code < 500:      # mantik hatasi: yeniden denemek anlamsiz
                raise OrderRejectedError(f"Binance reddetti: {mesaj} (kod {kod})",
                                         code=kod, http_status=e.code, payload=mesaj)
            son_hata = ExchangeError(mesaj, code=kod, http_status=e.code, payload=mesaj)
        except (urllib.error.URLError, OSError, ValueError) as e:
            son_hata = ExchangeError(f"baglanti hatasi: {e}")
        if retry and deneme < MAX_ATTEMPTS - 1:
            _sleep_backoff(deneme)
    raise son_hata if son_hata else ExchangeError("bilinmeyen istek hatasi")


# Imzasiz (public) REST cagrisi.
def public_request(path: str, *, method: str = "GET", timeout: int = DEFAULT_TIMEOUT,
                   retry: bool = True, **params) -> dict | list:
    _assert_allowed_path(path)
    p = {k: v for k, v in params.items() if v is not None}
    etiket = path + ("" if "symbol" in p else " [TUM]")
    REQUEST_COUNTS[etiket] = REQUEST_COUNTS.get(etiket, 0) + 1
    url = BASE_URL + path + ("?" + urllib.parse.urlencode(p) if p else "")
    return send_with_retry(urllib.request.Request(url, method=method),
                           timeout=timeout, retry=retry)


# Imzali (private) REST cagrisi.  (eski: bcek imzali=True)
def signed_request(path: str, *, method: str = "GET", timeout: int = DEFAULT_TIMEOUT,
                   retry: bool = True, **params) -> dict | list:
    _assert_allowed_path(path)
    if method == "POST" and path == "/api/v3/order":
        yon = str(params.get("side", "")).upper()
        if yon not in ("BUY", "SELL"):
            raise ValueError(f"gecersiz side: {params.get('side')!r}")
        if params.get("type") not in ("LIMIT", "MARKET"):
            raise ValueError(f"gecersiz type: {params.get('type')!r}")

    REQUEST_COUNTS[path + " (imzali)"] = REQUEST_COUNTS.get(path + " (imzali)", 0) + 1
    k = load_api_credentials()
    if not k:
        raise ExchangeError("API anahtari yok -- imzali istek gonderilemez")

    p = {k2: v for k2, v in params.items() if v is not None}
    p["timestamp"] = now_ms() + _durum["clock_skew_ms"]
    p["recvWindow"] = RECV_WINDOW_MS
    sorgu = urllib.parse.urlencode(p)
    sorgu += "&signature=" + build_query_signature(sorgu, k["secret"])

    if method == "GET":
        istek = urllib.request.Request(f"{BASE_URL}{path}?{sorgu}", method="GET")
    else:
        istek = urllib.request.Request(BASE_URL + path, data=sorgu.encode(), method=method)
        istek.add_header("Content-Type", "application/x-www-form-urlencoded")
    istek.add_header("X-MBX-APIKEY", k["key"])
    return send_with_retry(istek, timeout=timeout, retry=retry)


# --------------------------------------------------------------- uc noktalar

# Hesap bakiyeleri.
def fetch_account_balances() -> dict:
    return signed_request("/api/v3/account")


# Bir sembolun gerceklesmis islemleri.
def fetch_my_trades(symbol: str, *, limit: int = 50) -> list:
    return signed_request("/api/v3/myTrades", symbol=symbol, limit=limit)


# Tek emrin borsa durumu.
def fetch_order_status(symbol: str, order_id: int) -> dict:
    return signed_request("/api/v3/order", symbol=symbol, orderId=order_id)


# Idempotent emir kimligi uretir -- ag zaman asiminda emri bulabilmek icin.
def make_client_order_id(prefix: str = "cn") -> str:
    return f"{prefix}{uuid.uuid4().hex[:20]}"


# Emir gonderir. `client_order_id` verilmezse uretilir (idempotency).
def submit_order(symbol: str, side: str, order_type: str, *, quantity: float,
                 price: float | None = None, time_in_force: str | None = None,
                 client_order_id: str | None = None) -> dict:
    return signed_request(
        "/api/v3/order", method="POST", retry=False,   # emir ASLA korlemesine tekrarlanmaz
        symbol=symbol, side=side.upper(), type=order_type.upper(),
        quantity=quantity, price=price, timeInForce=time_in_force,
        newClientOrderId=client_order_id or make_client_order_id())


# Acik emri iptal eder.
def cancel_order(symbol: str, order_id: int) -> dict:
    return signed_request("/api/v3/order", method="DELETE", retry=False,
                          symbol=symbol, orderId=order_id)


# Emir defteri derinligi -- limit fiyati buradan secilir.
def fetch_order_book(symbol: str, *, limit: int = 10) -> dict:
    return public_request("/api/v3/depth", symbol=symbol, limit=limit)


# Mum verisi.
def fetch_klines(symbol: str, interval: str, *, limit: int = 500,
                 start_time: int | None = None, end_time: int | None = None) -> list:
    return public_request("/api/v3/klines", symbol=symbol, interval=interval,
                          limit=limit, startTime=start_time, endTime=end_time)


# Tek sembolun fiyati (agirlik 1).
def fetch_ticker_price(symbol: str) -> dict:
    return public_request("/api/v3/ticker/price", symbol=symbol)


# TUM sembollerin fiyati -- agirlik 4. Bilerek ve seyrek cagrilir;
# eski sistemde websocket koptugunda saniyede bir cagriliyordu.
def fetch_all_ticker_prices() -> list:
    return public_request("/api/v3/ticker/price")


# Sembol kurallari (LOT_SIZE, PRICE_FILTER, MIN_NOTIONAL).
def fetch_exchange_info(symbol: str | None = None) -> dict:
    return public_request("/api/v3/exchangeInfo", symbol=symbol)
