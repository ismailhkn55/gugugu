"""Cuzdan ve defter istatistigi -- TEK hesap.

Eski sistemde ayni hesap UC yerde ayri ayri yaziliydi: `bakiye()`,
`bot_cuzdan()`, `gercek_cuzdan()` -- kilitli/serbest hesabi ve
balance->USDT donguleri birebir kopyaydi. `istatistik()` ile
`istatistik_defter(canli)` ise 18 satiri aynı olup yalnizca defter
secimiyle ayriliyordu; ustelik `istatistik()` AKTIF MODUN defterini
okuyordu, bu yuzden `/yerel/gecmis?kaynak=dry` istense bile CANLI
istatistik donuyordu.
"""
from __future__ import annotations

from typing import Any, Mapping

from app.core.applog import get_logger, log_once
from app.trading.ledger import list_closed_orders, list_open_orders, load_ledger

_log = get_logger(__name__)


# Defter istatistigi. `live` ZORUNLU -- eski `istatistik()` aktif moda
# bakip yanlis defteri okuyordu.
# `sadece`: "el" -> dugmelerle acilanlar, "bot" -> botun actiklari,
# None -> hepsi. Cuzdan sayfasi "el" kullanir; bot sayfasi "bot".
# (23.09.2026, Ismail: "strategy/bot - cuzdan/canli bunlar farkli seyler")
def compute_ledger_stats(live: bool, *, sadece: str | None = None) -> dict:
    kapali = [e for e in load_ledger(live)["emirler"] if e.get("kapanis")]
    if sadece == "el":
        kapali = [e for e in kapali if e.get("el_kaynak")]
    elif sadece == "bot":
        kapali = [e for e in kapali if not e.get("el_kaynak")]
    karlar = [float(e["kar_p"]) for e in kapali if e.get("kar_p") is not None]
    if not karlar:
        return {"islem": 0, "kazanan": 0, "kaybeden": 0, "isabet": None,
                "ortalama": None, "toplam": 0.0, "en_iyi": None, "en_kotu": None}
    kazanan = [k for k in karlar if k > 0]
    return {
        "islem": len(karlar),
        "kazanan": len(kazanan),
        "kaybeden": len(karlar) - len(kazanan),
        "isabet": round(len(kazanan) / len(karlar) * 100, 2),
        "ortalama": round(sum(karlar) / len(karlar), 3),
        "toplam": round(sum(karlar), 3),
        "en_iyi": round(max(karlar), 3),
        "en_kotu": round(min(karlar), 3),
    }


def _acik_tutar(live: bool) -> float:
    """Acik pozisyonlarda bagli duran USDT -- GIRIS maliyeti."""
    return sum(float(e.get("tutar") or 0) for e in list_open_orders(live))


# Acik pozisyonlari ANLIK fiyattan degerlendirir (mark-to-market).
#
# 24.09.2026, Ismail: "acik tradeler botun parasinda oynama yapmiyor ...
# gercek cuzdanda oynama yapiyor ya o sekilde bot cuzdani da hareket
# etmeli". Eski hesap `kilitli`yi giris maliyetine esitliyor ve `toplam`
# acik K/Z'i hic katmiyordu -- fiyat oynadikca ekrandaki rakamlar donuk
# kaliyordu.
#
# Donus: (anlik piyasa degeri, giris maliyeti). Fiyati bulunamayan
# pozisyon GIRIS MALIYETINE esitlenir: uydurulan fiyat yok, sifir da yok.
def _acik_piyasa(live: bool) -> tuple[float, float]:
    acik = list_open_orders(live)
    if not acik:
        return 0.0, 0.0
    from app.market.price_source import get_prices
    try:
        fiyatlar = get_prices(sorted({e["sembol"] for e in acik if e.get("sembol")}))
    except Exception as e:  # noqa: BLE001 - ag hatasi cuzdan hesabini durdurmaz
        log_once(_log, "wallet-price", f"pozisyon fiyatlari alinamadi: {e}")
        fiyatlar = {}
    deger, maliyet = 0.0, 0.0
    for e in acik:
        tutar = float(e.get("tutar") or 0)
        maliyet += tutar
        f, _k = fiyatlar.get(e.get("sembol"), (None, None))
        mik = float(e.get("dolan_miktar") or e.get("miktar") or 0)
        deger += mik * float(f) if (f and mik) else tutar
    return deger, maliyet


# Kagit/bot cuzdan: ana para + gerceklesmis kar +- ACIK pozisyon K/Z.
def get_paper_wallet(settings: Mapping[str, Any]) -> dict:
    baslangic = float(settings.get("kagit_bakiye", 30.0))
    ist = compute_ledger_stats(False)
    kapali = list_closed_orders(False)
    gerceklesmis = sum(float(e.get("kar") or 0) for e in kapali)
    kilitli, giris_maliyet = _acik_piyasa(False)
    acik_kar = kilitli - giris_maliyet
    # toplam = nakit + eldeki coinlerin ANLIK degeri
    toplam = baslangic + gerceklesmis + acik_kar
    return {"kaynak": "kagit", "baslangic": baslangic, "toplam": round(toplam, 4),
            "serbest": round(toplam - kilitli, 4), "kilitli": round(kilitli, 4),
            "acik_kar": round(acik_kar, 4),
            "giris_maliyeti": round(giris_maliyet, 4),
            "istatistik": ist}


# Gercek Binance cuzdani. Ag hatasinda None doner -- sessizce sifir gostermez.
def get_live_wallet() -> dict | None:
    from app.exchange.binance_rest import fetch_account_balances
    from app.market.price_source import get_prices
    try:
        hesap = fetch_account_balances()
    except Exception as e:
        log_once(_log, "wallet-live", f"gercek cuzdan alinamadi: {e}")
        return None
    para, semboller = [], []
    for b in hesap.get("balances", []):
        serbest, kilitli = float(b.get("free") or 0), float(b.get("locked") or 0)
        if serbest + kilitli <= 0:
            continue
        para.append({"para": b["asset"], "serbest": serbest, "kilitli": kilitli})
        if b["asset"] != "USDT":
            semboller.append(b["asset"] + "USDT")
    fiyatlar = get_prices(semboller) if semboller else {}
    toplam = 0.0
    for p in para:
        if p["para"] == "USDT":
            p["usdt"] = p["serbest"] + p["kilitli"]
        else:
            f, _k = fiyatlar.get(p["para"] + "USDT", (None, "yok"))
            p["usdt"] = (p["serbest"] + p["kilitli"]) * float(f) if f else None
        toplam += p["usdt"] or 0.0
    usdt = next((p for p in para if p["para"] == "USDT"), None)
    return {"kaynak": "canli", "toplam": round(toplam, 4),
            "serbest": round(usdt["serbest"], 4) if usdt else 0.0,
            "para": sorted(para, key=lambda x: -(x.get("usdt") or 0)),
            "istatistik": compute_ledger_stats(True)}


# Aktif moda gore cuzdan. `live` ZORUNLU.       (eski: bakiye)
def get_wallet(live: bool, settings: Mapping[str, Any]) -> dict:
    if live:
        c = get_live_wallet()
        if c is not None:
            return c
        return {"kaynak": "canli", "toplam": None, "serbest": None, "para": [],
                "istatistik": compute_ledger_stats(True),
                "hata": "Binance'e ulasilamadi"}
    return get_paper_wallet(settings)


# Cuzdan genel gorunumu: GERCEK borsa cuzdani ve KAGIT cuzdan BIRLIKTE.
#
# 23.09.2026, Ismail: "cuzdan canli modda da olsa dry run da da olsa gercek
# degeri ve mevcut coinlerimizi gosterecek ... dry run da bile olsak ben
# binanceden coin alir isem cuzdanda onu takip edecek".
# Onceki davranis `get_wallet(live)` idi: kagit modda gercek bakiye HIC
# gosterilmiyordu, dolayisiyla borsadan elle alinan bir coin panelde
# gorunmuyordu.
#
# DIKKAT: emir yolundaki bakiye kontrolu (`get_free_quote_balance`) moda
# BAGLI kalmali -- kagit modda gercek parayla sinirlanmak yanlis olur.
# Bu yuzden `get_wallet` degistirilmedi; bu yalnizca GORUNUM fonksiyonu.
def get_wallet_overview(settings: Mapping[str, Any]) -> dict:
    from app.config.secrets import has_api_credentials
    anahtar = has_api_credentials()
    gercek = get_live_wallet() if anahtar else None
    return {
        "canli": bool(settings.get("canli")),
        "kaynak": "canli" if settings.get("canli") else "dry",
        "anahtar_var": anahtar,
        "gercek": gercek,
        "gercek_hata": None if gercek else (
            "Binance API anahtari kayitli degil" if not anahtar
            else "Binance'e ulasilamadi"),
        "kagit": get_paper_wallet(settings),
    }


# Alim icin kullanilabilir USDT.                (eski: serbest_usdt)
def get_free_quote_balance(live: bool, settings: Mapping[str, Any]) -> float:
    c = get_wallet(live, settings)
    return float(c.get("serbest") or 0)
