import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.core.applog import setup_logging
from app.market import indicators as IND, rank_repository as RR, exclusions as EX
setup_logging()

print("=== SUTUN KAYIT DEFTERI ===")
print("  kayitli sutun :", len(IND.COLUMN_REGISTRY))
print("  DB'den secilen:", len(IND.list_column_names()))
print("  turetilmis    :", [c.name for c in IND.COLUMN_REGISTRY if c.derived])
print("  renk alanlari :", len(IND.COLOR_SOURCE))
print("  kural alanlari:", len(IND.list_available_fields()))

print("\n=== SEMA SOZLESMESI vs GERCEK rank.sqlite ===")
r = RR.verify_schema_contract()
print(f"  veritabani sutun : {r['db_sutun']}")
print(f"  kayit defteri    : {r['defter_sutun']}")
print(f"  UYUMLU           : {r['uyumlu']}")
print(f"  defterde var DB'de yok : {r['eksik'] or 'yok'}")
print(f"  DB'de var defterde yok : {r['fazla'] or 'yok'}")

print("\n=== ema4 TUZAGI ===")
for alan in ("ema7", "ema20", "wma48", "ema4", "iz_yon", "renk_deg1h", "uydurma_alan"):
    print(f"  is_known_field({alan!r:16}) = {IND.is_known_field(alan)}")

print("\n=== HARIC LISTESI ===")
h = EX.load_excluded_symbols()
print("  haric sembol (iki bicim dahil):", len(h))
print("  ornek:", sorted(h)[:6])

print("\n=== GERCEK VERI (salt okunur) ===")
k = RR.fetch_db_coverage()
print(f"  toplam satir: {k['satir']:,}  tur: {k['tur']:,}")
d = RR.fetch_latest_snapshot(limit=400)
s = d["satir"]
print(f"  son turda {len(s)} coin, {len(d['turlar'])} tur izi")
x = s[0]
print(f"  ornek: {x['sembol']} rank={x['rank']} fiyat={x['fiyat']}")
print(f"    ema7={x['ema7']}  ema20={x['ema20']}  wma48={x['wma48']}")
print(f"    rsi={x['rsi']}  cci={x['cci']}  kdj_j={x['kdj_j']}")
print(f"    sira_izi={x['sira_izi'][:6]}...  iz_yon={x['iz_yon']}")
bos = [c for c in IND.list_column_names() if x.get(c) is None]
print(f"  bu satirda NULL olan sutunlar: {bos or 'yok'}")

print("\n=== iz_yon: 'olculmedi' ile 'kipirdamadi' AYRI MI ===")
print("  tek turluk iz  ->", RR.compute_trail_direction([5]), "(None = olculmedi)")
print("  degismemis iz  ->", RR.compute_trail_direction([5, 5, 5]), "(0.0 = kipirdamadi)")
print("  tirmanan iz    ->", RR.compute_trail_direction([30, 20, 10]), "(pozitif = yukari)")

print("\n=== HESAPLAR (bilinen girdilerle) ===")
kapanis = [10, 11, 12, 11, 13, 14, 13, 15, 16, 15, 17, 18, 17, 19, 20, 19, 21, 22, 21, 23]
print("  EMA(5) son     :", round(IND.compute_ema(kapanis, 5)[-1], 4))
print("  WMA(5)         :", round(IND.compute_wma(kapanis, 5), 4))
rsi, egim = IND.compute_rsi(kapanis, 14)
print("  RSI(14)        :", round(rsi, 2), " egim:", round(egim, 2))
h_, l_ = [c + 1 for c in kapanis], [c - 1 for c in kapanis]
print("  ATR%(14)       :", round(IND.compute_atr_percent(h_, l_, kapanis, 14), 4))
print("  CCI(20)        :", round(IND.compute_cci(h_, l_, kapanis, 20), 2))
print("  KDJ J          :", round(IND.compute_kdj_j(h_, l_, kapanis, 9), 2))
ohlc = [(c - 0.5, c + 1, c - 1, c) for c in kapanis]
ha = IND.build_heikin_ashi(ohlc)
print("  HA ardisik yesil:", IND.count_consecutive_green_ha(ha))
print("  HA yesil yukselis:", round(IND.measure_green_ha_gain(ha) or 0, 3))
print("  yesile donus     :", IND.count_bars_since_green_flip(ohlc))
