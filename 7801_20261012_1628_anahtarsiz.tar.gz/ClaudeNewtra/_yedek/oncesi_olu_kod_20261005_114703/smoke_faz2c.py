"""Faz 2 kapanis: registry dogrulamasi, aday secimi, geriye-test."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/DATA/AppData/Newtrade")
from app.core.applog import setup_logging
from app.core.errors import UnknownFieldError
from app.market import rank_repository as RR, candles as CN
from app.strategy import registry as REG, entry as EN, backtest as BT, rule_engine as RE
import strateji as ESKI
setup_logging()

print("=== 1) STRATEJI DOGRULAMA (kaydederken) ===")
st = REG.get_active_strategy(live=False)
print(f"  aktif (kagit): {st['ad']}")
print(f"  dogrulama: {REG.validate_strategy(st) or 'TEMIZ'}")
bozuk = {"ad": "TEST", "kurallar": [{"alan": "ema4", "op": ">", "deger": 0}],
         "cikis": st["cikis"], "stop": st["stop"]}
print(f"  ema4 iceren strateji -> {REG.validate_strategy(bozuk)}")
try:
    REG.save_strategy(bozuk)
    print("  HATA: bozuk strateji kaydedildi!")
except UnknownFieldError as e:
    print(f"  kaydetme REDDEDILDI: {e}")

print("\n=== 2) ACIKLAMA vs CALISAN KURALLAR ===")
print(f"  calisan kurallar: {REG.stamp_measurement_context(st)}")
acik = (st.get("aciklama") or "")[:150].replace("\n", " ")
print(f"  aciklama (ilk 150): {acik}...")
print("  -> aciklamadaki olcum sonuclari bu kural kumesine AIT DEGIL")

print("\n=== 3) ADAY SECIMI — eski motorla kiyas ===")
d = RR.fetch_latest_snapshot(limit=400)
satirlar = d["satir"]
yeni = EN.select_candidates(satirlar, st, limit=20)
eski = ESKI.adaylar(satirlar, st, limit=20)
print(f"  taranan: {yeni['tarandi']}  yeni aday: {len(yeni['aday'])}  eski aday: {len(eski)}")
ys = [x["sembol"] for x in yeni["aday"]]
es = [x["sembol"] for x in eski]
print(f"  AYNI SIRA VE KUME: {ys == es}")
print(f"  aday: {', '.join(ys[:8]) or '(yok)'}")
if yeni["yapilandirma_hatasi"]:
    print(f"  yapilandirma hatasi: {yeni['yapilandirma_hatasi']}")
if satirlar:
    r = EN.is_entry_allowed(satirlar[-1], st)
    print(f"  ornek eleme gerekcesi ({satirlar[-1]['sembol']}): {EN.explain_entry_rejection(r)}")

print("\n=== 4) GERIYE-TEST: sinanabilirlik ===")
bosluk = BT.summarize_backtest_gaps(st)
print(f"  sinanabilir kural : {bosluk['sinanabilir']}")
print(f"  SINANAMAZ kural   : {bosluk['sinanamaz']}")
print(f"  tam sinanabilir mi: {bosluk['tam_sinanabilir']}")

print("\n=== 5) GERIYE-TEST: gercek mumlarla ===")
sem = ys[0] if ys else satirlar[0]["sembol"]
t0 = time.time()
mumlar = CN.fetch_candle_page(sem, "5m", limit=500)
sonuc = BT.replay_strategy_signals(mumlar, st, warmup=60, max_bars=200)
print(f"  {sem}: {len(mumlar)} mum, {sonuc['taranan_bar']} bar tarandi "
      f"({time.time()-t0:.1f} sn)")
print(f"  tetiklenme noktasi: {len(sonuc['noktalar'])}")
for n in sonuc["noktalar"][:3]:
    print(f"    bar {n['bar']}  fiyat {n['fiyat']}")
print(f"  sinanan kural  : {sonuc['sinanan_kural']}")
print(f"  SINANAMAYAN    : {sonuc['sinanamayan_kural']}")
if sonuc["uyari"]:
    print(f"  UYARI: {sonuc['uyari']}")
