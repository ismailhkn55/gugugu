"""Geriye-test raporu + ANINDA K/Z icin gosterge onbellegi (katman 8, reporting).

NEDEN ONBELLEK (02.10.2026 olcumu): tek sembolun 2 gunluk (576 bar, 300 bar
pencere) gosterge satirlari 0.68 sn suruyor; 20 sembol ~14 sn. Gostergeler
STRATEJIDEN BAGIMSIZ, yalniz mumlara bagli -> bir kez hesaplanir, her yeni
KAPANMIS 5 dk mumda yalniz o tek satir eklenir. Strateji her degistiginde
yalniz kural degerlendirmesi + cikis simulasyonu kosar (milisaniyeler).

ISTEK HIC BEKLEMEZ: soguk dolum da artimli guncelleme de TEK bir arka plan
is parcaciginda, sirayla yapilir. Istek eldeki onbellekle aninda cevaplanir
(en fazla bir bar eski olabilir; yanitta yazar).

BAN/YUK KORUMASI (Ismail: "api ban yer, surekli sorgu atma"):
  * soguk dolum: sembol basina TEK istek (877 mum), sirayla, aralarinda bekleme
  * guncelleme: bir sembol icin ancak YENI MUM KAPANDIKTAN sonra (en fazla
    5 dk'da bir), 5 mumluk kucuk istek
  * `dis_istek` sayaci yanitla doner -- olculebilir
Yalniz KAPANMIS mumlar kullanilir (olusan mum yeniden boyanir).

ES ZAMANLILIK: onbellek kaydi hic YERINDE degistirilmez; guncelleme yeni
listeler kurar ve kilit altinda tek seferde yerine koyar. Okuyan istek
elindeki eski kaydi tutarli bicimde kullanmaya devam eder.
"""
from __future__ import annotations

import threading
import time
from collections import OrderedDict

from app.config.settings import load_settings
from app.core.applog import get_logger, log_once
from app.core.timeutil import now_ms
from app.market.candles import CANLI_PENCERE, build_indicator_frame, fetch_candle_page
from app.market.rank_repository import fetch_latest_snapshot
from app.reporting.journal_analysis import summarize_trade_profile
from app.strategy.backtest import build_history_rows, simulate_strategy_trades
from app.trading.exit_rules import plan_for_source

_log = get_logger(__name__)

BT_BAR = 576                 # 2 gun x 5 dk
BT_HIZLI_SEMBOL = 20         # anlik panel evreni
BT_GENIS_SEMBOL = 60         # "genis test"
BT_ONBELLEK_TAVAN = 80       # bellek siniri (en eski kullanilan atilir)
BT_ISTEK_ARASI_SN = 0.25     # arka plan istekleri arasi nefes
BAR_MS = 300_000

_kilit = threading.Lock()
_onbellek: "OrderedDict[str, dict]" = OrderedDict()   # sembol -> {"mumlar", "satirlar"}
_isinma = {"calisiyor": False, "kuyruk": [], "dis_istek": 0, "hata": 0}


def _kapanmis(mumlar: list) -> list:
    """Kapanis zamani gecmemis (olusan) mumu atar."""
    simdi = now_ms()
    return [m for m in mumlar if int(m[0]) + BAR_MS <= simdi]


def _bayat_mi(kayit: dict) -> bool:
    return now_ms() >= int(kayit["mumlar"][-1][0]) + 2 * BAR_MS


def _soguk_doldur(sembol: str) -> dict | None:
    with _kilit:
        _isinma["dis_istek"] += 1
    mumlar = _kapanmis(fetch_candle_page(sembol, "5m", limit=CANLI_PENCERE + BT_BAR + 1))
    satirlar = build_history_rows(mumlar, warmup=CANLI_PENCERE, max_bars=BT_BAR)
    return {"mumlar": mumlar, "satirlar": satirlar} if satirlar else None


def _artimli(kayit: dict, sembol: str) -> dict:
    """YENI bir kayit doner (eskisine dokunmaz)."""
    son = int(kayit["mumlar"][-1][0])
    with _kilit:
        _isinma["dis_istek"] += 1
    yeni = [m for m in _kapanmis(fetch_candle_page(sembol, "5m", limit=5)) if int(m[0]) > son]
    if not yeni:
        return kayit
    if int(yeni[0][0]) != son + BAR_MS:      # arada bosluk var -> bastan doldur
        return _soguk_doldur(sembol) or kayit
    mumlar, satirlar = list(kayit["mumlar"]), list(kayit["satirlar"])
    for m in yeni:
        mumlar.append(m)
        satir = build_indicator_frame(mumlar)
        if satir:
            satirlar.append(satir)
    return {"mumlar": mumlar[-(CANLI_PENCERE + BT_BAR):], "satirlar": satirlar[-BT_BAR:]}


# Bir sembolun gosterge gecmisini doldurur ya da gunceller (ARKA PLAN is parcacigi cagirir).
def ensure_symbol_history(sembol: str) -> dict | None:
    with _kilit:
        kayit = _onbellek.get(sembol)
    try:
        if kayit is None:
            yeni = _soguk_doldur(sembol)
        elif _bayat_mi(kayit):
            yeni = _artimli(kayit, sembol)
        else:
            return kayit
    except Exception as e:
        with _kilit:
            _isinma["hata"] += 1
        log_once(_log, f"bt-{sembol}", f"geriye-test mumlari alinamadi ({sembol}): {e}")
        return kayit
    if yeni is None:
        return kayit
    with _kilit:
        _onbellek[sembol] = yeni
        _onbellek.move_to_end(sembol)
        while len(_onbellek) > BT_ONBELLEK_TAVAN:
            _onbellek.popitem(last=False)
    return yeni


def _isit() -> None:
    while True:
        with _kilit:
            if not _isinma["kuyruk"]:
                _isinma["calisiyor"] = False
                return
            s = _isinma["kuyruk"].pop(0)
        ensure_symbol_history(s)
        time.sleep(BT_ISTEK_ARASI_SN)


# Eksik ya da bayat sembolleri ARKA PLANDA (tek is parcacigi, sirayla) doldurur.
def warm_backtest_cache(semboller: list[str]) -> None:
    with _kilit:
        for s in semboller:
            if s not in _isinma["kuyruk"]:
                _isinma["kuyruk"].append(s)
        if _isinma["calisiyor"] or not _isinma["kuyruk"]:
            return
        _isinma["calisiyor"] = True
    threading.Thread(target=_isit, name="bt-isinma", daemon=True).start()


# Geriye-test evreni: son toplayici turundaki coinler, 24s USDT HACMINE gore ilk `n`.
#
# 02.10.2026 OLCUMU: ilk surum toplayicinin RANK sirasini (en cok yukselenler)
# kullaniyordu -> "Hacim BB Tetik" %88 isabet gosterdi, ama ayni 20 coin 2 gunde
# al-tut ile ort. +%13.2 yukselmisti: gecmise BUGUNUN KAZANANLARIYLA bakiliyordu
# (hayatta kalan yanliligi). Likidite son performanstan cok daha az etkilenir.
# Tam yansiz degil -- arayuz al-tut kiyasini ve bu notu gosterir.
def get_backtest_universe(n: int) -> list[str]:
    satir = fetch_latest_snapshot(limit=400).get("satir") or []
    satir = [r for r in satir if r.get("sembol") and r.get("hacim")]
    satir.sort(key=lambda r: -float(r["hacim"]))
    return [r["sembol"] for r in satir[:n]]


def _al_tut(seri: list) -> float | None:
    if len(seri) < 2:
        return None
    a, b = float(seri[0][1][1]), float(seri[-1][1][4])
    return (b / a - 1) * 100 if a > 0 else None


# Stratejiyi (kaydedilmis YA DA taslak) onbellekteki gecmiste kosturur; ASLA beklemez.
def run_backtest(strategy: dict, *, wide: bool = False,
                 symbols: list[str] | None = None) -> dict:
    t0 = time.perf_counter()
    ayar = load_settings()
    evren = symbols or get_backtest_universe(BT_GENIS_SEMBOL if wide else BT_HIZLI_SEMBOL)
    with _kilit:
        kayitlar = {s: _onbellek[s] for s in evren if s in _onbellek}
        for s in kayitlar:
            _onbellek.move_to_end(s)
    gerekli = [s for s in evren if s not in kayitlar or _bayat_mi(kayitlar[s])]
    if gerekli:
        warm_backtest_cache(gerekli)
    with _kilit:
        dis = _isinma["dis_istek"]
    if not kayitlar:
        return {"hazirlaniyor": True, "hazir": 0, "toplam": len(evren), "dis_istek": dis}

    seriler = {}
    for s, k in kayitlar.items():
        mum_ts = {int(m[0]): m for m in k["mumlar"]}
        seriler[s] = [(r, mum_ts[int(r["ts"])]) for r in k["satirlar"] if int(r["ts"]) in mum_ts]

    plan = plan_for_source(None, ayar, strategy=strategy)
    tutar = float(strategy.get("tutar") or ayar.get("tutar") or 30.0)
    maks = int(strategy.get("maks_pozisyon", 3) or 3)
    komisyon = float(ayar.get("komisyon_toplam", 0) or 0)
    sim = simulate_strategy_trades(
        seriler, strategy, plan, fee_pct=komisyon, max_positions=maks,
        cooldown_min=float(ayar.get("coin_bekleme_dk", 0) or 0), amount=tutar)
    islem = sim["islemler"]
    profil = summarize_trade_profile(islem)
    al_tut = [x for x in (_al_tut(v) for v in seriler.values()) if x is not None]
    ilk = min((v[0][0]["ts"] for v in seriler.values() if v), default=None)
    son = max((v[-1][0]["ts"] for v in seriler.values() if v), default=None)
    sermaye = tutar * maks
    return {
        "hazirlaniyor": len(kayitlar) < len(evren), "hazir": len(kayitlar),
        "toplam": len(evren), "bayat": len([s for s in gerekli if s in kayitlar]),
        "strateji": strategy.get("ad"), "tutar": tutar, "komisyon_p": komisyon,
        "maks_pozisyon": maks,
        "donem": {"bas": ilk, "son": (son + BAR_MS) if son else None, "bar": BT_BAR},
        "semboller": sorted(seriler),
        "profil": profil,
        "ort_net_p": round(sum(t["kar_p"] for t in islem) / len(islem), 3) if islem else None,
        # Yuzdeler TOPLANMAZ (bkz. pnl.build_daily_pnl, "-57" dersi): getiri,
        # toplam USDT K/Z'nin AYNI ANDA gereken en buyuk sermayeye orani.
        "sermaye": sermaye,
        "sermaye_getiri_p": round(profil.get("toplam_kar", 0) / sermaye * 100, 3) if islem and sermaye else None,
        "al_tut_ort_p": round(sum(al_tut) / len(al_tut), 3) if al_tut else None,
        "islemler": islem[-300:], "islem_toplam": len(islem),
        "acik": sim["acik"], "sinyal": sim["sinyal"], "atlanan_sinyal": sim["atlanan_sinyal"],
        "sinanan_kural": sim["sinanan_kural"], "sinanamayan_kural": sim["sinanamayan_kural"],
        "tam_sinanabilir": sim["tam_sinanabilir"], "uyari": sim.get("uyari"),
        "sure_ms": round((time.perf_counter() - t0) * 1000, 1), "dis_istek": dis,
    }


# Onbellekteki bir sembolun kapanis serisi (grafik icin) -- dis istek ATMAZ.
def get_cached_close_series(sembol: str) -> list[list] | None:
    with _kilit:
        k = _onbellek.get(sembol)
    if not k:
        return None
    n = len(k["satirlar"])
    return [[int(m[0]), float(m[4])] for m in k["mumlar"][-n:]]


# Onbellek durumu (saglik/tanilama).
def describe_backtest_cache() -> dict:
    with _kilit:
        return {"sembol": len(_onbellek), "kuyruk": len(_isinma["kuyruk"]),
                "isiniyor": _isinma["calisiyor"], "dis_istek": _isinma["dis_istek"],
                "hata": _isinma["hata"]}
