"""Islem gunlugu analizi -- profil + 4 davranis teshisi (katman 8, reporting).

vibe-trading'in `analyze_trade_journal` ozelliginin 7801'e KENDI KODU olarak
tasinmasi (01.10.2026; vibe kaldirilacak, cagrilmaz). Harici paket yok
(host'ta pandas yok) -- saf Python.

FARK (bilerek): vibe CSV'deki al/sat satirlarini FIFO ile YENIDEN eslestiriyordu
ve bizim defterde 303 islemden 310 "roundtrip" uretip toplam K/Z'yi kaydiriyordu
(-7.08 yerine +1.76). Defterde her kayit zaten TAM bir islemdir (giris + kapanis
+ gercek `kar`); burada yeniden eslestirme YAPILMAZ, defterin kendi sonucu kullanilir.

Davranis esikleri ve tanimlari vibe ile BIREBIR (pandas'in davranisi dahil:
ceyreklik = dogrusal ara degerleme, std = orneklem std, dusus tepe = ilk
birikimli deger).
"""
from __future__ import annotations

import datetime
import math
import re
import statistics
from collections import defaultdict

from app.trading.ledger import list_closed_orders

TOZ_TUTAR_USDT = 1.0          # bunun altindaki islemler eski test artigi (0.01-0.4 USDT)
PUMP_ESIK = 1.03              # vibe: son alis, 3 alis onceki fiyattan %3 yuksekse "kovalama"
CAPA_CV_ESIK = 0.05           # vibe: fiyat degisim katsayisi < %5 ise "capalanma"
CAPA_MIN_SATIR = 5


def _utc_gun(ms: int) -> str:
    return datetime.datetime.fromtimestamp(ms / 1000, datetime.UTC).strftime("%Y-%m-%d")


# Defterdeki kapanmis islemleri tek bicime cevirir; toz (< TOZ_TUTAR_USDT) varsayilan olarak dislanir.
def load_closed_trades(live: bool, *, include_dust: bool = False,
                       until_ms: int | None = None) -> tuple[list[dict], int]:
    cikti, toz = [], 0
    for e in list_closed_orders(live):
        k = e.get("kapanis") or {}
        if not k.get("ts") or not e.get("ts"):
            continue
        if until_ms is not None and int(k["ts"]) > until_ms:
            continue
        tutar = float(e.get("tutar") or 0)
        if tutar < TOZ_TUTAR_USDT and not include_dust:
            toz += 1
            continue
        kar = e.get("kar")
        turetildi = False
        if kar is None and e.get("kar_p") is not None and tutar:
            kar = tutar * float(e["kar_p"]) / 100.0     # pnl.build_daily_pnl ile ayni turetme
            turetildi = True                            # ekranda belirtilir: USDT defterde yoktu
        if kar is None:
            continue
        miktar = float(e.get("miktar") or e.get("dolan_miktar") or 0)
        cikti.append({
            "sembol": e.get("sembol"),
            "giris_ts": int(e["ts"]),
            "cikis_ts": int(k["ts"]),
            "giris_fiyat": float(e.get("fiyat") or e.get("dolan_fiyat") or 0),
            "cikis_fiyat": float(k.get("fiyat") or 0),
            "miktar": miktar,
            "tutar": tutar,
            "kar": float(kar),
            "kar_p": float(e.get("kar_p") or 0),
            "sebep": str(k.get("sebep") or "?"),
            "el": bool(e.get("el_kaynak")),
            "turetildi": turetildi,
        })
    cikti.sort(key=lambda t: t["cikis_ts"])
    return cikti, toz


# Cikis sebebini kategoriye indirir: "STOP:kilit_%2.2" -> "STOP:kilit", "HEDEF:%1.8" -> "HEDEF".
def classify_exit_reason(reason: str) -> str:
    parca = (reason or "?").split(":")
    if parca[0] == "STOP" and len(parca) > 1:
        return "STOP:" + (re.split(r"[_%]", parca[1])[0] or parca[1])
    if parca[0] == "HEDEF":
        return "HEDEF"
    return parca[0]


# pandas Series.quantile ile ayni: dogrusal ara degerleme.
def compute_linear_quantile(values: list[float], q: float) -> float:
    s = sorted(values)
    if not s:
        return math.nan
    poz = (len(s) - 1) * q
    alt = math.floor(poz)
    ust = min(alt + 1, len(s) - 1)
    return s[alt] + (s[ust] - s[alt]) * (poz - alt)


# Skoru dusuk/orta/yuksek'e cevirir (vibe `_severity` ile ayni).
def rate_severity(score: float, medium: float, high: float) -> str:
    if score >= high:
        return "yuksek"
    if score >= medium:
        return "orta"
    return "dusuk"


def _ortalama(x: list[float]) -> float:
    return sum(x) / len(x) if x else 0.0


# Profil: isabet, kazanc/kayip orani, PF, toplam, dusus, egri, sebep ve sembol kirilimi.
def summarize_trade_profile(trades: list[dict]) -> dict:
    if not trades:
        return {"islem": 0}
    kaz = [t for t in trades if t["kar"] > 0]
    kay = [t for t in trades if t["kar"] < 0]
    ort_kaz = _ortalama([t["kar"] for t in kaz])
    ort_kay = _ortalama([t["kar"] for t in kay])
    top_kaz = sum(t["kar"] for t in kaz)
    top_kay = sum(t["kar"] for t in kay)

    egri, birikim, tepe, dusus = [], 0.0, None, 0.0
    for t in trades:                                     # cikis zamanina gore sirali
        birikim += t["kar"]
        tepe = birikim if tepe is None else max(tepe, birikim)
        dusus = min(dusus, birikim - tepe)
        egri.append({"ts": t["cikis_ts"], "birikim": round(birikim, 4)})

    def _grup(anahtar) -> list[dict]:
        g: dict[str, list[dict]] = defaultdict(list)
        for t in trades:
            g[anahtar(t)].append(t)
        satir = [{"ad": ad, "islem": len(v),
                  "kar": round(sum(x["kar"] for x in v), 4),
                  "isabet": round(sum(1 for x in v if x["kar"] > 0) / len(v) * 100, 1),
                  "ort_kar_p": round(_ortalama([x["kar_p"] for x in v]), 3)}
                 for ad, v in g.items()]
        return sorted(satir, key=lambda r: r["kar"])

    sureler = [(t["cikis_ts"] - t["giris_ts"]) / 60000 for t in trades]
    gun = max(1, (trades[-1]["cikis_ts"] - min(t["giris_ts"] for t in trades)) // 86400000)
    return {
        "islem": len(trades),
        "kazanan": len(kaz),
        "kaybeden": len(kay),
        "notr": len(trades) - len(kaz) - len(kay),
        "isabet": round(len(kaz) / len(trades) * 100, 2),
        "ort_kazanc": round(ort_kaz, 4),
        "ort_kayip": round(ort_kay, 4),
        "ort_kazanc_p": round(_ortalama([t["kar_p"] for t in kaz]), 3),
        "ort_kayip_p": round(_ortalama([t["kar_p"] for t in kay]), 3),
        "kazanc_kayip_orani": round(ort_kaz / abs(ort_kay), 2) if ort_kay else None,
        "kar_faktoru": round(top_kaz / abs(top_kay), 2) if top_kay else None,
        "toplam_kar": round(sum(t["kar"] for t in trades), 4),
        "turetilen": sum(1 for t in trades if t["turetildi"]),
        "bagli_tutar": round(sum(t["tutar"] for t in trades), 2),
        "maks_dusus": round(dusus, 4),
        "medyan_sure_dk": round(statistics.median(sureler), 1),
        "haftalik_islem": round(len(trades) / gun * 7, 2),
        "ilk_ts": trades[0]["giris_ts"],
        "son_ts": trades[-1]["cikis_ts"],
        "egri": egri,
        "sebep": _grup(lambda t: classify_exit_reason(t["sebep"])),
        "sembol": _grup(lambda t: t["sembol"]),
    }


# Kaybedeni uzun tutma: ort. kayip suresi / ort. kazanc suresi (>=1.2 orta, >=1.5 yuksek).
def detect_disposition_effect(trades: list[dict]) -> dict:
    gun = lambda t: (t["cikis_ts"] - t["giris_ts"]) / 86400000
    kaz = [gun(t) for t in trades if t["kar"] > 0]
    kay = [gun(t) for t in trades if t["kar"] < 0]
    if not kaz or not kay:
        return {"siddet": "dusuk", "kanit": "karsilastirmaya yetecek kazanan/kaybeden yok"}
    k1, k2 = _ortalama(kaz), _ortalama(kay)
    oran = k2 / k1 if k1 > 0 else math.inf
    return {"siddet": rate_severity(oran, 1.2, 1.5), "oran": round(oran, 2),
            "kazanan_sure_dk": round(k1 * 1440, 1), "kaybeden_sure_dk": round(k2 * 1440, 1),
            "kanit": f"Kaybedenler ort. {k2 * 1440:.0f} dk, kazananlar {k1 * 1440:.0f} dk tutuldu (oran {oran:.2f})."}


def _satirlar(trades: list[dict]) -> list[dict]:
    """Her islem iki satir: alis (giris) + satis (cikis) -- vibe'in satir tabani."""
    s = []
    for t in trades:
        s.append({"sembol": t["sembol"], "ts": t["giris_ts"], "fiyat": t["giris_fiyat"], "taraf": "al"})
        s.append({"sembol": t["sembol"], "ts": t["cikis_ts"], "fiyat": t["cikis_fiyat"], "taraf": "sat"})
    return s


# Asiri islem: yogun gunlerin (ust ceyrek) ort. K/Z'si sakin gunlerinkinden (alt ceyrek) kotu mu.
def detect_overtrading(trades: list[dict]) -> dict:
    gunluk: dict[str, int] = defaultdict(int)
    for r in _satirlar(trades):
        gunluk[_utc_gun(r["ts"])] += 1
    if len(gunluk) < 4:
        return {"siddet": "dusuk", "kanit": "4'ten az islem gunu"}
    sayilar = list(gunluk.values())
    yogun_esik = compute_linear_quantile(sayilar, 0.75)
    sakin_esik = compute_linear_quantile(sayilar, 0.25)
    yogun = {g for g, n in gunluk.items() if n >= yogun_esik}
    sakin = {g for g, n in gunluk.items() if n <= sakin_esik}
    yk = [t["kar"] for t in trades if _utc_gun(t["cikis_ts"]) in yogun]
    sk = [t["kar"] for t in trades if _utc_gun(t["cikis_ts"]) in sakin]
    if not yk or not sk:
        return {"siddet": "dusuk", "kanit": "islemler yogun/sakin gunlere yayilmamis"}
    y, s = _ortalama(yk), _ortalama(sk)
    taban = abs(s) if s != 0 else 1.0
    siddet = rate_severity((s - y) / taban, 0.3, 1.0) if y < s else "dusuk"
    return {"siddet": siddet, "yogun_gun_ort": round(y, 4), "sakin_gun_ort": round(s, 4),
            "yogun_esik": round(yogun_esik, 1),
            "kanit": f"Yogun gunlerde (>= {yogun_esik:.0f} satir) islem basi ort. {y:+.3f} USDT, "
                     f"sakin gunlerde (<= {sakin_esik:.0f}) {s:+.3f} USDT."}


# Pump kovalama: ayni sembolde alis fiyati, 3 alis onceki alistan %3+ yuksek mi (>=%40 orta, >=%60 yuksek).
def detect_chasing_buys(trades: list[dict]) -> dict:
    sembol: dict[str, list[dict]] = defaultdict(list)
    for r in sorted((r for r in _satirlar(trades) if r["taraf"] == "al"),
                    key=lambda r: (r["sembol"], r["ts"])):
        sembol[r["sembol"]].append(r)
    degerlendirilen = kovalama = 0
    for alislar in sembol.values():
        for i in range(3, len(alislar)):
            degerlendirilen += 1
            if alislar[i]["fiyat"] > alislar[i - 3]["fiyat"] * PUMP_ESIK:
                kovalama += 1
    if not degerlendirilen:
        return {"siddet": "dusuk", "kanit": "sembol basina yeterli tekrar alis yok"}
    oran = kovalama / degerlendirilen
    return {"siddet": rate_severity(oran, 0.4, 0.6), "oran": round(oran, 3),
            "kovalama": kovalama, "degerlendirilen": degerlendirilen,
            "kanit": f"{kovalama}/{degerlendirilen} alis (%{oran * 100:.0f}) ayni coinde %3+ yukselisten sonra yapildi."}


# Capalanma: >=5 satirli sembollerin kaci dar fiyat bandinda (CV < %5) (>=%33 orta, >=%66 yuksek).
def detect_price_anchoring(trades: list[dict]) -> dict:
    sembol: dict[str, list[float]] = defaultdict(list)
    for r in _satirlar(trades):
        sembol[r["sembol"]].append(r["fiyat"])
    satir = []
    for s, f in sembol.items():
        if len(f) < CAPA_MIN_SATIR:
            continue
        ort = statistics.fmean(f)
        if ort == 0:
            continue
        satir.append({"sembol": s, "satir": len(f), "cv": round(statistics.stdev(f) / ort, 4)})
    if not satir:
        return {"siddet": "dusuk", "kanit": "5+ satirli sembol yok"}
    capali = [r for r in satir if r["cv"] < CAPA_CV_ESIK]
    oran = len(capali) / len(satir)
    return {"siddet": rate_severity(oran, 0.33, 0.66), "oran": round(oran, 3),
            "capali": capali[:5], "degerlendirilen": len(satir),
            "kanit": f"{len(capali)}/{len(satir)} sik islem goren coin dar fiyat bandinda kaldi (CV<%5)."}


# Tam rapor: profil + 4 teshis. `sadece`: "el" / "bot" / None.
def build_journal_report(live: bool, *, include_dust: bool = False,
                         sadece: str | None = None, until_ms: int | None = None) -> dict:
    trades, toz = load_closed_trades(live, include_dust=include_dust, until_ms=until_ms)
    if sadece == "el":
        trades = [t for t in trades if t["el"]]
    elif sadece == "bot":
        trades = [t for t in trades if not t["el"]]
    return {
        "kaynak": "canli" if live else "dry",
        "toz_dislanan": toz,
        "profil": summarize_trade_profile(trades),
        "davranis": {
            "kaybedeni_tutma": detect_disposition_effect(trades),
            "asiri_islem": detect_overtrading(trades),
            "pump_kovalama": detect_chasing_buys(trades),
            "capalanma": detect_price_anchoring(trades),
        },
    }
