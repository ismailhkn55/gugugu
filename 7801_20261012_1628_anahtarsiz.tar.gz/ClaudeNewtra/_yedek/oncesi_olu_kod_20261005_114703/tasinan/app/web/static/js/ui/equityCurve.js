// equityCurve.js -- birikimli K/Z egrisi (SVG). Gunluk, geriye-test ve
// strateji paneli AYNI ciziciyi kullanir. Desen cuzdandaki renderPnlCurve
// ile ayni (sifir cizgisi + arti/eksi renk), ama hedef ogeyi parametre alir.

// Birikimli K/Z egrisini verilen kabin icine cizer; seri bossa kabi temizler.
export function drawEquityCurve(kap, seri, { yukseklik = 58 } = {}) {
  if (!kap) return;
  const v = (seri || []).map((x) => +x.birikim).filter(Number.isFinite);
  if (v.length < 2) { kap.innerHTML = `<div class="yok">VERI YOK</div>`; return; }
  const en = Math.max(...v, 0), az = Math.min(...v, 0), a = Math.max(1e-9, en - az);
  const alt = yukseklik - 6, boy = yukseklik - 14, n = v.length;
  const nokta = v.map((x, i) =>
    `${(i / (n - 1) * 300).toFixed(1)},${(alt - (x - az) / a * boy).toFixed(1)}`).join(" ");
  const sifir = (alt - (0 - az) / a * boy).toFixed(1);
  kap.innerHTML = `<svg viewBox="0 0 300 ${yukseklik}" preserveAspectRatio="none">
    <line x1="0" y1="${sifir}" x2="300" y2="${sifir}" stroke="currentColor" opacity=".25"/>
    <polyline points="${nokta}" fill="none" stroke="currentColor" stroke-width="1.6"
      class="${v.at(-1) >= 0 ? "arti" : "eksi"}"/></svg>`;
}
