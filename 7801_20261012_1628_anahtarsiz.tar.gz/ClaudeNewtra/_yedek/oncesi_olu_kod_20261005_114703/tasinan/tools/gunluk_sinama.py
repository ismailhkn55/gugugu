"""journal_analysis izole sinamasi -- defteri YALNIZ OKUR, hicbir sey yazmaz."""
import csv
import os
import sys

# Servisle AYNI veri koku -- yoksa eski sistemin varsayilan defteri okunur (01.10.2026: boyle yanildim).
os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/_cn_sunucu_testi")
os.environ.setdefault("NEWTRADE_RANK_DIR", "/DATA/AppData/_cn_sunucu_testi/rank")

sys.path.insert(0, "/DATA/AppData/ClaudeNewtra")
import app.reporting.journal_analysis as J

hatalar = []


def kontrol(ad, kosul, ek=""):
    print(("GECTI " if kosul else "KALDI ") + ad + (f"  [{ek}]" if ek else ""))
    if not kosul:
        hatalar.append(ad)


# CSV'nin son kapanisi (GTCUSDT 2026-10-01 18:45:41 UTC) -- ayni kesim
KESIM = 1790880341591
CSV = "/tmp/claudenewtra_trade_journal.csv"
tum = list(csv.DictReader(open(CSV, encoding="utf-8")))
satir = [r for r in tum if r["pnl"].strip()]        # K/Z'si bos satir islem sayilmaz
kontrol("CSV'de K/Z'si bos 3 satir", len(tum) - len(satir) == 3, f"{len(tum) - len(satir)}")
csv_pnl = [float(r["pnl"]) for r in satir]

r = J.build_journal_report(True, include_dust=True, until_ms=KESIM)
p = r["profil"]
# Defterde kar'i bos 3 islem: modul kar_p'den TURETIR (pnl.build_daily_pnl ile ayni), CSV bos birakmisti.
tr, _ = J.load_closed_trades(True, include_dust=True, until_ms=KESIM)
turetilen = [x for x in tr if x["turetildi"]]
ortak = [x for x in tr if not x["turetildi"]]
kontrol("turetilen 3 islem = CSV'deki bos 3 satir", len(turetilen) == 3 and p["turetilen"] == 3
        and sorted(x["sembol"] for x in turetilen) == sorted(r["symbol"] for r in tum if not r["pnl"].strip()),
        f"{[x['sembol'] for x in turetilen]}")
kontrol("islem sayisi = CSV 303 satir", p["islem"] == len(tum), f"{p['islem']} / {len(tum)}")
kontrol("ortak 300 islemin kari CSV ile ayni", len(ortak) == len(satir)
        and abs(sum(x["kar"] for x in ortak) - sum(csv_pnl)) < 1e-6,
        f"{round(sum(x['kar'] for x in ortak), 4)} / {round(sum(csv_pnl), 4)}")
kontrol("turetilen kar = tutar*kar_p/100", all(abs(x["kar"] - x["tutar"] * x["kar_p"] / 100) < 1e-9 for x in turetilen))
kontrol("kazanan sayisi (ortak) ayni", sum(1 for x in ortak if x["kar"] > 0) == sum(1 for x in csv_pnl if x > 0))
beklenen_isabet = round(sum(1 for x in tr if x["kar"] > 0) / len(tr) * 100, 2)
kontrol("isabet bagimsiz hesapla ayni", p["isabet"] == beklenen_isabet, f"{p['isabet']} / {beklenen_isabet}")
stop_b = next((s for s in p["sebep"] if s["ad"] == "STOP:baslangic"), None)
kontrol("STOP:baslangic 15 islem / -11.99", stop_b and stop_b["islem"] == 15
        and abs(stop_b["kar"] + 11.99) < 0.01, str(stop_b))

# dusus: CSV'den bagimsiz (pandas cummax mantigi)
cum, tepe, dd = 0.0, None, 0.0
for x in sorted(tr, key=lambda r: r["cikis_ts"]):
    cum += x["kar"]; tepe = cum if tepe is None else max(tepe, cum); dd = min(dd, cum - tepe)
kontrol("maks dusus bagimsiz hesapla ayni", abs(p["maks_dusus"] - round(dd, 4)) < 1e-9, f"{p['maks_dusus']} / {round(dd, 4)}")

d = r["davranis"]
k = d["pump_kovalama"]
kontrol("pump kovalama vibe ile ayni 79/128", k.get("kovalama") == 79 and k.get("degerlendirilen") == 128,
        f"{k.get('kovalama')}/{k.get('degerlendirilen')} {k['siddet']}")
c = d["capalanma"]
kontrol("capalanma vibe ile ayni 2/37", len(c.get("capali", [])) == 2 and c.get("degerlendirilen") == 37,
        f"{[x['sembol'] for x in c.get('capali', [])]} / {c.get('degerlendirilen')}")
a = d["asiri_islem"]
kontrol("asiri islem yogun esik vibe ile ayni 18", a.get("yogun_esik") == 18.0, f"{a}")
kt = d["kaybedeni_tutma"]
kontrol("kaybedeni tutma yuksek (vibe: yuksek, 2.73 FIFO)", kt["siddet"] == "yuksek", f"{kt.get('oran')}")

# toz filtresi
r2 = J.build_journal_report(True, include_dust=False, until_ms=KESIM)
csv_toz = sum(1 for r in tum if float(r["amount"]) < 1.0)
kontrol("toz sayisi CSV'deki tutar<1 ile ayni", r2["toz_dislanan"] == csv_toz
        and r2["profil"]["islem"] == len(tum) - csv_toz,
        f"toz {r2['toz_dislanan']} / CSV {csv_toz}, islem {r2['profil']['islem']}")

# saf fonksiyonlar
kontrol("sebep sinifi", [J.classify_exit_reason(x) for x in
        ("STOP:kilit_%2.2", "STOP:DINAMIK:atr%1.6/-%2", "HEDEF:%1.8", "ELLE", "GERCEK FILL", "STOP:baslangic")]
        == ["STOP:kilit", "STOP:DINAMIK", "HEDEF", "ELLE", "GERCEK FILL", "STOP:baslangic"])
kontrol("ceyreklik pandas ile ayni", J.compute_linear_quantile([1, 2, 3, 4], 0.75) == 3.25
        and J.compute_linear_quantile([5], 0.25) == 5)
bos = J.summarize_trade_profile([])
kontrol("bos defter cokmuyor", bos == {"islem": 0}
        and J.detect_disposition_effect([])["siddet"] == "dusuk"
        and J.detect_overtrading([])["siddet"] == "dusuk")

print("\nSONUC:", "HEPSI GECTI" if not hatalar else f"{len(hatalar)} KALDI: {hatalar}")
sys.exit(1 if hatalar else 0)
