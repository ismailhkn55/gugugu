"""Canli 7801 geriye-test uclari -- yalniz OKUR (POST'lar hicbir sey kaydetmez)."""
import hashlib, json, time, urllib.request, urllib.error

U = "http://127.0.0.1:7801"
ST_YOL = "/DATA/AppData/_cn_sunucu_testi/stratejiler.json"
hatalar = []


def kontrol(ad, kosul, ek=""):
    print(("GECTI " if kosul else "KALDI ") + ad + (f"  [{ek}]" if ek else ""))
    if not kosul:
        hatalar.append(ad)


def post(govde):
    r = urllib.request.Request(U + "/yerel/geriye-test", json.dumps(govde).encode(),
                               {"Content-Type": "application/json"})
    t = time.perf_counter()
    try:
        with urllib.request.urlopen(r, timeout=30) as y:
            return y.status, json.loads(y.read()), (time.perf_counter() - t) * 1000
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}"), (time.perf_counter() - t) * 1000


once = hashlib.sha256(open(ST_YOL, "rb").read()).hexdigest()
kod, d, _ = post({})
dis0 = d["dis_istek"]
sureler = [post({})[2] for _ in range(10)]
kontrol("10 istek, en yavasi < 2000 ms (uctan uca)", max(sureler) < 2000,
        f"min {min(sureler):.0f} / max {max(sureler):.0f} ms")
kod, d, _ = post({})
kontrol("tekrarli isteklerde dis istek ARTMADI", d["dis_istek"] == dis0, f"{dis0} -> {d['dis_istek']}")
kontrol("aktif strateji sonucu var", kod == 200 and d["profil"].get("islem", 0) >= 0 and d["hazir"] == 20,
        f"{d['strateji']} islem {d['profil'].get('islem')} K/Z {d['profil'].get('toplam_kar')}")

taslak = {"ad": "TASLAK-SINAMA", "kurallar": [{"alan": "rsi", "op": ">", "deger": 60, "aktif": True}],
          "maks_pozisyon": 3, "tutar": 50}
kod, t1, ms = post({"strateji": taslak})
kontrol("taslak calisti (kaydetmeden)", kod == 200 and t1["strateji"] == "TASLAK-SINAMA" and t1["tutar"] == 50,
        f"islem {t1['profil'].get('islem')} {ms:.0f} ms")
taslak2 = {**taslak, "kurallar": taslak["kurallar"] + [{"alan": "rsi", "op": "<", "deger": 70, "aktif": True}]}
kod, t2, _ = post({"strateji": taslak2})
# VE ile kural eklemek SINYAL sayisini artiramaz. Islem sayisi ARTABILIR: maks_pozisyon
# dolu oldugu anlarda elenen sinyaller yer acar (portfoy etkisi) -- bu bir hata degil.
kontrol("kural eklenince SINYAL azalir ya da esit (VE mantigi)",
        t2["sinyal"] <= t1["sinyal"],
        f"sinyal {t1['sinyal']} -> {t2['sinyal']}, islem {t1['profil'].get('islem')} -> {t2['profil'].get('islem')}")
kapali = {**taslak2, "kurallar": [taslak2["kurallar"][0], {**taslak2["kurallar"][1], "aktif": False}]}
kod, t3, _ = post({"strateji": kapali})
kontrol("kapatilan kural yok sayilir (= tek kurallik sonuc)", t3["islemler"] == t1["islemler"])

kod, b, _ = post({"strateji": {"ad": "x", "kurallar": "bozuk"}})
kontrol("bozuk govde -> 400", kod == 400, str(b))
kod, b, _ = post({"strateji": {"ad": "x", "kurallar": [{"alan": "yok_alan", "op": ">", "deger": 1}]}})
kontrol("bilinmeyen alan -> sinanamaz + dogrulama hatasi (cokmez)",
        kod == 200 and not b["tam_sinanabilir"] and b["dogrulama"], f"{b.get('sinanamayan_kural')} / {b.get('dogrulama')}")
kod, b, _ = post({"strateji": {"ad": "x", "kurallar": [], "maks_pozisyon": "abc"}})
kontrol("gecersiz maks_pozisyon -> 400 (500 degil)", kod == 400, f"{kod} {b}")
kod, b, _ = post({"ad": "BOYLE-BIR-STRATEJI-YOK"})
kontrol("olmayan ad -> 404", kod == 404)

s = d["semboller"][0]
with urllib.request.urlopen(f"{U}/yerel/geriye-test/seri?sembol={s}", timeout=10) as y:
    seri = json.loads(y.read())["seri"]
kontrol("seri ucu onbellekten (576 nokta)", len(seri) == 576, f"{s} {len(seri)}")
try:
    urllib.request.urlopen(f"{U}/yerel/geriye-test/seri?sembol=YOKUSDT", timeout=10); kod = 200
except urllib.error.HTTPError as e:
    kod = e.code
kontrol("onbellekte olmayan sembol -> 404 (Binance'e gitmez)", kod == 404)
kod, d2, _ = post({})
kontrol("seri ve hata isteklerinde de dis istek artmadi", d2["dis_istek"] == dis0, f"{d2['dis_istek']}")

sonra = hashlib.sha256(open(ST_YOL, "rb").read()).hexdigest()
kontrol("stratejiler.json DEGISMEDI", once == sonra)
print("\nSONUC:", "HEPSI GECTI" if not hatalar else f"{len(hatalar)} KALDI: {hatalar}")
