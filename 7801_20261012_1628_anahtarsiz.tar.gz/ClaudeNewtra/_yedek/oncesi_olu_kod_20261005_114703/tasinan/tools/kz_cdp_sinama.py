# -*- coding: utf-8 -*-
"""ANINDA K/Z paneli -- gercek tarayicida etkilesimli sinama (CDP, stdlib).
Kural anahtarina TIKLAR (yalniz bellekteki taslak), KAYDETMEZ. stratejiler.json
oncesi/sonrasi karsilastirilir. Konsol hatalari toplanir."""
import base64, hashlib, json, os, socket, struct, subprocess, sys, time, urllib.request

PORT = 9344
URL = "http://127.0.0.1:7801/#stratejiler"
ST_YOL = "/DATA/AppData/_cn_sunucu_testi/stratejiler.json"
hatalar, konsol = [], []


def kontrol(ad, kosul, ek=""):
    print(("GECTI " if kosul else "KALDI ") + ad + (f"  [{ek}]" if ek else ""), flush=True)
    if not kosul:
        hatalar.append(ad)


class WS:
    def __init__(self, url):
        h, yol = url[len("ws://"):].split("/", 1)
        host, port = h.split(":")
        self.s = socket.create_connection((host, int(port)), timeout=30)
        anahtar = base64.b64encode(os.urandom(16)).decode()
        self.s.sendall((f"GET /{yol} HTTP/1.1\r\nHost: {h}\r\nUpgrade: websocket\r\n"
                        f"Connection: Upgrade\r\nSec-WebSocket-Key: {anahtar}\r\n"
                        "Sec-WebSocket-Version: 13\r\n\r\n").encode())
        b = b""
        while b"\r\n\r\n" not in b:
            b += self.s.recv(4096)
        self.tampon = b.split(b"\r\n\r\n", 1)[1]
        self.no = 0

    def _oku(self, n):
        while len(self.tampon) < n:
            self.tampon += self.s.recv(65536)
        v, self.tampon = self.tampon[:n], self.tampon[n:]
        return v

    def mesaj(self):
        parca = b""
        while True:
            b0, b1 = self._oku(2)
            n = b1 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._oku(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._oku(8))[0]
            parca += self._oku(n)
            if b0 & 0x80:
                return json.loads(parca.decode("utf-8", "replace"))

    def gonder(self, method, params=None):
        self.no += 1
        veri = json.dumps({"id": self.no, "method": method, "params": params or {}}).encode()
        m = os.urandom(4)
        n = len(veri)
        bas = bytes([0x81]) + (bytes([0x80 | n]) if n < 126 else bytes([0x80 | 126]) + struct.pack(">H", n)
                               if n < 65536 else bytes([0x80 | 127]) + struct.pack(">Q", n))
        self.s.sendall(bas + m + bytes(x ^ m[i % 4] for i, x in enumerate(veri)))
        bekle = self.no
        while True:
            d = self.mesaj()
            if d.get("method") == "Runtime.exceptionThrown":
                konsol.append(d["params"]["exceptionDetails"].get("text", "") + " " +
                              str(d["params"]["exceptionDetails"].get("exception", {}).get("description", ""))[:200])
            elif d.get("method") == "Runtime.consoleAPICalled" and d["params"]["type"] == "error":
                konsol.append(" ".join(str(a.get("value", a.get("description", ""))) for a in d["params"]["args"])[:200])
            if d.get("id") == bekle:
                return d

    def js(self, ifade):
        r = self.gonder("Runtime.evaluate", {"expression": ifade, "returnByValue": True, "awaitPromise": True})
        return r.get("result", {}).get("result", {}).get("value")


def bekle_kosul(ws, ifade, sure=10.0):
    t = time.perf_counter()
    while time.perf_counter() - t < sure:
        if ws.js(ifade):
            return time.perf_counter() - t
        time.sleep(0.05)
    return None


once = hashlib.sha256(open(ST_YOL, "rb").read()).hexdigest()
krom = subprocess.Popen(["/snap/bin/chromium", "--headless=new", "--no-sandbox", "--disable-gpu",
                         "--window-size=1600,1000", f"--remote-debugging-port={PORT}",
                         f"--user-data-dir=/tmp/kz_prof_{PORT}", "about:blank"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
try:
    for _ in range(80):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json/version", timeout=1); break
        except Exception:
            time.sleep(0.25)
    r = urllib.request.Request(f"http://127.0.0.1:{PORT}/json/new?about:blank", method="PUT")
    ws = WS(json.loads(urllib.request.urlopen(r, timeout=5).read())["webSocketDebuggerUrl"])
    ws.gonder("Runtime.enable")
    ws.gonder("Page.enable")
    # fetch sayaci: sayfa yuklenmeden once
    ws.gonder("Page.addScriptToEvaluateOnNewDocument", {"source": """
      window.__kz = 0; const _f = window.fetch;
      window.fetch = (u, o) => { if (String(u).includes('/yerel/geriye-test') && !String(u).includes('/seri')) window.__kz++; return _f(u, o); };"""})
    ws.gonder("Page.navigate", {"url": URL})

    PANEL = "document.getElementById('stCanliKZ')"
    SONUC_VAR = f"(()=>{{const p={PANEL}; return p && !p.classList.contains('btBekliyor') && /USDT|0 islem/.test(p.innerText)}})()"
    t = bekle_kosul(ws, SONUC_VAR, 15)
    kontrol("acilista panel kendiliginden doldu", t is not None, f"{t:.2f} sn" if t else "yok")
    n_kural = ws.js("document.querySelectorAll('#stKurallar [data-ac]').length")
    kontrol("duzenleyicide kural var", (n_kural or 0) > 0, f"{n_kural} kural")
    IMZA = f"(()=>{{const p={PANEL}; const b=p.querySelector('.pnlBuyuk'), s=p.querySelector('.satirlar'); return (b?b.innerText:'')+'|'+(s?s.innerText:'')}})()"
    A = ws.js(IMZA)

    # 1) tek tiklama: kural 0 kapat -> 2 sn icinde yeni sonuc
    ws.js("window.__kz = 0")
    ws.js("document.querySelector('#stKurallar [data-ac=\"0\"]').click()")
    t = bekle_kosul(ws, f"(()=>{{const p={PANEL}; return !p.classList.contains('btBekliyor') && {IMZA} !== {json.dumps(A)}}})()", 5)
    B = ws.js(IMZA)
    kontrol("kural kapatinca panel < 2 sn'de guncellendi", t is not None and t < 2.0,
            f"{t:.2f} sn (800 ms bekleme dahil)" if t else "degismedi")
    kontrol("tek degisiklik = tek istek", ws.js("window.__kz") == 1, str(ws.js("window.__kz")))

    # 2) geri ac -> A'ya donmeli
    ws.js("document.querySelector('#stKurallar [data-ac=\"0\"]').click()")
    t = bekle_kosul(ws, f"(()=>!{PANEL}.classList.contains('btBekliyor') && {IMZA} === {json.dumps(A)})()", 5)
    kontrol("geri acinca ayni sonuc (deterministik)", t is not None)

    # 3) hizli 5 degisiklik (net etkisi = 1 kapatma) -> YALNIZ son sonuc, tek istek
    ws.js("window.__kz = 0")
    ws.js("(async()=>{for(let i=0;i<5;i++){document.querySelector('#stKurallar [data-ac=\"0\"]').click(); await new Promise(r=>setTimeout(r,120));}})()")
    time.sleep(2.5)
    C = ws.js(IMZA)
    kontrol("hizli 5 degisiklikte yalniz SON durumun sonucu", C == B)
    kontrol("hizli 5 degisiklikte TEK istek (son istek kazanir)", ws.js("window.__kz") == 1, str(ws.js("window.__kz")))
    # temizle: kural 0'i geri ac
    ws.js("document.querySelector('#stKurallar [data-ac=\"0\"]').click()")
    bekle_kosul(ws, f"(()=>!{PANEL}.classList.contains('btBekliyor') && {IMZA} === {json.dumps(A)})()", 5)

    # 4) TP kutusu -> sonuc degisir
    ws.js("const e=document.getElementById('stTp'); e.value='0.5'; e.dispatchEvent(new Event('input'))")
    ws.js("window.__kz = 0")
    t = bekle_kosul(ws, f"(()=>!{PANEL}.classList.contains('btBekliyor') && window.__kz === 1 && {IMZA} !== {json.dumps(A)})()", 5)
    kontrol("TP degisince panel guncellendi", t is not None and t < 2.0, f"{t:.2f} sn" if t else "degismedi")

    # 5) AYRINTILI -> geriye test sayfasi taslakla acilir
    ws.js("document.getElementById('btnStGeriyeDetay').click()")
    t = bekle_kosul(ws, "(()=>{const o=document.getElementById('btOzet'); return location.hash==='#geriyetest' && o && /USDT|0 islem/.test(o.innerText) && /TASLAK/.test(document.getElementById('btStrateji').innerText)})()", 10)
    kontrol("AYRINTILI: sayfa taslakla acildi", t is not None)
    satir = ws.js("document.querySelectorAll('#btIslemler tr.btSatir').length")
    bekle_kosul(ws, "document.querySelectorAll('#btGrafik circle').length >= 2", 8)
    nokta = ws.js("document.querySelectorAll('#btGrafik circle').length")
    kontrol("islem tablosu + grafik isaretleri", (satir or 0) == 0 or (nokta or 0) >= 2, f"{satir} satir, {nokta} isaret")
    png = ws.gonder("Page.captureScreenshot", {"format": "png"})["result"]["data"]
    open("/tmp/geriyetest_sayfa.png", "wb").write(base64.b64decode(png))
    ws.js("location.hash='#stratejiler'")
    time.sleep(1.5)
    png = ws.gonder("Page.captureScreenshot", {"format": "png"})["result"]["data"]
    open("/tmp/strateji_kz.png", "wb").write(base64.b64decode(png))
finally:
    krom.terminate()

kontrol("konsol hatasi yok", not konsol, " | ".join(konsol[:3]))
kontrol("stratejiler.json DEGISMEDI (tiklamalar kaydetmedi)",
        hashlib.sha256(open(ST_YOL, "rb").read()).hexdigest() == once)
print("\nSONUC:", "HEPSI GECTI" if not hatalar else f"{len(hatalar)} KALDI: {hatalar}")
