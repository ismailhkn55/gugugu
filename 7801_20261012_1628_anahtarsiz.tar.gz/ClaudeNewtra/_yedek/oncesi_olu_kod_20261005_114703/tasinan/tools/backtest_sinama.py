"""simulate_strategy_trades izole sinamasi -- ELLE HESAPLANMIS sentetik mumlar.
Ag yok, defter yok, DB yok. Gercek veriye HICBIR SEY yazilmaz."""
import os
import sys

os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/_cn_sunucu_testi")
os.environ.setdefault("NEWTRADE_RANK_DIR", "/DATA/AppData/_cn_sunucu_testi/rank")
sys.path.insert(0, "/DATA/AppData/ClaudeNewtra")
from app.strategy.backtest import simulate_strategy_trades
from app.strategy.exit import decide_exit

hatalar = []


def kontrol(ad, kosul, ek=""):
    print(("GECTI " if kosul else "KALDI ") + ad + (f"  [{ek}]" if ek else ""))
    if not kosul:
        hatalar.append(ad)


T0 = 1_790_000_000_000
B = 300_000
PLAN = {
    "cikis": {"hizli_esik": 99, "hiz_yavas": 0, "hedef_yavas": 2.0, "hedef_normal": 2.0,
              "trailing": 1.0, "kar_trailing_esik": None, "zaman_asimi_dk": None},
    "stop": {"baslangic": 1.0, "kilit_esik": 99, "kilit_deger": 0, "basabas_esik": 99},
    "beklet": {"aktif": False},
}
ST = {"ad": "sinama", "kurallar": [{"alan": "rsi", "op": ">", "deger": 50, "aktif": True}]}


def seri(rsi, mumlar, hiz):
    return [({"ts": T0 + i * B, "rsi": r, "hiz": hiz, "atr_pct": 0.3, "deg5m": 0.1, "hacim_x": 1.0},
             [T0 + i * B, *m, 1000.0]) for i, (r, m) in enumerate(zip(rsi, mumlar))]


# A: bar1 sinyal -> bar2 giris 100 -> bar3 HEDEF 102 (yuksek 102.5)
#    bar4 sinyal -> bar5 giris 100 -> bar5 dusuk 98 -> STOP 99
#    bar6 sinyal -> bar7 giris 100 -> bar8 BOSLUKLU acilis 98 (stop 99 alti) -> 98'den cikis
A = seri([40, 60, 40, 40, 60, 40, 60, 40, 40, 40],
         [(100, 100, 100, 100), (100, 100, 100, 100),
          (100, 101, 99.5, 100.5), (100.5, 102.5, 100, 102),
          (100, 100, 100, 100), (100, 100.2, 98, 99),
          (100, 100, 100, 100), (100, 100.4, 99.6, 100.1),
          (98, 98.5, 97.5, 98), (98, 98, 98, 98)], hiz=1.0)
# B: bar1'de sinyal ama hizi DUSUK -> maks_pozisyon=1 oldugu icin A secilir, B atlanir
Bs = seri([40, 60] + [40] * 8, [(50, 50, 50, 50)] * 10, hiz=0.5)

kw = dict(fee_pct=0.15, max_positions=1, cooldown_min=1, amount=100)
r = simulate_strategy_trades({"A": A, "B": Bs}, ST, PLAN, **kw)
t = r["islemler"]
kontrol("3 islem", len(t) == 3, str([(x["sembol"], x["sebep"]) for x in t]))
if len(t) == 3:
    kontrol("1) giris bar2 acilisi 100", t[0]["giris_fiyat"] == 100 and t[0]["giris_ts"] == T0 + 2 * B)
    kontrol("1) HEDEF 102'den (yuksek 102.5 degil)", t[0]["cikis_fiyat"] == 102 and t[0]["sebep"].startswith("HEDEF"),
            f"{t[0]['cikis_fiyat']} {t[0]['sebep']}")
    kontrol("1) net %1.85, 1.85 USDT", abs(t[0]["kar_p"] - 1.85) < 1e-9 and abs(t[0]["kar"] - 1.85) < 1e-9,
            f"{t[0]['kar_p']} {t[0]['kar']}")
    kontrol("2) giris bar5 (bekleme 5dk >= 1dk)", t[1]["giris_ts"] == T0 + 5 * B)
    kontrol("2) STOP:baslangic 99'dan", t[1]["sebep"] == "STOP:baslangic" and abs(t[1]["cikis_fiyat"] - 99) < 1e-9,
            f"{t[1]['cikis_fiyat']} {t[1]['sebep']}")
    kontrol("2) net -%1.15", abs(t[1]["kar_p"] + 1.15) < 1e-9, f"{t[1]['kar_p']}")
    kontrol("3) bosluklu acilista 98'den (stop 99 degil)", t[2]["cikis_fiyat"] == 98, f"{t[2]['cikis_fiyat']}")
    kontrol("3) net -%2.15", abs(t[2]["kar_p"] + 2.15) < 1e-9, f"{t[2]['kar_p']}")
kontrol("sinyal 4, atlanan 1 (B, maks pozisyon)", r["sinyal"] == 4 and r["atlanan_sinyal"] == 1,
        f"{r['sinyal']} / {r['atlanan_sinyal']}")
kontrol("B hic acilmadi", all(x["sembol"] == "A" for x in t))
kontrol("tam sinanabilir, uyari yok", r["tam_sinanabilir"] and r["uyari"] is None)

# maks pozisyon 2 -> B de acilir
r2 = simulate_strategy_trades({"A": A, "B": Bs}, ST, PLAN, **{**kw, "max_positions": 2})
kontrol("maks 2: B de girer (acik kalir)", any(x["sembol"] == "B" for x in r2["acik"]), str(r2["acik"]))

# bekleme: 10 dk -> bar4 sinyali (cikistan 5 dk sonra) ATLANIR
r3 = simulate_strategy_trades({"A": A, "B": Bs}, ST, PLAN, **{**kw, "cooldown_min": 10})
kontrol("bekleme 10dk: 2. giris atlanir", len(r3["islemler"]) == 2 and r3["atlanan_sinyal"] == 2,
        f"{len(r3['islemler'])} islem, atlanan {r3['atlanan_sinyal']}")

# deterministik
kontrol("ayni girdi -> bit bit ayni", simulate_strategy_trades({"A": A, "B": Bs}, ST, PLAN, **kw) == r)

# sinanamayan kural: rank -> dislanir, uyari gorunur
ST2 = {"ad": "x", "kurallar": ST["kurallar"] + [{"alan": "rank", "op": "<", "deger": 10, "aktif": True}]}
r4 = simulate_strategy_trades({"A": A, "B": Bs}, ST2, PLAN, **kw)
kontrol("rank sinanamaz -> EKSIK uyarisi", (not r4["tam_sinanabilir"]) and r4["uyari"]
        and r4["sinanamayan_kural"], str(r4["sinanamayan_kural"]))
kontrol("rank disinda sonuc ayni", r4["islemler"] == r["islemler"])

# kural yok
r5 = simulate_strategy_trades({"A": A}, {"ad": "bos", "kurallar": []}, PLAN, **kw)
kontrol("kural yok -> 0 islem + uyari", r5["islemler"] == [] and r5["uyari"])

# ileriye bakma: sinyal bari ile ayni barda giris YOK
kontrol("giris sinyalden SONRAKI barda", all(x["giris_ts"] > T0 + 1 * B for x in t))

# zaman asimi saati (now_ms_override)
PZ = {**PLAN, "cikis": {**PLAN["cikis"], "zaman_asimi_dk": 10, "hedef_normal": 50, "hedef_yavas": 50}}
poz = {"fiyat": 100, "dolan_fiyat": 100, "en_yuksek": 100.5, "hiz": 1, "ts": T0}
k1 = decide_exit(poz, 100.5, PZ, now_ms_override=T0 + 11 * 60000)
k2 = decide_exit(poz, 100.5, PZ, now_ms_override=T0 + 5 * 60000)
kontrol("zaman asimi: 11dk SAT, 5dk TUT", k1.should_sell and k1.reason.startswith("ZAMAN")
        and not k2.should_sell, f"{k1.reason} / {k2.reason}")

print("\nSONUC:", "HEPSI GECTI" if not hatalar else f"{len(hatalar)} KALDI: {hatalar}")
sys.exit(1 if hatalar else 0)
