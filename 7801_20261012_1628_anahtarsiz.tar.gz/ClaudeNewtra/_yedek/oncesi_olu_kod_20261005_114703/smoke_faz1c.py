"""Faz 1 kapanis sinamasi: benim hesapladigim gostergeler, toplayicinin
rank.sqlite'a yazdiklariyla ortusuyor mu? Eski sistemde geriye-test kendi
gosterge kodunu yaziyordu ve bu yuzden olculen sey ile ekranda gorunen sey
sessizce ayrisabiliyordu."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.core.applog import setup_logging
from app.market import rank_repository as RR, candles as CN, ticks as TK, price_source as PS
from app.exchange import binance_rest as BR, symbol_rules as SR
setup_logging()

print("=== saat senkronu ===")
print("  borsa saat farki:", BR.sync_exchange_clock(), "ms")
print("  kullanilan agirlik:", BR.get_used_weight())

d = RR.fetch_latest_snapshot(limit=50)
hedef = next((s for s in d["satir"] if s.get("rsi") is not None
              and s.get("ema7") is not None and s.get("hacim_x") is not None), d["satir"][0])
sem = hedef["sembol"]
print(f"\n=== {sem} — 5m mum cekiliyor (tek istek) ===")
mumlar = CN.fetch_candle_page(sem, "5m", limit=500)
print(f"  {len(mumlar)} mum, agirlik simdi: {BR.get_used_weight()}")

satir = CN.build_indicator_frame(mumlar)
print(f"\n=== KARSILASTIRMA  (sol: benim hesabim / sag: toplayici) ===")
print(f"  {'alan':<18} {'ClaudeNewtra':>16} {'rank.sqlite':>16}   fark")
onemli = ["fiyat", "rsi", "atr_pct", "cci", "kdj_j", "ema7", "ema20", "wma48",
          "ema20_uzak", "ema48_uzak", "deg1h", "deg4h", "ha_ardisik_yesil",
          "obv_kesim", "hiz"]
uyum = 0
for a in onemli:
    m, t = satir.get(a), hedef.get(a)
    if isinstance(m, (int, float)) and isinstance(t, (int, float)):
        taban = max(abs(t), 1e-9)
        fark = abs(m - t) / taban * 100
        isaret = "OK " if fark < 5 else ("~  " if fark < 20 else "!! ")
        uyum += fark < 5
        print(f"  {a:<18} {m:>16.6g} {t:>16.6g}   {isaret}%{fark:.2f}")
    else:
        print(f"  {a:<18} {str(m):>16} {str(t):>16}   -")
print(f"\n  %5'ten yakin: {uyum}/{len([a for a in onemli])}")
print("  NOT: birebir esitlik BEKLENMIYOR -- toplayici 5 dk'lik anlik goruntu")
print("       yaziyor, ben o andan sonraki canli mumla hesapliyorum.")

print("\n=== fiyat kaynagi ===")
f, kaynak = PS.get_price(sem)
print(f"  {sem}: {f}  <- {PS.describe_price_source(kaynak)}")

print("\n=== sembol kurallari ===")
k = SR.get_symbol_filters(sem)
print(f"  {k['symbol']}: step={k['step']} tick={k['tick']} min_notional={k['min_notional']} durum={k['status']}")
print(f"  islem goruyor mu: {SR.is_symbol_tradable(sem)}")
print(f"  yuvarlama: 123.456789 -> {SR.round_quantity_to_step(123.456789, k['step'])}")

print("\n=== tick tekrar engeli ===")
os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/Newtrade")
parti = {"TESTUSDT": [{"ts": 1, "fiyat": 1.0}, {"ts": 1, "fiyat": 1.0},
                      {"ts": 1, "fiyat": 1.0}, {"ts": 2, "fiyat": 1.1}]}
print("  4 tick'in 3'u ayni:", TK.is_duplicate_tick("TESTUSDT", 1, 1.0), "(ilk cagri: False beklenir)")
print(f"  toplam agirlik: {BR.get_used_weight()}")
