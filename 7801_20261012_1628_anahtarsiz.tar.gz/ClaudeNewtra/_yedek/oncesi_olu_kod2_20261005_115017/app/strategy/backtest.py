"""Geriye-test: stratejiyi gecmis mumlarda calistirir.

ESKI HALI: `sunucu.py` icinde `do_GET`'in ortasinda, satir 2201-2566 arasi
**365 satirlik** bir blok. `do_GET`'in %60'i tek bir uctu ve icinde on kadar
yerel fonksiyon tanimliyordu.

IKI CIDDI KUSURU VARDI:

1. GOSTERGELERI KENDI HESAPLIYORDU. RSI/HA/EMA/gun_pct icin ayri bir
   uygulama yazilmisti; `gostergeler.py`'nin kendi docstring'i bunu acikca
   yasakliyor: "Iki yerde ayri yazilirsa sinamanin olctugu sey ile ekranda
   gorunen sey sessizce ayrisir." Burada `market.indicators` cagriliyor --
   canli tarafla BIREBIR ayni kod (15/15 esitlik kanitlandi).

2. SINANAMAYAN ALANI "GECTI" SAYIYORDU. `CIFT_ATLA` listesindeki rank
   alanlari (rank, rank_hacim, rank_hiz, rank_atr) geriye-testte HER ZAMAN
   geciyordu -- cunku o anki 213 coin arasindaki SIRA gecmiste yeniden
   kurulamaz. Sonuc: geriye-test canlidan sistematik olarak IYIMSER.
   Ustelik `iz_yon` ve `hacim_x_1h/4h` `CIFT_ATLA`'da DEGILDI ve
   hesaplanmiyordu da -- o alani kullanan strateji sifir nokta veriyordu.

   Burada bu alanlar "gecti" sayilmaz. `untestable_fields` ile acikca
   raporlanir: "bu kural gecmiste SINANAMADI".
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

from app.core.applog import get_logger
from app.market.candles import build_indicator_frame
from app.market.indicators import count_consecutive_green_ha, is_known_field
from app.strategy.rule_engine import RuleOutcome, evaluate_rule, describe_rule

_log = get_logger(__name__)

# Tek sembolun kendi mumlarindan YENIDEN KURULAMAYAN alanlar.
# Hepsi o anki coin evreni icindeki SIRAYI ya da coklu-sembol kiyasini
# gerektirir; tek bir sembolun gecmis mumundan uretilemezler.
UNTESTABLE_FIELDS: frozenset[str] = frozenset({
    "rank", "rank_hacim", "rank_hiz", "rank_atr",   # siralama
    "iz_yon", "sira_izi",                            # sira izi
    "hacim_x_1h", "hacim_x_4h",                      # yalniz ilk 150 cift icin olculur
    "deg24", "gun_pct",                              # Binance kayan penceresi / UTC gun
    "ha_1d_ardisik_yesil", "ha_4h_ardisik_yesil", "ha_1h_ardisik_yesil",  # ust zaman dilimi
    "ha_4h_yesil_yukselis",                          # ayni sebep -- 4H mum gerekir
    "genislik", "total3_5m",                         # TUM EVRENDEN hesaplanir (TP085);
                                                     # tek sembolun gecmis mumundan KURULAMAZ
})


# 02.10.2026, Ismail: "grafik niye kullanamiyor, ustte 4h'yi kirmizi
# gosteriyor ya". Ust zaman dilimi HA alanlari, o dilimin KAPANMIS mumlari
# verilirse gecmiste de kurulabilir (toplayici canlida da yalniz kapanmis
# mum kullanir). Mum verilmeyen cagrilarda eskisi gibi sinanamaz kalir.
HIGHER_TF_FIELDS: dict[str, tuple[str, int]] = {
    "ha_1h_ardisik_yesil": ("1h", 3_600_000),
    "ha_4h_ardisik_yesil": ("4h", 14_400_000),
    "ha_1d_ardisik_yesil": ("1d", 86_400_000),
}


# Bir kural, tek sembolun gecmis mumlarindan sinanabilir mi?
# `provided`: cagiranin ayrica mumunu verdigi ust zaman dilimi alanlari.
def is_rule_testable(rule: Mapping[str, Any], *,
                     provided: frozenset[str] = frozenset()) -> tuple[bool, str]:
    for anahtar in ("alan", "deger_alan"):
        ad = rule.get(anahtar)
        if not ad:
            continue
        if ad in provided:
            continue
        if ad in UNTESTABLE_FIELDS:
            return False, f"{ad} gecmiste yeniden kurulamaz"
        if not is_known_field(ad):
            return False, f"{ad} diye bir alan yok"
    return True, ""


# Stratejinin hangi kurallari gecmiste sinanabilir, hangileri sinanamaz.
# `aktif: false` kurallar (switch ile kapatilmis) TAMAMEN atlanir --
# rule_engine.evaluate_rule_set ile AYNI davranis.
def summarize_backtest_gaps(strategy: Mapping[str, Any], *,
                            provided: frozenset[str] = frozenset()) -> dict:
    sinanabilir, sinanamaz = [], []
    for k in (strategy.get("kurallar") or []):
        if not k.get("aktif", True):
            continue
        ok, neden = is_rule_testable(k, provided=provided)
        (sinanabilir if ok else sinanamaz).append(
            describe_rule(k) if ok else f"{describe_rule(k)} ({neden})")
    return {"sinanabilir": sinanabilir, "sinanamaz": sinanamaz,
            "tam_sinanabilir": not sinanamaz}


# Mum serisinden, her bar icin gosterge satiri uretir.
# Canli tarafla AYNI `build_indicator_frame` kullanilir.
def build_history_rows(candles: Sequence[Sequence], *, warmup: int = 60,
                       max_bars: int | None = None) -> list[dict]:
    n = len(candles)
    if n <= warmup:
        return []
    bas = warmup
    if max_bars is not None and (n - warmup) > max_bars:
        bas = n - max_bars
    satirlar = []
    for i in range(bas, n):
        satir = build_indicator_frame(candles, upto=i + 1)
        if satir:
            satir["_bar"] = i
            satirlar.append(satir)
    return satirlar


# Strateji hangi ust zaman dilimi HA alanlarini kullaniyor -> {alan: aralik}.
def list_higher_tf_needs(strategy: Mapping[str, Any]) -> dict[str, str]:
    lazim = {}
    for k in (strategy.get("kurallar") or []):
        if not k.get("aktif", True):
            continue
        for anahtar in ("alan", "deger_alan"):
            ad = k.get(anahtar)
            if ad in HIGHER_TF_FIELDS:
                lazim[ad] = HIGHER_TF_FIELDS[ad][0]
    return lazim


# Her 5m satira, KARAR ANINDA (5m mumun kapanisi) kapanmis ust dilim
# mumlarindan ha_*_ardisik_yesil degerini yazar. Canliyla ayni fonksiyon.
def attach_higher_tf_fields(rows: list[dict], higher_tf: Mapping[str, Sequence[Sequence]],
                            *, bar_ms: int = 300_000) -> None:
    for alan, mumlar in higher_tf.items():
        sure = HIGHER_TF_FIELDS[alan][1]
        ohlc = [(float(m[1]), float(m[2]), float(m[3]), float(m[4])) for m in mumlar]
        kapanis = [int(m[0]) + sure for m in mumlar]
        j = 0
        for s in rows:
            karar = s["ts"] + bar_ms
            while j < len(kapanis) and kapanis[j] <= karar:
                j += 1
            s[alan] = count_consecutive_green_ha(ohlc[:j]) if j else None


# 02.10.2026, Ismail: grafikte her girisin SONUCU. Giris = sinyal mumundan
# sonraki mumun acilisi. Once +hedef% mi -stop% mi (ayni mumda ikisi -> stop,
# temkinli). `horizon` mum icinde hicbiri yoksa "sure", veri bitmisse "acik".
def measure_signal_outcome(candles: Sequence[Sequence], bar: int, *, target_pct: float = 2.0,
                           stop_pct: float = 2.0, horizon: int = 48) -> str:
    if bar + 1 >= len(candles):
        return "acik"
    giris = float(candles[bar + 1][1])
    for j in range(bar + 1, min(len(candles), bar + 1 + horizon)):
        if float(candles[j][3]) <= giris * (1 - stop_pct / 100):
            return "stop"
        if float(candles[j][2]) >= giris * (1 + target_pct / 100):
            return "hedef"
    return "sure" if bar + horizon < len(candles) else "acik"


# Stratejiyi gecmis mumlarda calistirir; tetiklenme noktalarini doner.
# (eski: /yerel/gecmis-sinyal icindeki 365 satir)
# `higher_tf`: {alan: o dilimin mumlari} -- verilirse 4h/1h/1d HA kurallari da sinanir.
def replay_strategy_signals(candles: Sequence[Sequence], strategy: Mapping[str, Any],
                            *, warmup: int = 60, max_bars: int | None = 576,
                            skip_untestable: bool = False,
                            higher_tf: Mapping[str, Sequence[Sequence]] | None = None) -> dict:
    higher_tf = {a: m for a, m in (higher_tf or {}).items() if a in HIGHER_TF_FIELDS and m}
    verilen = frozenset(higher_tf)
    kurallar = [k for k in (strategy.get("kurallar") or []) if k.get("aktif", True)]
    bosluk = summarize_backtest_gaps(strategy, provided=verilen)
    sinanabilir = [k for k in kurallar if is_rule_testable(k, provided=verilen)[0]]

    if not skip_untestable and bosluk["sinanamaz"]:
        # Eski sistem bu kurallari sessizce "gecti" sayip devam ediyordu.
        _log.warning("geriye-testte sinanamayan kural(lar) var: %s",
                     "; ".join(bosluk["sinanamaz"]))

    kullanilacak = sinanabilir if skip_untestable else sinanabilir
    satirlar = build_history_rows(candles, warmup=warmup, max_bars=max_bars)
    if higher_tf:
        attach_higher_tf_fields(satirlar, higher_tf)

    noktalar = []
    for s in satirlar:
        if not kullanilacak:
            break
        sonuclar = [evaluate_rule(s, k) for k in kullanilacak]
        if all(r.outcome is RuleOutcome.GECTI for r in sonuclar):
            noktalar.append({"ts": s["ts"], "fiyat": s["fiyat"], "bar": s["_bar"],
                             "sonuc": measure_signal_outcome(candles, s["_bar"])})

    return {
        "noktalar": noktalar,
        "taranan_bar": len(satirlar),
        "strateji": strategy.get("ad"),
        "sinanan_kural": [describe_rule(k) for k in kullanilacak],
        "sinanamayan_kural": bosluk["sinanamaz"],
        "tam_sinanabilir": bosluk["tam_sinanabilir"],
        "uyari": None if bosluk["tam_sinanabilir"] else
                 ("Bu sonuc EKSIK: yukaridaki kurallar gecmiste yeniden "
                  "kurulamadigi icin sinanmadi. Eski sistem onlari 'gecti' "
                  "sayip daha iyimser bir sonuc gosteriyordu."),
    }


# ======================================================================
# KAR/ZARAR SIMULASYONU (02.10.2026) -- SAF: dosya/ag yok, veri alir sonuc doner.
#
# Eski geriye-test yalnizca sinyal NOKTASI buluyordu, K/Z hesaplamiyordu.
# Burada CANLI BOTUN AYNI YOLU izlenir:
#   giris : entry.is_entry_allowed (canliyla ayni kural motoru), adaylar
#           `hiz`e gore azalan sirada, `maks_pozisyon` siniri, coin bekleme suresi
#   cikis : exit.decide_exit + cagiranin verdigi plan (trading.exit_rules
#           .plan_for_source) -- canlida 171.360/171.360 birebir olculen karar
#   K/Z   : net% = brut% - komisyon_toplam (position_service ile ayni)
#
# ILERIYE BAKMA YOK:
#   * sinyal bar t KAPANDIKTAN sonra bilinir -> giris bar t+1 ACILISINDAN
#   * bar i icindeki cikis kararlarinda gostergeler (atr_pct, deg5m, hacim_x)
#     bar i-1'in satirindan gelir (bar i'nin kendisi o an henuz bitmemistir)
#
# BAR ICI SIRA (temkinli varsayim -- once kotu senaryo):
#   1) DUSUK : once stop sinanir (tepe henuz bu barin yuksegini icermez).
#              Acilis zaten stopun altindaysa (bosluk) acilistan, degilse stop
#              fiyatindan cikilir.
#   2) YUKSEK: tepe guncellenir; sabit HEDEF burada tetiklenirse hedef
#              fiyatindan (acilis ustundeyse acilistan) cikilir.
#   3) KAPANIS: iz surme / kar trailing / zaman / yukselen tepeyle yukselen
#              stop. Stop bar araligindaysa stop fiyatindan, degilse kapanistan.
# ======================================================================
BAR_MS = 300_000


def _cikis_fiyati(karar, mum, giris: float, asama: str) -> float | None:
    acilis, yuksek, dusuk, kapanis = (float(mum[1]), float(mum[2]),
                                      float(mum[3]), float(mum[4]))
    neden = karar.reason
    if neden.startswith("STOP:"):
        stop = float(karar.stop.price)
        if asama == "dusuk":
            return acilis if acilis <= stop else stop
        return stop if dusuk <= stop <= yuksek else kapanis
    if neden.startswith("HEDEF:") and asama == "yuksek":
        hedef = giris * (1 + float(karar.target.target) / 100)
        return acilis if acilis >= hedef else hedef
    if asama == "kapanis":
        return kapanis
    return None


