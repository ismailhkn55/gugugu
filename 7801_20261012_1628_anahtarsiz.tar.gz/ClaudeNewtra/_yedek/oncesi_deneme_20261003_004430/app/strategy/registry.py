"""Strateji kayit defteri: liste, kaydet, sil, aktif secimi.

DEGISEN: strateji KAYDEDILIRKEN kurallari dogrulanir. Bilinmeyen alan
iceren strateji REDDEDILIR. Eski sistemde boyle bir strateji sorunsuz
kaydediliyor, sonra sonsuza kadar sifir aday veriyordu (`ema4` hala oyle).
"""
from __future__ import annotations

from typing import Any, Mapping

from app.config.paths import get_strategies_path
from app.core.applog import get_logger
from app.core.errors import UnknownFieldError
from app.core.jsonstore import read_json_file, write_json_file
from app.core.timeutil import now_ms
from app.market.indicators import list_available_fields
from app.strategy.rule_engine import OPERATORS, describe_rule, list_known_fields

_log = get_logger(__name__)


def _dosya() -> dict:
    d = read_json_file(get_strategies_path(), {}) or {}
    d.setdefault("stratejiler", [])
    return d


# Satir icin KISA, BENZERSIZ kod uretir (ad bas harfleri + sayilar).
# "TP085" -> "TP085"; "HA Cok Zamanli N3" -> "HCKZN3"; cakisan varsa sona 2,3...
def _kod_uret(ad: str, alinmis: set[str]) -> str:
    temiz = "".join(ch for ch in str(ad or "").upper() if ch.isalnum())[:6] or "ST"
    kod, i = temiz, 2
    while kod in alinmis:
        kod, i = f"{temiz}{i}", i + 1
    return kod


# `kod` ve `acik` alanlarini saglar: yeni satirda ikisi de yoksa uretilir.
# `acik` eski satirlarda da None olabilir -> True sayilir (aciklar).
def _kod_ve_acik_sagla(d: dict) -> bool:
    alinmis = {s.get("kod") for s in d["stratejiler"] if s.get("kod")}
    degisti = False
    for s in d["stratejiler"]:
        if not s.get("kod"):
            s["kod"] = _kod_uret(s.get("ad", ""), alinmis)
            alinmis.add(s["kod"])
            degisti = True
        if "acik" not in s:
            s["acik"] = True
            degisti = True
    return degisti


# Her satirin KOD ve AC/KAPA bayragi olur. Ismail: "tp 0,85 i begendim
# 7801 e bunu strategy olarak yap ... ayrica her satıra bi kod geliyor ya
# uygulamamızda ... ve en azından kapalısını görmezse deneme yapabilelim".
def list_strategies() -> dict:
    d = _dosya()
    if _kod_ve_acik_sagla(d):
        write_json_file(get_strategies_path(), d)
    return {"stratejiler": d["stratejiler"],
            "aktif_dry": d.get("aktif_dry"), "aktif_canli": d.get("aktif_canli")}


# Stratejiyi ACAR / KAPATIR (satir bileseni `stAnahtar`).
# Kapali strateji secilemez (`set_active_strategy` reddeder); su anda
# AKTIF olan bir strateji kapatilamaz -- bot onu kullanmaktadir.
def toggle_strategy(name: str, acik: bool) -> tuple[bool, str]:
    d = _dosya()
    hedef = next((s for s in d["stratejiler"] if s.get("ad") == name), None)
    if hedef is None:
        return False, "strateji yok"
    if not acik:
        hangi = None
        if d.get("aktif_dry") == name:
            hangi = "kagit (dry)"
        if d.get("aktif_canli") == name:
            hangi = ("canli" if not hangi else "kagit (dry) + canli")
        if hangi:
            return False, (f"'{name}' simdi AKTIF ({hangi}); once baska bir "
                           "stratejiye gec, sonra kapat")
    if bool(hedef.get("acik", True)) == bool(acik):
        return True, ("zaten acik" if acik else "zaten kapali")
    hedef["acik"] = bool(acik)
    write_json_file(get_strategies_path(), d)
    return True, ("acildi" if acik else "kapatildi")


# Stratejinin kurallarini bilinen alanlara karsi dogrular.
# Sorun listesi doner; bos liste = temiz.
def validate_strategy(strategy: Mapping[str, Any]) -> list[str]:
    sorunlar: list[str] = []
    bilinen = set(list_known_fields())
    for k in (strategy.get("kurallar") or []):
        metin = describe_rule(k)
        alan = k.get("alan")
        if not alan:
            sorunlar.append(f"{metin}: alan adi yok"); continue
        if alan not in bilinen:
            sorunlar.append(f"{metin}: '{alan}' diye bir alan YOK")
        if k.get("op") not in OPERATORS:
            sorunlar.append(f"{metin}: taninmayan operator '{k.get('op')}'")
        d2 = k.get("deger_alan")
        if d2 and d2 not in bilinen:
            sorunlar.append(f"{metin}: '{d2}' diye bir alan YOK")
        if not d2 and k.get("op") not in ("yukari", "asagi") and "deger" not in k:
            sorunlar.append(f"{metin}: ne deger ne deger_alan var")
    return sorunlar


# Aktif stratejiyi doner. `live` ZORUNLU -- kagit ve canli AYRI secilir.
def get_active_strategy(live: bool) -> dict:
    if not isinstance(live, bool):
        raise TypeError("get_active_strategy: `live` acikca True/False verilmeli")
    d = _dosya()
    ad = d.get("aktif_canli" if live else "aktif_dry")
    for s in d["stratejiler"]:
        if s.get("ad") == ad:
            return s
    if d["stratejiler"]:
        # Eski sistem burada SESSIZCE listenin ilkine dusuyordu; artik loglanir.
        _log.warning("aktif strateji bulunamadi (%r) -- listenin ilki kullaniliyor", ad)
        return d["stratejiler"][0]
    raise LookupError("hic strateji kayitli degil")


# Stratejiyi kaydeder. Bilinmeyen alan varsa UnknownFieldError firlatir.
def save_strategy(strategy: Mapping[str, Any], *, allow_unknown: bool = False) -> dict:
    sorunlar = validate_strategy(strategy)
    if sorunlar and not allow_unknown:
        raise UnknownFieldError(
            (strategy.get("kurallar") or [{}])[0].get("alan", "?"),
            tuple(list_available_fields()))
    d = _dosya()
    yeni = dict(strategy)
    yeni["guncelleme"] = now_ms()
    yeni.setdefault("acik", True)
    if not yeni.get("kod"):
        alinmis = {s.get("kod") for s in d["stratejiler"]
                   if s.get("kod") and s.get("ad") != yeni.get("ad")}
        yeni["kod"] = _kod_uret(yeni.get("ad", ""), alinmis)
    for i, s in enumerate(d["stratejiler"]):
        if s.get("ad") == yeni.get("ad"):
            d["stratejiler"][i] = yeni
            break
    else:
        d["stratejiler"].append(yeni)
    write_json_file(get_strategies_path(), d)
    return {"kaydedildi": yeni.get("ad"), "uyari": sorunlar}


# Strateji siler.
def delete_strategy(name: str) -> bool:
    d = _dosya()
    once = len(d["stratejiler"])
    d["stratejiler"] = [s for s in d["stratejiler"] if s.get("ad") != name]
    if len(d["stratejiler"]) == once:
        return False
    for k in ("aktif_dry", "aktif_canli"):
        if d.get(k) == name:
            d[k] = d["stratejiler"][0]["ad"] if d["stratejiler"] else None
    write_json_file(get_strategies_path(), d)
    return True


# Aktif stratejiyi secer. `live` ZORUNLU.
# `acik:false` olan strateji SECILEMEZ (kapali satir hicbir modda calismaz).
def set_active_strategy(name: str, *, live: bool) -> bool:
    if not isinstance(live, bool):
        raise TypeError("set_active_strategy: `live` acikca True/False verilmeli")
    d = _dosya()
    hedef = next((s for s in d["stratejiler"] if s.get("ad") == name), None)
    if hedef is None:
        return False
    if not hedef.get("acik", True):
        _log.warning("kapali strateji aktif edilemedi: %s", name)
        return False
    d["aktif_canli" if live else "aktif_dry"] = name
    write_json_file(get_strategies_path(), d)
    return True


# Aciklamadaki olcum sonucunun HANGI kural kumesine ait oldugunu damgalar.
# Aktif stratejinin aciklamasi 1D+4H+1H+5M Heikin Ashi'yi ve 6 aylik test
# sonuclarini anlatiyor; gercek kurallari ise wma48/cci/rank_atr/kdj_j/
# ha_ardisik_yesil. Yani o sonuclar CALISAN KURALLARA AIT DEGIL.
def stamp_measurement_context(strategy: Mapping[str, Any]) -> str:
    # 28.09.2026, Ismail: "ben de yazdim olmadi, sirayla mi yazmak
    # gerekiyor" -- bu ozet KAPALI (aktif:false) kurallari da gosteriyordu,
    # strateji listesinde disardan bakinca sanki hepsi (switch ile
    # kapatilanlar dahil) birbiriyle celisen dev bir VE zinciri gibi
    # gorunuyordu. `evaluate_rule_set` zaten sadece AKTIF kurallari
    # kullaniyor -- bu ozet de AYNI filtreyi uygulamali.
    kurallar = [k for k in (strategy.get("kurallar") or []) if k.get("aktif", True)]
    return " VE ".join(describe_rule(k) for k in kurallar) or "(kural yok)"
