// chartGrid.js -- GRAFIK sayfasi: SECILENLER'in ilk 9 coini, 3x3 TradingView grafigi.
//
// 05.10.2026, Ismail: "secilenler sayfasinin altinda grafik adinda bi sayfa, 9 tane
// tradingview ekranini sigdiracagiz, en ustte yatayda butonlar olacak trade ekranindaki
// gibi, her coinin uzerinde gunluk, 24 saatlik, 4 saatlik ve 2 saatlik yuzde" +
// "sayfa acilinca veri cekecek, sayfa kapali iken o sayfada veri cekme yok".
//
// VERI YUKU (Binance'e surekli sorgu YOK):
//   * aday listesi: /yerel/aday?n=9 -- sayfaya bagli zamanlayici (poll.js), 30 sn;
//     9'dan az secilen varsa bos kutular ANASAYFA'nin en ustundeki coinlerle dolar
//     (/yerel/ozet?n=20, yalniz eksik varsa) -- Ismail: "9 adet olacak dedim ya"
//   * mumlar: sayfa acilinca coin basina BIR kez 300 mum; sonra YALNIZ mum kapanisinda
//     coin basina 2 mum (5M'de 9 istek / 5 dk)
//   * canli fiyat: websocket (aggTrade) son mumu gunceller
// Sayfadan cikinca zamanlayici, mum kapanis zamani ve websocket KAPANIR; geri
// gelince her sey bastan cekilir (eski veri gosterilmez).
import { apiGet } from "../api.js";
import { bollinger, ema, heikinAshi, klineCevir, vwap } from "../chart/indicators.js";
import { createSocketManager } from "../live/socketManager.js";
import { registerPoll, sharePollResult } from "../poll.js";
import { getTercih, setTercih } from "../store.js";
import { openSymbol } from "./trade.js";

const KUTU_SAYISI = 9;
const MUM_SAYISI = 300;
const ARALIK_MS = { "5m": 300000, "1h": 3600000, "4h": 14400000, "1d": 86400000 };
const EMA_DONEM = [7, 20, 48, 99];
const EMA_RENK = ["#FFCC00", "#33CCCC", "#9999FF", "#FF9933"];
const KARE_SAYISI = 10;                 // trade ekraniyla AYNI: panel = 10 adet %1 karesi
const UST_PAY = 0.06, ALT_PAY = 0.22;

let _kuruldu = false;
let _acik = false;               // sayfa su an gorunuyor mu (kapaliyken HICBIR veri islenmez)
let _soket = null;
let _kapanisZamani = null;
let _semboller = [];             // kutulardaki coinler (sirayla)
let _satirlar = new Map();       // sembol -> /yerel/aday (ya da dolgu icin /yerel/ozet) satiri
let _dolgu = new Set();          // SECILEN olmayan, anasayfadan doldurulan coinler
const _kutular = new Map();      // sembol -> {kok, grafik, ser, mumlar, sonKapanis, merkez, izgara}

const tercih = () => ({ aralik: "5m", g: { hacim: true }, son: 128, ...(getTercih("grafikSayfa") || {}) });
const tercihYaz = (yama) => setTercih("grafikSayfa", { ...tercih(), ...yama });
const css = (ad, yedek) => getComputedStyle(document.documentElement).getPropertyValue(ad).trim() || yedek;

function fiyatYaz(p) {
  if (p == null || !isFinite(p)) return "";
  const a = Math.abs(p);
  return p.toFixed(a >= 100 ? 2 : a >= 1 ? 4 : a >= 0.01 ? 5 : 8);
}

// "#RRGGBB" -> yari soluk (trade grafigindeki %1 cizgileriyle ayni).
function yariSolukRenk(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex.trim());
  return m ? `rgba(${parseInt(m[1], 16)},${parseInt(m[2], 16)},${parseInt(m[3], 16)},0.5)` : hex;
}

// Kutunun mum serisi icin 10 kare eksen araligi (son kapanis ortada; kenara 1 kareden
// fazla yaklasirsa yeniden ortalanir). tvChart.onKareAraligi ile AYNI hesap.
function kareAraligiUret(k) {
  return (orijinal) => {
    const c = k.sonKapanis;
    if (!(c > 0)) return orijinal();
    const yarim = Math.pow(1.01, KARE_SAYISI / 2);
    if (!(k.merkez > 0) || c > k.merkez * yarim / 1.01 || c < k.merkez / yarim * 1.01) k.merkez = c;
    const alt = k.merkez / yarim, ust = k.merkez * yarim, boy = ust - alt;
    return { priceRange: { minValue: alt + boy * ALT_PAY, maxValue: ust - boy * UST_PAY } };
  };
}

// Tek kutunun TradingView grafigini kurar.
function kutuGrafigiKur(k) {
  const L = window.LightweightCharts;
  const izgara = css("--izgara-sik", "#0b2028");
  const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
  k.grafik = L.createChart(k.kok.querySelector(".grfGrafik"), {
    autoSize: true,
    layout: { background: { type: "solid", color: "transparent" }, textColor: css("--metin-sonuk", "#5d7d8a"),
              fontFamily: "Share Tech Mono, DejaVu Sans Mono, monospace",
              fontSize: document.documentElement.dataset.cihaz === "tv" ? 14 : 10 },
    grid: { vertLines: { color: izgara }, horzLines: { visible: false } },
    rightPriceScale: { borderColor: izgara, scaleMargins: { top: UST_PAY, bottom: ALT_PAY } },
    timeScale: { borderColor: izgara, timeVisible: true, secondsVisible: false, rightOffset: 2, barSpacing: 4 },
    crosshair: { mode: L.CrosshairMode.Normal },
    localization: { priceFormatter: fiyatYaz },
  });
  const cizgi = (color, lineStyle = 0) => k.grafik.addLineSeries({
    color, lineWidth: 1, lineStyle, priceLineVisible: false, lastValueVisible: false,
    crosshairMarkerVisible: false, autoscaleInfoProvider: () => null });
  k.ser = {
    hacim: k.grafik.addHistogramSeries({ priceScaleId: "hacim", priceFormat: { type: "volume" },
                                         priceLineVisible: false, lastValueVisible: false }),
    mum: k.grafik.addCandlestickSeries({ upColor: arti, downColor: eksi, borderUpColor: arti,
                                         borderDownColor: eksi, wickUpColor: arti, wickDownColor: eksi,
                                         autoscaleInfoProvider: kareAraligiUret(k) }),
    ema: EMA_RENK.map((r) => cizgi(r)),
    bb: [0, 2, 0].map((s) => cizgi("#6699CC", s)),
    vwap: cizgi("#CC99FF"),
  };
  k.grafik.priceScale("hacim").applyOptions({ visible: false, scaleMargins: { top: 0.82, bottom: 0 } });
  k.izgara = []; k.izgaraAnahtar = "";
}

// %1 yatay cizgiler: 1.01^k seviyeleri (trade grafigiyle AYNI fiyatlarda).
function yuzdeCizgileri(k, veri) {
  let az = Infinity, en = -Infinity;
  for (const m of veri) { if (m.d < az) az = m.d; if (m.y > en) en = m.y; }
  if (!(az > 0) || !(en > az)) return;
  const K = 1.01;
  const k0 = Math.floor(Math.log(az / K) / Math.log(K)), k1 = Math.ceil(Math.log(en * K) / Math.log(K));
  if (`${k0}:${k1}` === k.izgaraAnahtar) return;
  for (const c of k.izgara) k.ser.mum.removePriceLine(c);
  const renk = yariSolukRenk(css("--izgara-cizgi", "#1d4352"));
  k.izgara = [];
  for (let i = k0; i <= k1 && k.izgara.length < 300; i++) {
    k.izgara.push(k.ser.mum.createPriceLine({ price: Math.pow(K, i), color: renk, lineWidth: 1,
                                              lineStyle: 0, axisLabelVisible: false, title: "" }));
  }
  k.izgaraAnahtar = `${k0}:${k1}`;
}

// Kutunun mumlarini ve acik gostergeleri cizer.
function kutuCiz(k, sigdir = false) {
  if (!k.grafik || !k.mumlar.length) return;
  const g = tercih().g;
  const z = (ms) => Math.floor(ms / 1000);      // eksen UTC (Binance saati, trade ekraniyla ayni)
  const veri = g.ha ? heikinAshi(k.mumlar) : k.mumlar;
  const arti = css("--arti", "#33CC99"), eksi = css("--eksi", "#FF3366");
  k.sonKapanis = k.mumlar.at(-1).k;
  k.ser.mum.setData(veri.map((m) => ({ time: z(m.t), open: m.a, high: m.y, low: m.d, close: m.k })));
  k.ser.hacim.setData(!g.hacim ? [] : k.mumlar.map((m, i) => ({
    time: z(m.t), value: m.h || 0, color: (veri[i].k >= veri[i].a ? arti : eksi) + "66" })));
  const kap = k.mumlar.map((m) => m.k);
  const seri = (dizi) => k.mumlar.flatMap((m, i) =>
    dizi[i] != null && isFinite(dizi[i]) ? [{ time: z(m.t), value: dizi[i] }] : []);
  k.ser.ema.forEach((s, i) => s.setData(g.ema ? seri(ema(kap, EMA_DONEM[i])) : []));
  const b = g.bb ? bollinger(kap, 20, 2) : null;
  ["ust", "orta", "alt"].forEach((ad, i) => k.ser.bb[i].setData(b ? seri(b[ad]) : []));
  k.ser.vwap.setData(g.vwap ? seri(vwap(k.mumlar)) : []);
  yuzdeCizgileri(k, veri);
  if (sigdir) sonMumlariGoster(k);
}

// Kutuda son N mumu (ya da TUMU) gosterir.
function sonMumlariGoster(k) {
  const n = tercih().son, top = k.mumlar.length;
  if (!k.grafik || !top) return;
  if (n === "tumu") k.grafik.timeScale().fitContent();
  else k.grafik.timeScale().setVisibleLogicalRange({ from: Math.max(0, top - n), to: top + 2 });
}

// Kutu basligindaki fiyat + GUN / 24s / 4s / 2s yuzdeleri.
function basligiYaz(k, sembol) {
  const s = _satirlar.get(sembol) || {};
  const dolgu = _dolgu.has(sembol);
  k.kok.classList.toggle("grfDolgu", dolgu);
  k.kok.querySelector(".grfEtiket").textContent = dolgu ? `ANASAYFA #${s.rank ?? "?"}` : "SECILEN";
  const fiyat = k.sonKapanis ?? s.fiyat;
  k.kok.querySelector(".grfFiyat").textContent = fiyat == null ? "·" : fiyatYaz(fiyat);
  for (const [alan, el] of [["gun_pct", "gun"], ["deg24", "d24"], ["deg4h", "d4"], ["deg2h", "d2"]]) {
    const kutu = k.kok.querySelector(`[data-y="${el}"]`);
    const v = s[alan];
    kutu.classList.toggle("arti", v > 0);
    kutu.classList.toggle("eksi", v < 0);
    kutu.querySelector("b").textContent = v == null ? "·" : (v > 0 ? "+" : "") + (+v).toFixed(1) + "%";
  }
}

// Tek coinin mumlarini sunucudan ceker (sayfa kapaliysa HIC cekmez).
async function mumlariCek(sembol, limit) {
  if (!_acik) return null;
  const d = await apiGet(`/yerel/mum?symbol=${sembol}&interval=${tercih().aralik}&limit=${limit}`, { sessiz: true });
  return Array.isArray(d) ? klineCevir(d) : null;
}

// Kutulari coin listesine gore kurar; yeni coinin 300 mumu cekilir.
async function kutulariGuncelle() {
  const izgara = document.getElementById("grfIzgara");
  if (!izgara || !_acik) return;
  const bos = izgara.querySelector(".grfBos");
  if (bos) bos.hidden = _semboller.length > 0;
  for (const [s, k] of _kutular) {
    if (_semboller.includes(s)) continue;
    try { k.grafik?.remove(); } catch { /* zaten kaldirilmis */ }
    k.kok.remove();
    _kutular.delete(s);
  }
  const yeniler = [];
  _semboller.forEach((s, i) => {
    let k = _kutular.get(s);
    if (!k) {
      const kok = document.createElement("div");
      kok.className = "grfKutu";
      kok.dataset.sembol = s;
      kok.innerHTML = `<div class="grfBaslik"><b class="grfAd" title="TRADE ekraninda ac">${s.replace(/USDT$/, "")}</b>`
        + `<span class="grfEtiket"></span><span class="grfFiyat">·</span>`
        + `<span class="trKutu" data-y="gun" title="UTC gunu icindeki degisim"><i>GUN</i><b>·</b></span>`
        + `<span class="trKutu" data-y="d24" title="son 24 saat"><i>24s</i><b>·</b></span>`
        + `<span class="trKutu" data-y="d4" title="son 4 saat"><i>4s</i><b>·</b></span>`
        + `<span class="trKutu" data-y="d2" title="son 2 saat"><i>2s</i><b>·</b></span></div>`
        + `<div class="grfGrafik"></div>`;
      k = { kok, grafik: null, ser: null, mumlar: [], sonKapanis: null, merkez: null };
      _kutular.set(s, k);
      yeniler.push(s);
    }
    k.kok.style.order = i;
    if (!k.kok.isConnected) izgara.appendChild(k.kok);
    if (!k.grafik) kutuGrafigiKur(k);
    basligiYaz(k, s);
  });
  _soket?.subscribeSymbols(_semboller);
  await Promise.all(yeniler.map(async (s) => {
    const m = await mumlariCek(s, MUM_SAYISI);
    const k = _kutular.get(s);
    if (!m || !k) return;
    k.mumlar = m;
    kutuCiz(k, true);
    basligiYaz(k, s);
  }));
  kapanisiKur();
}

// Mum kapanisinda (aralik sinirindan 3 sn sonra) her coinin SON 2 mumu cekilir.
function kapanisiKur() {
  clearTimeout(_kapanisZamani);
  if (!_acik) return;
  const ms = ARALIK_MS[tercih().aralik] || 300000;
  const kalan = ms - (Date.now() % ms) + 3000;
  _kapanisZamani = setTimeout(async () => {
    await Promise.all(_semboller.map(async (s) => {
      const m = await mumlariCek(s, 2);
      const k = _kutular.get(s);
      if (!m || !k || !k.mumlar.length) return;
      for (const y of m) {
        const i = k.mumlar.findIndex((x) => x.t === y.t);
        if (i >= 0) k.mumlar[i] = y;
        else if (y.t > k.mumlar.at(-1).t) k.mumlar.push(y);
      }
      if (k.mumlar.length > MUM_SAYISI + 50) k.mumlar.splice(0, k.mumlar.length - MUM_SAYISI);
      kutuCiz(k);
    }));
    kapanisiKur();
  }, kalan);
}

// Websocket fiyati: son mumu gunceller (yeni doneme gectiyse yeni mum acar).
function fiyatGeldi(sembol, f, _onceki, ts) {
  if (!_acik) return;
  const k = _kutular.get(sembol);
  if (!k || !k.mumlar.length || !(f > 0)) return;
  const ms = ARALIK_MS[tercih().aralik] || 300000;
  const donem = Math.floor((ts || Date.now()) / ms) * ms;
  const son = k.mumlar.at(-1);
  if (donem > son.t) k.mumlar.push({ t: donem, a: f, y: f, d: f, k: f, h: 0 });
  else if (donem === son.t) { son.y = Math.max(son.y, f); son.d = Math.min(son.d, f); son.k = f; }
  else return;
  k.sonKapanis = f;
  if (k.cizimBekliyor) return;               // saniyede ~20 tik: kare basina tek cizim
  k.cizimBekliyor = true;
  requestAnimationFrame(() => {
    k.cizimBekliyor = false;
    if (!_acik || !k.grafik) return;
    const g = tercih().g, m = k.mumlar.at(-1);
    const v = g.ha ? heikinAshi(k.mumlar.slice(-60)).at(-1) : m;
    k.ser.mum.update({ time: Math.floor(m.t / 1000), open: v.a, high: v.y, low: v.d, close: v.k });
    k.kok.querySelector(".grfFiyat").textContent = fiyatYaz(f);
  });
}

// Ust dugmelerin acik/kapali gorunumu tercihle esitlenir.
function dugmeleriIsaretle() {
  const t = tercih();
  for (const b of document.querySelectorAll("#grfUst [data-aralik]")) b.classList.toggle("acik", b.dataset.aralik === t.aralik);
  for (const b of document.querySelectorAll("#grfUst [data-g]")) b.classList.toggle("acik", !!t.g[b.dataset.g]);
  for (const b of document.querySelectorAll("#grfUst [data-son]")) b.classList.toggle("acik", String(t.son) === b.dataset.son);
}

// Aralik degisince tum mumlar bastan cekilir.
function araligiDegistir(aralik) {
  tercihYaz({ aralik });
  yenidenCek();
}

// Tum kutularin 300 mumunu bastan ceker (sayfa acilisi / aralik degisimi).
async function yenidenCek() {
  await Promise.all(_semboller.map(async (s) => {
    const m = await mumlariCek(s, MUM_SAYISI);
    const k = _kutular.get(s);
    if (!m || !k) return;
    k.mumlar = m; k.merkez = null;
    kutuCiz(k, true);
    basligiYaz(k, s);
  }));
  kutulariGuncelle();
}

// Aday listesi; 9'dan azsa eksik kadar anasayfanin en ust coinleri eklenir.
async function adaylariCek() {
  const d = await apiGet("/yerel/aday?n=9", { sessiz: true });
  if (!d) return null;
  // Ismail: "ayni coinden 2 tane olmasin" -- ayni sembol ya da ayni TABAN coin
  // (ADAUSDT / ADAUSDC) ikinci kez kutu almaz; once SECILEN, sonra dolgu.
  const goruldu = new Set();
  const tekil = (x) => {
    const taban = String(x.sembol || "").toUpperCase().replace(/(USDT|USDC|FDUSD)$/, "");
    if (!taban || goruldu.has(taban)) return false;
    goruldu.add(taban);
    return true;
  };
  const aday = (d.aday || []).filter(tekil).slice(0, KUTU_SAYISI);
  let dolgu = [];
  if (aday.length < KUTU_SAYISI) {
    const o = await apiGet("/yerel/ozet?n=30", { sessiz: true });
    dolgu = (o?.satir || []).filter(tekil).slice(0, KUTU_SAYISI - aday.length);
  }
  return { strateji: d.strateji, aday, dolgu };
}

// Aday sonucu: 9 kutu (once SECILENLER, sonra anasayfa dolgusu) + yuzdeler.
function adaylarGeldi(d) {
  if (!_acik || !d) return;
  const liste = [...d.aday, ...d.dolgu];
  _satirlar = new Map(liste.map((x) => [x.sembol, x]));
  _dolgu = new Set(d.dolgu.map((x) => x.sembol));
  const bilgi = document.getElementById("grfBilgi");
  if (bilgi) bilgi.textContent = `${d.strateji || "-"} · ${d.aday.length} SECILEN`
    + (d.dolgu.length ? ` + ${d.dolgu.length} ANASAYFA (en ust sira)` : "");
  const yeni = liste.map((x) => x.sembol);
  const ayni = yeni.length === _semboller.length && yeni.every((s, i) => s === _semboller[i]);
  _semboller = yeni;
  if (ayni) { for (const [s, k] of _kutular) basligiYaz(k, s); return; }
  kutulariGuncelle();
}

// GRAFIK sayfasini kurar: dugmeler bir kez baglanir; her giriste veri bastan cekilir.
export function mountChartGridPage() {
  if (_acik && _soket) return;     // zaten acik (ayni sayfaya tekrar tiklandi) -- ikinci soket acma
  _acik = true;
  if (!window.LightweightCharts) return;
  _soket = createSocketManager({ onFiyat: fiyatGeldi });
  dugmeleriIsaretle();
  if (_kuruldu) {
    _semboller = [];               // eski coin/mum gosterilmez -- aday gelince bastan
    for (const [s, k] of _kutular) {
      try { k.grafik?.remove(); } catch { /* zaten kaldirilmis */ }
      k.kok.remove(); _kutular.delete(s);
    }
    return;                        // zamanlayici sayfaya girince kendiliginden tur atar
  }
  _kuruldu = true;
  document.getElementById("grfUst")?.addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    if (b.dataset.aralik) { araligiDegistir(b.dataset.aralik); dugmeleriIsaretle(); return; }
    if (b.dataset.g) {
      const g = { ...tercih().g, [b.dataset.g]: !tercih().g[b.dataset.g] };
      tercihYaz({ g });
      for (const k of _kutular.values()) kutuCiz(k);
    } else if (b.dataset.son) {
      tercihYaz({ son: b.dataset.son === "tumu" ? "tumu" : +b.dataset.son });
      for (const k of _kutular.values()) sonMumlariGoster(k);
    }
    dugmeleriIsaretle();
  });
  document.getElementById("grfIzgara")?.addEventListener("click", (e) => {
    const s = e.target.closest(".grfAd") && e.target.closest(".grfKutu")?.dataset.sembol;
    if (s) openSymbol(s);
  });
  registerPoll("grafikAday", 30, adaylariCek, { sayfa: "grafik" });
  sharePollResult("grafikAday", adaylarGeldi);
}

// Sayfadan cikis: websocket, mum kapanis zamanlayicisi ve aday zamanlayicisi DURUR.
export function unmountChartGridPage() {
  _acik = false;
  clearTimeout(_kapanisZamani); _kapanisZamani = null;
  if (_soket) { _soket.subscribeSymbols([]); _soket.close(); _soket = null; }
}
