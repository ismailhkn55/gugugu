// strategies.js -- STRATEJILER: liste, kural duzenleyici, geriye-test bilgisi.
//
// IKI YENILIK:
// 1. Alan listesi SUNUCUDAN gelir (`/yerel/strateji` -> `alanlar`). Eski
//    sistemde arayuz kendi listesini tutuyordu ve icinde `ema4` vardi --
//    veritabaninda OLMAYAN bir alan. Onu secen kural sonsuza kadar sifir
//    aday veriyor, hata da vermiyordu.
// 2. Her strateji icin "geriye testte SINANABILIR mi" bilgisi gosterilir.
import { apiGet, apiPost } from "../api.js";
import { askConfirm } from "../ui/confirm.js";
import { showToast } from "../ui/toast.js";
import { fieldLabel, formatSigned, formatRuleValue, formatUsdt, operatorLabel } from "../format.js";
import { registerPoll, refreshNow, sharePollResult } from "../poll.js";
import { getState, setState } from "../store.js";
import { botuAcKapat } from "./botPage.js";
import { apiGet as _apiGet } from "../api.js";

let _kuruldu = false;
let _secili = null;
let _kurallar = [];
let _alanlar = [];
let _operatorler = [];
let _aciklamalar = {};   // alan -> aciklama metni (sunucudan, COLUMN_REGISTRY)

// Kural listesini cizer.  (eski: kurallariCiz)
//
// 27.09.2026, Ismail: "her seferinde silmek istemiyorum, o secenegin
// uzerine switch koy acik kapali" -- her satirda kucuk bir ac/kapa anahtari
// (`data-ac="i"`). Kapali kural SILINMEZ, `aktif:false` ile listede soluk
// kalir; sunucu tarafinda rule_engine.evaluate_rule_set bunu ATLAR.
export function renderRuleEditor() {
  const e = document.getElementById("stKurallar");
  if (!e) return;
  e.innerHTML = _kurallar.length
    ? _kurallar.map((k, i) => {
        const acik = k.aktif !== false;
        return `
      <div class="kuralSatir${acik ? "" : " kuralKapali"}" data-i="${i}">
        <button class="kuralAnahtar${acik ? " acik" : ""}" data-ac="${i}"
                title="${acik ? "Bu kurali gecici kapat" : "Bu kurali ac"}">${acik ? "●" : "○"}</button>
        <span>${fieldLabel(k.alan)} <b>${operatorLabel(k.op)}</b> ${
          k.deger_alan ? fieldLabel(k.deger_alan)
                       : formatRuleValue(k.alan, k.deger)}</span>
        <button data-sil="${i}" title="Kurali TAMAMEN sil">×</button>
      </div>`;
      }).join("")
    : `<div class="kucuk">kural yok — asagidan ekle</div>`;
  renderRulePreview();
}

// Kural kumesinin okunur ozeti.  (eski: onizle)
export function renderRulePreview() {
  const e = document.getElementById("stOnizleme");
  if (!e) return;
  const acikKurallar = _kurallar.filter((k) => k.aktif !== false);
  e.textContent = acikKurallar.length
    ? acikKurallar.map((k) => `${k.alan} ${k.op} ${k.deger_alan || formatRuleValue(k.alan, k.deger)}`).join("  VE  ")
    : (_kurallar.length ? "— (tum kurallar kapali)" : "—");
}

// Alan ve operator seceneklerini SUNUCUDAN doldurur.
//
// 27.09.2026, Ismail: "seceneklerini az aciklayici yap" -- her secenegin
// uzerine gelince (title) COLUMN_REGISTRY'deki gercek aciklamasi cikar;
// metin JS'te TEKRAR YAZILMAZ, sunucudan (`aciklamalar`) gelir.
function secenekleriDoldur() {
  for (const id of ["kAlan", "kDegerAlan"]) {
    const s = document.getElementById(id);
    if (!s) continue;
    const bos = id === "kDegerAlan" ? `<option value="">(sabit sayi)</option>` : "";
    s.innerHTML = bos + _alanlar.map((a) =>
      `<option value="${a}" title="${(_aciklamalar[a] || "").replace(/"/g, "&quot;")}">${fieldLabel(a)}</option>`).join("");
  }
  const o = document.getElementById("kOp");
  if (o) o.innerHTML = _operatorler.map((x) =>
    `<option value="${x}">${operatorLabel(x)}</option>`).join("");
}

// Kayitli stratejileri listeler.  (eski: listeCiz)
//
// Her satirda: KOD (rozetin solunda), ac/kapa anahtari (`stAnahtar`).
// Kapali satir soluk gorunur; kapali strateji bot tarafinda secilemez
// (`set_active_strategy` reddeder). TP gosteren stratejide "TP %x" rozeti.
export function renderStrategyList(d) {
  const e = document.getElementById("stListe");
  if (!e) return;
  const liste = d?.stratejiler || [];
  e.innerHTML = liste.map((s) => {
    const sorun = s._dogrulama?.length;
    const gt = s._geriye_test || {};
    const acik = s.acik !== false;
    const tp = s.cikis?.hedef_normal;
    return `<div class="stOge ${s.ad === _secili ? "secili" : ""}${acik ? "" : " kapali"}"
                 data-ad="${s.ad}">
      <div class="stSutun">
        <div class="stOgeBas">
          <span class="stKod">${s.kod || ""}</span><b>${s.ad}</b>
          ${d.aktif_dry === s.ad ? '<span class="rozet">KAGIT</span>' : ""}
          ${d.aktif_canli === s.ad ? '<span class="rozet canli">CANLI</span>' : ""}
          ${tp != null ? `<span class="rozet tp">TP %${tp}</span>` : ""}</div>
        <div class="kucuk">${(s._calisan_kurallar || "").slice(0, 90)}</div>
        ${sorun ? `<div class="eksi kucuk">HATA: ${s._dogrulama[0]}</div>` : ""}
        ${gt.sinanamaz?.length
          ? `<div class="kucuk uyari">geriye testte sinanamaz: ${gt.sinanamaz.join(", ")}</div>` : ""}
      </div>
      <button class="stAnahtar${acik ? "" : " kapali"}" data-anahtar="${s.ad}"
              title="stratejiyi ac / kapat">${acik ? "ACIK" : "KAPALI"}</button>
    </div>`;
  }).join("") || `<div class="bos">strateji yok</div>`;
}

// Secili stratejiyi forma basar.  (eski: formaBas)
export function fillStrategyForm(s) {
  const yaz = (id, v) => { const e = document.getElementById(id); if (e) e.value = v ?? ""; };
  yaz("stAd", s?.ad); yaz("stAciklama", s?.aciklama);
  yaz("stTutar", s?.tutar); yaz("stTutarYuzde", s?.tutar_yuzde);
  yaz("stMaks", s?.maks_pozisyon); yaz("stHedefG", s?.gunluk_hedef);
  yaz("stTp", s?.cikis?.hedef_normal ?? s?.cikis?.hedef_yavas);
  yaz("stZamanDk", s?.cikis?.zaman_asimi_dk);
  // ANA PARA stratejinin degil, AYARIN alanidir (`kagit_bakiye`).
  //
  // 23.09.2026, Ismail: "ben bota 100 dolar tanimliyorum ama botta hala
  // 30 yaziyor". Sebep: bu kutu `s?.ana_para` okuyordu -- strateji
  // kaydinda boyle bir alan YOK, dolayisiyla kutu hep bos geliyordu; ve
  // `collectStrategyForm` onu hic TOPLAMIYORDU, yani yazdigin deger
  // hicbir yere gitmiyordu. Yardim metni "ayarlardaki ayni degerdir"
  // diyordu ama bagli degildi.
  yaz("stAnaPara", getState("ayar")?.kagit_bakiye);
  _kurallar = JSON.parse(JSON.stringify(s?.kurallar || []));
  renderRuleEditor();
  const a = document.getElementById("stAktifAd");
  if (a) a.textContent = s?.ad || "—";
}

// Formdaki strateji tanimini nesneye toplar.  (eski: formdanTopla)
//
// CIKIS: yalnizca doldurulan alanlar gonderilir. TP bos birakilirsa
// `cikis` GONDERILMEZ -> stratejinin eski cikis tanimi da silinir ve bot
// global plani kullanir. Sunucuda (`plan_for_source`) strateji ciks'i
// global planin UZUNE biner; `None` degerler gecmez.
export function collectStrategyForm() {
  const al = (id) => document.getElementById(id)?.value;
  const sayi = (id) => { const v = parseFloat(al(id)); return Number.isFinite(v) ? v : null; };
  const tp = sayi("stTp");
  const zaman = sayi("stZamanDk");
  const st = { ad: (al("stAd") || "").trim(), aciklama: al("stAciklama") || "",
               tutar: sayi("stTutar"), tutar_yuzde: sayi("stTutarYuzde"),
               maks_pozisyon: sayi("stMaks"), gunluk_hedef: sayi("stHedefG"),
               kurallar: _kurallar };
  const cikis = {};
  if (tp != null && tp > 0) {
    // Saf sabit hedef: trailing/dinamik tamamen disari, hedef her hizde ayni.
    cikis.hedef_yavas = tp;
    cikis.hedef_normal = tp;
    cikis.hizli_esik = 999999;
    cikis.hiz_yavas = -999999;
    cikis.kar_trailing_esik = null;
    cikis.trailing = null;
    cikis.zaman_asimi_dk = zaman != null && zaman > 0 ? zaman : 0;
  } else if (zaman != null && zaman > 0) {
    cikis.zaman_asimi_dk = zaman;      // sadece zaman asimi istenmis
  }
  if (Object.keys(cikis).length) st.cikis = cikis;
  return st;
}

// Strateji listesini VE botun cuzdanini sunucudan ceker.  (eski: stratejiYukle)
//
// Cuzdan da buradan geliyor cunku bu sayfadaki "BOT KONTROL" karti botun
// HANGI parayla calistigini gostermeli: bot kagit modda kagit cuzdani,
// canli modda gercek bakiyeyi kullanir.
export async function refreshStrategies() {
  const [liste, bakiye] = await Promise.all([
    apiGet("/yerel/strateji", { sessiz: true }),
    apiGet("/yerel/bakiye", { sessiz: true }),
  ]);
  return liste ? { ...liste, bakiye } : null;
}

// Strateji komutunu (kaydet / sil / etkinlestir) calistirir.  (eski: stratejiCalistir)
export async function runStrategyCommand(govde) {
  const c = await apiPost("/yerel/strateji", govde);
  if (c?.hata) {
    showToast(c.hata + (c.sorunlar?.length ? " — " + c.sorunlar[0] : ""), "hata", 8000);
    return null;
  }
  refreshNow("strateji");
  return c;
}

// Strateji sayfasindaki bot ozeti.
function botOzetiCiz(d) {
  const yaz = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  yaz("stKip", d.bot_canli ? "CANLI" : "KAGIT");
  yaz("stPoz", String(d.acik_pozisyon ?? 0));
  yaz("stGun", formatSigned(d.bugun_kar_p));
  // BOTUN NEREDE calistigi ACIKCA yazilir.
  //
  // 23.09.2026, Ismail: "bot calistir dedim, bot nerede calisiyor belli
  // degil; bot dry run'da calisiyor demeli". Onceden yalnizca
  // "CALISIYOR" yaziyordu -- hangi parayla calistigi gorunmuyordu.
  const b = document.getElementById("botBilgi");
  if (b) {
    const calisan = (d.isler || []).filter((j) => j.calisiyor).length;
    const nerede = d.bot_canli ? "CANLI'DA (GERCEK PARA)" : "DRY RUN'DA (KAGIT)";
    b.textContent = d.bot_acik
      ? `${nerede} CALISIYOR · ${calisan}/${(d.isler || []).length} is`
      : `DURDU · calistirilirsa ${nerede} calisacak`;
    b.className = "botBilgi " + (d.bot_acik ? (d.bot_canli ? "eksi" : "arti") : "");
  }
  const ac = document.getElementById("btnBotAc");
  if (ac) ac.textContent = d.bot_acik ? "BOTU DURDUR" : "BOTU CALISTIR";
  const devam = document.getElementById("btnBotDevam");
  if (devam) devam.style.display = d.durum?.durdu ? "" : "none";
}

// Botun cuzdanini ve AKTIF STRATEJININ para ayarlarini yazar.
//
// Bot giris tutarini stratejiden alir (`trade_loop.try_strategy_entry`:
// `st.tutar` varsa onu, yoksa genel `ayar.tutar`). Bu satirlar o gercegi
// ekrana tasir -- eskiden sayfada botun parasina dair HICBIR sey yoktu.
export function renderStrategyWallet(bakiye, strateji, botCanli) {
  const yaz = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  const c = botCanli ? bakiye?.gercek : bakiye?.kagit;
  yaz("stCuzdan", c?.toplam == null
    ? (botCanli ? "gercek cuzdan okunamadi" : "·")
    : `${formatUsdt(c.toplam)} USDT (${botCanli ? "gercek" : "kagit"})`);

  const yuzde = strateji?.tutar_yuzde;
  const tutar = strateji?.tutar;
  const etkin = yuzde != null && c?.toplam != null
    ? (c.toplam * yuzde) / 100
    : (tutar != null ? +tutar : null);
  yaz("stIslemTutar", etkin == null ? "·"
    : yuzde != null ? `%${yuzde} = ${formatUsdt(etkin)} USDT`
    : `${formatUsdt(etkin)} USDT`);

  const maks = strateji?.maks_pozisyon;
  yaz("stBagli", etkin == null || !maks ? "·"
    : `${formatUsdt(etkin * maks)} USDT (${maks} pozisyon)`);
}

// STRATEJILER sayfasini kurar ve form olaylarini baglar.
export function mountStrategiesPage() {
  if (_kuruldu) return;
  _kuruldu = true;

  // "alanla kiyasla" -- sabit sayi yerine BASKA BIR ALANLA kiyaslama.
  const karsi = document.getElementById("kAlanKarsi");
  const alanSec = () => {
    const acik = !!karsi?.checked;
    const da = document.getElementById("kDegerAlan");
    const dd = document.getElementById("kDeger");
    if (da) da.hidden = !acik;
    if (dd) dd.hidden = acik;
  };
  karsi?.addEventListener("change", alanSec);
  alanSec();

  // bot bekleme ayarlari
  document.getElementById("btnBotBeklemeKaydet")?.addEventListener("click", async () => {
    const { apiPost } = await import("../api.js");
    const c = await apiPost("/yerel/ayar", {
      bot_bekleme_sn: parseInt(document.getElementById("botBeklemeSn")?.value, 10) || 0,
      coin_bekleme_dk: parseInt(document.getElementById("coinBeklemeDk")?.value, 10) || 0 });
    if (c) showToast("BEKLEME AYARI KAYDEDILDI", "bilgi");
  });
  document.getElementById("btnBotDevam")?.addEventListener("click", async () => {
    const { apiPost } = await import("../api.js");
    await apiPost("/yerel/bot", { devam: 1 });
    refreshNow("stratejiBot");
  });

  registerPoll("stratejiBot", 5, () => _apiGet("/yerel/bot", { sessiz: true }), { sayfa: "stratejiler" });
  sharePollResult("stratejiBot", (d) => {
    botOzetiCiz(d);
    const a = getState("ayar") || {};
    const bs = document.getElementById("botBeklemeSn");
    const cb = document.getElementById("coinBeklemeDk");
    if (bs && document.activeElement !== bs) bs.value = a.bot_bekleme_sn ?? "";
    if (cb && document.activeElement !== cb) cb.value = a.coin_bekleme_dk ?? "";
  });

  document.getElementById("btnKuralEkle")?.addEventListener("click", () => {
    const alan = document.getElementById("kAlan")?.value;
    const op = document.getElementById("kOp")?.value;
    const karsiAcik = !!document.getElementById("kAlanKarsi")?.checked;
    const degerAlan = karsiAcik ? document.getElementById("kDegerAlan")?.value : "";
    const deger = parseFloat(document.getElementById("kDeger")?.value);
    if (!alan || !op) return;
    const k = { alan, op, aktif: true };
    if (["yukari", "asagi"].includes(op)) { /* deger yok */ }
    else if (degerAlan) k.deger_alan = degerAlan;
    else if (Number.isFinite(deger)) k.deger = deger;
    else return showToast("deger ya da karsi alan gerekli", "uyari");
    _kurallar.push(k);
    renderRuleEditor();
  });

  document.getElementById("stKurallar")?.addEventListener("click", (e) => {
    const ac = e.target.dataset.ac;
    if (ac !== undefined) {
      const k = _kurallar[+ac];
      if (k) k.aktif = k.aktif === false;   // false->true, (true|undefined)->false
      renderRuleEditor();
      return;
    }
    const i = e.target.dataset.sil;
    if (i === undefined) return;
    _kurallar.splice(+i, 1);
    renderRuleEditor();
  });

  document.getElementById("stListe")?.addEventListener("click", async (e) => {
    // AC/KAPA anahtari: satirdaki `stAnahtar` butonu. Secim yapmaz, sadece
    // bayragi cevirir; sunucu aktif stratejiyi kapatmayi reddederse
    // `hata` mesaji toast olarak gosterilir (apiPost hatasi).
    const anahtar = e.target.closest("[data-anahtar]");
    if (anahtar) {
      const ad = anahtar.dataset.anahtar;
      const s = (getState("stratejiler") || []).find((x) => x.ad === ad);
      const acik = !(s?.acik !== false);          // su anki -> cevrilecek hali
      const c = await runStrategyCommand({ anahtar: { ad, acik } });
      if (c?.ok) showToast(`${ad}: ${c.mesaj === "acildi" ? "ACIK" : "KAPALI"}`, "ok");
      return;
    }
    const ad = e.target.closest("[data-ad]")?.dataset.ad;
    if (!ad) return;
    _secili = ad;
    const d = await apiGet("/yerel/strateji", { sessiz: true });
    fillStrategyForm(d?.stratejiler?.find((x) => x.ad === ad));
    renderStrategyList(d);
  });

  // BOTU CALISTIR dugmesi BU SAYFADA duruyor (BOT KONTROL karti) ama
  // tiklama olayi `botPage.js` icinde baglaniyordu -- yani yalnizca BOT
  // sayfasina girildiginde calisiyordu.
  //
  // 23.09.2026, Ismail: "botu calistir dedim hic bi sey gelmedi".
  // Stratejiler sayfasindan basildiginda dugme OLUYDU. Isaretleme
  // (`btnBotAc` yazisi) burada, olay orada olunca kimse fark etmemis.
  // Ayni sinif hata: butonlarin `disabled` kalmasi (bkz. 7.13).
  document.getElementById("btnBotAc")?.addEventListener("click", botuAcKapat);
  document.getElementById("btnBotDevam")?.addEventListener("click", async () => {
    const c = await apiPost("/yerel/bot", { devam: 1 });
    if (c) { showToast("bot devam ediyor", "ok"); refreshNow("stratejiBot"); }
  });

  document.getElementById("btnStYeni")?.addEventListener("click", () => {
    _secili = null; fillStrategyForm({ ad: "", kurallar: [] });
  });
  document.getElementById("btnStKaydet")?.addEventListener("click", async () => {
    const st = collectStrategyForm();
    if (!st.ad) return showToast("strateji adi gerekli", "uyari");
    // ANA PARA ayara yazilir (strateji kaydinin alani degil).
    const ana = document.getElementById("stAnaPara")?.value;
    const anaSayi = ana === "" || ana == null ? null : +ana;
    if (anaSayi != null && Number.isFinite(anaSayi)
        && anaSayi !== +(getState("ayar")?.kagit_bakiye ?? NaN)) {
      const a = await apiPost("/yerel/ayar", { kagit_bakiye: anaSayi });
      if (a?.ayar) {
        setState({ ayar: a.ayar });
        showToast(`kagit ana para: ${anaSayi} USDT`, "ok");
      }
    }
    const c = await runStrategyCommand({ strateji: st });
    if (c) showToast(`kaydedildi: ${c.kaydedildi}`, "ok");
  });
  document.getElementById("btnStSil")?.addEventListener("click", async () => {
    if (!_secili) return;
    if (!await askConfirm("STRATEJIYI SIL", _secili)) return;
    await runStrategyCommand({ sil: _secili });
    _secili = null; fillStrategyForm(null);
  });
  document.getElementById("btnStCalistirDry")?.addEventListener("click", async () => {
    if (_secili) { await runStrategyCommand({ aktif_yap: _secili, canli: false });
                   showToast(`${_secili} KAGIT botta aktif`, "ok"); }
  });
  document.getElementById("btnStCalistirCanli")?.addEventListener("click", async () => {
    if (!_secili) return;
    if (!await askConfirm("CANLI BOTTA CALISTIR",
      `${_secili} GERCEK PARA ile calisacak.`, { onayMetni: "CANLI" })) return;
    await runStrategyCommand({ aktif_yap: _secili, canli: true });
    showToast(`${_secili} CANLI botta aktif`, "uyari");
  });

  registerPoll("strateji", 30, refreshStrategies, { sayfa: "stratejiler" });
  sharePollResult("strateji", (d) => {
    setState({ stratejiler: d.stratejiler || [] });
    if (d.alanlar && d.alanlar.length !== _alanlar.length) {
      _alanlar = d.alanlar; _operatorler = d.operatorler || [];
      _aciklamalar = d.aciklamalar || {};
      secenekleriDoldur();
    }
    if (!_secili) {
      _secili = d.aktif_dry || d.stratejiler?.[0]?.ad || null;
      fillStrategyForm(d.stratejiler?.find((x) => x.ad === _secili));
    }
    renderStrategyList(d);
    // Botun parasi: AKTIF stratejinin tutar ayarlariyla birlikte.
    const botCanli = !!getState("bot")?.bot_canli;
    const aktifAd = botCanli ? d.aktif_canli : d.aktif_dry;
    const aktif = d.stratejiler?.find((x) => x.ad === (aktifAd || d.aktif_dry));
    renderStrategyWallet(d.bakiye, aktif, botCanli);
  });
}
