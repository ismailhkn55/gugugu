"""Cikis karari -- SISTEMDEKI TEK KARAR NOKTASI.

ESKI SISTEMDEKI ASIL CAKISMA (kullanicinin "birbiriyle cakisiyor" dedigi sey):
IKI ayri cikis motoru ayni anda calisiyordu.

  Motor A -- `takipci()`, 1 saniyede bir, websocket'ten:
      kendi `if/elif`'i vardi; `e["kar_al"]` alanini okuyup satiyordu.
  Motor B -- `bot_turu()`, 5 saniyede bir:
      `ST.cikis_karari()` ile tam kural zincirini calistiriyordu.

Ve `kar_al` alanini yazan kod, cikista kullanilmayan HAM stratejiden
geliyordu (`_bot_strateji_giris_dene` -> `ST.hedef_belirle(hiz, st_i)`),
cikista ise o strateji `_bot_cikis_olustur` ile 999'lara ezilmisti.
Sonuc, canli defterde olculdu: `bot_cikis_esik: 5.0` ayari HIC CALISMIYOR,
pozisyon +%1.89'da kapaniyordu (SANTOSUSDT, defter_dry.json id 307).

BURADA: karari yalnizca `decide_exit` verir. `bot/watcher.py` sadece
fiyat/tepe/dip BESLER; `kar_al` alanini yalnizca `trading/exit_rules`
yazar ve bu fonksiyon okur.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from app.core.timeutil import now_ms
from app.strategy.targets import (StopPlan, TargetPlan, resolve_profit_target,
                                  resolve_stop_price, should_hold_on_momentum)


@dataclass(frozen=True)
class ExitDecision:
    """Karar: SAT mi TUT mu, neden, hangi stop/hedef ile."""
    action: str                # "SAT" | "TUT"
    reason: str
    profit_pct: float
    stop: StopPlan
    target: TargetPlan
    highest: float

    @property
    def should_sell(self) -> bool:
        return self.action == "SAT"


def _karar(action, reason, kar_p, stop, hedef, tepe) -> ExitDecision:
    return ExitDecision(action, reason, round(kar_p, 3), stop, hedef, tepe)


# Ivme tespiti: son barin degisimi VEYA hacim carpani esigi asiyorsa "hizlaniyor".
# Esikler Ayarlar > BOT CIKISI kartindan gelir.
def detect_acceleration(stop_cfg: Mapping[str, Any], *, change_pct: float | None,
                        volume_ratio: float | None) -> bool:
    if not stop_cfg.get("ivme_carpan"):
        return False
    esik, hacim = stop_cfg.get("ivme_esik"), stop_cfg.get("ivme_hacim")
    if esik is not None and change_pct is not None and change_pct >= float(esik):
        return True
    if hacim is not None and volume_ratio is not None and volume_ratio >= float(hacim):
        return True
    return False


# Stop tetiklendi mi.
def check_stop_hit(price: float, stop: StopPlan) -> bool:
    return price <= stop.price


# Tepeden geri cekilme cikisi (hizli kosan coin).
def check_trailing_exit(price: float, highest: float, profit_pct: float,
                        target: TargetPlan) -> tuple[bool, float]:
    geri = (highest / price - 1) * 100 if price else 0.0
    return (profit_pct > 0 and geri >= float(target.trailing or 0)), geri


# Kar esigi bir kez gecildiyse artik sabit hedefte satmayiz; tepeyi takip
# ederiz. Boylece kosan coin erken kesilmez.
def check_profit_trailing(price: float, entry: float, highest: float,
                          exit_cfg: Mapping[str, Any]) -> tuple[bool, bool, float, float]:
    kt = exit_cfg.get("kar_trailing_esik")
    if not kt:
        return False, False, 0.0, 0.0
    tepe_kar = (highest / entry - 1) * 100
    if tepe_kar < float(kt):
        return False, False, tepe_kar, 0.0
    geri = (highest / price - 1) * 100 if price else 0.0
    tr = float(exit_cfg.get("trailing") or 1.0)
    return True, (geri >= tr), tepe_kar, geri


# Sabit hedefe ulasildi mi.
def check_fixed_target(profit_pct: float, target: TargetPlan) -> bool:
    return target.target is not None and profit_pct >= float(target.target)


# Zaman asimi (yalnizca kardayken satar).
# `now_ms_override`: geriye-testte "simdi" mumun zamanidir; verilmezse gercek saat
# (canli davranis DEGISMEZ).
def check_time_stop(opened_ms: int, profit_pct: float,
                    exit_cfg: Mapping[str, Any], *,
                    now_ms_override: int | None = None) -> tuple[bool, float]:
    dk = exit_cfg.get("zaman_asimi_dk")
    if not dk:
        return False, 0.0
    simdi = now_ms() if now_ms_override is None else int(now_ms_override)
    gecen = (simdi - int(opened_ms)) / 60000
    return (gecen > float(dk) and profit_pct > 0), gecen


# Acik pozisyon icin TEK karar. (eski: cikis_karari)
def decide_exit(position: Mapping[str, Any], price: float,
                strategy: Mapping[str, Any], *,
                candle=None, atr_pct: float | None = None,
                obv_angle: float | None = None, atr_rising: bool | None = None,
                change_pct: float | None = None,
                volume_ratio: float | None = None,
                now_ms_override: int | None = None) -> ExitDecision:
    # Ismail: "cuzdanda 3.50 gordum 1.8'den satti" -- `fiyat` emrin NOMINAL
    # fiyati, `dolan_fiyat` GERCEK ortalama dolum fiyatidir. Ikisi farkli
    # olabilir (piyasa emri sinyal anindaki degil gerceklestigi andaki
    # fiyattan doler). Buradaki HER karar gercek dolum fiyatindan hesaplanir;
    # eskiden nominal kullaniliyor ve kar YANLIS (dusuk) gorunuyordu.
    giris = float(position.get("dolan_fiyat") or position["fiyat"])
    tepe = max(float(position.get("en_yuksek") or giris), price)
    kar_p = (price / giris - 1) * 100

    cikis_cfg, stop_cfg = strategy["cikis"], strategy["stop"]
    hedef = resolve_profit_target(position.get("hiz"), cikis_cfg)

    # Fitil yalnizca pozisyon HENUZ kara gecmemisken anlamli (dip donusu);
    # kar kilidi devredeyse fitil stop'u asagi cekmemeli.
    basabas_esik = float(stop_cfg.get("basabas_esik", 0) or 0)
    kilitli = ((tepe / giris - 1) * 100) >= basabas_esik
    alt_fitil = None if kilitli else (float(candle[3]) if candle else None)

    hizli = detect_acceleration(stop_cfg, change_pct=change_pct, volume_ratio=volume_ratio)
    stop = resolve_stop_price(giris, tepe, stop_cfg, low_wick=alt_fitil,
                              atr_pct=atr_pct, accelerating=hizli)

    # 1) stop
    if check_stop_hit(price, stop):
        return _karar("SAT", "STOP:" + stop.reason, kar_p, stop, hedef, tepe)

    # 2) iz surme (hizli kosan coin)
    if hedef.kind == "trailing":
        sat, geri = check_trailing_exit(price, tepe, kar_p, hedef)
        if sat:
            return _karar("SAT", f"TRAILING:-%{geri:.2f}", kar_p, stop, hedef, tepe)
        return _karar("TUT", f"trailing tepe {tepe}", kar_p, stop, hedef, tepe)

    # 3) kar trailing
    devrede, sat, tepe_kar, geri = check_profit_trailing(price, giris, tepe, cikis_cfg)
    if devrede:
        kt = cikis_cfg.get("kar_trailing_esik")
        tr = float(cikis_cfg.get("trailing") or 1.0)
        h2 = TargetPlan("kar_trailing", kt, tr)
        if sat:
            return _karar("SAT", f"KAR_TRAILING:tepe%{tepe_kar:.2f}/-%{geri:.2f}",
                          kar_p, stop, h2, tepe)
        return _karar("TUT", f"KAR_TRAILING:tepe%{tepe_kar:.2f} (-%{geri:.2f})",
                      kar_p, stop, h2, tepe)

    # 4) sabit hedef + bekletme
    if check_fixed_target(kar_p, hedef):
        bekle, neden = should_hold_on_momentum(candle, strategy.get("beklet"),
                                               obv_angle=obv_angle, atr_rising=atr_rising)
        if bekle:
            return _karar("TUT", "BEKLET:" + neden, kar_p, stop, hedef, tepe)
        return _karar("SAT", f"HEDEF:%{hedef.target}", kar_p, stop, hedef, tepe)

    # 5) zaman asimi
    sat, gecen = check_time_stop(position["ts"], kar_p, cikis_cfg,
                                 now_ms_override=now_ms_override)
    if sat:
        return _karar("SAT", f"ZAMAN:{int(gecen)}dk", kar_p, stop, hedef, tepe)

    return _karar("TUT", f"hedef %{hedef.target} bekleniyor", kar_p, stop, hedef, tepe)
