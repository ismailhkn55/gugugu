# ESLESTIRME — eski ad → yeni ad

> Bu dosya **elle yazılmaz.** `FONKSIYONLAR.txt` içindeki `(eski: ...)`
> notlarından `tools/gen_eslestirme.py` ile üretilir; liste değişince
> yeniden koşulur, böylece ikisi asla ayrışmaz.

Geçiş sırasında "bu fonksiyon neredeydi" sorusunun cevabı burada.
`(eski: ...)` notu olmayan adlar **yeni** — eski sistemde karşılığı yoktu
(çoğu, eskiden hiç ayrılmamış bir sorumluluğu adlandırıyor).

**Eşleşen ad: 144**  ·  Python 89  ·  JavaScript 55


## Python / sunucu

| Eski ad | Yeni ad | Nerede | Ne yapar |
|---|---|---|---|
| `/yerel/gecmis-sinyal içi 365 satır` | `replay_strategy_signals` | `app/strategy/backtest.py` | Stratejiyi geçmiş mumlarda çalıştırır |
| `_ac` | `open_rank_db_readonly` | `app/market/rank_repository.py` | rank.sqlite'ı salt okunur açar |
| `_acik` | `is_telegram_configured` | `app/notify/telegram_client.py` | Token ve chat tanımlı mı |
| `_acik_pozisyonlar` | `list_open_orders` | `app/trading/ledger.py` | Açık/takipteki emirler |
| `_alan_oku` | `read_rule_field` | `app/strategy/rule_engine.py` | Alanı okur; alan yoksa ALAN_YOK döner, ASLA sessiz False değil |
| `_bot_cikis_olustur` | `build_bot_plan` | `app/trading/exit_rules.py` | Bot girişinin planı |
| `_bot_strateji_giris_dene` | `try_strategy_entry` | `app/bot/trade_loop.py` | Stratejiye göre giriş dener |
| `_cagir` | `call_telegram_api` | `app/notify/telegram_client.py` | API çağrısı |
| `_cerceve` | `encode_frame` | `app/exchange/binance_ws.py` | WebSocket çerçevesi kurar |
| `_dolum_oku` | `read_fill_details` | `app/trading/order_service.py` | Dolum fiyatı ve miktarını okur |
| `_dongu` | `run_stream_loop` | `app/exchange/binance_ws.py` | Okuma döngüsü, koparsa üstel bekleyip döner |
| `_dongu` | `run_command_poller` | `app/notify/telegram_commands.py` | getUpdates döngüsü |
| `_fiyatlar` | `get_prices` | `app/market/price_source.py` | Çoklu fiyat |
| `_gunluk_kaydet` | `append_daily_snapshot` | `app/reporting/daily_archive.py` | gunluk/ dizinine tur kaydı |
| `_gunun_kari` | `compute_today_profit` | `app/reporting/stats.py` | Bugünün gerçekleşmiş kârı |
| `_kural_gecti` | `evaluate_rule` | `app/strategy/rule_engine.py` | Tek kuralı değerlendirir |
| `_kural_metni` | `describe_rule` | `app/strategy/rule_engine.py` | Kuralı okunur metne çevirir |
| `_maskele` | `mask_payload` | `app/exchange/binance_ws.py` | İstemci maskesi uygular |
| `_oku ×3` | `read_json_file` | `app/core/jsonstore.py` | JSON'u güvenle okur, yoksa varsayılanı döner |
| `_panel_tuslari` | `build_panel_keyboard` | `app/notify/telegram_client.py` | Inline tuş takımı |
| `_renk` | `derive_color_field` | `app/strategy/rule_engine.py` | renk_* alanlarını yüzdeden türetir |
| `_tick_kaydet` | `flush_ticks_to_disk` | `app/market/ticks.py` | Tamponu diske yazar |
| `_yaz ×2` | `write_json_file` | `app/core/jsonstore.py` | Geçici dosya + rename ile atomik yazar |
| `_yontem_uygula` | `change_exit_method` | `app/trading/position_service.py` | Açık pozisyonun çıkış yöntemini değiştirir |
| `aday_metni` | `render_candidates` | `app/notify/telegram_commands.py` | /aday metni |
| `adaylar` | `select_candidates` | `app/strategy/entry.py` | Geçenleri sıralayıp aday listesi üretir |
| `aktif` | `get_active_strategy` | `app/strategy/registry.py` | Aktif strateji |
| `aktif_yap` | `set_active_strategy` | `app/strategy/registry.py` | Aktif stratejiyi seçer (kâğıt/canlı ayrı) |
| `B1 hatası` | `reset_ledger` | `app/trading/ledger.py` | Defteri sıfırlar — hedef defter AÇIK verilir |
| `bakiye` | `get_wallet` | `app/trading/wallet.py` | Aktif moda göre cüzdan |
| `basamakla` | `round_quantity_to_step` | `app/exchange/symbol_rules.py` | Miktarı adım büyüklüğüne yuvarlar |
| `basla` | `start_command_poller` | `app/notify/telegram_commands.py` | Döngüyü başlatır |
| `bcek` | `signed_request` | `app/exchange/binance_rest.py` | HMAC imzalı REST çağrısı |
| `beklet_mi` | `should_hold_on_momentum` | `app/strategy/targets.py` | Hedefe ulasildi ama momentum guclu -> bekle |
| `borsa_senkron` | `sync_with_exchange` | `app/trading/reconcile.py` | Borsa ile defteri eşitler |
| `BOT sözlüğü` | `get_bot_state` | `app/bot/trade_loop.py` | Bot durumu — kilitli erişim |
| `bot_cuzdan` | `get_paper_wallet` | `app/trading/wallet.py` | Kâğıt cüzdan |
| `bot_turu` | `run_bot_cycle` | `app/bot/trade_loop.py` | Bot turu |
| `cikis_karari` | `decide_exit` | `app/strategy/exit.py` | TEK çıkış kararı noktası |
| `coin` | `fetch_symbol_series` | `app/market/rank_repository.py` | Tek coinin geçmiş serisi |
| `defter_al` | `load_ledger` | `app/trading/ledger.py` | Defteri okur — `live` ZORUNLU parametre |
| `defter_sifirla` | `reset_ledger` | `app/trading/ledger.py` | Defteri sıfırlar — hedef defter AÇIK verilir |
| `defter_yaz` | `save_ledger` | `app/trading/ledger.py` | Defteri atomik yazar — `live` ZORUNLU |
| `dip` | `get_session_low` | `app/exchange/binance_ws.py` | Pozisyon açıldığından beri en düşük |
| `dryrun_giris_manuel` | `place_paper_entry` | `app/trading/order_service.py` | Kâğıt giriş — canlı mod kapalıyken de çalışır |
| `durum` | `get_stream_status` | `app/exchange/binance_ws.py` | Bağlantı durumu ve son veri yaşı |
| `durum_metni` | `render_status` | `app/notify/telegram_commands.py` | /durum metni |
| `el_strateji "al"` | `build_manual_plan` | `app/trading/exit_rules.py` | AL butonunun çıkış planı |
| `el_strateji "alsat*"` | `build_scalp_plan` | `app/trading/exit_rules.py` | ALSAT 1/2/3 planı |
| `el_strateji "altakip"` | `build_follow_plan` | `app/trading/exit_rules.py` | AL TAKIP butonunun planı |
| `emir_durum_kontrol` | `refresh_order_statuses` | `app/trading/order_service.py` | Açık emirlerin borsa durumunu tazeler |
| `emir_iptal` | `cancel_open_order` | `app/trading/order_service.py` | Açık limit emri iptal eder |
| `emir_ver alış yolu` | `place_entry_order` | `app/trading/order_service.py` | Alış emri gönderir |
| `emirler_metni` | `render_orders` | `app/notify/telegram_commands.py` | /emirler metni |
| `fiyat` | `get_last_price` | `app/exchange/binance_ws.py` | Sembolün son fiyatı |
| `gercek_cuzdan` | `get_live_wallet` | `app/trading/wallet.py` | Gerçek Binance cüzdanı |
| `giris_uygun` | `is_entry_allowed` | `app/strategy/entry.py` | Bu satır stratejinin giriş kurallarını geçiyor mu |
| `gunluk_pnl` | `build_daily_pnl` | `app/reporting/pnl.py` | Günlük kâr/zarar serisi |
| `haric_kume ×3 kopya` | `load_excluded_symbols` | `app/market/exclusions.py` | Hariç tutulan coinler, 60 sn önbellekli |
| `haric_yaz` | `save_excluded_symbols` | `app/market/exclusions.py` | Hariç listesini yazar |
| `hedef_belirle` | `resolve_profit_target` | `app/strategy/targets.py` | Kâr hedefini belirler |
| `hiz` | `compute_normalized_momentum` | `app/market/indicators.py` | Değişimin kendi tipik hareketine oranı |
| `isabet_olc` | `measure_signal_accuracy` | `app/reporting/accuracy.py` | Sinyal isabet ölçümü |
| `istatistik` | `compute_ledger_stats` | `app/trading/wallet.py` | Defter istatistiği — `live` ZORUNLU |
| `istatistik_defter` | `compute_ledger_stats` | `app/trading/wallet.py` | Defter istatistiği — `live` ZORUNLU |
| `iz_yon` | `compute_trail_direction` | `app/market/rank_repository.py` | İz yönü: pozitif = sıralamada tırmanıyor |
| `Izleyici` | `LiveTradeStream` | `app/exchange/binance_ws.py` | aggTrade akışını yöneten sınıf |
| `kapsam` | `fetch_db_coverage` | `app/market/rank_repository.py` | Veritabanının zaman aralığı |
| `kaydet` | `save_strategy` | `app/strategy/registry.py` | Stratejiyi kaydeder — bilinmeyen alan varsa REDDEDER |
| `komut_isle` | `handle_telegram_command` | `app/notify/telegram_commands.py` | Komutu işler |
| `liste` | `list_strategies` | `app/strategy/registry.py` | Kayıtlı stratejiler |
| `M12` | `render_active_rules` | `app/notify/telegram_commands.py` | /strateji metni — ÇALIŞAN kuralları yazar |
| `mumTopla sunucu tarafı` | `fetch_candle_range` | `app/market/candles.py` | Sayfalayarak geniş aralık çeker |
| `ozet` | `fetch_latest_snapshot` | `app/market/rank_repository.py` | Son turun satırları + sıra izi |
| `pozisyon_haric_yaz` | `save_position_exclusions` | `app/market/exclusions.py` | Pozisyon hariç listesini yazar |
| `pozisyon_metni` | `render_positions` | `app/notify/telegram_commands.py` | /pozisyon metni |
| `pozisyon_uzlastir` | `reconcile_positions` | `app/trading/reconcile.py` | Borsada olup defterde olmayanı bulur |
| `profit_metni` | `render_profit` | `app/notify/telegram_commands.py` | /profit metni |
| `rank_gecmisi` | `fetch_rank_history` | `app/market/rank_repository.py` | N dakika önceki rank'lar |
| `sembol_kural` | `get_symbol_filters` | `app/exchange/symbol_rules.py` | LOT_SIZE / PRICE_FILTER / MIN_NOTIONAL |
| `serbest_usdt` | `get_free_quote_balance` | `app/trading/wallet.py` | Harcanabilir USDT |
| `sifirla` | `reset_symbol_extremes` | `app/exchange/binance_ws.py` | Tepe/dip'i anlık fiyata sıfırlar |
| `sil` | `delete_strategy` | `app/strategy/registry.py` | Strateji siler |
| `son_fiyatlar` | `fetch_snapshot_prices` | `app/market/rank_repository.py` | Son turdaki tüm fiyatlar |
| `stop_belirle` | `resolve_stop_price` | `app/strategy/targets.py` | Stop fiyatını belirler |
| `strateji_metni` | `render_active_rules` | `app/notify/telegram_commands.py` | /strateji metni — ÇALIŞAN kuralları yazar |
| `takipci` | `run_price_watch_loop` | `app/bot/watcher.py` | Websocket fiyat takibi |
| `tepe` | `get_session_high` | `app/exchange/binance_ws.py` | Pozisyon açıldığından beri en yüksek |
| `yaz / tg` | `send_message` | `app/notify/telegram_client.py` | Telegram mesajı gönderir |

## JavaScript / arayüz

| Eski ad | Yeni ad | Nerede | Ne yapar |
|---|---|---|---|
| `alanAdi` | `fieldLabel` | `static/js/format.js` | Kural alaninin Turkce ekran adini dondurur. |
| `ANA_WS` | `createSocketManager` | `static/js/live/socketManager.js` |  |
| `anaXAl` | `getScrollX` | `static/js/chart/zoom.js` | Yatay kaydirma konumu (piksel). |
| `anaXAyarla` | `setScrollX` | `static/js/chart/zoom.js` | Yatay kaydirmayi ust sinira kadar yazar. |
| `ayarFormaBas` | `fillSettingsForm` | `static/js/pages/settingsPage.js` | Ayar formunu semadan ve mevcut degerlerden doldurur. |
| `ayarYukle` | `refreshSettings` | `static/js/pages/settingsPage.js` | Ayarlari sunucudan ceker. |
| `baglantiDurumu` | `renderConnectionBadge` | `static/js/ui/shell.js` | Baglanti rozetini cizer. |
| `botKontrolCiz` | `renderBotControls` | `static/js/pages/botPage.js` | Bot ac/kapat ve mod dugmelerini cizer. |
| `botModDegistir` | `setBotMode` | `static/js/pages/botPage.js` | Botun calisma modunu (kagit/canli) degistirir. |
| `botYenile` | `refreshBotState` | `static/js/pages/botPage.js` | Bot durumunu sunucudan tazeler. |
| `btnTumu` | `fitAllCandles` | `static/js/chart/zoom.js` | Tum mumlari ekrana sigdirir. |
| `butonAdi` | `buttonLabel` | `static/js/format.js` | Buton adi (el_kaynak -> okunur). |
| `ciz` | `renderSymbolTable` | `static/js/pages/trade.js` | Tabloyu cizer. |
| `coinAc` | `openSymbol` | `static/js/pages/trade.js` | Coine tiklandiginda islem ekranini acar. |
| `egriCiz` | `renderPnlCurve` | `static/js/pages/wallet.js` | Kar/zarar egrisi (SVG). |
| `elleYenile` | `manualRefresh` | `static/js/ui/shell.js` | aksi halde hizli donen turlarda goz bunu fark etmiyor. |
| `formaBas` | `fillStrategyForm` | `static/js/pages/strategies.js` | Secili stratejiyi forma basar. |
| `formdanTopla` | `collectStrategyForm` | `static/js/pages/strategies.js` | Formdaki strateji tanimini nesneye toplar. |
| `gonder` | `apiPost` | `static/js/api.js` | TEK POST noktasi. |
| `hucre` | `formatCell` | `static/js/format.js` | Tablo hucresi: sayi ise renk sinifiyla birlikte. |
| `jget` | `apiGet` | `static/js/api.js` | TEK GET noktasi. `r.ok` ZORUNLU. |
| `kazananlariYenile` | `renderWinners` | `static/js/pages/winners.js` | Siralamada tirmanan coinleri kart olarak cizer. |
| `kurallariCiz` | `renderRuleEditor` | `static/js/pages/strategies.js` | Kural listesini cizer. |
| `limitCizgiCiz` | `renderLimitLine` | `static/js/chart/limitline.js` | Cizgiyi cizer (ust katman -- mum katmani guncellenince silinmez). |
| `limitFiyatPiksel` | `limitPriceToPixel` | `static/js/chart/limitline.js` | Limit fiyatini grafikteki piksel yuksekligine cevirir. |
| `limitKaydiriciAralik` | `getLimitRange` | `static/js/chart/limitline.js` | Kaydirici araligi: anlik fiyatin +/- %8'i. |
| `limitPikselFiyat` | `limitPixelToPrice` | `static/js/chart/limitline.js` | Piksel <-> fiyat donusumu (son cizim olceginden). |
| `limitTutamacBagla` | `attachLimitHandle` | `static/js/chart/limitline.js` | Tutamaci ve kaydiriciyi baglar. Iptal fonksiyonu doner. |
| `listeCiz` | `renderStrategyList` | `static/js/pages/strategies.js` | Kayitli stratejileri listeler. |
| `menuAc` | `openDrawer` | `static/js/ui/shell.js` | Yan menuyu acar. |
| `menuKapat` | `closeDrawer` | `static/js/ui/shell.js` | Yan menuyu kapatir. |
| `modUygula` | `applyDensityMode` | `static/js/ui/theme.js` | Yogunluk (sik/genis) modu. |
| `mumGenislikSifirla` | `resetCandleWidth` | `static/js/chart/zoom.js` | Zoom, kaydirma ve fiyat kilidini varsayilana dondurur. |
| `notCiz` | `renderNotes` | `static/js/pages/notes.js` | Notlari kart listesi olarak cizer. |
| `notFormAc` | `openNoteEditor` | `static/js/pages/notes.js` | Not formunu acar (iskeletteki #notPerde). |
| `notGoruntule` | `openNoteViewer` | `static/js/pages/notes.js` | Notu okuma penceresinde gosterir (iskeletteki #notGorPerde). |
| `notlariAl` | `refreshNotes` | `static/js/pages/notes.js` | Notlari sunucudan ceker. |
| `onay` | `askConfirm` | `static/js/ui/confirm.js` | Onay ister; kullanici onaylarsa true doner. |
| `onayKapat` | `closeConfirm` | `static/js/ui/confirm.js` | Acik onay penceresini kapatir. |
| `onizle` | `renderRulePreview` | `static/js/pages/strategies.js` | Kural kumesinin okunur ozeti. |
| `opAdi` | `operatorLabel` | `static/js/format.js` | Karsilastirma operatorunun Turkce adini dondurur. |
| `POZ_WS` | `createSocketManager` | `static/js/live/socketManager.js` |  |
| `saatCiz` | `renderClock` | `static/js/ui/shell.js` | Saati yazar (1 saniyede bir). |
| `secCiz` | `renderPicks` | `static/js/pages/picks.js` | Aktif stratejinin sectigi coinleri cizer. |
| `secilenlerYukle` | `refreshPicks` | `static/js/pages/picks.js` | Aday listesini sunucudan ceker. |
| `stratejiCalistir` | `runStrategyCommand` | `static/js/pages/strategies.js` | Strateji komutunu (kaydet / sil / etkinlestir) calistirir. |
| `sureYaz` | `formatDuration` | `static/js/format.js` | Sure: "2s 14dk". |
| `temaUygula` | `applyTheme` | `static/js/ui/theme.js` | Temayi uygular. |
| `trKutuCiz` | `renderMiniChart` | `static/js/chart/renderer.js` | Mini kutu: sabit genislik, gosterge yok, fiyat ekseni yok. |
| `usdt` | `formatUsdt` | `static/js/format.js` | USDT tutari. |
| `veriYenile` | `refreshSymbolTable` | `static/js/pages/trade.js` | Tabloyu tazeler (zamanlayici cagirir). |
| `yaziUygula` | `applyFont` | `static/js/ui/theme.js` | Yazi tipini uygular. |
| `yontemAc` | `openMethodPicker` | `static/js/ui/methodPicker.js` | Pencereyi acar. `onDegisti` basarili degisimden sonra cagrilir. |
| `zmn` | `formatClock` | `static/js/format.js` | Saat (HH:MM:SS). |
| `zoomUygula` | `applyZoom` | `static/js/chart/zoom.js` | Mum genisligini carpanla olceklendirir. |


## Eski sistemde karşılığı olmayan adlar (381)

Bunlar yeni sorumluluklar — çoğu, eskiden bir yere sıkışmış ya da
hiç ayrılmamış bir işi kendi adıyla ortaya çıkarıyor.


**`app/bot/scheduler.py`**

- `JOB_REGISTRY` — Tüm arka plan işlerinin TEK listesi
- `register_job` — İş kaydı: ad, aralık, fonksiyon
- `start_all_jobs` — Hepsini başlatır ve hangisinin çalıştığını LOGLAR (takipci vakasının çözümü)
- `list_running_jobs` — Şu an dönen işler ve son tur zamanları
- `run_job_loop` — Tek bir işin döngüsü, hatayı yutmaz raporlar
- `Job` — Tek arka plan isi: ad, aralik, fonksiyon, sayaclar
- `stop_all_jobs` — Tum isleri durdurur (kapanista)

**`app/bot/trade_loop.py`**

- `manage_open_positions` — Açık pozisyonları çıkış kararına götürür
- `update_bot_state` — Bot durumunu kilit altında günceller
- `giris_kaydi_yaz` — Başarılı bot girişini giris_kaydi.jsonl'ye yazar

**`app/bot/watcher.py`**

- `feed_position_extremes` — Tepe/dip'i besler — KARAR VERMEZ (B3'ün çözümü)

**`app/config/paths.py`**

- `get_app_root` — Uygulama kök dizinini döner, tüm yollar bundan türer
- `get_ledger_path` — Canlı/kâğıt defter dosyasının yolu — `canli` ZORUNLU parametre
- `get_rank_root` — rank.sqlite ve panel_ayar.json dizini (ayri servis yazar)
- `get_secrets_path` — gizli/binance.json yolu
- `get_settings_path` — ayar.json yolu
- `get_strategies_path` — stratejiler.json yolu
- `get_notes_path` — notlar.json yolu
- `get_reconcile_log_path` — uzlastirma_gunlugu.json yolu
- `get_journal_dir` — gunluk/ dizini (sembol başına günlük kayıt)
- `get_tick_dir` — tickler/ dizini
- `get_heatmap_state_path` — heatmap_durum.json yolu (endeks/akis)
- `get_rank_db_path` — rank.sqlite yolu (salt okunur)
- `get_panel_config_path` — rank/panel_ayar.json yolu (hariç listesi)
- `get_static_dir` — Tarayıcıya servis edilen tek dizin

**`app/config/secrets.py`**

- `load_api_credentials` — Binance anahtarını okur; bellekte önbellekler (eskiden her istekte diskten)
- `save_api_credentials` — Anahtarı 0600 izniyle yazar ve Binance'e doğrulatır
- `delete_api_credentials` — Anahtarı siler ve canlı modu kapatır
- `has_api_credentials` — Anahtar var mı — emir uçlarının ön koşulu

**`app/config/settings.py`**

- `SETTING_SCHEMA` — Her ayarın tipi, varsayılanı ve ONU OKUYAN modül
- `load_settings` — ayar.json'u şemaya göre okur, eksikleri varsayılanla doldurur
- `SettingSpec` — Tek bir ayarin tanimi: tip, varsayilan, etiket, okuyan modul
- `list_setting_keys` — Bilinen ayar anahtarlari
- `check_scalp_target_order` — ALSAT hedefleri artan sirada mi — UYARIR, degeri degistirmez
- `save_settings` — Ayarları atomik yazar, şema dışı anahtarı reddeder
- `describe_setting` — Bir ayarın ne işe yaradığını döner (arayüz etiketi buradan)
- `list_orphan_settings` — Hiçbir modülün okumadığı ayarları listeler — açılışta uyarılır
- `is_live_trading_enabled` — Gerçek para modu açık mı
- `get_exit_geometry` — Çıkış geometrisi ayarlarını tek sözlükte toplar

**`app/core/applog.py`**

- `setup_logging` — Log biçimini ve hedefini kurar
- `get_logger` — Modül adına bağlı logger döner
- `log_once` — Aynı hatayı tekrar tekrar basmaz, sayar
- `get_repeat_count` — Bir hatanin kac kez tekrarlandigi (saglik ucu raporlar)

**`app/core/errors.py`**

- `AppError` — Tüm uygulama hatalarının atası
- `UnknownFieldError` — Strateji kuralı olmayan bir alanı istedi — ARTIK SESSİZ DEĞİL
- `ExchangeError` — Binance genel hatası, kodu ve gövdesiyle
- `RateLimitError` — 429/418 — kaç saniye beklenmeli bilgisiyle
- `OrderRejectedError` — Emir borsa tarafından reddedildi
- `LedgerConflictError` — Defter beklenmedik şekilde değişmiş

**`app/core/jsonstore.py`**

- `append_jsonl_record` — JSONL dosyasına tek satır ekler
- `read_jsonl_records` — JSONL dosyasını satır satır okur

**`app/core/locking.py`**

- `ledger_lock` — Defter kilidi — oku-değiştir-yaz'ın TAMAMINI sarar
- `assert_no_network_in_lock` — Kilit içinde ağ çağrısı yapılırsa hata fırlatır (eskiden emir_iptal yapıyordu)
- `is_holding_lock` — Su an defter kilidi tutuluyor mu

**`app/core/timeutil.py`**

- `now_ms` — Şimdiki zaman, epoch milisaniye
- `utc_day_start_ms` — İçinde bulunulan UTC gününün açılış zamanı
- `align_to_bucket_ms` — Zamanı 5 dakikalık kılavuza oturtur
- `format_duration` — Süreyi "2s 14dk" gibi okunur yazar

**`app/exchange/binance_rest.py`**

- `public_request` — İmzasız REST çağrısı
- `build_query_signature` — urlencode edilmiş sorgunun imzasını üretir
- `send_with_retry` — Üstel beklemeyle yeniden dener, 429/418'i ayırt eder
- `read_error_payload` — Binance hata gövdesindeki kodu okur (-2010, -1013 gibi)
- `track_request_weight` — X-MBX-USED-WEIGHT-1M başlığını izler, tavana yaklaşınca yavaşlar
- `get_request_counts` — Uc bazinda Binance cagri sayilari
- `reset_request_counts` — Cagri sayaclarini sifirlar
- `sync_rate_limits` — Gercek hiz sinirlarini borsadan okur (1200 degil 6000)
- `get_used_weight` — Son olculen dakikalik Binance agirligi
- `make_client_order_id` — Idempotent emir kimligi uretir (ag zaman asiminda emri bulmak icin)
- `sync_exchange_clock` — /api/v3/time ile saat farkını ölçer
- `get_clock_skew_ms` — Ölçülen saat farkı — imza hatalarının sessiz kaynağıydı
- `fetch_account_balances` — Hesap bakiyeleri
- `fetch_my_trades` — Bir sembolün gerçekleşmiş işlemleri
- `fetch_order_status` — Tek emrin borsa durumu
- `submit_order` — Emir gönderir, newClientOrderId ile idempotent
- `cancel_order` — Emir iptali
- `fetch_order_book` — Derinlik — limit fiyatı buradan seçilir
- `fetch_klines` — Mum verisi
- `fetch_ticker_price` — Tek sembolün fiyatı
- `fetch_all_ticker_prices` — Tüm sembollerin fiyatı (ağırlık 4 — bilinçli kullanılır)
- `fetch_exchange_info` — Sembol kuralları (LOT_SIZE, MIN_NOTIONAL)

**`app/exchange/binance_ws.py`**

- `decode_frame_header` — FIN biti ve uzunluğu okur, ÜST SINIR uygular
- `subscribe_symbols` — Abonelik kümesini günceller, ortak sembolleri kesmez
- `drain_tick_buffer` — Biriken tick'leri alır ve tamponu boşaltır
- `is_stream_stale` — Veri akışı durmuş mu — eskiden hiç bakılmıyordu

**`app/exchange/symbol_rules.py`**

- `normalize_symbol` — "btc" → "BTCUSDT"
- `round_price_to_tick` — Fiyatı tick büyüklüğüne yuvarlar
- `meets_min_notional` — Emir asgari tutarı geçiyor mu
- `is_symbol_tradable` — Sembol su an islem goruyor mu — delist edilmisleri eler

**`app/market/candles.py`**

- `fetch_candle_page` — Tek sayfa mum çeker
- `build_indicator_frame` — Mum serisinden gösterge satırı üretir (geriye-test bunu kullanır)

**`app/market/exclusions.py`**

- `load_position_exclusions` — Uzlaştırmada sayılmayan varlıklar
- `expand_symbol_forms` — "BNB" ve "BNBUSDT" biçimlerinin ikisini de üretir

**`app/market/indicators.py`**

- `COLUMN_REGISTRY` — TEK KAYNAK: her sütunun adı, tipi, anlamı, üreteni
- `list_column_names` — Kayıt defterindeki sütun adları — şema/INSERT/arayüz bundan üretilir
- `ColumnSpec` — Tek bir gosterge sutununun tanimi
- `build_select_clause` — SQL SELECT sutun listesi — elle yazilmis KOLON dizesinin yerine
- `get_column_meta` — Bir sütunun anlamı ve hesaplayan fonksiyonu
- `is_known_field` — Bu alan gerçekten var mı — `ema4` kazasını imkânsız kılar
- `median` — Ortanca; cift sayida elemanda ORTALAMA (toplayici.py:200 ile ayni)
- `compute_ema` — Üstel hareketli ortalama
- `compute_wma` — Ağırlıklı hareketli ortalama
- `compute_rsi` — RSI(14), Wilder
- `compute_atr_percent` — ATR(14) / fiyat × 100
- `compute_obv` — On Balance Volume
- `compute_obv_signal` — OBV'nin EMA(20)'si
- `compute_cross_age` — Kaç bardır sinyalin üstünde/altında
- `compute_slope_angle` — Bir serinin eğimi, derece (45° = kendi tipik hızı)
- `compute_cci` — CCI(20), Lambert
- `compute_kdj_j` — KDJ(9,3,3) J değeri
- `build_heikin_ashi` — Heikin Ashi serisi
- `count_consecutive_green_ha` — Ardışık yeşil HA mum sayısı
- `measure_green_ha_gain` — Yeşil HA serisinin başından beri % yükseliş
- `count_bars_since_green_flip` — Kırmızıdan yeşile dönüşten beri kaç mum
- `compute_volume_ratio` — Hacmin kendi ortancasına oranı

**`app/market/price_source.py`**

- `get_price` — Tek fiyat — kaynağıyla birlikte döner
- `describe_price_source` — Bu fiyat nereden geldi (akış / REST / anlık görüntü)

**`app/market/rank_repository.py`**

- `list_db_columns` — Veritabanindaki GERCEK sutunlar
- `verify_schema_contract` — Kayit defteri ile veritabani semasini karsilastirir — acilista kosar
- `fetch_cci_history` — N dk onceki CCI (heatmap filtresi)
- `attach_rank_trail` — Satırlara sıra izini ekler
- `fetch_rows_for_symbols` — Verilen sembollerin son tur satırları — hariç listesi UYGULANMAZ
- `capture_market_snapshot` — Tek sembolün o anki piyasa görüntüsü — emir kaydına gömülür
- `attach_market_fields` — Satırlara piyasa alanlarını ekler: genislik + total3_5m

**`app/market/ticks.py`**

- `buffer_tick` — Tick'i tampona alır
- `is_duplicate_tick` — Aynı (ts, fiyat) daha önce yazıldı mı — %35 tekrarı bitirir
- `read_tick_archive` — Bir sembolün tick geçmişini okur

**`app/notify/telegram_commands.py`**

- `is_authorized_chat` — Gelen chat kayıtlı mı — YETKİLENDİRME (M1'in çözümü)

**`app/reporting/daily_archive.py`**

- `is_archive_enabled` — Arşiv açık mı — kimse okumuyorsa yazılmaz da (1.1 GB'ın çözümü)

**`app/reporting/pnl.py`**

- `compute_cumulative_curve` — Birikimli eğri

**`app/reporting/stats.py`**

- `summarize_trades` — İşlem özeti: isabet, ortalama, en iyi/kötü

**`app/strategy/backtest.py`**

- `build_history_rows` — Geçmiş mumlardan gösterge satırları — market/indicators'ı KULLANIR
- `mark_unavailable_fields` — Geçmişte kurulamayan alanı "geçti" saymaz, açıkça işaretler
- `is_rule_testable` — Bu kural tek sembolun gecmis mumundan sinanabilir mi
- `summarize_backtest_gaps` — Hangi kurallar sınanamadı — sonuca not düşer

**`app/strategy/entry.py`**

- `explain_entry_rejection` — Neden elendi — alan alan gerekçe

**`app/strategy/exit.py`**

- `ExitDecision` — Cikis karari: SAT/TUT, gerekce, stop, hedef
- `should_sell` — Karar SAT mi (ExitDecision ozelligi)
- `detect_acceleration` — Son bar hizlaniyor mu (ivme esigi/hacim carpani)
- `check_stop_hit` — Stop tetiklendi mi
- `check_trailing_exit` — Tepeden geri çekilme çıkışı
- `check_profit_trailing` — Kâr eşiği sonrası iz sürme
- `check_fixed_target` — Sabit hedef
- `check_time_stop` — Zaman aşımı

**`app/strategy/registry.py`**

- `validate_strategy` — Kuralları bilinen alanlara karşı doğrular
- `stamp_measurement_context` — Açıklamadaki ölçümün hangi kural kümesine ait olduğunu damgalar
- `toggle_strategy` — Stratejiyi açar / kapatır (satır bileşeni `stAnahtar`)

**`app/strategy/rule_engine.py`**

- `RuleOutcome` — Dort durumlu sonuc: GECTI / KALDI / OLCULMEDI / ALAN_YOK
- `RuleResult` — Kural sonucu + gerekcesi (panelde gosterilir)
- `passed` — Kural gecti mi (RuleResult ozelligi)
- `evaluate_rule_set` — Kural listesinin tamamını değerlendirir
- `list_available_fields` — Kural yazarken seçilebilecek alanlar — arayüz listesi bundan üretilir
- `list_known_fields` — Kural yazarken secilebilecek TUM alanlar
- `explain_rule_outcome` — Kural neden geçmedi: "değer tutmadı" mı "alan yok" mu

**`app/strategy/targets.py`**

- `build_target_plan` — Giriş ve çıkış geometrisini TEK yerde üretir
- `StopPlan` — Stop fiyati + yuzdesi + neden o degerde oldugu
- `TargetPlan` — Kar hedefi: sabit yuzde mi, iz surme mi
- `apply_fixed_lock` — Klasik sabit kilit modu (basabas/kilit esikleri)
- `apply_stop_ladder` — Kâr eşiklerine göre stop merdiveni
- `apply_dynamic_trail` — ATR ölçekli takip mesafesi
- `apply_wick_tolerance` — Fitil toleransı

**`app/trading/exit_rules.py`**

- `plan_for_source` — Emrin kaynağına göre doğru planı seçer
- `apply_plan_to_order` — Planı emrin kar_al/stop alanlarına yazar — TEK yazıcı (B3'ün çözümü)

**`app/trading/ledger.py`**

- `backup_ledger` — Yıkıcı işlem öncesi zaman damgalı yedek
- `purge_closed_orders` — Kapanmışları siler, açıkları korur
- `next_order_id` — Sıradaki emir kimliği
- `make_order_key` — ("canli"|"dry", id) — defterler arası çakışmayı bitirir
- `find_order` — Emir bulur — hangi defterden olduğu belli
- `append_order` — Deftere emir ekler
- `update_order` — Emri kilit içinde günceller
- `list_closed_orders` — Kapanmış emirler
- `iter_orders` — Defterdeki tum emirler uzerinde gezinir

**`app/trading/order_service.py`**

- `pick_limit_price` — Emir defteri derinliginden limit fiyati secer
- `place_exit_order` — Satış emri gönderir
- `recover_after_send_failure` — Emir gitti mi belirsizse borsaya sorar
- `is_filter_reject` — Filtre hatası mı — -1013 NOTIONAL / LOT_SIZE

**`app/trading/position_service.py`**

- `close_position` — Pozisyon kapatır — satıştan ÖNCE defteri yeniden okur (B2'nin çözümü)
- `is_position_still_open` — Pozisyon HALA acik mi -- kilit icinde TAZE okuma
- `close_all_positions` — Tüm açıkları kapatır
- `record_position_close` — Kapanışı deftere ve sayaçlara işler — TEK kopya

**`app/trading/reconcile.py`**

- `log_reconciliation` — Uzlaştırma günlüğüne yazar
- `detect_manual_sells` — Elle satılmışları tespit eder
- `fetch_exchange_holdings` — Borsadaki varlik miktarlari (haric tutulanlar elenir)
- `adopt_untracked_holdings` — Borsada olup defterde olmayani takibe alir (BNB/USDT + toz haric)

**`app/trading/wallet.py`**

- `get_wallet_overview` — Gerçek ve kâğıt cüzdanı BİRLİKTE döndürür — görünüm için

**`app/web/handlers/admin_api.py`**

- `handle_bot_status` — GET /yerel/bot
- `handle_bot_command` — POST /yerel/bot — 5 iş yapan uç ayrıştırılır
- `handle_legacy_status` — GET /yerel/durum
- `handle_app_version` — GET /yerel/surum
- `handle_health` — GET /yerel/saglik -- YENI: neyin calistigi tek bakista
- `handle_route_list` — GET /yerel/uclar -- YENI: kayitli uc listesi
- `handle_telegram_config` — POST /yerel/telegram
- `handle_telegram_send` — POST /yerel/telegram-mesaj
- `handle_reconcile_now` — POST /yerel/uzlastir-simdi
- `handle_reconcile_log` — GET /yerel/uzlastirma-gunlugu

**`app/web/handlers/market_api.py`**

- `handle_snapshot` — GET /yerel/ozet
- `handle_winners` — GET /yerel/kazananlar
- `handle_candidates` — GET /yerel/aday
- `handle_candles` — GET /yerel/mum
- `handle_history_signals` — GET /yerel/gecmis-sinyal
- `handle_tick_archive` — GET /yerel/tickler
- `handle_exclusions_read` — GET /yerel/haric
- `handle_exclusions_write` — POST /yerel/haric
- `handle_position_exclusions_read` — GET /yerel/pozisyon-haric
- `handle_position_exclusions_write` — POST /yerel/pozisyon-haric
- `handle_heatmap` — Endeks + heatmap + akis verisi (YAPAY ZEKA MIMO)

**`app/web/handlers/notes_api.py`**

- `handle_notes_read` — GET /yerel/notlar
- `handle_notes_write` — POST /yerel/notlar

**`app/web/handlers/orders_api.py`**

- `handle_order_list` — GET /yerel/emirler
- `handle_place_order` — POST /yerel/emir
- `handle_paper_entry` — POST /yerel/dryrun_giris
- `handle_cancel_order` — POST /yerel/emir/iptal
- `handle_close_one` — POST /yerel/emir/kapat
- `handle_close_all` — POST /yerel/emir/hepsini-kapat
- `handle_change_method` — POST /yerel/yontem-degistir
- `handle_purge_ledger` — POST /yerel/defter-temizle

**`app/web/handlers/report_api.py`**

- `handle_pnl` — GET /yerel/pnl
- `handle_balance` — GET /yerel/bakiye
- `handle_paper_wallet` — GET /yerel/bot-cuzdan
- `handle_live_wallet` — GET /yerel/gercek-cuzdan
- `handle_trade_history` — GET /yerel/gecmis
- `handle_accuracy` — GET /yerel/isabet

**`app/web/handlers/settings_api.py`**

- `handle_settings_read` — GET /yerel/ayar
- `handle_settings_write` — POST /yerel/ayar
- `handle_credentials_write` — POST /yerel/anahtar

**`app/web/handlers/strategy_api.py`**

- `handle_strategy_list` — GET /yerel/strateji
- `handle_strategy_command` — POST /yerel/strateji (kaydet / sil / aktif yap)

**`app/web/router.py`**

- `ROUTE_TABLE` — (yöntem, yol) → işleyici tablosu — 945 satırlık if/elif'in yerine
- `register_route` — Yol kaydı
- `resolve_route` — Gelen isteği işleyiciye eşler
- `parse_query_params` — Sorgu dizesini çözer — 6 kez kopyalanmış idiom tek yerde
- `Route` — Tek uc: yontem + yol + isleyici + aciklama
- `list_routes` — Kayitli tum uclar (dokumantasyon ve saglik ucu)
- `query_int` — Sorgu parametresini tipli okur
- `query_live` — kaynak=canli/dry -> bool; ASLA ayar['canli']'ya dusmez
- `read_json_body` — POST gövdesini okur

**`app/web/routes.py`**

- `register_all_routes` — 42 ucun tamamini kaydeder (acilista bir kez)

**`app/web/server.py`**

- `create_http_server` — Sunucuyu kurar, portu yoklar, allow_reuse ayarlar
- `run_http_server` — Dinlemeye başlar
- `suppress_client_disconnect` — BrokenPipe/ConnectionReset'i tek noktada yutar (750 traceback'in çözümü)
- `ensure_port_available` — Port doluysa kimin tuttuğunu söyler (348 × "Address already in use")

**`app/web/static_guard.py`**

- `is_public_asset` — Bu dosya tarayıcıya verilebilir mi — BEYAZ LİSTE (anahtar sızıntısının çözümü)
- `guess_content_type` — Uzantiya gore icerik tipi
- `resolve_static_path` — Istenen yolu statik dizindeki dosyaya cevirir (disari cikamaz)

**`main.py`**

- `run_startup_checks` — Acilis denetimleri: sema uyumu, olu ayarlar, tutarsizliklar
- `register_all_jobs` — Arka plan islerini TEK listeden kaydeder
- `build_application` — Katmanları kurar ve birbirine bağlar
- `pozisyon_kapandi_bildir` — Kapanan pozisyonu Telegram'a bildirir
- `main` — Giriş noktası

**`static/js/api.js`**

- `apiError` — Sunucu hatasini kullaniciya GORUNUR kilar.
- `apiHataSayisi` — Toplam hata sayisi (durum satirinda gosterilir).
- `withAbort` — Sayfa degisince toplu iptal edilen `AbortSignal`'i dondurur.
- `iptalEtHepsini` — Acik tum istekleri iptal eder ve yeni denetleyici kurar.

**`static/js/chart/gestures.js`**

- `attachChartGestures` — Grafik kutusuna hareketleri baglar. `yenidenCiz` her degisimde cagrilir.

**`static/js/chart/indicators.js`**

- `ema` — Ustel hareketli ortalama (EMA) serisi.
- `sma` — Basit hareketli ortalama (SMA) serisi.
- `rsi` — Goreli guc endeksi (RSI) serisi.
- `bollinger` — Bollinger bantlari: ust, orta ve alt seri.
- `vwap` — Hacim agirlikli ortalama fiyat (VWAP) serisi.
- `obv` — Denge hacmi (OBV) serisi.
- `atr` — Ortalama gercek aralik (ATR) serisi.
- `heikinAshi` — Heikin Ashi -- yol bagimlidir, verilen diliminin TAMAMINDAN kurulur.
- `klineCevir` — Binance kline dizisini {t,a,y,d,k,h} nesnelerine cevirir.

**`static/js/chart/limitline.js`**

- `isLimitOpen` — LIMIT anahtari acik mi.
- `getLimitPrice` — Secili limit fiyati.
- `setLimitPrice` — Limit fiyatini yazar.
- `resetLimit` — Limit cizgisini kapatir ve fiyati sifirlar.
- `followPrice` — olur ve takip DURUR -- elle konan fiyat websocket'le ezilmemeli.
- `refreshLimitSlider` — gorunur, ust katman BOS (0 oge). Gereksiz bagimlilik kaldirildi.

**`static/js/chart/renderer.js`**

- `DRAW_COUNTS` — Konsoldan `__cn.cizim()` ile okunur.
- `getChartScale` — Bir kutunun son cizim olcegi (mum adimi, fiyat araligi).
- `renderCandleChart` — Mum grafigini cizer; katmanlari ayri ayri gunceller.
- `renderTradeMarkers` — Giris/cikis islem noktalarini ayri katmana cizer.
- `renderPriceLine` — Yatay fiyat cizgisi (limit / stop / hedef) -- ust katman.
- `updateLastCandle` — zaman tam cizim yapar (olcek degismistir).
- `renderCrosshair` — Basili tutulan mumun ortasindan gecen dikey imleci cizer.

**`static/js/chart/zoom.js`**

- `ZOOM_LIMITS` — Burada TEK sinir kumesi var ve TUM yazicilar `clampCandleWidth`'ten gecer.
- `SAG_EKSEN_PX` — Son mumun etiketlerin altinda kalmamasi `BOSLUK_MUM` ile saglanir.
- `BOSLUK_MUM` — BOSLUK_MUM kadar nefes payi eklenir.
- `clampCandleWidth` — Mum genisligini tek ve ortak sinir kumesine oturtur.
- `getCandleWidth` — Gecerli mum genisligi (piksel).
- `setCandleWidth` — Mum genisligini sinirlar icinde yazar.
- `fitRecentCandles` — Son N mumu ekrana sigdirip en sona kaydirir.
- `scrollToEnd` — En sagda (en yeni mumda) durur.
- `maxScrollX` — Verilen toplam mum ve kap genisligine gore azami kaydirma.
- `getPriceLock` — Dikey pinch ile kilitlenmis fiyat araligi (yoksa null).
- `setPriceLock` — Fiyat eksenini verilen araliga kilitler.
- `clearPriceLock` — Fiyat ekseni kilidini kaldirir, otomatik sigdirmaya doner.

**`static/js/format.js`**

- `formatPrice` — Fiyati anlamli basamaga gore, sondaki sifirlar olmadan yazar.
- `coinName` — yalnizca yer kapliyordu. Tam sembol `title` ile erisilebilir kalir.
- `formatPercent` — Yuzde biçimi, isaretli.
- `formatSigned` — Isaretli yuzde (+/-).
- `formatRuleValue` — Kural degerini alanina gore bicimler (1 ondalik: coinsay, coingreen, yesildeg, kirmizideg, fark128, kare128, yukselis128).

**`static/js/giris.js`**

- `sayfalariKaydet` — yalnizca o sayfaya ilk girildiginde kurulur.
- `ayarlariKur` — Ayarlar TEK yerden cekilir; mod rozeti ve diger sayfalar buradan beslenir.
- `basla` — (aciklama yok)

**`static/js/keys.js`**

- `registerShortcut` — Kisayol kaydi. Iptal eden fonksiyon doner.
- `pushModalLayer` — Modal katmanini yigina ekler.
- `popModalLayer` — En ustteki katmani kapatir; katman yoksa false doner.
- `listModalLayers` — Acik katmanlar (hata ayiklama).
- `handleKeyDown` — Merkezi klavye yonlendiricisi.
- `baglaKlavye` — Merkezi klavye yonlendiricisini belgeye baglar.

**`static/js/pages/botPage.js`**

- `renderPaperWallet` — Kagit cuzdan ozetini cizer.
- `renderPaperHistory` — -- giris/cikis detaylari ve, varsa, o anin gosterge degerleri.
- `botuAcKapat` — bu kabul edilemez.
- `mountBotPage` — BOT sayfasini kurar ve zamanlayicisini kaydeder.

**`static/js/pages/heatmap.js`**

- `pencereSaniye` — 5 dk penceresinin kacinci saniyesinde oldugumuz
- `hedefPenceresinde` — Cagri hedef penceresinde mi (bitime ~40 sn kala)
- `sonrakiHedefTs` — Sonraki 5 dk - 40 sn hedefinin epoch'u
- `renkFor` — deg24 -> tema arti/eksi alpha'li renk
- `renderHeatmap` — Endeks kartlari + akis rozeti + karo gridini cizer
- `refreshHeatmap` — Heatmap verisini ceker (zorla=false hedefi bekler)
- `karolariCiz` — CCI filtresi + siralama ile karo ciz
- `mountHeatmapPage` — HEATMAP sayfasini kurar (30 sn tik, hedefte veri)

**`static/js/pages/islem.js`**

- `mountTradePanel` — Islem panelini kurar: grafikler, dugmeler ve canli akis.
- `unmountTradePanel` — Sayfadan cikilinca websocket aboneligini birakir.
- `seciliSembolDegisti` — Secili coin degisince tum paneli tazeler.

**`static/js/pages/notes.js`**

- `mountNotesPage` — NOTLAR sayfasini kurar ve olaylarini baglar.

**`static/js/pages/picks.js`**

- `mountPicksPage` — SECILENLER sayfasini kurar ve zamanlayicisini kaydeder.

**`static/js/pages/settingsPage.js`**

- `mountSettingsPage` — AYARLAR sayfasini kurar ve form olaylarini baglar.
- `createExclusionPanel` — Haric tutma panelini (coin ve pozisyon) kurar.

**`static/js/pages/strategies.js`**

- `refreshStrategies` — canli modda gercek bakiyeyi kullanir.
- `renderStrategyWallet` — ekrana tasir -- eskiden sayfada botun parasina dair HICBIR sey yoktu.
- `mountStrategiesPage` — STRATEJILER sayfasini kurar ve form olaylarini baglar.

**`static/js/pages/trade.js`**

- `KOLONLAR` — Kolon tanimlari -- `alan` adlari SUNUCUNUNKILERLE AYNI.
- `alignStickyHeader` — Sabit kolonlarin yatay konumunu gercek genisliklerle hizalar.
- `unmountTradePage` — Sayfadan cikilinca canli akis aboneligi birakilir.
- `mountTradePage` — Anasayfayi kurar; tekrar girildiginde canli akisa yeniden abone olur.

**`static/js/pages/wallet.js`**

- `renderWallet` — Cuzdan ozetini, pozisyonlari ve gecmisi cizer.
- `refreshWallet` — icin kar/zarar ve gecmis de HER ZAMAN canli defterden okunur.
- `mountWalletPage` — CUZDAN sayfasini kurar ve zamanlayicisini kaydeder.
- `unmountWalletPage` — Sayfadan cikilinca canli akis aboneligi birakilir.

**`static/js/pages/winners.js`**

- `refreshWinners` — Kazananlar listesini sunucudan ceker.
- `mountWinnersPage` — KAZANANLAR sayfasini kurar ve zamanlayicisini kaydeder.

**`static/js/poll.js`**

- `registerPoll` — Bir yenileme isi kaydeder. `sayfa` verilirse YALNIZCA o sayfa acikken doner.
- `sharePollResult` — Isin sonucuna abone olur; aboneligi iptal eden fonksiyon doner.
- `setActivePage` — Aktif sayfayi bildirir; sayfaya bagli isler buna gore doner.
- `getActivePage` — O an aktif olan sayfanin adi.
- `startPolling` — Kayitli tum zamanlayicilari baslatir.
- `stopPolling` — Kayitli tum zamanlayicilari durdurur.
- `refreshNow` — Elle yenileme: interval'i SIFIRLAR, boylece hemen sonra bir tur daha atmaz.
- `listPolls` — Kayitli isler ve son tur bilgileri (hata ayiklama / saglik).

**`static/js/store.js`**

- `getState` — Durumu okur (kopya degil, salt okunur kullanin).
- `setState` — Durumu gunceller ve ilgili aboneleri uyarir.
- `subscribeState` — Durum degisimine abone olur; aboneligi iptal eden fonksiyon doner.
- `getTercih` — Kullanici tercihini okur (anahtarsiz cagrilirsa tumunu).
- `setTercih` — Tercihi YALNIZCA kullanici eylemiyle degistirin.
- `tercihleriYukle` — Tercihleri `localStorage`'dan okuyup bellege alir.
- `selectRows` — Anasayfa coin tablosunun satirlari.
- `selectSettings` — Yuklu `ayar.json` icerigi.
- `selectSelectedSymbol` — O an secili coin sembolu.
- `selectOpenPositions` — Acik ve takipteki pozisyonlarin birlesik listesi.

**`static/js/ui/fullscreen.js`**

- `isFullscreen` — Tarayici tam ekran modunda mi.
- `enterFullscreen` — Tam ekrana gecer; istege bagli olarak ekran yonunu kilitler.
- `exitFullscreen` — Tam ekran modundan cikar.
- `toggleFullscreen` — Tam ekrani acar/kapatir.
- `baglaTamEkran` — Dugmeyi bagla; durum degisiminde `aria-pressed` gunceller.

**`static/js/ui/marketDetail.js`**

- `renderTrailSparkline` — bu yuzden yon = ilk - son.
- `renderTrailCell` — Iz grafigi + "ilk>son" sayilari (tablo hucresinin ici).
- `renderMarketDetail` — deger URETILMEZ.

**`static/js/ui/methodPicker.js`**

- `YONTEMLER` — Secenekler: her biri farkli bir CIKIS PLANI uretir (trading/exit_rules).
- `baglaYontemKapat` — Yontem secici penceresinin kapatma olaylarini baglar.

**`static/js/ui/perde.js`**

- `openPerde` — Pencereyi acar; kapatma fonksiyonu doner.
- `closePerde` — Verilen perdeyi kapatir.
- `isPerdeOpen` — Perde acik mi.

**`static/js/ui/positionTable.js`**

- `renderPositionTable` — sey yoktur; onun yerine piyasanin limite gore nerede oldugu yazilir.
- `updatePositionPrices` — tiklamayi bozuyor; yalnizca ilgili hucreler guncellenir.
- `renderClosedTrades` — yoktur -- uydurulmaz, sadece gosterilmez.

**`static/js/ui/shell.js`**

- `registerPage` — Bir sayfanin kurucusunu (ve istege bagli temizleyicisini) kaydeder.
- `navigateToPage` — Verilen sayfaya gecer: gorunumu, zamanlayicilari ve adresi gunceller.
- `renderDataAge` — Verinin ne kadar taze oldugunu alt durum satirina yazar.
- `renderModeBadge` — Calisma modu rozetini (DRY RUN / CANLI) cizer.
- `mountAppShell` — Kabugu kurar: menu, kenar tuslari, kisayollar, saat.

**`static/js/ui/theme.js`**

- `TEMALAR` — Secilebilir tema adlari.
- `TEMA_KISA` — Tema dugmesinde gosterilecek kisa ad.
- `YAZITIPLERI` — Sabit genislikli oldugu icin sayi sutunlari da hizali kalir.
- `YAZI_KISA` — Yazi tipi dugmesinde gosterilecek kisa ad.
- `applyPortraitMode` — Dikey/yatay gorunum modunu uygular.
- `temalariUygula` — Kayitli tercihleri uygular (acilista bir kez).

**`static/js/ui/toast.js`**

- `showToast` — Kisa bildirim baloncugu gosterir.
- `showToastDetail` — Baslik + aciklama ile bildirim (eski `toast(baslik, mesaj, tur, sure)` karsiligi).
- `dismissToast` — Acik bildirimi kapatir.
