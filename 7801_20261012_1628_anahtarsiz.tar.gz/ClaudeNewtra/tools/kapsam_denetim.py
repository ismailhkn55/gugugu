# -*- coding: utf-8 -*-
"""Kapsam denetimi: listede/belgede eksik veya cagrilmayan seyler var mi?

1) Kodda tanimli her modul FONKSIYONLAR.txt'de bir bolum olarak var mi
2) DOKUMANTASYON.md her paketten soz ediyor mu
3) Hicbir yerden IMPORT edilmeyen JS export'lari (olu kod adayi)
4) Hicbir yerden cagrilmayan Python fonksiyonlari (olu kod adayi)
"""
import os, re

KOK = "/DATA/AppData/ClaudeNewtra"
JS = os.path.join(KOK, "app/web/static/js")
APP = os.path.join(KOK, "app")
liste = open(os.path.join(KOK, "FONKSIYONLAR.txt"), encoding="utf-8").read()
dok = open(os.path.join(KOK, "DOKUMANTASYON.md"), encoding="utf-8").read()

# ---------- 1) modul kapsami ----------
js_moduller, py_moduller = [], []
for d, _a, fs in os.walk(JS):
    for f in sorted(fs):
        if f.endswith(".js"):
            js_moduller.append("static/js/" + os.path.relpath(os.path.join(d, f), JS).replace(os.sep, "/"))
for d, _a, fs in os.walk(APP):
    if "__pycache__" in d or "static" in d:
        continue
    for f in sorted(fs):
        if f.endswith(".py") and f != "__init__.py":
            py_moduller.append(os.path.relpath(os.path.join(d, f), KOK).replace(os.sep, "/"))

eksik_liste = [m for m in js_moduller + py_moduller if m not in liste]
print("1) FONKSIYONLAR.txt'de BOLUMU OLMAYAN modul:", len(eksik_liste))
for m in eksik_liste:
    print("     ", m)

# ---------- 2) belgede gecmeyen paket ----------
paketler = sorted({m.split("/")[1] for m in py_moduller if m.startswith("app/")})
eksik_dok = [p for p in paketler if p not in dok]
print("2) DOKUMANTASYON.md'de gecmeyen paket:", len(eksik_dok), eksik_dok or "")

# ---------- 3) import edilmeyen JS export'lari ----------
EXPORT = re.compile(r"^export\s+(?:async\s+)?(?:function\s+([A-Za-z0-9_$]+)|(?:const|let)\s+([A-Za-z0-9_$]+))", re.M)
tum_js = {}
for d, _a, fs in os.walk(JS):
    for f in fs:
        if f.endswith(".js"):
            tam = os.path.join(d, f)
            tum_js[tam] = open(tam, encoding="utf-8").read()
butun = "\n".join(tum_js.values())
# "Baska modulden kullanilmiyor" TEK BASINA olu kod demek DEGILDIR:
# sayfa cizicileri (`renderWallet` vb.) kendi modulunde cagrilir ve
# yalnizca sozlesme listesi icin disa acilir. Bu yuzden iki ayri sayi:
#   a) yalnizca kendi modulunde kullanilanlar  -> normal
#   b) HICBIR yerde kullanilmayanlar           -> gercek olu kod adayi
sadece_ic, hic = [], []
for tam, metin in tum_js.items():
    goreli = "static/js/" + os.path.relpath(tam, JS).replace(os.sep, "/")
    for m in EXPORT.finditer(metin):
        ad = m.group(1) or m.group(2)
        disarida = sum(1 for t, x in tum_js.items()
                       if t != tam and re.search(r"\b%s\b" % re.escape(ad), x))
        icerde = len(re.findall(r"\b%s\b" % re.escape(ad), metin))
        if disarida:
            continue
        (sadece_ic if icerde > 1 else hic).append((goreli, ad))
print("3a) yalnizca KENDI modulunde kullanilan export:", len(sadece_ic), "(normal)")
print("3b) HICBIR yerde kullanilmayan JS export'u:", len(hic))
for g, a in hic:
    print("     %-34s %s" % (g, a))

# ---------- 4) cagrilmayan Python fonksiyonlari ----------
DEF = re.compile(r"^def\s+([a-zA-Z_][A-Za-z0-9_]*)", re.M)
tum_py = {}
for d, _a, fs in os.walk(APP):
    if "__pycache__" in d:
        continue
    for f in fs:
        if f.endswith(".py"):
            tam = os.path.join(d, f)
            tum_py[tam] = open(tam, encoding="utf-8").read()
tum_py[os.path.join(KOK, "main.py")] = open(os.path.join(KOK, "main.py"), encoding="utf-8").read()
hepsi = "\n".join(tum_py.values())
olu = []
for tam, metin in tum_py.items():
    goreli = os.path.relpath(tam, KOK).replace(os.sep, "/")
    for m in DEF.finditer(metin):
        ad = m.group(1)
        if ad.startswith("_"):
            continue
        # tanim disinda kac kez geciyor
        gecis = len(re.findall(r"\b%s\b" % re.escape(ad), hepsi))
        if gecis <= 1:
            olu.append((goreli, ad))
print("4) HIC cagrilmayan Python fonksiyonu:", len(olu))
for g, a in olu:
    print("     %-40s %s" % (g, a))
