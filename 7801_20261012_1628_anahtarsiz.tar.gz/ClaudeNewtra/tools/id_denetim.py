# -*- coding: utf-8 -*-
"""TUM sayfalarda: HTML'deki id, JS'te kullaniliyor mu?

"Dugme bir sayfada, olay baska bir modulde" hatasini yakalar
(23.09.2026: BOTU CALISTIR stratejiler sayfasindaydi, olayi botPage.js
baglıyordu -> stratejiler sayfasindan basilinca HICBIR SEY olmuyordu).
"""
import os, re
KOK = "/DATA/AppData/ClaudeNewtra/app/web/static"
html = open(os.path.join(KOK, "index.html"), encoding="utf-8").read()

# id -> hangi sayfada
# </section> ile sayfa kapanir; sonradan gelen id'ler kabuktur
# (YAPAY ZEKA MIMO: heatmap son sayfa olunca kabuk id'leri yanlis ataniyordu)
sayfa, idler = None, {}
for satir in html.split("\n"):
    m = re.search(r'data-sayfa="([a-z]+)"', satir)
    if m and "section" in satir:
        sayfa = m.group(1)
    for i in re.findall(r'id="([A-Za-z0-9_-]+)"', satir):
        idler.setdefault(i, sayfa or "(kabuk)")
    if "</section>" in satir and sayfa:
        sayfa = None

js = ""
for d, _a, fs in os.walk(os.path.join(KOK, "js")):
    for f in fs:
        if f.endswith(".js"):
            js += open(os.path.join(d, f), encoding="utf-8").read() + "\n"

# JS'te hangi modul hangi id'yi kullaniyor
modul_id = {}
for d, _a, fs in os.walk(os.path.join(KOK, "js")):
    for f in sorted(fs):
        if not f.endswith(".js"):
            continue
        yol = os.path.join(d, f)
        goreli = os.path.relpath(yol, os.path.join(KOK, "js"))
        metin = open(yol, encoding="utf-8").read()
        for i in idler:
            if re.search(r'["\'`]%s["\'`]' % re.escape(i), metin):
                modul_id.setdefault(i, []).append(goreli)

SAYFA_MODUL = {
    "trade": "pages/trade.js", "islem": "pages/islem.js",
    "secilenler": "pages/picks.js", "kazananlar": "pages/winners.js",
    "cuzdan": "pages/wallet.js", "heatmap": "pages/heatmap.js",
    "stratejiler": "pages/strategies.js", "bot": "pages/botPage.js",
    "notlar": "pages/notes.js", "ayarlar": "pages/settingsPage.js",
}

kullanilmayan, yanlis_modul = [], []
for i, syf in sorted(idler.items()):
    moduller = modul_id.get(i, [])
    if not moduller:
        kullanilmayan.append((syf, i)); continue
    beklenen = SAYFA_MODUL.get(syf)
    if beklenen and beklenen not in moduller and not any(
            m.startswith("ui/") or m in ("giris.js", "poll.js", "store.js") for m in moduller):
        yanlis_modul.append((syf, i, ",".join(moduller)))

print("HTML id sayisi:", len(idler))
print()
print("1) HICBIR JS'te gecmeyen id:", len(kullanilmayan))
for syf, i in kullanilmayan:
    print("     %-12s %s" % (syf, i))
print()
print("2) BASKA sayfanin modulunde islenen id:", len(yanlis_modul))
for syf, i, m in yanlis_modul:
    print("     %-12s %-22s -> %s" % (syf, i, m))
