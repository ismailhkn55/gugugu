#!/usr/bin/env python3
"""JS'in urettigi CSS siniflarinin karsiligi var mi?

Ilk yazimda `.kazKart`, `.modalPerde`, `.toastKap` gibi siniflar uydurmustum;
CSS'lerinde karsiligi olmadigi icin o parcalar BICIMSIZ cikiyordu (kullanici
"kazananlarda sadece yazilar gozukuyor" diye bildirdi). Bu betik ayni hatayi
bir daha sessizce yapmayi engeller.
"""
import os
import re
import sys

KOK = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "app", "web", "static")

def main() -> int:
    css = ""
    for f in sorted(os.listdir(os.path.join(KOK, "css"))):
        css += open(os.path.join(KOK, "css", f), encoding="utf-8").read()
    css_siniflar = set(re.findall(r"\.([a-zA-Z][a-zA-Z0-9_-]*)", css))

    html = open(os.path.join(KOK, "index.html"), encoding="utf-8").read()
    html_siniflar = set()
    for m in re.findall(r'class="([^"]+)"', html):
        html_siniflar |= {w for w in m.split() if w}

    js = ""
    for d, _a, ns in os.walk(os.path.join(KOK, "js")):
        if os.sep + "vendor" in d:      # dis kutuphane (lightweight-charts) -- kendi siniflari
            continue
        for n in sorted(ns):
            if n.endswith(".js"):
                js += open(os.path.join(d, n), encoding="utf-8").read()

    uretilen = set()
    for m in re.findall(r'class="([^"`]+)"', js):
        uretilen |= {w for w in m.split() if w and "$" not in w}
    for m in re.findall(r'classList\.(?:add|toggle|remove)\(\s*"([a-zA-Z][\w-]*)"', js):
        uretilen.add(m)
    for m in re.findall(r'className\s*=\s*"([^"]+)"', js):
        uretilen |= {w for w in m.split() if w and "$" not in w}

    # Gecerli bir CSS sinif adi olmayanlari ele: regex, sablon dizesi
    # parcalari ve JS ifadeleri (`===`, `||`, `>=`, `arti|eksi|...`).
    gecerli = re.compile(r"^[A-Za-z][A-Za-z0-9_-]*$")
    # JS degiskeni olup sinif SANILAN adlar (className atamasindan gelir).
    YANLIS_POZITIF = {"suan", "_secili"}
    eksik = sorted(c for c in uretilen
                   if gecerli.match(c) and c not in YANLIS_POZITIF
                   and c not in css_siniflar and c not in html_siniflar)
    print(f"JS {len(uretilen)} sinif uretiyor  |  CSS karsiligi YOK: {len(eksik)}")
    for j in range(0, len(eksik), 4):
        print("   " + "  ".join(f"{x:<22}" for x in eksik[j:j + 4]))
    return 1 if eksik else 0


if __name__ == "__main__":
    sys.exit(main())
