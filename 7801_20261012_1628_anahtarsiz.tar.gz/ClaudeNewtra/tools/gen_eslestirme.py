#!/usr/bin/env python3
"""ESLESTIRME.md'yi FONKSIYONLAR.txt icindeki "(eski: X)" notlarindan uretir.
Elle yazilmaz -- liste degisince yeniden kosulur, boylece ikisi ayrisamaz."""
import re, sys, collections

LISTE = sys.argv[1] if len(sys.argv) > 1 else "FONKSIYONLAR.txt"
CIKTI = sys.argv[2] if len(sys.argv) > 2 else "ESLESTIRME.md"

MODUL = re.compile(r"^([A-Za-z0-9_./-]+\.(?:py|js))\s*$")
AD    = re.compile(r"^ {4}([A-Za-z_][A-Za-z0-9_]*)\s{2,}(\S.*)$")
ESKI  = re.compile(r"\(eski:\s*([^)]+)\)")

kayit, modul = [], None
for satir in open(LISTE, encoding="utf-8"):
    satir = satir.rstrip("\n")
    if not satir.strip() or satir.lstrip().startswith("#"):
        continue
    m = MODUL.match(satir)
    if m:
        modul = m.group(1); continue
    m = AD.match(satir)
    if m and modul:
        kayit.append((m.group(1), modul, m.group(2).strip()))

esl = []
for yeni, modul, gorev in kayit:
    m = ESKI.search(gorev)
    if not m:
        continue
    ham = m.group(1).strip()
    aciklama = ESKI.sub("", gorev).strip(" —-")
    # "haric_kume ×3 kopya" gibi notlari ayikla
    for parca in re.split(r"\s*\+\s*|\s*,\s*", ham):
        parca = parca.strip()
        if parca:
            esl.append((parca, yeni, modul, aciklama))

esl.sort(key=lambda x: x[0].lower())
py = [e for e in esl if e[2].endswith(".py")]
js = [e for e in esl if e[2].endswith(".js")]

with open(CIKTI, "w", encoding="utf-8") as f:
    f.write("""# ESLESTIRME — eski ad → yeni ad

> Bu dosya **elle yazılmaz.** `FONKSIYONLAR.txt` içindeki `(eski: ...)`
> notlarından `tools/gen_eslestirme.py` ile üretilir; liste değişince
> yeniden koşulur, böylece ikisi asla ayrışmaz.

Geçiş sırasında "bu fonksiyon neredeydi" sorusunun cevabı burada.
`(eski: ...)` notu olmayan adlar **yeni** — eski sistemde karşılığı yoktu
(çoğu, eskiden hiç ayrılmamış bir sorumluluğu adlandırıyor).

""")
    f.write(f"**Eşleşen ad: {len(esl)}**  ·  Python {len(py)}  ·  JavaScript {len(js)}\n\n")
    for baslik, kume in (("## Python / sunucu", py), ("## JavaScript / arayüz", js)):
        f.write(f"\n{baslik}\n\n| Eski ad | Yeni ad | Nerede | Ne yapar |\n|---|---|---|---|\n")
        for eski, yeni, modul, acik in kume:
            f.write(f"| `{eski}` | `{yeni}` | `{modul}` | {acik} |\n")

    yenisi = [k for k in kayit if not ESKI.search(k[2])]
    f.write(f"\n\n## Eski sistemde karşılığı olmayan adlar ({len(yenisi)})\n\n")
    f.write("Bunlar yeni sorumluluklar — çoğu, eskiden bir yere sıkışmış ya da\n"
            "hiç ayrılmamış bir işi kendi adıyla ortaya çıkarıyor.\n\n")
    grup = collections.defaultdict(list)
    for ad, modul, gorev in yenisi:
        grup[modul].append((ad, gorev))
    for modul in sorted(grup):
        f.write(f"\n**`{modul}`**\n\n")
        for ad, gorev in grup[modul]:
            f.write(f"- `{ad}` — {gorev}\n")

print(f"{CIKTI}: {len(esl)} eslestirme ({len(py)} py, {len(js)} js), "
      f"{len(kayit)-len(esl)} yeni ad")
