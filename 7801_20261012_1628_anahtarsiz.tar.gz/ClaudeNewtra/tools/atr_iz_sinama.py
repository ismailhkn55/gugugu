# -*- coding: utf-8 -*-
"""ATR IZI sinamasi (06.10.2026, DOKUMANTASYON 7.52).

1) Canli karar yolu (plan_for_source -> decide_exit) bagimsiz simulatorle
   AYNI sonucu veriyor mu (1m mum, kotumser sira: once dip, sonra tepe).
2) "merdiven" modu DEGISMEDI (ayni plan sozlugu).
3) Cark: ATR buyuyunce stop geri cekilmez; baslangic/elle stop carka takilmaz.
4) ATR yoksa iz yerinde bekler.
Kullanim: python3 tools/atr_iz_sinama.py <atr_veri.json>   (veri yoksa yalniz 2-4)
YALITILMIS: dosya/ag yok, yalniz saf fonksiyonlar.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("NEWTRADE_DATA_DIR", "/tmp/atr_iz_sinama_bos")
from app.strategy.exit import decide_exit
from app.trading.exit_rules import build_manual_plan, plan_for_source

AYAR = {"al_stop": 6.0, "al_kilit2_esik": 1.8, "al_kilit2_yuzde": 0.7, "al_kilit3_esik": 3.0,
        "al_kilit3_yuzde": 2.2, "al_dinamik_esik": 7.0, "al_trailing_mesafe": 2.0,
        "dinamik_atr_carpan": 1.2, "dinamik_mesafe_tavan": 4.0, "dinamik_mesafe_taban_min": 0.6,
        "al_cikis_modu": "atr_iz", "atr_iz_aktif": 5.0, "atr_iz_kilit": 2.0,
        "atr_iz_carpan": 4.0, "atr_iz_min": 1.0}
hata = []
def bekle(k, m):
    print(("TAMAM " if k else "HATA  ") + m)
    if not k: hata.append(m)


def atr5(c):
    m5, atr, a = [], [], None
    for i in range(0, len(c) - 4, 5):
        p = c[i:i + 5]; m5.append((p[0][1], max(x[2] for x in p), min(x[3] for x in p), p[-1][4]))
    for i, x in enumerate(m5):
        tr = x[1] - x[2] if i == 0 else max(x[1] - x[2], abs(x[1] - m5[i-1][3]), abs(x[2] - m5[i-1][3]))
        a = tr if a is None else (a * 13 + tr) / 14
        atr.append(a / x[3] * 100)
    return atr


def bagimsiz(c, g, atr, s=6.0, aktif=5.0, kilit=2.0, cp=4.0, mn=1.0):
    stop = g * (1 - s / 100); tepe = g
    for i, (t, o, h, l, k) in enumerate(c):
        if l <= stop: return min(stop, o) / g * 100 - 100
        tepe = max(tepe, h); j = i // 5 - 1
        if (tepe / g - 1) * 100 >= aktif:
            stop = max(stop, g * (1 + kilit / 100))
            if j >= 14: stop = max(stop, tepe * (1 - max(mn, cp * atr[j]) / 100))
    return (c[-1][4] / g - 1) * 100


def canli_yol(c, g, atr):
    plan = plan_for_source(None, AYAR, strategy={"cikis_yontemi": "al"})
    poz = {"fiyat": g, "dolan_fiyat": g, "ts": c[0][0], "hiz": None,
           "en_yuksek": g, "stop_guncel": g * 0.94, "stop_sebep": "baslangic"}
    for i, (t, o, h, l, k) in enumerate(c):
        j = i // 5 - 1
        a = atr[j] if j >= 14 else None
        for fiyat in (l, h):                       # kotumser: once dip
            kr = decide_exit(poz, fiyat, plan, atr_pct=a)
            if kr.should_sell:
                return min(poz["stop_guncel"], o) / g * 100 - 100
            poz.update(en_yuksek=kr.highest, stop_guncel=kr.stop.price, stop_sebep=kr.stop.reason)
    return (c[-1][4] / g - 1) * 100


# 1) esdegerlik
if len(sys.argv) > 1:
    P = json.load(open(sys.argv[1]))
    fark, s_b, s_c = 0, [], []
    for p in P:
        atr = atr5(p["c"])
        b = bagimsiz(p["c"], p["g"], atr); cv = canli_yol(p["c"], p["g"], atr)
        s_b.append(b - 0.15); s_c.append(cv - 0.15)
        if abs(b - cv) > 0.02: fark += 1
    for k in ("canli", "bot"):
        idx = [i for i, p in enumerate(P) if p["k"] == k]
        print(f"   {k}: n={len(idx)} bagimsiz ort net {sum(s_b[i] for i in idx)/len(idx):+.3f}  "
              f"canli yol {sum(s_c[i] for i in idx)/len(idx):+.3f}")
    bekle(fark <= len(P) * 0.01, f"canli karar yolu = bagimsiz simulator ({len(P)} islem, farkli {fark})")

# 2) merdiven modu degismedi
eski = {**AYAR, "al_cikis_modu": "merdiven"}
p = build_manual_plan(eski)
bekle(p["ad"] == "AL (kademeli stop)" and p["stop"]["merdiven"] == [(1.8, 0.7), (3.0, 2.2)]
      and "cark" not in p["stop"] and "atr_zorunlu" not in p["stop"], "merdiven modu eski plan")
bekle(build_manual_plan({k: v for k, v in eski.items() if k != "al_cikis_modu"})["ad"] == "AL (kademeli stop)",
      "ayar yoksa varsayilan merdiven")

# 3) cark
plan = build_manual_plan(AYAR)
poz = {"fiyat": 100, "dolan_fiyat": 100, "ts": 0, "en_yuksek": 110, "stop_guncel": 106.0, "stop_sebep": "DINAMIK:x"}
kr = decide_exit(poz, 108, plan, atr_pct=2.0)      # 4x2=8% -> 101.2 < 106
bekle(abs(kr.stop.price - 106.0) < 1e-9 and not kr.should_sell, f"ATR buyudu, stop geri cekilmedi ({kr.stop.price})")
poz2 = {**poz, "stop_guncel": 99.0, "stop_sebep": "elle", "en_yuksek": 101}
kr2 = decide_exit(poz2, 100.5, plan, atr_pct=1.0)
bekle(kr2.stop.price < 99.0, f"elle/baslangic stop carka takilmadi ({kr2.stop.price:.2f})")

# 4) ATR yok
poz3 = {"fiyat": 100, "dolan_fiyat": 100, "ts": 0, "en_yuksek": 110, "stop_guncel": 102.0, "stop_sebep": "kilit_%2"}
kr3 = decide_exit(poz3, 109, plan, atr_pct=None)
bekle(abs(kr3.stop.price - 102.0) < 1e-9, f"ATR yok -> iz yerinde ({kr3.stop.price})")
kr4 = decide_exit(poz3, 109, plan, atr_pct=0.5)    # 4x0.5=2% -> 107.8
bekle(abs(kr4.stop.price - 107.8) < 1e-6, f"ATR 0.5 -> stop tepe-%2 = 107.8 ({kr4.stop.price})")

print("SONUC:", "HATA %d" % len(hata) if hata else "HEPSI TAMAM")
sys.exit(1 if hata else 0)
