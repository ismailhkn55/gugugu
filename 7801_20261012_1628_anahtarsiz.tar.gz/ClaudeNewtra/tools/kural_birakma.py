import os, sys, collections
sys.path.insert(0, "/DATA/AppData/ClaudeNewtra")
os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/_cn_sunucu_testi")
from app.market import rank_repository as RR
from app.market.exclusions import load_excluded_symbols
from app.strategy.registry import get_active_strategy
from app.strategy.rule_engine import evaluate_rule, RuleOutcome, describe_rule

st = get_active_strategy(live=False)
kur = [k for k in st["kurallar"] if k.get("aktif", True)]
ad = [describe_rule(k) for k in kur]
haric = load_excluded_symbols()
GUN = float(sys.argv[1]) if len(sys.argv) > 1 else 7
with RR.open_rank_db_readonly() as c:
    son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
    turlar = RR.list_rounds_with_trail(c, son - int(GUN * 86400000), son)
    olay = []                       # (ts, sembol, fiyat, kalan_index_listesi)
    for ts, iz in turlar:
        for r in RR.build_round_snapshot(c, ts, iz, haric):
            kal = [i for i, k in enumerate(kur) if evaluate_rule(r, k).outcome is not RuleOutcome.GECTI]
            if len(kal) <= 1:
                olay.append((ts, r["sembol"], r.get("fiyat"), kal))
    # fiyat yolu: tur fiyatlari (sonraki 48 tur = 4 saat)
    semb = {o[1] for o in olay}
    yol = collections.defaultdict(list)
    for s in semb:
        for ts, f in c.execute("SELECT ts, fiyat FROM anlik WHERE sembol=? AND ts>=? ORDER BY ts",
                               (s, son - int(GUN * 86400000))):
            yol[s].append((ts, f))

import bisect
def sonuc(s, ts, g):
    y = yol[s]; t = [x[0] for x in y]
    i = bisect.bisect_right(t, ts)
    if not g: return "yok"
    for _, f in y[i:i + 48]:
        if f is None: continue
        if f <= g * 0.98: return "stop"
        if f >= g * 1.02: return "hedef"
    return "sure" if i + 48 <= len(y) else "acik"

# ayni coinde art arda turlari tek giris say: ilk tur (onceki tur ayni durumda degilse)
def ilkler(liste):
    gor, out = {}, []
    tl = [x[0] for x in turlar]; onceki = {t: tl[i - 1] if i else None for i, t in enumerate(tl)}
    anahtar = {(o[0], o[1]) for o in liste}
    for o in sorted(liste):
        if (onceki[o[0]], o[1]) in anahtar: continue
        out.append(o)
    return out

def ozet(liste):
    c = collections.Counter(sonuc(o[1], o[0], o[2]) for o in liste)
    h, s_ = c["hedef"], c["stop"]
    return f"{len(liste):5d}  hedef {h:4d}  stop {s_:4d}  sure {c['sure']:4d}  isabet {100*h/max(1,h+s_):5.1f}%"

sinyal = [o for o in olay if not o[3]]
print(f"{GUN:g} gun, {len(turlar)} tur. Giris = ayni coinde art arda turlarin ilki. Sonuc: once +%2 mi -%2 mi (4 saat, tur fiyati)")
print(f"{'STRATEJININ GIRISLERI':38s}", ozet(ilkler(sinyal)))
for i, a in enumerate(ad):
    yalniz = [o for o in olay if o[3] == [i]]
    if yalniz:
        print(f"{'yalniz ' + a + ' engelledi':38s}", ozet(ilkler(yalniz)))

orta = turlar[len(turlar) // 2][0]
print("\nIKI YARI (isabet = hedef / (hedef+stop)):")
def yari(liste, a):
    l = ilkler(liste); A = [o for o in l if o[0] < orta]; B = [o for o in l if o[0] >= orta]
    def i(x):
        c = collections.Counter(sonuc(o[1], o[0], o[2]) for o in x); return f"{len(x):5d} isabet {100*c['hedef']/max(1,c['hedef']+c['stop']):5.1f}%"
    print(f"  {a:38s} 1. yari {i(A)}   2. yari {i(B)}")
yari(sinyal, "STRATEJININ GIRISLERI")
for j, a in enumerate(ad):
    yari([o for o in olay if o[3] == [j]], "yalniz " + a)
