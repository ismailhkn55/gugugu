# -*- coding: utf-8 -*-
# Bassiz Chromium'u CDP ile surer: sayfayi acar, konsol hatalarini ve
# basarisiz ag isteklerini toplar, ekran goruntusu alir.
# Bagimlilik yok -- websocket cercevelemesi elle yazilmistir (stdlib).
import base64, json, os, socket, struct, subprocess, sys, time, urllib.request

PORT = 9333
HEDEF = sys.argv[1]
CIKTI = sys.argv[2]
YETKI = sys.argv[3] if len(sys.argv) > 3 else ""
BEKLE = float(sys.argv[4]) if len(sys.argv) > 4 else 9.0
# 5. arguman: sayfa YUKLENMEDEN once calistirilacak JS dosyasi
# (ornegin tercihleri `localStorage`'a yazmak icin).
ONCE = open(sys.argv[5], encoding="utf-8").read() if len(sys.argv) > 5 else ""
# 6. arguman: pencere olcusu "GENISLIKxYUKSEKLIK"
PENCERE = sys.argv[6] if len(sys.argv) > 6 else "1600,1000"

# Chromium'u ayri bir profille, uzaktan hata ayiklama acik baslatir.
def chromium_baslat():
    prof = "/tmp/cdp_prof_%d" % PORT
    p = subprocess.Popen(
        ["/snap/bin/chromium", "--headless=new", "--no-sandbox", "--disable-gpu",
         "--hide-scrollbars", "--window-size=" + PENCERE.replace("x", ","),
         "--remote-debugging-port=%d" % PORT, "--user-data-dir=" + prof,
         "about:blank"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(80):
        try:
            urllib.request.urlopen("http://127.0.0.1:%d/json/version" % PORT, timeout=1).read()
            return p
        except Exception:
            time.sleep(0.25)
    raise RuntimeError("chromium acilmadi")

# Yeni sekme acar, CDP websocket adresini dondurur.
def sekme_ac():
    r = urllib.request.Request("http://127.0.0.1:%d/json/new?about:blank" % PORT,
                               method="PUT")
    d = json.loads(urllib.request.urlopen(r, timeout=5).read())
    return d["webSocketDebuggerUrl"]

# --- asgari websocket istemcisi ------------------------------------------
class WS:
    def __init__(self, url):
        _, rest = url.split("://", 1)
        hostport, yol = rest.split("/", 1)
        h, _, pr = hostport.partition(":")
        self.s = socket.create_connection((h, int(pr or 80)), timeout=30)
        anahtar = base64.b64encode(os.urandom(16)).decode()
        self.s.sendall(("GET /%s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\n"
                        "Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n"
                        "Sec-WebSocket-Version: 13\r\n\r\n" % (yol, hostport, anahtar)).encode())
        tampon = b""
        while b"\r\n\r\n" not in tampon:
            tampon += self.s.recv(4096)
        self.kuyruk = tampon.split(b"\r\n\r\n", 1)[1]
        self.no = 0

    def gonder(self, yontem, **par):
        self.no += 1
        govde = json.dumps({"id": self.no, "method": yontem, "params": par}).encode()
        mask = os.urandom(4)
        n = len(govde)
        bas = b"\x81"
        if n < 126:   bas += bytes([0x80 | n])
        elif n < 65536: bas += b"\xfe" + struct.pack(">H", n)
        else:         bas += b"\xff" + struct.pack(">Q", n)
        self.s.sendall(bas + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(govde)))
        return self.no

    def _al(self, n):
        while len(self.kuyruk) < n:
            p = self.s.recv(65536)
            if not p: raise RuntimeError("baglanti kapandi")
            self.kuyruk += p
        v, self.kuyruk = self.kuyruk[:n], self.kuyruk[n:]
        return v

    # Tek cerceve okur; parcali (FIN=0) mesajlari birlestirir.
    def oku(self):
        govde = b""
        while True:
            b1, b2 = self._al(2)
            fin, uzun = b1 & 0x80, b2 & 0x7F
            if uzun == 126:   uzun = struct.unpack(">H", self._al(2))[0]
            elif uzun == 127: uzun = struct.unpack(">Q", self._al(8))[0]
            govde += self._al(uzun)
            if fin: break
        return json.loads(govde.decode("utf-8", "replace"))

ch = chromium_baslat()
try:
    ws = WS(sekme_ac())
    ws.gonder("Runtime.enable"); ws.gonder("Log.enable")
    ws.gonder("Network.enable"); ws.gonder("Page.enable")
    if YETKI:
        ws.gonder("Network.setExtraHTTPHeaders", headers={"Authorization": YETKI})
    if ONCE:
        ws.gonder("Page.addScriptToEvaluateOnNewDocument", source=ONCE)
    git = ws.gonder("Page.navigate", url=HEDEF)

    hatalar, agHatalari = [], []
    bitis = time.time() + BEKLE
    self_ss = None
    while time.time() < bitis:
        self_s = ws.s; self_s.settimeout(max(0.2, bitis - time.time()))
        try:
            m = ws.oku()
        except socket.timeout:
            break
        except Exception:
            break
        y = m.get("method")
        if y == "Runtime.consoleAPICalled" and m["params"].get("type") in ("error", "warning"):
            t = " ".join(str(a.get("value", a.get("description", ""))) for a in m["params"].get("args", []))
            hatalar.append(("konsol-" + m["params"]["type"], t[:300]))
        elif y == "Runtime.exceptionThrown":
            d = m["params"]["exceptionDetails"]
            hatalar.append(("istisna", (d.get("exception", {}).get("description") or d.get("text", ""))[:300]))
        elif y == "Log.entryAdded" and m["params"]["entry"].get("level") == "error":
            hatalar.append(("log", m["params"]["entry"].get("text", "")[:300]))
        elif y == "Network.responseReceived":
            r = m["params"]["response"]
            if r.get("status", 0) >= 400:
                agHatalari.append((r["status"], r["url"][:160]))
        elif y == "Network.loadingFailed":
            agHatalari.append(("BASARISIZ", m["params"].get("errorText", "") + " " + str(m["params"].get("type"))))

    ws.s.settimeout(30)
    ws.gonder("Page.captureScreenshot", format="png")
    for _ in range(300):
        m = ws.oku()
        if "result" in m and "data" in m.get("result", {}):
            open(CIKTI, "wb").write(base64.b64decode(m["result"]["data"]))
            break

    print("HEDEF:", HEDEF)
    print("konsol/istisna hatasi:", len(hatalar))
    for t, x in hatalar[:25]: print("   [%s] %s" % (t, x))
    print("ag hatasi (>=400 / basarisiz):", len(agHatalari))
    for s, u in agHatalari[:25]: print("   [%s] %s" % (s, u))
    print("ekran goruntusu:", CIKTI, os.path.getsize(CIKTI) if os.path.exists(CIKTI) else "YOK")
finally:
    ch.terminate()
