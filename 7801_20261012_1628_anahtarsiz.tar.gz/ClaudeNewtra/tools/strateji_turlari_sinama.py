# -*- coding: utf-8 -*-
"""`/yerel/strateji-turlari` sinamasi (DOKUMANTASYON 7.59). Salt okunur.

1. Uc, bagimsiz aractan (tools/strateji_gecmis.py) AYNI turlari, AYNI coinler icin bulur.
2. Strateji guncellemesinden sonraki her bot girisi, girdigi turda uctan da gelir.
3. Eski bot girislerinde: kayitli giris satiri (giris_piyasa) butun guncel kurallari
   geciyorsa uc o turda o coini secer; gecmiyorsa secmez (giris satiri = o turun satiri).
4. Ikinci cagri onbellekten (hesap yok) ve hizli.
Binance'e coin basina 1 mum istegi (gecmis-sinyal ile ayni).
"""
import bisect, json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/_cn_sunucu_testi")

from app.config.paths import get_ledger_path
from app.market.rank_repository import open_rank_db_readonly
from app.strategy.entry import is_entry_allowed
from app.strategy.registry import get_active_strategy
from app.web.handlers import market_api as M
from strateji_gecmis import strateji_gecmisi

hata = 0
def kontrol(ad, kosul, ayrinti=""):
    global hata
    print(("TAMAM " if kosul else "HATA  ") + ad + (f"  [{ayrinti}]" if ayrinti else ""))
    hata += 0 if kosul else 1

st = get_active_strategy(live=False)
dry = json.load(open(get_ledger_path(False)))["emirler"]
bot = [e for e in dry if not e.get("el_kaynak") and e.get("giris_piyasa")]
with open_rank_db_readonly() as c:
    tur = [r[0] for r in c.execute("SELECT DISTINCT ts FROM anlik WHERE ts>=? ORDER BY ts",
                                    (min(e["ts"] for e in bot) - 3_600_000,))]
tur_of = lambda ms: tur[bisect.bisect_right(tur, ms) - 1]

sonra = [e for e in bot if e["ts"] >= st["guncelleme"]]
semboller = sorted({e["sembol"] for e in sonra} | {"NEARUSDT", "APTUSDT"})
t0 = time.time()
yanit = {s: M.handle_strategy_rounds({"params": {"sembol": s, "limit": "300"}})[1] for s in semboller}
ilk = time.time() - t0
t0 = time.time()
for s in semboller[:1]:
    M.handle_strategy_rounds({"params": {"sembol": s, "limit": "300"}})
ikinci = time.time() - t0

# 1. bagimsiz aracla ayni
for s in semboller:
    y = yanit[s]
    tlar = [n["ts"] for n in y["noktalar"]]
    if not y["taranan_tur"]:
        kontrol(f"{s}: tur var", False); continue
    turlar = sorted(M._TUR_ONBELLEK["tur"])          # ucun hesapladigi turlar
    bas, bit = turlar[0], turlar[-1]
    arac = strateji_gecmisi(bas, bit, st, [s])["sinyal"]
    ar = sorted(x["ts"] for x in arac)
    tlar = [t for t in tlar if bas <= t <= bit]
    kontrol(f"{s}: uc = arac ({len(tlar)} sinyal, {y['taranan_tur']} tur)", sorted(tlar) == ar,
            f"yalniz uc {sorted(set(tlar)-set(ar))[:3]} yalniz arac {sorted(set(ar)-set(tlar))[:3]}")
    kontrol(f"{s}: sinanamayan kural yok", y["sinanamayan_kural"] == [] and y["tam_sinanabilir"])

# 2. guncelleme sonrasi bot girisleri
for e in sonra:
    tl = {n["ts"] for n in yanit[e["sembol"]]["noktalar"]}
    kontrol(f"bot girisi {e['sembol']} {e['ts']}: girdigi turda sinyal", tur_of(e["ts"]) in tl)

# 3. eski girisler: giris satiri kurallari geciyor mu <-> uc o turu seciyor mu
eski = [e for e in bot if e["ts"] < st["guncelleme"]]
secim = M.fetch_strategy_round_picks(st, tur_of(min(e["ts"] for e in eski)), max(tur))
uy, toplam = 0, 0
for e in eski:
    t = tur_of(e["ts"])
    if t not in secim:
        continue
    toplam += 1
    gecer = is_entry_allowed(e["giris_piyasa"], st)["gecti"]
    sec = any(s == e["sembol"] for s, _ in secim[t])
    uy += gecer == sec
kontrol(f"eski {toplam} bot girisinde giris satiri ile tur secimi ayni", uy == toplam, f"{uy}/{toplam}")

kontrol(f"ilk cagri {ilk:.1f} sn ({len(semboller)} coin), ikinci {ikinci*1000:.0f} ms", ikinci < 2.0)
print("SONUC:", "TAMAM" if not hata else f"{hata} HATA")
sys.exit(1 if hata else 0)
