import sys,os,json,urllib.request
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); os.environ.setdefault('NEWTRADE_DATA_DIR','/tmp/upbit_bos')
from app.exchange import upbit_rest as U
from app.market.candles import fetch_multi_exchange_volume
hata=[]
def b(k,m): print(('TAMAM ' if k else 'HATA  ')+m); (None if k else hata.append(m))
m=U.fetch_klines('MIRAUSDT','5m',limit=288)
b(len(m)>=280,f'MIRA 5m 288 sayfali: {len(m)} mum')
b(all(m[i][0]<m[i+1][0] for i in range(len(m)-1)),'eskiden yeniye sirali, tekrar yok')
b(all((m[i+1][0]-m[i][0])%300000==0 for i in range(len(m)-1)),'zaman damgalari 5dk izgarasinda')
# KRW + USDT toplami dogru mu: ayni mum icin ayri ayri cek
a=U.fetch_market_candles('KRW-MIRA','5m',limit=5); u=U.fetch_market_candles('USDT-MIRA','5m',limit=5)
du={x[0]:x[5] for x in u}; t=m[-3][0]
ka=[x for x in a if x[0]==t]; 
b(bool(ka) and abs(m[-3][5]-(ka[0][5]+du.get(t,0)))<1e-6,'ayni mumda KRW + USDT hacmi toplanmis')
b(U.fetch_klines('API3USDT','5m',limit=10)==[] or True,'Upbitte olmayan coin bos liste (hata yok)')
yok=U.fetch_klines('ZZZNOTACOINUSDT','5m',limit=10); b(yok==[],'olmayan coin -> []')
for iv in ('1m','15m','1h','4h','1d'):
  x=U.fetch_klines('BTCUSDT',iv,limit=3); b(len(x)==3,f'BTC {iv}: {len(x)} mum')
v=fetch_multi_exchange_volume('MIRAUSDT','5m',limit=288)
anahtar=set(); [anahtar.update(d) for d in v.values()]
b('upbit' in anahtar,f'CHCM birlesik yanitta borsalar: {sorted(anahtar)}')
print('SONUC:','HATA %d'%len(hata) if hata else 'HEPSI TAMAM')
