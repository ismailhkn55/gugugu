// %1 izgara sinamasi: uc grafigin izgara fonksiyonu kaynaktan cikarilip
// gercek Binance 24s araliklariyla (her USDT cifti) kosulur.
import fs from "fs";
const [renPath, tvPath, cgPath, coinPath] = process.argv.slice(2);
const coinler = JSON.parse(fs.readFileSync(coinPath, "utf8"));
const cikar = (src, ad) => {
  const i = src.indexOf(`function ${ad}(`);
  const j = src.indexOf("\n}\n", i);
  if (i < 0 || j < 0) throw new Error(ad + " bulunamadi");
  return src.slice(i, j + 2);
};
const ren = fs.readFileSync(renPath, "utf8");
const sabitler = (ren.match(/^const IZGARA_[A-Z]+ = .*$/gm) || []).join("\n");
const izgaraCiz = new Function("KENAR", "el", sabitler + "\n" + cikar(ren, "izgaraCiz") + "\nreturn izgaraCiz;")(
  { ust: 0, alt: 0, sag: 52 }, () => ({}));
const fiyatYakala = (src, ad) => {
  const fiyatlar = [];
  const ser = { mum: { createPriceLine: (o) => (fiyatlar.push(o.price), o), removePriceLine() {} } };
  return { fiyatlar, ser };
};
const tvSrc = fs.readFileSync(tvPath, "utf8"), cgSrc = fs.readFileSync(cgPath, "utf8");
const tvFn = new Function("ctx", `let _izgara=[],_izgaraAnahtar="";const _ser=ctx.ser;const css=()=>"";const yariSoluk=x=>x;
  const document={documentElement:{dataset:{}}};` + cikar(tvSrc, "yuzdeIzgarasiCiz") + "\nreturn yuzdeIzgarasiCiz;");
const cgFn = new Function("", `const css=()=>"";const yariSolukRenk=x=>x;` + cikar(cgSrc, "yuzdeCizgileri") + "\nreturn yuzdeCizgileri;")();

let hata = 0, olcum = 0, enKotu = 0;
const denetle = (ad, s, fiyatlar, az, en) => {
  fiyatlar = [...fiyatlar].sort((a, b) => a - b);
  for (let i = 1; i < fiyatlar.length; i++) {
    const oran = fiyatlar[i] / fiyatlar[i - 1];
    olcum++; enKotu = Math.max(enKotu, Math.abs(oran - 1.01));
    if (Math.abs(oran - 1.01) > 1e-9) { if (hata++ < 8) console.log(`HATA ${ad} ${s}: ${fiyatlar[i-1]} -> ${fiyatlar[i]} = %${((oran-1)*100).toFixed(4)}`); }
  }
  // seviye 1.01^k mi (grafikler arasi ayni fiyatlar)
  for (const f of fiyatlar) { const k = Math.log(f) / Math.log(1.01);
    if (Math.abs(k - Math.round(k)) > 1e-6) { if (hata++ < 8) console.log(`HATA ${ad} ${s}: ${f} 1.01^k degil`); } }
  // aralik kapsandi mi: az..en icinde %1'den buyuk bosluk yok
  const ic = fiyatlar.filter((f) => f >= az && f <= en);
  if (en / az > 1.0201 && ic.length < 2) { if (hata++ < 8) console.log(`HATA ${ad} ${s}: aralik bos`); }
};
const YUK = [60, 120, 200, 400, 700, 1000];
let renSay = 0;
for (const c of coinler) {
  for (const anaYuk of YUK) {
    const y = (v) => (c.en - v) / (c.en - c.az) * anaYuk;
    const cizgiler = izgaraCiz({ appendChild() {} }, { az: c.az, en: c.en, y, W: 800, anaYuk, sagKenar: 52 });
    // piksel -> fiyat geri cevrimi
    const fiyatlar = cizgiler.map((py) => c.en - py / anaYuk * (c.en - c.az));
    // piksel yuvarlamasi yok (py ham); yine de fiyatlari dogrudan 1.01^k'ye oturt
    const kesin = fiyatlar.map((f) => Math.pow(1.01, Math.round(Math.log(f) / Math.log(1.01))));
    for (let i = 0; i < fiyatlar.length; i++) if (Math.abs(fiyatlar[i] / kesin[i] - 1) > 1e-9) { if (hata++ < 8) console.log("HATA renderer piksel", c.s); }
    if (c.en / c.az <= 4) denetle("renderer", c.s + "@" + anaYuk, kesin, c.az, c.en);
    renSay++;
  }
  const tv = fiyatYakala(); tvFn(tv)([{ d: c.az, y: c.en }]); denetle("tvChart", c.s, tv.fiyatlar, c.az, c.en);
  const cg = fiyatYakala(); cgFn({ ser: cg.ser, izgara: [], izgaraAnahtar: "" }, [{ d: c.az, y: c.en }]); denetle("chartGrid", c.s, cg.fiyatlar, c.az, c.en);
}
console.log(`coin ${coinler.length}, renderer cizimi ${renSay}, komsu cizgi olcumu ${olcum}, en buyuk sapma ${enKotu.toExponential(2)}, HATA ${hata}`);
process.exit(hata ? 1 : 0);
