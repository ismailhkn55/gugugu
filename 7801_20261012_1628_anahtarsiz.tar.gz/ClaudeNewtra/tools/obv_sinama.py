# obv_aci_degisim sinamasi (DOKUMANTASYON 7.60). Salt okunur.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/_cn_sunucu_testi")
from app.market import rank_repository as RR
from app.market.indicators import is_known_field
from app.strategy.backtest import is_rule_testable
hata = 0
def kontrol(ad, k, a=""):
    global hata
    print(("TAMAM " if k else "HATA  ") + ad + (f"  [{a}]" if a else "")); hata += 0 if k else 1
kontrol("kayit defterinde", is_known_field("obv_aci_degisim"))
kontrol("mum geriye-testinde sinanamaz", not is_rule_testable({"alan": "obv_aci_degisim", "op": ">", "deger": 0})[0])
d = RR.fetch_latest_snapshot(limit=400, cache_sn=0)
with RR.open_rank_db_readonly() as c:
    onceki = dict(c.execute("SELECT sembol, obv_aci FROM anlik WHERE ts=?", (d["turlar"][-2],)).fetchall())
ok = [r for r in d["satir"] if r.get("obv_aci") is not None and onceki.get(r["sembol"]) is not None]
kontrol(f"{len(ok)} satirda fark = obv_aci - onceki tur (elle)", all(abs(r["obv_aci_degisim"] - (r["obv_aci"] - onceki[r["sembol"]])) < 1e-9 for r in ok))
kontrol("dolu", sum(r.get("obv_aci_degisim") is not None for r in d["satir"]) >= len(ok) > 0)
cap = RR.capture_market_snapshot(ok[0]["sembol"])
kontrol("giris/cikis kaydinda da var", cap.get("obv_aci_degisim") is not None and abs(cap["obv_aci_degisim"] - ok[0]["obv_aci_degisim"]) < 1e-9)
print("ornek:", [(r["sembol"], round(r["obv_aci"], 1), round(r["obv_aci_degisim"], 1)) for r in ok[:4]])
print("SONUC:", "TAMAM" if not hata else f"{hata} HATA"); sys.exit(1 if hata else 0)
