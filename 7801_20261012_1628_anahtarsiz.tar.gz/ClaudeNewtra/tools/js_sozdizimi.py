#!/usr/bin/env python3
"""TUM JS modullerinin sozdizimini dogrular (node --check).

NEDEN: JS dosyalarini duzenlerken regex kullandim ve
`registerPoll("islemMum", 30, async () => { await anaMumlariYukle(, ...` gibi
BOZUK bir satir urettim. Tek modul patlayinca TUM modul grafigi yuklenmiyor
ve sayfa HIC render olmuyor -- `--dump-dom` ham HTML donduruyor, "calisiyor"
gibi gorunuyor. Bu betik her degisiklikten sonra kosulmali.

Not: ES modulleri icin `node --check` yetmez (import/export'u betik sayar),
o yuzden dosya gecici olarak .mjs uzantisiyla denetlenir.
"""
import os
import shutil
import subprocess
import sys
import tempfile

KOK = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "app", "web", "static", "js")
NODE_ADAYLARI = ["node", "/usr/local/bin/node",
                 os.path.expanduser("~/.local/nodejs/bin/node"),
                 os.path.expanduser("~/node-v20.18.0-linux-x64/bin/node")]


def node_bul() -> str | None:
    for n in NODE_ADAYLARI:
        y = shutil.which(n) if os.sep not in n else (n if os.path.exists(n) else None)
        if y:
            return y
    return None


def main() -> int:
    node = node_bul()
    if not node:
        print("node bulunamadi -- JS sozdizimi denetlenemedi"); return 0

    hatalar = []
    sayi = 0
    with tempfile.TemporaryDirectory() as gecici:
        for d, _alt, adlar in sorted(os.walk(KOK)):
            for a in sorted(adlar):
                if not a.endswith(".js"):
                    continue
                sayi += 1
                kaynak = os.path.join(d, a)
                hedef = os.path.join(gecici, a.replace(".js", ".mjs"))
                shutil.copyfile(kaynak, hedef)
                p = subprocess.run([node, "--check", hedef],
                                   capture_output=True, text=True)
                if p.returncode != 0:
                    goreli = os.path.relpath(kaynak, KOK)
                    ilk = [s for s in p.stderr.split("\n") if "SyntaxError" in s]
                    hatalar.append((goreli, ilk[0].strip() if ilk else
                                    p.stderr.strip().split("\n")[0]))

    print(f"{sayi} JS modulu denetlendi  |  SOZDIZIMI HATASI: {len(hatalar)}")
    for yol, mesaj in hatalar:
        print(f"   {yol}\n      {mesaj}")
    return 1 if hatalar else 0


if __name__ == "__main__":
    sys.exit(main())
