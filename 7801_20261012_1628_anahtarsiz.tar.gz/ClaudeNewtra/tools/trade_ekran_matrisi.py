import sys,json,time,base64,os
src=open('/DATA/AppData/ClaudeNewtra/tools/cdp_denetim.py').read()
sys.argv=['x','about:blank','/tmp/x.png']
exec(src[:src.index('\nch = chromium_baslat()')].replace('PORT = 9333','PORT = 9366'))
OLC=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'trade_ekran_olc.js')).read()
SEN=[('A_yatay_tv_chcm',780,360,True,{'tvGrafik':True,'gosterge':{'hacim':True,'hacimCokBorsa':True,'ema':True},'emaDonem':[5,10,30,60]},'yatay'),
     ('B_yatay_tv_hcm',780,360,True,{'tvGrafik':True,'gosterge':{'hacim':True}},'yatay'),
     ('C_yatay_tv_sade',780,360,True,{'tvGrafik':True,'gosterge':{}},'yatay'),
     ('D_yatay_svg_chcm',780,360,True,{'tvGrafik':False,'gosterge':{'hacim':True,'hacimCokBorsa':True,'ema':True},'emaDonem':[5,10,30,60]},'yatay'),
     ('E_dikey_tv_chcm',360,780,True,{'tvGrafik':True,'gorunum':'dikey','gosterge':{'hacim':True,'hacimCokBorsa':True,'ema':True},'emaDonem':[5,10,30,60]},'dikey'),
     ('E2_dik_tut_yatay_mod',360,780,True,{'tvGrafik':True,'gorunum':'yatay','gosterge':{'hacim':True,'hacimCokBorsa':True,'ema':True},'emaDonem':[5,10,30,60]},'yatay'),
     ('F_masaustu_tv_chcm',1600,1000,False,{'tvGrafik':True,'gosterge':{'hacim':True,'hacimCokBorsa':True,'ema':True},'emaDonem':[5,10,30,60]},'yatay')]
for ad,W,H,mob,ter,gor in SEN:
  p=chromium_baslat(); ws=WS(sekme_ac()); hata=[]
  def cmd(m,**k):
    i=ws.gonder(m,**k)
    while True:
      r=ws.oku()
      if r.get('method')=='Runtime.exceptionThrown': hata.append(r['params']['exceptionDetails'].get('exception',{}).get('description','')[:160])
      if r.get('method')=='Runtime.consoleAPICalled' and r['params'].get('type')=='error': hata.append(' '.join(str(a.get('value',a.get('description','')))[:120] for a in r['params']['args']))
      if r.get('id')==i: return r
  cmd('Runtime.enable'); cmd('Page.enable')
  cmd('Emulation.setDeviceMetricsOverride',width=W,height=H,deviceScaleFactor=3 if mob else 1,mobile=mob)
  if mob: cmd('Emulation.setTouchEmulationEnabled',enabled=True,maxTouchPoints=5)
  cmd('Page.addScriptToEvaluateOnNewDocument',source="try{var t=JSON.parse(localStorage.getItem('cn-tercih')||'{}');Object.assign(t,%s);localStorage.setItem('cn-tercih',JSON.stringify(t))}catch(e){}"%json.dumps(ter))
  cmd('Page.navigate',url='http://127.0.0.1:7801/#islem/ORCAUSDT')
  bas=time.time()
  while time.time()-bas<15:
    ws.s.settimeout(1)
    try:
      r=ws.oku()
      if r.get('method')=='Runtime.exceptionThrown': hata.append(r['params']['exceptionDetails'].get('exception',{}).get('description','')[:160])
      if r.get('method')=='Runtime.consoleAPICalled' and r['params'].get('type')=='error': hata.append(str(r['params']['args'])[:160])
    except Exception: pass
  ws.s.settimeout(30)
  r=cmd('Runtime.evaluate',expression=OLC,returnByValue=True,awaitPromise=True)
  v=r.get('result',{}).get('result',{}).get('value')
  s=cmd('Page.captureScreenshot',format='png'); open(f'/tmp/m_{ad}.png','wb').write(base64.b64decode(s['result']['data']))
  print(ad,json.dumps(v,ensure_ascii=False),'HATA',len(hata),hata[:3],flush=True)
  p.kill(); time.sleep(1)
