(async()=>{
 const R=(e)=>{if(!e) return null; const b=e.getBoundingClientRect(); return [Math.round(b.y),Math.round(b.height)]};
 const mini=['grafGun','grafUst','grafAlt','grafDort'].map(id=>{const e=document.getElementById(id); if(!e) return null;
   const ys=[...e.querySelectorAll('svg rect')].map(r=>r.getBoundingClientRect()).filter(b=>b.height>0&&b.width<20);
   if(!ys.length) return 'mum yok'; const b=e.getBoundingClientRect();
   return [Math.round(b.height),Math.round(Math.min(...ys.map(q=>q.y))-b.y),Math.round(b.bottom-Math.max(...ys.map(q=>q.y+q.height)))]});
 const mg=[...document.querySelectorAll('#miniGosterge .mgHucre')];
 const tv=document.querySelector('#grafCanli .tvGrafik');
 return {gorunum:document.documentElement.dataset.gorunum, tv:!!tv, mini_yuk_bosUst_bosAlt:mini,
  mgSatir:new Set(mg.map(e=>Math.round(e.getBoundingClientRect().y))).size, mgKesilen:mg.filter(e=>e.scrollWidth>e.clientWidth+1).length,
  grafCanli:R(document.querySelector('#grafCanli')), tvSatir:tv?[...tv.querySelectorAll('table tr')].map(R):null,
  svgHacimDilim:tv?null:document.querySelectorAll('#grafCanli .kHacim rect').length};
})()
