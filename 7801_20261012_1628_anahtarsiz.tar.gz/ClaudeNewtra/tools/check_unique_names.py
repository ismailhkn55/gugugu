#!/usr/bin/env python3
"""FONKSIYONLAR.txt icindeki HER adin benzersiz oldugunu dogrular.

Neden var: eski sistemde `_oku` uc modulde, `_yaz` iki modulde, `_dongu` iki
modulde ayri isler yapiyordu. Bir adin ne yaptigini anlamak icin once hangi
dosyada oldugunu bulmak gerekiyordu. Bu betik o durumun geri gelmesini
engeller -- kod yazilmadan ONCE ve her degisiklikten sonra kosar.

Kullanim:
    python3 tools/check_unique_names.py            # FONKSIYONLAR.txt'yi dogrula
    python3 tools/check_unique_names.py --kod      # ayrica gercek kodla karsilastir

Cikis kodu 0 = temiz, 1 = cakisma var.
"""
from __future__ import annotations

import argparse
import ast
import collections
import os
import re
import sys

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LISTE = os.path.join(KOK, "FONKSIYONLAR.txt")

# "app/web/router.py" gibi modul basligi
MODUL = re.compile(r"^(?P<yol>[A-Za-z0-9_./-]+\.(?:py|js))\s*$")
# "    send_json_response   JSON cevap (eski: js)" gibi ad satiri
AD = re.compile(r"^ {4}(?P<ad>[A-Za-z_][A-Za-z0-9_]*)\s{2,}(?P<gorev>\S.*)$")


def listeyi_oku(yol: str):
    """FONKSIYONLAR.txt -> [(ad, modul, gorev, satir_no)]"""
    kayit, modul = [], None
    with open(yol, encoding="utf-8") as f:
        for n, satir in enumerate(f, 1):
            satir = satir.rstrip("\n")
            if not satir.strip() or satir.lstrip().startswith("#"):
                continue
            m = MODUL.match(satir)
            if m:
                modul = m.group("yol")
                continue
            m = AD.match(satir)
            if m:
                if modul is None:
                    print(f"  satir {n}: modul basligi olmadan ad — {m.group('ad')}")
                    continue
                kayit.append((m.group("ad"), modul, m.group("gorev").strip(), n))
    return kayit


def cakismalari_bul(kayit):
    sayac = collections.defaultdict(list)
    for ad, modul, _gorev, n in kayit:
        sayac[ad].append((modul, n))
    return {ad: yer for ad, yer in sayac.items() if len(yer) > 1}


def js_adlari(kok: str) -> set:
    """JS modullerindeki DISA ACILAN (export) adlar.

    23.09.2026'da eklendi: o tarihe kadar denetim yalnizca Python'u
    kapsiyordu ve `pages/*.js` yazildikca liste ile kod sessizce
    ayrisiyordu (kullanici "fonksiyon listesine de dikkat et" dedi).
    """
    import re as _re
    adlar = set()
    desenler = [
        _re.compile(r"^export\s+(?:async\s+)?function\s+([A-Za-z_$][\w$]*)", _re.M),
        _re.compile(r"^export\s+(?:const|let|class)\s+([A-Za-z_$][\w$]*)", _re.M),
    ]
    # Export'u OLMAYAN modullerde (giris noktalari) ust duzey `function`
    # bildirimleri sayilir -- `gen_js_listesi.py` ile AYNI kural.
    # 23.09.2026 kapsam denetiminde bulundu: `giris.js` hicbir sey
    # disa acmadigi icin ne listede ne denetimde gorunuyordu.
    ust = _re.compile(r"^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)", _re.M)
    for d, _alt, dosyalar in os.walk(kok):
        for a in sorted(dosyalar):
            if not a.endswith(".js"):
                continue
            metin = open(os.path.join(d, a), encoding="utf-8").read()
            bulunan = set()
            for desen in desenler:
                bulunan |= set(desen.findall(metin))
            adlar |= bulunan or set(ust.findall(metin))
    return adlar


def kodla_karsilastir(kayit):
    """Gercek .py ve .js dosyalarindaki tanimlar listeyle ortusuyor mu?"""
    listedeki = {ad for ad, _m, _g, _n in kayit}
    koddaki, sabitler, eksik_dosya = set(), set(), []
    # main.py `app/` disinda; o da sozlesmeye dahil.
    taranacak = [os.path.join(KOK, "app")]
    kok_main = os.path.join(KOK, "main.py")
    for dizin, _alt, adlar in ([(KOK, [], ["main.py"])] if os.path.exists(kok_main) else []) \
            + [x for x in os.walk(os.path.join(KOK, "app"))]:
        if "__pycache__" in dizin:
            continue
        for a in sorted(adlar):
            if not a.endswith(".py"):
                continue
            t = os.path.join(dizin, a)
            try:
                agac = ast.parse(open(t, encoding="utf-8").read())
            except SyntaxError as e:
                eksik_dosya.append(f"{t}: {e}")
                continue
            # YALNIZCA sozlesmeye giren adlar toplanir:
            #   * modul duzeyindeki public def/class
            #   * PUBLIC siniflarin public metotlari
            # Ic ice fonksiyonlar, "_" ile baslayan yardimcilar ve private
            # siniflarin metotlari uygulama detayidir -- sozlesmeye girmezler.
            for d in agac.body:
                if isinstance(d, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if not d.name.startswith("_"):
                        koddaki.add(d.name)
                elif isinstance(d, ast.ClassDef):
                    if d.name.startswith("_"):
                        continue
                    koddaki.add(d.name)
                    for m in d.body:
                        if (isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef))
                                and not m.name.startswith("_")):
                            koddaki.add(m.name)
                elif isinstance(d, (ast.Assign, ast.AnnAssign)):
                    # SABITLER icin kural ASIMETRIKTIR:
                    #   * fonksiyon/sinif  -> listede OLMAK ZORUNDA
                    #   * sabit            -> listede olmak ZORUNDA DEGIL,
                    #     ama listeye yazildiysa kodda BULUNMALI
                    # (aksi halde `EPS`, `API`, `BASE_URL` gibi ic ayrinti
                    #  sabitler sozlesmeyi gurultuye bogar.)
                    hedefler = d.targets if isinstance(d, ast.Assign) else [d.target]
                    for h in hedefler:
                        if isinstance(h, ast.Name) and h.id.isupper():
                            sabitler.add(h.id)
    js_kok = os.path.join(KOK, "app", "web", "static", "js")
    if os.path.isdir(js_kok):
        koddaki |= js_adlari(js_kok)
    # Sabitler yalnizca LISTEDEYSE dogrulanir (bkz. yukaridaki asimetri).
    koddaki |= (sabitler & listedeki)
    return listedeki, koddaki, eksik_dosya


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kod", action="store_true",
                    help="gercek kodla da karsilastir (kod yazildiktan sonra)")
    a = ap.parse_args()

    if not os.path.exists(LISTE):
        print(f"HATA: {LISTE} yok"); return 1

    kayit = listeyi_oku(LISTE)
    print(f"FONKSIYONLAR.txt  ->  {len(kayit)} ad, "
          f"{len({m for _a, m, _g, _n in kayit})} modul\n")

    # --- modul basina dagilim ---
    per = collections.Counter(m for _a, m, _g, _n in kayit)
    katman = collections.Counter()
    for m, c in per.items():
        parca = m.split("/")
        katman["/".join(parca[:2]) if len(parca) > 2 else parca[0]] += c
    print("Katman basina:")
    for k, c in sorted(katman.items(), key=lambda x: -x[1]):
        print(f"  {k:28} {c:>4}")

    # --- asil sinama ---
    cak = cakismalari_bul(kayit)
    print()
    if cak:
        print(f"CAKISMA VAR — {len(cak)} ad birden fazla yerde:")
        for ad, yer in sorted(cak.items()):
            print(f"  {ad}")
            for modul, n in yer:
                print(f"      satir {n:>4}  {modul}")
        return 1
    print(f"BENZERSIZ: {len(kayit)} adin hepsi tek bir yerde tanimli.")

    # --- gorev aciklamasi bos kalmis mi ---
    bos = [ad for ad, _m, g, _n in kayit if len(g) < 5]
    if bos:
        print(f"\nUYARI: {len(bos)} adin gorev aciklamasi cok kisa: {', '.join(bos[:8])}")

    if a.kod:
        listedeki, koddaki, hatali = kodla_karsilastir(kayit)
        print("\nKod karsilastirmasi:")
        if hatali:
            print("  sozdizimi bozuk:", *hatali, sep="\n    ")
        yazilmamis = listedeki - koddaki
        listesiz = koddaki - listedeki
        print(f"  listede olup kodda yok : {len(yazilmamis)}")
        print(f"  kodda olup listede yok : {len(listesiz)}")
        if listesiz:
            print("  ONCE LISTEYE EKLE:", ", ".join(sorted(listesiz)[:15]))
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
