# -*- coding: utf-8 -*-
"""Borsada kapanmis emir + mukerrer takibe-alma sinamasi (06.10.2026, §7.51).

YALITILMIS: gecici veri klasoru, Binance cagrilari sahte. Gercek deftere
DOKUNMAZ -- NEWTRADE_DATA_DIR import'tan ONCE gecici klasore sabitlenir.
Kullanim: python3 tools/emir_temizlik_sinama.py
"""
import json, os, sys, tempfile, threading, time

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VERI = tempfile.mkdtemp(prefix="cn_emir_sinama_")
os.environ["NEWTRADE_DATA_DIR"] = VERI
sys.path.insert(0, KOK)

from app.config import paths  # noqa: E402
assert os.path.abspath(paths.get_app_root()) == os.path.abspath(VERI), paths.get_app_root()

from app.core.errors import ExchangeError  # noqa: E402
from app.exchange import binance_rest as REST  # noqa: E402
from app.trading import ledger as LD, order_service as OS, reconcile as RC  # noqa: E402

simdi = int(time.time() * 1000)
eski = simdi - 20 * 60000          # 20 dk once -> zaman asimini gecmis


def emir(i, sembol, durum, borsa_id=None, borsa_durum=None, dolan=0.0, ts=eski, dugme="AL"):
    return {"id": i, "sembol": sembol, "taraf": "BUY", "dugme": dugme, "fiyat": 1.0,
            "miktar": 10.0, "tutar": 10.0, "ts": ts, "durum": durum, "borsa_id": borsa_id,
            "borsa_durum": borsa_durum, "dolan_miktar": dolan, "dolan_fiyat": 1.0 if dolan else None,
            "dolum_ts": ts if dolan else None, "kapanis": None, "kar": None, "canli": True}


defter = {"emirler": [
    emir(1, "BANDUSDT", "ACIK", 111, "NEW"),                       # borsada CANCELED -> IPTAL
    emir(2, "AAAUSDT", "ACIK", 222, "NEW", ts=simdi),              # borsada NEW, yeni -> ACIK kalir
    emir(3, "BBBUSDT", "ACIK", 333, "NEW"),                        # borsada EXPIRED, 4 dolmus -> DOLDU
    emir(4, "CCCUSDT", "ACIK", 444, "NEW"),                        # borsa -2013 -> IPTAL
    emir(5, "RLCUSDT", "DOLDU", None, "ADOPTED", 31.2, eski, "UZLASTIRMA"),
    emir(6, "RLCUSDT", "DOLDU", None, "ADOPTED", 31.2, eski + 5, "UZLASTIRMA"),  # mukerrer -> IPTAL
    emir(7, "DDDUSDT", "DOLDU", 777, "FILLED", 10.0),              # tek kayit, borsada var -> kalir
    emir(8, "EEEUSDT", "DOLDU", 888, "FILLED", 10.0),              # AL ile alinmis
    emir(9, "EEEUSDT", "DOLDU", None, "ADOPTED", 10.0, eski + 9, "UZLASTIRMA"),  # borsada 20 -> ikisi de kalir
], "sira": 10}
json.dump(defter, open(os.path.join(VERI, "defter_canli.json"), "w"))
json.dump({"emirler": [], "sira": 1}, open(os.path.join(VERI, "defter_dry.json"), "w"))

BORSA = {111: {"status": "CANCELED", "executedQty": "0", "cummulativeQuoteQty": "0", "orderId": 111},
         222: {"status": "NEW", "executedQty": "0", "cummulativeQuoteQty": "0", "orderId": 222},
         333: {"status": "EXPIRED", "executedQty": "4", "cummulativeQuoteQty": "4", "orderId": 333}}
iptal_cagrisi = []


def sahte_durum(sembol, oid):
    if oid == 444:
        raise ExchangeError("Order does not exist.", code=-2013)
    return BORSA[oid]


def sahte_iptal(sembol, oid):
    iptal_cagrisi.append(oid)
    raise ExchangeError("Unknown order sent.", code=-2011)


REST.fetch_order_status = sahte_durum
REST.cancel_order = sahte_iptal
OS.REST = REST

hata = []
def bekle(kosul, mesaj):
    print(("TAMAM " if kosul else "HATA  ") + mesaj)
    if not kosul:
        hata.append(mesaj)

# 1) emir durumlari
s = OS.refresh_order_statuses(True, timeout_minutes=6)
byid = {e["id"]: e for e in LD.load_ledger(True)["emirler"]}
bekle(byid[1]["durum"] == "IPTAL" and byid[1]["borsa_durum"] == "CANCELED", "BAND borsada CANCELED -> IPTAL")
bekle(byid[2]["durum"] == "ACIK", "borsada NEW + zaman asimi dolmamis -> ACIK kalir")
bekle(byid[3]["durum"] == "DOLDU" and byid[3]["dolan_miktar"] == 4.0, "EXPIRED + 4 dolmus -> DOLDU (4)")
bekle(byid[4]["durum"] == "IPTAL" and byid[4]["borsa_durum"] == "BORSADA_YOK", "-2013 -> IPTAL (BORSADA_YOK)")
bekle(iptal_cagrisi == [], f"borsada kapali emre iptal istegi GITMEDI ({iptal_cagrisi})")
s2 = OS.refresh_order_statuses(True, timeout_minutes=6)
bekle(s2["guncellenen"] == 0, "ikinci tur: yapilacak is yok (tekrar etmiyor)")

# 2) mukerrer takip
RC.fetch_account_balances = lambda: {"balances": [
    {"asset": "RLC", "free": "31.2", "locked": "0"}, {"asset": "DDD", "free": "10", "locked": "0"},
    {"asset": "EEE", "free": "20", "locked": "0"}, {"asset": "BBB", "free": "4", "locked": "0"}]}
RC.adopt_untracked_holdings = lambda live, elde, prices=None: []
r = RC.reconcile_positions(True, prices={})
byid = {e["id"]: e for e in LD.load_ledger(True)["emirler"]}
bekle(byid[5]["durum"] == "DOLDU", "RLC en eski kayit (5) kalir")
bekle(byid[6]["durum"] == "IPTAL" and byid[6]["borsa_durum"] == "MUKERRER" and not byid[6].get("kapanis"),
      "RLC mukerrer (6) -> IPTAL, kar/zarar yazilmadi")
bekle(byid[7]["durum"] == "DOLDU", "tek kayitli coin (DDD) kalir")
bekle(byid[8]["durum"] == "DOLDU" and byid[9]["durum"] == "DOLDU", "EEE: AL 10 + takip 10, borsada 20 -> ikisi de kalir")
r2 = RC.reconcile_positions(True, prices={})
bekle(r2["mukerrer_iptal"] == [], "ikinci tur: mukerrer yok")

# 3) es zamanli takibe alma: iki is parcacigi ayni anda -> TEK kayit
import importlib
RC2 = importlib.reload(RC)
import app.market.price_source as PS, app.exchange.symbol_rules as SR, app.market.rank_repository as RR
PS.get_prices = lambda ss: {x: (2.0, "sahte") for x in ss}
SR.get_symbol_filters = lambda s: {"tick": 0.0001, "step": 0.1}
RR.capture_market_snapshot = lambda s: (time.sleep(0.2), {"fiyat": 2.0})[1]
engel = threading.Barrier(2)
def kos():
    engel.wait()
    RC2.adopt_untracked_holdings(True, {"ZZZUSDT": 50.0}, {"ZZZUSDT": (2.0, "sahte")})
ip = [threading.Thread(target=kos) for _ in range(2)]
[t.start() for t in ip]; [t.join() for t in ip]
zzz = [e for e in LD.load_ledger(True)["emirler"] if e["sembol"] == "ZZZUSDT" and e["durum"] == "DOLDU"]
bekle(len(zzz) == 1, f"es zamanli iki takibe-alma -> 1 kayit (bulunan {len(zzz)})")

print("\nveri klasoru:", VERI)
print("SONUC:", "HATA %d" % len(hata) if hata else "HEPSI TAMAM")
sys.exit(1 if hata else 0)
