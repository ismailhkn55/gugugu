# -*- coding: utf-8 -*-
"""Piyasa/akis alanlari sinamasi (DOKUMANTASYON 7.59). Salt okunur, dis istek YOK."""
import bisect, json, os, statistics as S, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/_cn_sunucu_testi")
from app.config.paths import get_heatmap_state_path
from app.market import rank_repository as RR
from app.market.exclusions import load_excluded_symbols
from app.market.indicators import is_known_field
from app.strategy.backtest import is_rule_testable

hata = 0
def kontrol(ad, k, a=""):
    global hata
    print(("TAMAM " if k else "HATA  ") + ad + (f"  [{a}]" if a else "")); hata += 0 if k else 1

YENI = ("kirmizi_pct", "total3_24", "usdt_hacim_d", "akis_coin", "gun_arti_sayi", "gun_iki_ustu_sayi")
for f in YENI:
    kontrol(f"{f}: kayit defterinde", is_known_field(f))
    kontrol(f"{f}: mum geriye-testinde sinanamaz olarak isaretli", not is_rule_testable({"alan": f, "op": ">", "deger": 0})[0])

d = RR.fetch_latest_snapshot(limit=400, cache_sn=0)
r0 = d["satir"][0]
kontrol("son tur: alanlar dolu", all(r0.get(f) is not None for f in RR.PIYASA_ALANLARI),
        {f: r0.get(f) for f in RR.PIYASA_ALANLARI})
kontrol("her satirda ayni piyasa degeri", all(all(r.get(f) == r0.get(f) for f in RR.PIYASA_ALANLARI) for r in d["satir"]))
kontrol("akis_coin = (usdt_hacim_d < -1 VE genislik >= 55)",
        r0["akis_coin"] == int(r0["usdt_hacim_d"] < -1 and r0["genislik"] >= 55))
gp = [r["gun_pct"] for r in d["satir"] if r.get("gun_pct") is not None]
kontrol("gun_arti_sayi = elle sayim", r0["gun_arti_sayi"] == sum(1 for g in gp if g > 0), (r0["gun_arti_sayi"], sum(1 for g in gp if g > 0)))
kontrol("gun_iki_ustu_sayi = elle sayim", r0["gun_iki_ustu_sayi"] == sum(1 for g in gp if g > 2), (r0["gun_iki_ustu_sayi"], sum(1 for g in gp if g > 2)))
kontrol("yesil + kirmizi <= 100", r0["genislik"] + r0["kirmizi_pct"] <= 100.0001)
cap = RR.capture_market_snapshot(d["satir"][3]["sembol"])
kontrol("giris/cikis kaydi (capture_market_snapshot) = botun gordugu tur",
        all(abs((cap.get(f) or 0) - (r0.get(f) or 0)) < 1e-9 for f in RR.PIYASA_ALANLARI),
        {f: (cap.get(f), r0.get(f)) for f in RR.PIYASA_ALANLARI})

# gecmis: son 7 gun tur tur
haric = load_excluded_symbols()
with RR.open_rank_db_readonly() as c:
    son = c.execute("SELECT max(ts) FROM anlik").fetchone()[0]
    turlar = RR.list_rounds_with_trail(c, son - 7 * 86_400_000, son)
    seri = []
    for ts, iz in turlar:
        s = RR.build_round_snapshot(c, ts, iz, haric)
        if s and s[0].get("usdt_hacim_d") is not None:
            seri.append((ts, s[0]["usdt_hacim_d"], s[0]["genislik"], s[0]["akis_coin"]))
    dl = [x[1] for x in seri]
    print(f"7 gun: {len(seri)} tur, usdt_hacim_d medyan {S.median(dl):+.3f}% p05 {sorted(dl)[len(dl)//20]:+.3f} p95 {sorted(dl)[-len(dl)//20]:+.3f}")
    print(f"  usdt_hacim_d < -1: {sum(x < -1 for x in dl)} tur, genislik>=55: {sum(x[2] >= 55 for x in seri)} tur, akis_coin=1: {sum(x[3] == 1 for x in seri)} tur")
    # heatmap (Binance tum USDT) ile ayni araliklarda yon uyumu
    hm = (json.load(open(get_heatmap_state_path())) or {}).get("gecmis") or []
    tl = [x[0] for x in seri]
    uy, n, ciftler = 0, 0, []
    for a, b in zip(hm, hm[1:]):
        ia, ib = bisect.bisect_right(tl, a["ts"]) - 1, bisect.bisect_right(tl, b["ts"]) - 1
        if ia < 0 or ib <= ia or not a.get("usdt_hacim") or not b.get("usdt_hacim"):
            continue
        hd = (b["usdt_hacim"] / a["usdt_hacim"] - 1) * 100
        bizim = 1.0
        for _, x, _, _ in seri[ia + 1:ib + 1]:
            bizim *= 1 + x / 100
        bd = (bizim - 1) * 100
        ciftler.append((hd, bd)); n += 1; uy += (hd > 0) == (bd > 0)
    if n:
        print(f"  heatmap (Binance TUM USDT) ile {n} aralikta yon uyumu {uy}/{n}; ornek (heatmap, bizim): {[(round(h,2), round(b,2)) for h, b in ciftler[:6]]}")
print("SONUC:", "TAMAM" if not hata else f"{hata} HATA"); sys.exit(1 if hata else 0)
