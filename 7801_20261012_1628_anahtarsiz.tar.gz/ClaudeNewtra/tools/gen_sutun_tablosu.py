#!/usr/bin/env python3
"""DOKUMANTASYON.md'deki sutun tablosunu COLUMN_REGISTRY'den URETIR.
Elle yazilmaz -- kayit defteri degisince yeniden kosulur.
Kullanim: python3 tools/gen_sutun_tablosu.py
"""
import os, sys
KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, KOK)
from app.market.indicators import COLUMN_REGISTRY, COLOR_SOURCE

BAS = "<!-- SUTUN-TABLOSU-BASLANGIC -->"
SON = "<!-- SUTUN-TABLOSU-SON -->"

s = [BAS, "", f"**{len([c for c in COLUMN_REGISTRY if not c.derived])} sutun** "
     f"veritabanindan secilir, **{len([c for c in COLUMN_REGISTRY if c.derived])}** "
     f"calisma aninda turetilir, **{len(COLOR_SOURCE)}** renk alani yuzdelerden hesaplanir.",
     "", "| # | Sutun | Tip | Anlam | Ureten |", "|---|---|---|---|---|"]
for i, c in enumerate(COLUMN_REGISTRY, 1):
    tip = {float: "REAL", int: "INT", str: "TEXT", list: "liste"}.get(c.kind, str(c.kind))
    ad = f"`{c.name}`" + (" *(turetilmis)*" if c.derived else "")
    s.append(f"| {i} | {ad} | {tip} | {c.meaning} | `{c.producer}` |")
s += ["", "**Renk alanlari** (yuzdeden turetilir, veritabaninda yok): "
      + ", ".join(f"`{k}`" for k in sorted(COLOR_SOURCE)), "", SON]
tablo = "\n".join(s)

yol = os.path.join(KOK, "DOKUMANTASYON.md")
m = open(yol, encoding="utf-8").read()
if BAS in m and SON in m:
    m = m[:m.index(BAS)] + tablo + m[m.index(SON) + len(SON):]
else:
    capa = ("Tam sütun tablosu (ad, tip, anlam, üreten fonksiyon) Faz 1'de buraya\n"
            "girecek; kaynağı `app/market/indicators.py` içindeki `COLUMN_REGISTRY`.")
    if capa not in m:
        print("capa bulunamadi"); sys.exit(1)
    m = m.replace(capa, tablo)
open(yol, "w", encoding="utf-8").write(m)
print(f"DOKUMANTASYON.md: {len(COLUMN_REGISTRY)} sutunluk tablo uretildi")
