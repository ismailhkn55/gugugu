# -*- coding: utf-8 -*-
"""Uzlastirma gerileme testi: BEKLEYEN emir pozisyon sayilmamali.

23.09.2026'da yasanan olay: dolmamis bir LIMIT alis emri borsada ACIK
beklerken uzlastirma onu "ELLE_SATILDI" diye kapatti ve uydurma kar/zarar
yazdi. Bu test o durumu yeniden kurar.

IZOLE calisir: gecici bir veri dizini kullanir, gercek deftere DOKUNMAZ.
"""
import json, os, shutil, sys, tempfile

kok = tempfile.mkdtemp(prefix="uzlastirma_testi_")
os.environ["NEWTRADE_DATA_DIR"] = kok
os.environ["NEWTRADE_RANK_DIR"] = os.path.join(kok, "rank")
os.makedirs(os.environ["NEWTRADE_RANK_DIR"], exist_ok=True)
sys.path.insert(0, "/DATA/AppData/ClaudeNewtra")

from app.trading.reconcile import detect_manual_sells

defter = {
    "sira": 3,
    "emirler": [
        # 1) BEKLEYEN limit emri -- borsada karsiligi YOK, ama pozisyon DEGIL
        {"id": 1, "sembol": "AAAUSDT", "taraf": "BUY", "durum": "ACIK",
         "fiyat": 0.05, "miktar": 100.0, "tutar": 5.0, "dolan_miktar": 0.0,
         "borsa_durum": "NEW", "kapanis": None, "canli": True, "ts": 1},
        # 2) DOLMUS pozisyon, borsada duruyor -> uzlastirmaya girmemeli
        {"id": 2, "sembol": "BBBUSDT", "taraf": "BUY", "durum": "DOLDU",
         "fiyat": 1.0, "miktar": 10.0, "tutar": 10.0, "dolan_miktar": 10.0,
         "borsa_durum": "FILLED", "kapanis": None, "canli": True, "ts": 2},
        # 3) DOLMUS pozisyon, borsada YOK -> GERCEKTEN elle satilmis
        {"id": 3, "sembol": "CCCUSDT", "taraf": "BUY", "durum": "DOLDU",
         "fiyat": 2.0, "miktar": 5.0, "tutar": 10.0, "dolan_miktar": 5.0,
         "borsa_durum": "FILLED", "kapanis": None, "canli": True, "ts": 3},
    ],
}
yol = os.path.join(kok, "defter_canli.json")
json.dump(defter, open(yol, "w", encoding="utf-8"))

elde = {"BBBUSDT": 10.0}          # yalnizca 2 numara borsada duruyor
bulunan = detect_manual_sells(True, elde)
idler = sorted(x["id"] for x in bulunan)

print("uzlastirmaya giren id'ler:", idler)
basarili = idler == [3]
print("BEKLENEN: [3]  (yalnizca gercekten satilmis DOLMUS pozisyon)")
print("SONUC:", "GECTI" if basarili else "KALDI")
if 1 in idler:
    print("  HATA: bekleyen limit emri (id=1) pozisyon sayildi!")
shutil.rmtree(kok, ignore_errors=True)
sys.exit(0 if basarili else 1)
