// Canli son-mum EMA guncellemesi == tam yeniden hesap mi? (ORCAUSDT 5m gercek veri)
import fs from "fs";
import { ema } from "/DATA/AppData/ClaudeNewtra/app/web/static/js/chart/indicators.js";
const k = JSON.parse(fs.readFileSync(process.argv[2])).map((x) => +x[4]);
let hata = 0, en = 0;
for (const n of [7, 20, 48, 99]) {
  const taban = k.slice(0, -1);                       // son mum henuz yok
  let e = ema(taban, n); let onceki = e.at(-1), son = e.at(-1);
  // yeni mum acilir: onceki = son; birkac tik
  onceki = son;
  for (const fiyat of [k.at(-1) * 0.99, k.at(-1) * 1.01, k.at(-1)]) {
    son = onceki + (2 / (n + 1)) * (fiyat - onceki);
  }
  const dogru = ema(k, n).at(-1);
  const fark = Math.abs(son / dogru - 1); en = Math.max(en, fark);
  if (fark > 1e-12) { hata++; console.log("HATA n=" + n, son, dogru); }
}
console.log("4 donem, en buyuk fark", en.toExponential(2), hata ? "HATA" : "TAMAM");
