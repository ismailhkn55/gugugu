# -*- coding: utf-8 -*-
"""Stratejinin GECMIS turlarda hangi coinleri secerdi -- canli botla AYNI yol.

10.10.2026, Ismail: "strategy ne diyorsa ona gore secmeli". `/yerel/gecmis-sinyal`
mumlardan yeniden kurdugu icin genislik / rank_hacim / izas kurallarini SINAYAMIYOR.
Oysa rank.sqlite `anlik` tablosu her 5 dk turunda tum coinlerin satirini sakliyor:
canli bot da (`bot/trade_loop.try_strategy_entry`) tam bu satirlari okuyor.

Bu arac her gecmis tur icin `fetch_latest_snapshot(limit=400)`'u O TURDA calismis
gibi kurar (`rank_repository.build_round_snapshot`; `/yerel/strateji-turlari` ile ayni) ve `select_candidates` ile aktif stratejiyi uygular.
Salt okunur: rank.sqlite `mode=ro`, hicbir dosyaya yazmaz (yalniz --cikti).

Sinirlar: haric listesi ve strateji BUGUNKU halleriyle uygulanir (gecmiste farkli
olabilir); botun ek elemeleri (acik pozisyon, coin bekleme, maks pozisyon) yok --
bu "strateji bu turda bu coini secerdi" listesidir.

Kullanim:
    python3 tools/strateji_gecmis.py --bas 2026-09-25 --bit 2026-10-10 --cikti /tmp/x.json
"""
import argparse, json, os, sys, time
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("NEWTRADE_DATA_DIR", "/DATA/AppData/_cn_sunucu_testi")

from app.market.exclusions import load_excluded_symbols
from app.market.rank_repository import (build_round_snapshot, list_rounds_with_trail,
                                        open_rank_db_readonly)
from app.strategy.entry import select_candidates
from app.strategy.registry import get_active_strategy


def gun_ms(s, son=False):
    t = datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp() * 1000
    return int(t + (86_400_000 - 1 if son else 0))


def strateji_gecmisi(bas_ms, bit_ms, strateji=None, semboller=None):
    st = strateji or get_active_strategy(live=False)
    haric = load_excluded_symbols()
    istenen = set(semboller) if semboller else None
    sinyal = []
    with open_rank_db_readonly() as c:
        for son, turlar in list_rounds_with_trail(c, bas_ms, bit_ms):
            satir = build_round_snapshot(c, son, turlar, haric)
            s = select_candidates(satir, st, limit=10_000)
            for x in s["aday"]:
                if istenen is None or x["sembol"] in istenen:
                    sinyal.append({"ts": son, "sembol": x["sembol"], "fiyat": x.get("fiyat"),
                                   "hiz": x.get("hiz"), "izas": x.get("izas"),
                                   "genislik": x.get("genislik")})
    return {"strateji": st.get("ad"), "guncelleme": st.get("guncelleme"),
            "kurallar": [f'{k.get("alan")} {k.get("op")} {k.get("deger", "")}'.strip()
                         for k in st.get("kurallar") or [] if k.get("aktif", True)],
            "haric_sayisi": len(haric), "sinyal": sinyal}


if __name__ == "__main__":
    a = argparse.ArgumentParser()
    a.add_argument("--bas", required=True)
    a.add_argument("--bit", required=True)
    a.add_argument("--cikti", required=True)
    o = a.parse_args()
    t0 = time.time()
    d = strateji_gecmisi(gun_ms(o.bas), gun_ms(o.bit, son=True))
    d["sure_sn"] = round(time.time() - t0, 1)
    with open(o.cikti, "w") as f:
        json.dump(d, f, ensure_ascii=False)
    print(f'{d["strateji"]}: {len(d["sinyal"])} sinyal, {d["sure_sn"]} sn -> {o.cikti}')
