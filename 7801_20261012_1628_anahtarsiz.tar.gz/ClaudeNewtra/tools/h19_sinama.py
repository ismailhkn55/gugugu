# -*- coding: utf-8 -*-
"""H19 (Trendline Confluence) sinamasi (12.10.2026, DOKUMANTASYON 7.61).

1) Esdeger testi: rank/gostergeler.h19_tl_giris_serisi (rank servisinin
   KULLANDIGI kod) ile ClaudeNewtra/app/market/indicators.
   compute_h19_tl_giris_serisi (ClaudeNewtra'nin KULLANDIGI kod) AYNI OHLC
   ile BIREBIR AYNI sonucu veriyor mu -- iki servis ayri dosya/venv oldugu
   icin modul paylasilamaz, kod kopyalanir; bu test ayrismayi yakalar.
2) Onay geciktirme: compute_h19_tl_giris() dizinin SONUNDAN n_swing bar
   GERIYE bakarak okuyor mu (repaint testi) -- son n_swing bar HENUZ
   kesinlesmemis bir swing-low icerse bile ONA GORE sinyal URETMEMELI.
3) is_known_field("h19_tl_giris") True, backtest.UNTESTABLE_FIELDS'TA YOK
   (tek sembolun kendi mumundan kurulabiliyor -- h23 ile ayni durum).
4) exit_rules.plan_for_source + targets.resolve_profit_target/
   resolve_stop_price'i DOGRUDAN cagirip h19_trendline stratejisinin
   GERCEKTEN +%1.2 hedef / -%6 stop urettigini dogrular (kod OKUYARAK degil,
   CALISTIRARAK).
5) validate_strategy ile h19_trendline kuralinin "bilinmeyen alan" HATASI
   vermedigini dogrular (save_strategy'nin UnknownFieldError'u).

Kullanim: python3 tools/h19_sinama.py
YALITILMIS: NEWTRADE_DATA_DIR izole bir /tmp dizinine ayarlanir (gercek
deftere/strateji dosyasina DOKUNULMAZ, proje kurali -- bkz.
feedback_7801_calisma_kurallari #2).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("NEWTRADE_DATA_DIR", "/tmp/h19_sinama_bos")
sys.path.insert(0, "/DATA/AppData/rank")

hata = []


def bekle(k, m):
    print(("TAMAM " if k else "HATA  ") + m)
    if not k:
        hata.append(m)


# ---------------------------------------------------------------- 1) esdeger
import gostergeler as RANK_G  # noqa: E402
from app.market import indicators as IND  # noqa: E402


def sentetik_ohlc(seed, n=400):
    import random
    rnd = random.Random(seed)
    close = [100.0]
    for _ in range(n - 1):
        close.append(close[-1] * (1 + rnd.gauss(0, 0.004)))
    high = [c * (1 + abs(rnd.gauss(0, 0.002))) for c in close]
    low = [c * (1 - abs(rnd.gauss(0, 0.002))) for c in close]
    return high, low, close


toplam_fark = 0
toplam_bar = 0
for seed in range(10):
    h, l, c = sentetik_ohlc(seed)
    rank_seri = RANK_G.h19_tl_giris_serisi(h, l, c)
    cn_seri = IND.compute_h19_tl_giris_serisi(h, l, c)
    fark = sum(1 for a, b in zip(rank_seri, cn_seri) if bool(a) != bool(b))
    toplam_fark += fark
    toplam_bar += len(rank_seri)
bekle(toplam_fark == 0,
      f"rank/gostergeler.h19_tl_giris_serisi == indicators.compute_h19_tl_giris_serisi "
      f"(10 sentetik seri, {toplam_bar} bar, fark={toplam_fark})")

# h19_tl_giris (0/1/None) sarmalayicisi da ayni mi (gostergeler Binance kline
# listesi alir, indicators ayri dizi alir -- girdi farkli sarilmis, cikti AYNI
# olmali).
h, l, c = sentetik_ohlc(99)
mumlar = [[i, 0, h[i], l[i], c[i], 0] for i in range(len(c))]
rank_tek = RANK_G.h19_tl_giris(mumlar)
cn_tek = IND.compute_h19_tl_giris(h, l, c)
bekle(rank_tek == cn_tek, f"h19_tl_giris() sarmalayicilari ayni deger (rank={rank_tek}, cn={cn_tek})")


# ---------------------------------------------------------- 2) onay geciktirme
# Elle kurulmus bir seri: SON n_swing(=5) bar icinde bir swing-low OLABILIR
# ama henuz n_swing bar sonrasi gelmedigi icin KESINLESEMEZ -- fonksiyon bu
# barlari (indeks n-5..n-1) HICBIR ZAMAN "su anki" sinyal olarak okumamali;
# okunan index HER ZAMAN len-1-n_swing olmalidir.
h, l, c = sentetik_ohlc(7, n=200)
seri_tam = IND.compute_h19_tl_giris_serisi(h, l, c)
n = len(c)
# serinin SON 5 elemaninda sl[] fraktal tanimla KESINLIKLE hesaplanamaz
# (gelecek bar yok) -- bu da long_giris'in o indekslerde hep False olmasini
# garanti eder (REPAINT riski yok).
son5_hep_false = all(not seri_tam[i] for i in range(n - 5, n))
bekle(son5_hep_false, "son n_swing(=5) barda long_giris HICBIR ZAMAN True degil (repaint yok)")
deger = IND.compute_h19_tl_giris(h, l, c)
beklenen = 1 if seri_tam[n - 1 - 5] else 0
bekle(deger == beklenen, f"compute_h19_tl_giris() index len-1-n_swing'i okuyor ({deger}=={beklenen})")


# -------------------------------------------------- 3) alan bilgisi + backtest
from app.strategy.backtest import UNTESTABLE_FIELDS  # noqa: E402

bekle(IND.is_known_field("h19_tl_giris"), "is_known_field('h19_tl_giris') == True")
bekle("h19_tl_giris" not in UNTESTABLE_FIELDS,
      "h19_tl_giris UNTESTABLE_FIELDS icinde DEGIL (tek sembolden kurulabiliyor)")


# --------------------------------------------------------------- 4) cikis/stop
from app.trading.exit_rules import plan_for_source  # noqa: E402
from app.strategy.targets import resolve_profit_target, resolve_stop_price  # noqa: E402

AYAR = {"bot_cikis_stop": 7.0, "bot_cikis_esik": 5.0, "bot_cikis_mesafe": 1.4,
        "bot_cikis_merdiven_esik": 1.8, "bot_cikis_merdiven_kilit": 0.8,
        "bot_cikis_ivme_acik": True, "bot_cikis_ivme_carpan": 3.0,
        "bot_cikis_ivme_esik": 1.0, "bot_cikis_ivme_hacim": 3.0}
STRATEJI_H19 = {"ad": "h19_trendline",
                "kurallar": [{"alan": "h19_tl_giris", "op": "==", "deger": 1, "aktif": True}],
                "cikis": {"hedef_yavas": 1.2, "hedef_normal": 1.2},
                "stop": {"baslangic": 6}}
plan = plan_for_source(None, AYAR, strategy=STRATEJI_H19)
hedef = resolve_profit_target(0.0, plan["cikis"])  # hiz=0 -> normal dal
bekle(hedef.kind == "sabit" and float(hedef.target) == 1.2,
      f"resolve_profit_target -> sabit +%1.2 hedef (kind={hedef.kind}, target={hedef.target})")
entry = 100.0
stop = resolve_stop_price(entry, entry, plan["stop"])  # henuz kar yok -> baslangic stop
bekle(abs(stop.percent - (-6.0)) < 1e-9,
      f"resolve_stop_price -> baslangic -%6 stop (percent={stop.percent})")
bekle(str(STRATEJI_H19.get("cikis_yontemi") or "") == "",
      "cikis_yontemi BOS -- AL butonunun planini MIRAS ALMIYOR")


# --------------------------------------------------------------- 5) kayit testi
from app.strategy.registry import validate_strategy  # noqa: E402

sorunlar = validate_strategy(STRATEJI_H19)
bekle(not sorunlar, f"validate_strategy(h19_trendline) temiz (sorunlar={sorunlar})")

print()
if hata:
    print(f"TOPLAM {len(hata)} HATA:")
    for h_ in hata:
        print("  -", h_)
    sys.exit(1)
print("TUM H19 SINAMALARI TAMAM.")
