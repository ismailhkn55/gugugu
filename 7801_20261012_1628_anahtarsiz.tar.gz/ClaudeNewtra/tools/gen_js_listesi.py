#!/usr/bin/env python3
"""FONKSIYONLAR.txt'nin JAVASCRIPT bolumunu GERCEK KODDAN uretir.

Neden: JS bolumunu kod yazilmadan once elle yazmistim; gerceklestirme
farkli gelisince liste ile kod sessizce ayristi (59 ad kodda vardi,
listede yoktu). Artik uretiliyor -- `gen_eslestirme.py` ve
`gen_sutun_tablosu.py` ile ayni mantik.

Aciklama olarak her `export`un USTUNDEKI yorum satiri kullanilir; yoksa
bos birakilir ve `check_unique_names.py` "gorev aciklamasi cok kisa"
diye uyarir.
"""
import os
import re
import sys

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JS_KOK = os.path.join(KOK, "app", "web", "static", "js")
LISTE = os.path.join(KOK, "FONKSIYONLAR.txt")
BAS = "# ============================================================================\n# ClaudeNewtra — FONKSIYON ADLARI  (BÖLÜM 2/2: JavaScript / arayüz)"

EXPORT = re.compile(
    r"^export\s+(?:async\s+)?(?:function|const|let|class)\s+([A-Za-z_$][\w$]*)", re.M)


# Export'u olmayan modullerde (giris noktalari) ust duzey `function`
# bildirimlerini yakalar -- aksi halde `giris.js` gibi dosyalar listede
# HIC gorunmuyordu (23.09.2026 kapsam denetiminde bulundu).
UST_FONKSIYON = re.compile(r"^(?:async\s+)?function\s+([A-Za-z0-9_$]+)")


def dosya_adlari(yol: str):
    """[(ad, aciklama)] -- aciklama, export'un ustundeki yorum satiri."""
    satirlar = open(yol, encoding="utf-8").read().split("\n")
    cikti = []
    desen = EXPORT
    if not any(EXPORT.match(x) for x in satirlar):
        desen = UST_FONKSIYON          # export yok: giris noktasi modulu
    for i, s in enumerate(satirlar):
        m = desen.match(s)
        if not m:
            continue
        acik = ""
        for j in range(i - 1, max(-1, i - 6), -1):
            t = satirlar[j].strip()
            if t.startswith("//"):
                acik = t.lstrip("/ ").strip()
                break
            if t and not t.startswith("*") and not t.startswith("/*"):
                break
        cikti.append((m.group(1), acik))
    return cikti


def main() -> int:
    bolumler = []
    for d, alt, dosyalar in sorted(os.walk(JS_KOK)):
        alt.sort()
        for a in sorted(dosyalar):
            if not a.endswith(".js"):
                continue
            tam = os.path.join(d, a)
            goreli = "static/js/" + os.path.relpath(tam, JS_KOK).replace(os.sep, "/")
            adlar = dosya_adlari(tam)
            if not adlar:
                continue
            satir = [goreli]
            for ad, acik in adlar:
                satir.append(f"    {ad:<31} {acik or '(aciklama yok)'}")
            bolumler.append("\n".join(satir))

    toplam = sum(s.count("\n    ") + s.count("\n") - s.count("\n\n") for s in [])
    govde = (BAS + "\n#\n"
             "# BU BOLUM KODDAN URETILIR -- elle duzenleme:\n"
             "#   python3 tools/gen_js_listesi.py\n"
             "# Aciklama, her `export`un USTUNDEKI yorum satirindan alinir.\n"
             "# ============================================================================\n\n\n"
             + "\n\n".join(bolumler) + "\n")

    metin = open(LISTE, encoding="utf-8").read()
    i = metin.find(BAS)
    if i < 0:
        print("HATA: JS bolumu basligi bulunamadi"); return 1
    open(LISTE, "w", encoding="utf-8").write(metin[:i] + govde)
    n = sum(len(dosya_adlari(os.path.join(d, a)))
            for d, _x, fs in os.walk(JS_KOK) for a in fs if a.endswith(".js"))
    print(f"FONKSIYONLAR.txt JS bolumu uretildi: {n} ad, {len(bolumler)} modul")
    return 0


if __name__ == "__main__":
    sys.exit(main())
