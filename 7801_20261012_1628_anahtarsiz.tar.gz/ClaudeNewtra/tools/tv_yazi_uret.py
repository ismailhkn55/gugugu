"""TV MODU yazi boyutu ureticisi (03.10.2026, Ismail: "temaya TV modu ekle, onda yazilar
MINIMUM 14px olsun, YALNIZCA TV modunda buyusun").

css/*.css icindeki her `font-size: Npx` (N < 14) kuralinin secicisi icin
`html[data-cihaz="tv"] <secici> { font-size: 14px }` uretir -> css/99-tv-mod.css.
index.html'deki satir ici kucuk yazilar icin [style*=...] kurali ekler.
Telefon/PC'de (data-cihaz bos) HICBIR SEY degismez. CSS degisince yeniden calistir:
    python3 tools/tv_yazi_uret.py"""
import glob, os, re

KOK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "web", "static")
CIKTI = os.path.join(KOK, "css", "99-tv-mod.css")
ESIK = 14.0
TV = 'html[data-cihaz="tv"]'


def kurallar(metin):
    """(secici, govde) ciftleri; @media/@supports icleri de acilir, @font-face/@keyframes atlanir."""
    metin = re.sub(r"/\*.*?\*/", "", metin, flags=re.S)
    i, n = 0, len(metin)
    while i < n:
        a = metin.find("{", i)
        if a < 0:
            return
        bas = metin[i:a].strip()
        d, j = 1, a + 1
        while j < n and d:
            d += {"{": 1, "}": -1}.get(metin[j], 0)
            j += 1
        govde = metin[a + 1:j - 1]
        if bas.startswith(("@media", "@supports")):
            yield from kurallar(govde)
        elif not bas.startswith("@"):
            yield bas, govde
        i = j


def tv_secici(s):
    s = s.strip()
    if s.startswith("html"):
        return TV + s[4:]
    if s.startswith(":root"):
        return TV + s[5:]
    return f"{TV} {s}"


satirlar, sayac = [], 0
for yol in sorted(glob.glob(os.path.join(KOK, "css", "*.css"))):
    if yol.endswith("99-tv-mod.css"):
        continue
    for secici, govde in kurallar(open(yol, encoding="utf-8").read()):
        m = re.findall(r"font-size\s*:\s*([0-9.]+)px", govde)
        if not m or float(m[-1]) >= ESIK:
            continue
        secs = [tv_secici(x) for x in secici.split(",") if x.strip()]
        satirlar.append(f"{','.join(secs)}{{font-size:{ESIK:g}px}}  /* {os.path.basename(yol)}: {m[-1]}px */")
        sayac += 1
html = open(os.path.join(KOK, "index.html"), encoding="utf-8").read()
for b in sorted(set(re.findall(r"font-size:\s*([0-9.]+)px", html)), key=float):
    if float(b) < ESIK:
        satirlar.append(f'{TV} [style*="font-size:{b}px"]{{font-size:{ESIK:g}px!important}}  /* index.html satir ici */')
        sayac += 1
open(CIKTI, "w", encoding="utf-8").write(
    "/* 99-tv-mod.css -- OTOMATIK URETILDI (tools/tv_yazi_uret.py), ELLE DUZENLEME.\n"
    "   TV MODU: 14px'ten kucuk TUM yazilar 14px. Yalniz html[data-cihaz=\"tv\"] iken etkili. */\n"
    + "\n".join(satirlar) + "\n")
print(f"{sayac} kural -> {CIKTI}")
